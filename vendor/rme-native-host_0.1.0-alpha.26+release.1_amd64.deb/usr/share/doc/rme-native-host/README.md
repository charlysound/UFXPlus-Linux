# Common Linux audio exposure

The native RME runtime supplies the device identity, negotiated rate, active
channels and physical mapping. Linux host services consume that same contract;
they do not add another USB model table or another audio owner.

For each admitted native attachment, the audio owner registers a `snd-rme-pcm`
ALSA card and a PipeWire Device. Capture and playback may have different channel
counts. Card numbers may change; use the reported ALSA card ID or stable device
UID. The ALSA card follows the current native session rate: it does not change the
hardware clock when an application requests another rate. Closing the owner
disconnects its card; outstanding ALSA handles retain their buffers until closed.

The PipeWire Device groups the existing stream nodes. Channel labels come from
the common port contract. Names attributed to TotalMix carry their reference
identity in the producer data; a fallback name is not a native parity claim.
Node names remain stable for the same UID and stream topology.

Open the existing **UFX+ USB Settings** launcher (or `rme-driver-panel`), choose
the device, and open **PipeWire Nodes**. Each native device stores its selection
under `$XDG_CONFIG_HOME/rme-native/devices/<sha256-of-UID>/nodes.json` (default
`~/.config`). The schema is `{ "schema": 1, "uid": "…", "enabled": { "node-name": true } }`.
Missing selections default to enabled. Applying a native selection changes only
its PipeWire stream publication; USB audio and its ALSA card stay running.
Disabled nodes disappear from the graph and lose their links. Re-enabling a node
may require reconnecting its links in the patchbay. ALSA continues exposing the
active physical channels; a PipeWire group switch does not renumber ALSA channels.

## Per-card state and settings

The panel and OSCmix consume the same `rme-linux-settings` authority. Open
`rme-driver-panel --uid UID`, or use **Linux Settings** in OSCmix for its selected
card. The status separates ALSA registration, PipeWire publication, MIDI,
requested preferences and acknowledged frontend settings. Unknown values stay
unknown. Process IDs are bound to their start time, parent and USB incarnation;
an old connection cannot authorize a setting on its replacement.

Each native card stores `linux.json` beside `nodes.json`:
`{ "schema": 1, "uid": "…", "revision": 1, "backend": "pipewire+alsa", "buffer_frames": 0 }`.
The common runtime supports **ALSA** and **PipeWire + ALSA**. ALSA alone needs no
PipeWire server. Switching frontends preserves the USB owner, ALSA card and
native configuration. The common host does not add another RME model catalogue.

The buffer control is a **PipeWire stream request**, reused from the UFX+
implementation. A nonzero value requests that stream quantum; Auto releases it.
The update preserves existing node identities and links. It is not a measured
latency or a buffer imposed on ALSA applications: those clients negotiate their
own periods and buffers. In ALSA mode this preference is saved for returning to
PipeWire. The actual quantum is shown only when measured.

The CLI has `status [--uid UID]` and
`apply --uid UID --expected-marker JSON --request JSON`. The marker comes from
the current status; requests can contain `backend`, `buffer_frames` and/or an
`enabled` map of current node names. A successful response requires the owner's
matching acknowledgement, not just a file write. Per-card locks serialize
changes. An uncertain result stays explicit; it never causes an automatic
hardware retry or silent rollback.

The existing UFX+ service retains its transport and its three frontend choices.
The native manager reserves devices already owned by that service. Its adapter
reuses the existing settings transaction and restores only surviving links that
existed before that card's explicit settings change. The panel does not offer
legacy UFX+ clock or digital controls for another device. A metadata update to
the legacy Python supervisor adds process identity and buffer acknowledgement
at its next explicit restart; an already running old supervisor keeps unknown
fields explicit instead of inferring application from saved preferences.

`rme-native-host` installs the independent DKMS module, its access rule, and the
common settings panel. It redirects the original panel and node command launchers
with package-owned `dpkg-divert` entries; removing it restores those launchers.
It does not replace or unload the legacy UFX+ module, binary or user service.
Its two legacy Python metadata files are installed with reversible diversions;
the running supervisor is not restarted by package installation.
Install the matching OSCmix runtime bundle for the native audio owner. First
module loading and native-service activation are explicit installation steps;
later boots load the independent module through modules-load.d.

This Linux adaptation is separate from the native driver/TotalMix reconstruction.
Automatic exposure applies to devices admitted by the existing native profile
and transport checks. It does not establish untested hardware support or fill in
unported native DSP, clock, or startup-restoration behavior.

The common code uses Linux, ALSA, PipeWire and XDG interfaces. The `.deb` and
portable FHS archive share their payload; distribution/kernel preflight and
installation details are in [rme-portable-host.md](rme-portable-host.md).
These adapters do not claim qualification on Fedora or other distributions.

## Frontend recovery and diagnostic lifetime

A failed PipeWire connection is recovered inside its existing audio owner. The
Bridge, kernel ALSA card, direct PCM endpoint, MIDI and native USB worker remain
owned; no native initialization or rate operation is replayed. Only the failed
PipeWire Core/Device/streams are released and rebuilt using the same UID, active
format, node selection and Linux preferences. Node identities/links can change
after a server loss. No link to an unrelated endpoint is invented.

The additive `RME_LINUX_RECOVERY` event contains schema1, uid,
connection_generation, format_generation, state (`waiting`, `recovered`, `error`),
attempt, reason and usb_restarted:false. The launcher publishes it as
owner.recovery and the manager as row.recovery. During waiting/error,
row.status is `recovering`, ALSA and the complete connection marker remain
available, PipeWire is unavailable and settings mutations are refused. A mixer
consumer may retain its control/levels owner when the markers are unchanged.
Neither audio generation nor format generation advances for frontend recovery.

There are at most three frontend attempts per observed PipeWire socket
incarnation, with bounded backoff. A new server socket permits a new frontend
attempt budget. A positive Device/node binding, settings acknowledgement and
recovered event are required before running is published again. Startup without
the selected PipeWire server also retains ALSA while waiting. Native callback or
USB faults keep their existing stop behavior; an uncertain frontend removal is
latched and never replayed automatically. An explicit saved ALSA-only selection
can be consumed without a PipeWire connection.

Continuous session/MIDI logs retain bounded tails with discarded-character
counters. An exited MIDI child loses readiness and reports an error independently
of the audio owner; an absent or externally owned MIDI interface stays explicit.
The manager verifies the actual launcher/audio process identities before using a
ready snapshot. These are Linux lifecycle policies, not new native RME commands.

`rme-linux-settings diagnose [--uid UID]` exposes the same validated session as
status, with per-component session/ALSA/PipeWire/MIDI/settings checks, requested
and acknowledged values, recovery/rate transitions and complete identity marker.
ALSA-only is reported as PipeWire not requested; absent/external MIDI remains
distinct from a dead MIDI owner. Unknown timing measurements stay null. This
command is read-only and never sends a rate, mixer, reset or initialization write.

## Bounded graph snapshots

The host package includes `rme-pw-graph`,a short-lived,read-only registry reader
used by the existing route-preservation code. It projects only Client/Node/Port/
Link identity and endpoint fields,not arbitrary audio parameters. An unrelated
client's malformed `audio.position` therefore cannot corrupt JSON serialization
or require disabling that client. Required identities are still strict;unknown,
conflicting or incomplete endpoint data refuses the whole snapshot.

Registry removal/reuse and late info are generation-bound. The initial registry
and bound info must reach an unchanged core-sync barrier within two seconds.
Object/event/field/output memory bounds apply. The reader creates no stream,
link,device,audio owner,application thread,poller or persistent catalogue;normal connection
and proxy cleanup do not destroy server globals. PipeWire socket identity,
UID/format authority and link restoration guards remain in `linux_control`.

The host manifest declares `graph_snapshot_abi:1` and the helper hash. Build it
alongside the other release artifacts before making the DEB/portable package:

```sh
cargo build --release -p ufxplus-daemon --bin rme-pw-graph
```

Older payloads without this helper keep their strict `pw-dump` compatibility
path. An installed helper that fails,times out or returns incompatible data
does **not** fall back or authorize a partial graph. Diagnostics contain current
port names,process IDs and device identities;keep captures private when needed.
The isolated integration test reproduces malformed global `pw-dump` output and
checks the real native-reader → Python-route-consumer path,three independent
node owners,link endpoints,removal/reuse and preservation of unrelated owners.
# Readable device and connector names

The native host keeps its stable `RME…` kernel card IDs and existing `hw:`
addresses. It additionally publishes selectable ALSA PCM/control aliases such
as `rme_fireface_ufx_plus_<stable-id>`, with the model, channel counts and active
rate in the ALSA device hint. The suffix distinguishes identical units and does
not depend on the card index. `rme-alsa-names --enable` links the generated view
from an absent `~/.asoundrc`,using the standard ALSA user include. It refuses to
overwrite any custom ALSA configuration;such users must merge/include the view
explicitly. `rme-alsa-names` refreshes the view from the admitted current status;
it does not open audio or change device settings. The manager refreshes only
changed bytes. A missing runtime view after logout is an optional ALSA include,
not a new default PCM or hardware owner.

PipeWire/JACK descriptions include the model, unit ID and Inputs/Outputs.
Ports identify their packed PCM index and physical connector, for example
`09 Mic/Inst 9`, `09 Phones 9` or `23 ADAT 9`. Physical numbering follows the
native stream layout at the current rate; inactive channels are not invented.
The console's native labels and the wire/DSP coordinates are unchanged.

The raw ALSA kernel ABI does not carry arbitrary physical channel strings:
DAWs using `hw:` directly may still show numeric channels. Use PipeWire/JACK
for the physical port labels, or the DAW's own channel-name editor.

Existing technical node names and numeric object paths remain stable, but the
human-readable PipeWire port names change. Active routes are restored by native
coordinates during the qualified local update. Third-party saved patchbays that
key only on the old display strings may require selecting the new port once.
