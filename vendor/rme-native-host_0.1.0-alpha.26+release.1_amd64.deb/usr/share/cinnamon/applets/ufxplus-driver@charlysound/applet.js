const Applet = imports.ui.applet;
const Mainloop = imports.mainloop;
const Util = imports.misc.util;

// Read-only indicator; all settings belong to RME USB Settings.
class UfxplusApplet extends Applet.TextIconApplet {
    constructor(orientation, panelHeight, instanceId) {
        super(orientation, panelHeight, instanceId);
        this.set_applet_icon_symbolic_name("audio-card-symbolic");
        this.set_applet_label("RME");
        this.set_applet_tooltip("Open RME USB Settings");
        this._alive = true;
        this._busy = false;
        this._settingsOnly = true;
        this._data = null;
        this.refresh();
        this._timer = Mainloop.timeout_add_seconds(3, () => {
            if (!this._alive) return false;
            this.refresh();
            return true;
        });
    }

    _openSettings() {
        // Resolve selection in the panel, never from an old status snapshot.
        if (this._alive) Util.spawn(["rme-driver-panel"]);
    }
    on_applet_clicked() { this._openSettings(); }
    _onButtonPressEvent(actor, event) {
        if (event.get_button() === 3) {
            if (this._applet_enabled) this._openSettings();
            return true;
        }
        return super._onButtonPressEvent(actor, event);
    }
    _unavailable(error) {
        this._data = null;
        this.set_applet_label("RME ?");
        this.set_applet_tooltip("Driver status unavailable" + (error ? "\n" + error : "") + "\nOpen RME USB Settings");
    }
    refresh() {
        if (!this._alive || this._busy) return;
        this._busy = true;
        try {
            Util.spawnCommandLineAsyncIO(null, (stdout, stderr, code) => {
                this._busy = false;
                if (!this._alive) return;
                try {
                    const data = JSON.parse(stdout || "");
                    if (code !== 0 || !data || data.ok !== true)
                        throw Error((data && data.error) || stderr || "No valid driver status");
                    this._data = data;
                    const model = data.model || "RME";
                    const rate = Number.isFinite(data.sample_rate) && data.sample_rate > 0 ? data.sample_rate / 1000 : null;
                    const buffer = data.buffer_frames;
                    this.set_applet_label(model + (rate !== null ? " " + rate + "k" : " …"));
                    const lines = [model, "State: " + (data.state || "unavailable"),
                        "Sample rate: " + (rate !== null ? rate + " kHz" : "unavailable"),
                        "Audio buffer: " + (Number.isInteger(buffer) && buffer > 0 ? buffer + " samples" : buffer === 0 ? "Auto" : "unavailable"),
                        "Clock source: " + (data.clock_source || "unavailable")];
                    if (data.failure_reason || data.error) lines.push(data.failure_reason || data.error);
                    lines.push("Open RME USB Settings");
                    this.set_applet_tooltip(lines.join("\n"));
                } catch (error) { this._unavailable(String(error)); }
            }, {argv:["rme-driver-applet", "status"]});
        } catch (error) {
            this._busy = false;
            if (this._alive) this._unavailable(String(error));
        }
    }
    on_applet_removed_from_panel() {
        this._alive = false;
        if (this._timer) Mainloop.source_remove(this._timer);
    }
}
function main(metadata, orientation, panelHeight, instanceId) {
    return new UfxplusApplet(orientation, panelHeight, instanceId);
}
