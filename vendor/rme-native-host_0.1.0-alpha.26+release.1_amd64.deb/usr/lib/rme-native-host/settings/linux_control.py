#!/usr/bin/python3
"""Common per-UID Linux state and acknowledged settings. No USB commands here."""
import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import selectors
import stat
import subprocess
import sys
import tempfile
import time

import backend_control
import buffer_control
import node_control
import runtime_state
import settings_control
import secrets
import capabilities
import rate_control
import owner_policy
import hardware_control
import category_nodes
import software_effects_control

PROC = Path('/proc')
ASOUND = PROC / 'asound'
NATIVE_PCM = Path('/dev/rme-pcm')
BACKENDS = ('alsa', 'pipewire+alsa')
SIZES = tuple(buffer_control.SIZES)
U64_MAX = 2**64 - 1
PW_DUMP_LIMIT = 8_000_000
PW_DUMP_TIMEOUT = 3
PW_GRAPH_HELPER = Path(__file__).resolve().parent.parent / 'rme-pw-graph'
PW_GRAPH_TYPES = {'PipeWire:Interface:' + kind for kind in ('Node', 'Port', 'Link', 'Client')}
PW_GRAPH_NUMBERS = {'client.id', 'node.id', 'port.id'}
PW_GRAPH_STRINGS = {'application.process.id', 'node.name', 'port.name', 'port.direction'}
PW_GRAPH_KEYS = dict(Node={'object.serial','client.id','node.name','application.process.id'},
                     Port={'object.serial','node.id','port.id','port.name','port.direction'},
                     Client={'object.serial','application.process.id'},Link={'object.serial'})


class ControlError(RuntimeError):
    def __init__(self, code, message, uncertain=False):
        super().__init__(message)
        self.code, self.uncertain = code, uncertain


def uid_check(uid):
    if not isinstance(uid, str) or not uid.startswith('rme:') or not 0 < len(uid) <= 512 or '\0' in uid:
        raise ControlError('invalid', 'Invalid RME device identity')
    return uid


def read_json(path, *, private=False, limit=2_000_000):
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC), 'r') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o022 or (private and info.st_mode & 0o777 != 0o600):
            raise ControlError('unavailable', 'Settings/status file has an invalid owner or mode')
        text = stream.read(limit + 1)
    if len(text) > limit:
        raise ControlError('invalid', 'Settings/status file is too large')
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ControlError('invalid', 'Invalid settings/status object')
    return value


def process_identity(pid, expected, parent=None):
    if type(pid) is not int or pid <= 0 or not isinstance(expected, str) or not expected.isdecimal():
        raise ControlError('stale', 'Process identity is missing')
    try:
        directory = PROC / str(pid)
        if directory.stat().st_uid != os.getuid():
            raise ControlError('stale', 'Process belongs to another user')
        fields = (directory / 'stat').read_text().rsplit(')', 1)[1].split()
        if fields[0] == 'Z' or fields[19] != expected or (parent is not None and int(fields[1]) != parent):
            raise ControlError('stale', 'Process identity changed')
        return expected
    except (OSError, ValueError, IndexError) as error:
        raise ControlError('stale', 'Process is no longer available') from error


def snapshot():
    try:
        value = read_json(node_control.native_status_path(), private=True)
        if (type(value.get('schema')) is not int or value['schema'] != 1 or value.get('closing')
                or value.get('inventory_error') or not isinstance(value.get('devices'), list)
                or any(not isinstance(r, dict) for r in value['devices'])
                or not isinstance(value.get('manager_nonce'), str) or not value['manager_nonce']):
            raise ControlError('unavailable', 'RME device inventory is unavailable')
        process_identity(value.get('manager_pid'), value.get('manager_process_start'))
        return value
    except (OSError, ValueError, TypeError) as error:
        raise ControlError('unavailable', 'RME device manager status is unavailable') from error


def config_path(uid):
    return node_control.native_config_path(uid_check(uid)).with_name('linux.json')


def validate_settings(value, uid):
    if (not isinstance(value, dict) or set(value) != {'schema', 'uid', 'revision', 'backend', 'buffer_frames'}
            or type(value.get('schema')) is not int or value['schema'] != 1 or value.get('uid') != uid
            or type(value.get('revision')) is not int or not 0 <= value['revision'] <= U64_MAX
            or value.get('backend') not in BACKENDS or type(value.get('buffer_frames')) is not int
            or value['buffer_frames'] not in SIZES):
        raise ControlError('invalid', 'Invalid saved Linux audio settings')
    return value


def read_settings(uid):
    try:
        return validate_settings(read_json(config_path(uid)), uid)
    except FileNotFoundError:
        return dict(schema=1, uid=uid, revision=0, backend='pipewire+alsa', buffer_frames=0)


def read_nodes(uid):
    try:
        return node_control.native_validate(read_json(node_control.native_config_path(uid)), uid)
    except FileNotFoundError:
        return dict(schema=1, uid=uid, enabled={})


def read_nodes_snapshot(uid):
    path = node_control.native_config_path(uid)
    try:
        with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC), 'rb') as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o022:
                raise ControlError('invalid', 'Invalid node selection file owner or mode')
            raw = stream.read(131073)
        if len(raw) > 131072: raise ControlError('invalid', 'Node selection file is too large')
        value = node_control.native_validate(json.loads(raw), uid)
    except FileNotFoundError:
        value, raw = dict(schema=1, uid=uid, enabled={}), b''
    return value, hashlib.sha256(raw).hexdigest()


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(value, stream, separators=(',', ':'))
            stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def backup_legacy_nodes(uid, expected_hash):
    """Retain the exact V1 bytes and their digest before an explicit V2 save."""
    path = node_control.native_config_path(uid)
    try:
        with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC),'rb') as stream:
            raw = stream.read(131073)
    except FileNotFoundError:
        if expected_hash != hashlib.sha256(b'').hexdigest(): raise ControlError('stale','Node preferences changed before migration')
        return
    if hashlib.sha256(raw).hexdigest() != expected_hash: raise ControlError('stale','Node preferences changed before migration')
    if json.loads(raw).get('schema') != 1: return
    backup = path.with_name('nodes-v1-' + expected_hash + '.json')
    try:
        fd = os.open(backup,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    except FileExistsError:
        with os.fdopen(os.open(backup,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC),'rb') as stream:
            if stream.read(131073) != raw: raise ControlError('invalid','Legacy node backup does not match its digest')
    else:
        with os.fdopen(fd,'wb') as stream: stream.write(raw);stream.flush();os.fsync(stream.fileno())


def _base(snapshot, record):
    uid = uid_check(record.get('uid'))
    generation, attachment = record.get('generation'), record.get('attachment')
    if type(generation) is not int or generation <= 0 or not isinstance(attachment, dict):
        raise ControlError('stale', 'RME connection identity is incomplete')
    marker = {key: snapshot[key] for key in ('manager_pid', 'manager_process_start', 'manager_nonce')}
    marker.update(generation=generation, attachment=attachment)
    return dict(schema=1, uid=uid, model=record.get('model') or 'RME', state=record.get('status') or 'unavailable',
                rate=None, capture_channels=None, playback_channels=None,
                alsa=dict(ready=False, card_index=None, card_id=None, rate=None, capture_channels=None, playback_channels=None),
                pipewire=dict(ready=False, device_id=None, nodes=[], rate=None, backend=None),
                midi=dict(ready=False, state='unavailable', ports=None), settings=None, applied=None,
                marker=marker, settings_capabilities=dict(backends=list(BACKENDS), buffer_frames=list(SIZES)),
                nodes=[], can_apply=False, error=record.get('reason'), native=True,
                channel_map=None, rate_capabilities=None, rate_change=record.get('rate_change'), pcm_clients=None,recovery=record.get('recovery'),owner_change=record.get('owner_change'),hardware_change=record.get('hardware_change'),hardware_settings=None,
                manager_capabilities=snapshot.get('manager_capabilities') if hardware_control.loaded_abi2(snapshot) else None)


def _plans(audio, uid):
    if type(audio.get('pipewire_nodes_abi')) is int and audio['pipewire_nodes_abi'] == 2:
        categories = category_nodes.catalog(audio, uid)
        plans = audio.get('nodes')
        if (not isinstance(plans, list) or len(plans) != len(categories)
                or any(not isinstance(p, dict) for p in plans)
                or len({p.get('name') for p in plans}) != len(plans)
                or {(p.get('category'), p.get('name')) for p in plans}
                != {(p['category'], p['name']) for p in categories}):
            raise ControlError('invalid', 'Category audio plans differ from the loaded catalog')
        return categories
    plans = audio.get('nodes')
    if not isinstance(plans, list) or not plans:
        raise ControlError('unavailable', 'Audio channel inventory is unavailable')
    names = set()
    for p in plans:
        if (not isinstance(p, dict) or not isinstance(p.get('name'), str) or p['name'] in names
                or not p['name'].startswith('rme.' + uid.encode().hex() + '.')
                or p.get('direction') not in ('Capture', 'Playback')
                or type(p.get('channels')) is not int or not 0 < p['channels'] <= 256):
            raise ControlError('invalid', 'Invalid audio channel inventory')
        names.add(p['name'])
    return plans


def _kernel(metadata, uid, audio):
    if (not isinstance(metadata, dict) or metadata.get('uid') != uid or metadata.get('schema') != 1
            or metadata.get('generation') != audio.get('connection_generation')
            or metadata.get('rate') != audio.get('rate')
            or type(metadata.get('card_index')) is not int or metadata['card_index'] < 0
            or not isinstance(metadata.get('card_id'), str) or not metadata['card_id']):
        raise ControlError('unavailable', 'ALSA kernel registration is unavailable')
    for key, field in (('capture_channels', 'capture_names'), ('playback_channels', 'playback_names')):
        if (type(metadata.get(key)) is not int or not 0 < metadata[key] <= 256
                or not isinstance(audio.get(field), list) or len(audio[field]) != metadata[key]):
            raise ControlError('stale', 'ALSA and USB channel geometry disagree')
    try:
        if (ASOUND / ('card' + str(metadata['card_index'])) / 'id').read_text().strip() != metadata['card_id']:
            raise ControlError('stale', 'ALSA card identity changed')
    except OSError as error:
        raise ControlError('unavailable', 'ALSA kernel card is no longer present') from error
    return dict(ready=True, **{k: metadata[k] for k in ('card_index', 'card_id', 'rate', 'capture_channels', 'playback_channels')})


def _admitted_audio(snapshot, record, result):
    uid, owner = result['uid'], record.get('owner') or {}
    if (owner.get('uid') != uid or owner.get('attachment') != record['attachment']
            or not node_control.native_attachment_current(record['attachment'])):
        raise ControlError('stale', 'RME attachment changed')
    pid, start = owner.get('pid'), owner.get('process_start')
    if pid != record.get('pid') or start != record.get('process_start'):
        raise ControlError('stale', 'RME launcher identity changed')
    process_identity(pid, start, snapshot['manager_pid'])
    worker = (owner.get('workers') or {}).get('audio') or {}
    process_identity(worker.get('pid'), worker.get('process_start'), pid)
    result['marker'].update(owner_pid=pid, owner_process_start=start,
                            worker_pid=worker['pid'], worker_process_start=worker['process_start'])
    audio = owner.get('audio') or {}
    if (audio.get('uid') != uid or type(audio.get('rate')) is not int or audio['rate'] <= 0
            or type(audio.get('connection_generation')) is not int or audio['connection_generation'] <= 0
            or type(audio.get('format_generation')) is not int or not 0 < audio['format_generation'] <= U64_MAX):
        raise ControlError('unavailable', 'USB audio session metadata is unavailable')
    result['marker']['audio_generation'] = audio['connection_generation']
    result['marker']['audio_format_generation'] = audio['format_generation']
    return owner, audio


def _software_effects(audio, uid):
    return software_effects_control.validate_metadata(audio.get('software_effects'), uid,
        audio['connection_generation'], audio['format_generation'], audio['rate'])


def software_effects_authority(uid):
    """Loaded audio authority only: filesystem/process checks, no USB/subprocess."""
    uid_check(uid)
    value = snapshot()
    records = [r for r in value['devices'] if r.get('uid') == uid]
    if len(records) != 1:
        raise ControlError('unavailable', 'Software effects device is disconnected or ambiguous')
    record = records[0]
    phase = (record.get('owner_change') or {}).get('phase')
    if (record.get('external_supervisor') or record.get('status') not in ('running', 'recovering')
            or phase in ('waiting_legacy', 'starting', 'restoring_links', 'rolling_back')):
        raise ControlError('unavailable', 'The selected audio owner does not admit software effects')
    result = _base(value, record)
    owner, audio = _admitted_audio(value, record, result)
    _kernel(owner.get('kernel_card'), uid, audio)
    result.update(rate=audio['rate'], software_effects=_software_effects(audio, uid))
    return result


def _native(snapshot, record):
    result = _base(snapshot, record)
    uid, owner = result['uid'], record.get('owner') or {}
    saved_error = None
    try:
        result['settings'] = read_settings(uid)
    except (OSError,ValueError,ControlError) as error:
        saved_error = str(error)
    if record.get('status')=='clock_idle':
        if not node_control.native_attachment_current(record['attachment']):raise ControlError('stale','Idle clock attachment changed')
        token=record.get('hardware_idle_request_id')
        if not isinstance(token,str) or not token:raise ControlError('stale','Idle clock authority is missing')
        result['marker']['hardware_idle_request_id']=token
    if record.get('status') not in ('running','recovering'):
        return result
    owner, audio = _admitted_audio(snapshot, record, result)
    pid = owner['pid']
    transport=owner.get('transport')
    if transport is not None:
        if (not isinstance(transport,dict) or transport.get('schema')!=1 or transport.get('uid')!=uid or
                any(transport.get(k)!=audio.get(k) for k in ('connection_generation','format_generation')) or
                type(transport.get('sequence')) is not int or transport['sequence']<0 or
                transport.get('state') not in ('starting','flowing','recovering','error','stopped')):
            raise ControlError('stale','USB transport health belongs to another audio owner')
        result['transport']=transport
    result['software_effects'] = None
    result['software_effects_error'] = None
    if audio.get('software_effects') is not None:
        try:result['software_effects'] = _software_effects(audio, uid)
        except (software_effects_control.FxError,OSError,ValueError,TypeError) as error:
            result['software_effects_error'] = str(error)
    result['rate_capabilities'] = audio.get('rate_capabilities')
    result['pcm_clients'] = owner.get('pcm_clients')
    recovery=owner.get('recovery')
    if recovery is not None:
        if (not isinstance(recovery,dict) or recovery.get('uid')!=uid or recovery.get('schema')!=1 or recovery.get('usb_restarted') is not False or
                recovery.get('state') not in ('waiting','recovered','error') or any(recovery.get(k)!=audio.get(k) for k in ('connection_generation','format_generation'))):
            raise ControlError('stale','Frontend recovery belongs to another audio session')
        result['recovery']=recovery
    recovering=isinstance(recovery,dict) and recovery.get('state') in ('waiting','error')
    topology=audio.get('topology') or {}
    result['channel_map']={d:[p['native_channel']-1 for p in (topology.get(d) or {}).get('physical_ports',[])] for d in ('capture','playback')} if topology else None
    plans = _plans(audio, uid)
    kernel = _kernel(owner.get('kernel_card'), uid, audio)
    result.update(rate=audio['rate'], capture_channels=kernel['capture_channels'],
                  playback_channels=kernel['playback_channels'], alsa=kernel,
                  display_name=(audio.get('topology') or {}).get('model') or audio.get('model'))
    ack = owner.get('linux_settings')
    if ack is not None:
        if (not isinstance(ack, dict) or ack.get('schema') != 1 or ack.get('uid') != uid
                or ack.get('applied') is not True or type(ack.get('revision')) is not int
                or not 0 <= ack['revision'] <= U64_MAX or ack.get('backend') not in BACKENDS
                or type(ack.get('buffer_frames')) is not int or ack['buffer_frames'] not in SIZES
                or ack.get('connection_generation') != audio['connection_generation']
                or ack.get('format_generation') != audio.get('format_generation')):
            raise ControlError('stale', 'Applied Linux settings belong to another session')
        result['applied'] = ack
    backend = ack.get('backend') if ack else None
    saved = result['settings'] or {}
    failure = owner.get('linux_settings_error') or {}
    refused = failure.get('uid') == uid and failure.get('revision') == saved.get('revision')
    pending = not saved_error and not refused and (ack is None or ack.get('revision') != saved.get('revision'))
    published = owner.get('pipewire')
    abi2 = type(audio.get('pipewire_nodes_abi')) is int and audio['pipewire_nodes_abi'] == 2
    by_name = {}
    if published is not None and (not isinstance(published, dict) or published.get('rate') != audio['rate']
            or type(published.get('device_id')) is not int or not 0 <= published['device_id'] < 2**32-1
            or not isinstance(published.get('nodes'), list)):
        raise ControlError('stale', 'PipeWire publication is incomplete')
    saved_nodes, nodes_hash = read_nodes_snapshot(uid)
    nodes_pending = False
    if abi2:
        categories = category_nodes.catalog(audio, uid)
        selection = category_nodes.normalize(saved_nodes, uid, categories)
        projected, publication_matches = category_nodes.project(categories, selection, published)
        result.update(pipewire_nodes_abi=2, categories=projected, node_selection=selection,
                      node_selection_sha256=nodes_hash, pipewire_node_catalog=categories)
        pending = pending or not ack or ack.get('node_selection_abi') != 2 or ack.get('node_selection_sha256') != nodes_hash
        nodes_pending = backend == 'pipewire+alsa' and not publication_matches
        result['nodes'] = []
    else:
        if saved_nodes.get('schema') != 1:
            raise ControlError('unavailable', 'Loaded worker cannot apply category selections; restart this card with the updated runtime')
        if published is not None:
            for row in published['nodes']:
                if (not isinstance(row, dict) or row.get('name') in by_name or row.get('name') not in {p['name'] for p in plans}
                        or type(row.get('enabled')) is not bool
                        or (row['enabled'] and (type(row.get('id')) is not int or not 0 <= row['id'] < 2**32-1))
                        or (not row['enabled'] and row.get('id') is not None)):
                    raise ControlError('stale', 'PipeWire node publication is incomplete')
                by_name[row['name']] = row
            if len(by_name) != len(plans): raise ControlError('stale', 'PipeWire node publication is incomplete')
        result['nodes'] = [dict(direction='capture' if p['direction'] == 'Capture' else 'playback', index=p['name'],
                                name=p['name'], label=p.get('description') or p['name'], channels=p['channels'],
                                enabled=saved_nodes['enabled'].get(p['name'], True),
                                applied_enabled=by_name.get(p['name'], {}).get('enabled'),
                                present=by_name.get(p['name'], {}).get('id') is not None) for p in plans]
        nodes_pending = backend == 'pipewire+alsa' and any(r['applied_enabled'] != r['enabled'] for r in result['nodes'])
    # A missing frontend does not invalidate the already verified USB owner,
    # kernel card, channel geometry or MIDI. Keep their per-card status visible
    # while refusing settings changes until PipeWire has a coherent state.
    frontend_error = None
    if not pending and not recovering and backend == 'pipewire+alsa' and published is None:
        frontend_error = failure.get('error') or 'PipeWire device is not ready'
    if not pending and backend == 'alsa' and published is not None:
        frontend_error = 'PipeWire device removal has not completed'
    result['pipewire'] = dict(ready=published is not None, device_id=published.get('device_id') if published else None,
                              nodes=published['nodes'] if published else [], rate=audio['rate'] if published else None, backend=backend,
                              state='recovering' if recovering else 'ready' if published else
                                    'not_requested' if backend == 'alsa' else 'unavailable',
                              error=frontend_error)
    midi = owner.get('midi') or {}
    midi_worker = (owner.get('workers') or {}).get('midi') or {}
    if midi.get('status') == 'ready' and midi_worker:
        try:
            process_identity(midi_worker.get('pid'), midi_worker.get('process_start'), pid)
            midi_current = True
        except ControlError:
            midi_current = False
        ports = midi.get('ports')
        if ports is None:
            ready = midi.get('ready') or {}
            ports = ready.get('ports') if isinstance(ready, dict) else None
        ready = midi.get('ready') or {}
        capture_ports, playback_ports = ready.get('capture_ports'), ready.get('playback_ports')
        if type(capture_ports) is int and type(playback_ports) is int and min(capture_ports,playback_ports) >= 0:
            ports = max(capture_ports,playback_ports)
        result['midi'] = dict(ready=midi_current, state='ready' if midi_current else 'unavailable', ports=ports if midi_current and type(ports) is int else None,
                              capture_ports=capture_ports,playback_ports=playback_ports)
    else:
        result['midi'] = dict(ready=False, state=midi.get('status') or 'unavailable', ports=None)
    result['settings_error'] = owner.get('linux_settings_error')
    transport_pending=transport is not None and transport['state']!='flowing'
    result.update(state='recovering' if recovering or transport_pending else 'running', can_apply=not recovering and not transport_pending and not saved_error and not pending and not nodes_pending and not frontend_error,
                  settings_state='invalid' if saved_error else 'pending' if pending or nodes_pending else 'refused' if refused else 'applied',
                  error=saved_error or (recovery.get('reason') if recovering else
                      'Native USB transport is '+transport['state'] if transport_pending else frontend_error))
    return result


def _legacy_midi():
    try:
        text=subprocess.check_output(['systemctl','--user','show','ufxplus-midi.service',
                                      '--property=ActiveState','--property=MainPID'],text=True,timeout=2)
        properties=dict(line.split('=',1) for line in text.splitlines() if '=' in line)
        if properties.get('ActiveState')!='active':
            return dict(ready=False,state=properties.get('ActiveState','unavailable'),ports=None)
        pid=int(properties['MainPID'])
        fields=(PROC/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
        if (PROC/str(pid)/'cmdline').read_bytes().split(b'\0')[0]!=b'/usr/bin/ufxplus-midi':
            raise ValueError('Unknown legacy MIDI process')
        process_identity(pid,fields[19])
        text=(ASOUND/'seq/clients').read_text()
        import re
        blocks=re.split(r'(?m)^Client ',text)
        matches=[b for b in blocks if '"RME Fireface UFX+ MIDI"' in b.split('\n',1)[0]]
        if len(matches)!=1:raise ValueError('Legacy MIDI ALSA client unavailable')
        ports=len(re.findall(r'(?m)^\s+Port\s+\d+',matches[0]))
        return dict(ready=ports>0,state='ready' if ports else 'starting',ports=ports or None,pid=pid,process_start=fields[19])
    except (OSError,ValueError,KeyError,IndexError,subprocess.SubprocessError):
        return dict(ready=False,state='unavailable',ports=None)


def _read_pw_dump():
    return _read_graph_child(['pw-dump'])


def _read_graph_child(command, *, strict=False):
    """Bound both the child lifetime and captured bytes, including updates."""
    child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    deadline=time.monotonic()+PW_DUMP_TIMEOUT
    data=bytearray()
    try:
        with selectors.DefaultSelector() as reader:
            reader.register(child.stdout,selectors.EVENT_READ)
            while True:
                remaining=deadline-time.monotonic()
                if remaining<=0 or not reader.select(remaining):
                    raise subprocess.TimeoutExpired(command,PW_DUMP_TIMEOUT)
                chunk=os.read(child.stdout.fileno(),min(65536,PW_DUMP_LIMIT+1-len(data)))
                if not chunk:break
                data.extend(chunk)
                if len(data)>PW_DUMP_LIMIT:
                    raise ControlError('unavailable','PipeWire graph is too large')
        if child.wait(timeout=max(0.001,deadline-time.monotonic())):
            raise ControlError('unavailable','PipeWire graph could not be read')
        # Some PipeWire clients publish legacy-encoded descriptive strings.
        # Keep numeric graph identities and valid native UID metadata usable;
        # the JSON/identity validators below still reject malformed structure.
        return data.decode('utf-8', errors='strict' if strict else 'replace')
    except BaseException:
        if child.poll() is None:child.kill()
        child.wait()
        raise
    finally:
        child.stdout.close()


def _parse_pw_dump(text):
    """Fold every JSON array in a finite pw-dump stream into its final graph.

    Updates are sparse: missing fields retain their previous value, object
    fields merge, arrays replace, and null fields are removed. info:null is
    the object-removal event, so a subsequently reused ID starts empty.
    """
    if not isinstance(text,str) or len(text.encode('utf-8'))>PW_DUMP_LIMIT:
        raise ControlError('unavailable','PipeWire graph is too large or invalid')
    def merge(before,patch,depth=0):
        if depth>64:raise ControlError('unavailable','PipeWire graph nesting is too deep')
        result=dict(before) if isinstance(before,dict) else {}
        for key,value in patch.items():
            if value is None:result.pop(key,None)
            elif isinstance(value,dict):result[key]=merge(result.get(key),value,depth+1)
            else:result[key]=value
        return result
    def invalid_constant(value):
        raise ValueError('Invalid JSON constant '+value)
    decoder=json.JSONDecoder(parse_constant=invalid_constant)
    position=0;objects={};batches=0
    try:
        while position<len(text):
            while position<len(text) and text[position].isspace():position+=1
            if position==len(text):break
            batch,position=decoder.raw_decode(text,position)
            if not isinstance(batch,list):raise ValueError('Expected a PipeWire object array')
            batches+=1
            for update in batch:
                if (not isinstance(update,dict) or type(update.get('id')) is not int
                        or not 0<=update['id']<2**32-1):
                    raise ValueError('Invalid PipeWire object identity')
                identifier=update['id']
                if 'info' in update and update['info'] is None:
                    objects.pop(identifier,None)
                    continue
                old=objects.get(identifier,{})
                if 'type' in update and update['type']!=old.get('type'):
                    old={}
                objects[identifier]=merge(old,update)
        if not batches:raise ValueError('Empty PipeWire dump')
    except (ValueError,RecursionError) as error:
        raise ControlError('unavailable','Invalid or incomplete PipeWire graph stream') from error
    return list(objects.values())


def _parse_native_graph(text):
    """Validate the entire ABI1 projection before a route can use any row.

    No malformed-object skipping,raw JSON fragments,unknown identity coercion
    or fallback to pw-dump after an installed native reader failed.
    """
    def unique(pairs):
        result={}
        for key,value in pairs:
            if key in result:raise ValueError('Duplicate graph JSON key')
            result[key]=value
        return result
    def invalid_constant(value):raise ValueError('Invalid JSON constant '+value)
    def integer(value,limit=2**32-1):return type(value) is int and 0<=value<limit
    try:
        if not isinstance(text,str) or len(text.encode('utf-8'))>PW_DUMP_LIMIT:raise ValueError('Graph byte limit')
        value=json.loads(text,object_pairs_hook=unique,parse_constant=invalid_constant)
        if (not isinstance(value,dict) or set(value)!={'schema','objects'} or
                type(value['schema']) is not int or value['schema']!=1 or
                not isinstance(value['objects'],list) or len(value['objects'])>16384):
            raise ValueError('Unknown native graph ABI')
        rows={}
        ends={'output-node-id','output-port-id','input-node-id','input-port-id'}
        for row in value['objects']:
            if (not isinstance(row,dict) or set(row)!={'id','type','info'} or
                    not integer(row['id']) or row['id'] in rows or row['type'] not in PW_GRAPH_TYPES or
                    not isinstance(row['info'],dict)):
                raise ValueError('Invalid graph object identity')
            kind=row['type'].rsplit(':',1)[-1];info=row['info']
            if set(info)!=({'props'}|ends if kind=='Link' else {'props'}):raise ValueError('Unexpected graph info fields')
            props=info['props']
            if not isinstance(props,dict) or set(props)-PW_GRAPH_KEYS[kind]:
                raise ValueError('Unexpected graph properties')
            if not integer(props.get('object.serial'),2**64):raise ValueError('Missing graph object serial')
            for key,item in props.items():
                if key in PW_GRAPH_NUMBERS and not integer(item):raise ValueError('Invalid graph object reference')
                if key in PW_GRAPH_STRINGS and (not isinstance(item,str) or len(item.encode('utf-8'))>8192):
                    raise ValueError('Invalid graph text identity')
            if kind=='Node' and not props.get('node.name'):raise ValueError('Missing graph node name')
            if kind=='Port' and (not integer(props.get('node.id')) or not props.get('port.name') or props.get('port.direction') not in ('in','out')):
                raise ValueError('Missing graph port identity')
            if kind=='Link' and any(not integer(info[k]) for k in ends):raise ValueError('Invalid graph link endpoint')
            rows[row['id']]=row
        for row in rows.values():
            kind=row['type'].rsplit(':',1)[-1];info=row['info'];props=info['props']
            if kind=='Port' and (rows.get(props['node.id']) or {}).get('type')!='PipeWire:Interface:Node':
                raise ValueError('Graph port parent missing')
            if kind=='Link':
                for bank,direction in (('output','out'),('input','in')):
                    port=rows.get(info[bank+'-port-id']) or {}
                    p=(port.get('info') or {}).get('props') or {}
                    if (port.get('type')!='PipeWire:Interface:Port' or p.get('node.id')!=info[bank+'-node-id'] or p.get('port.direction')!=direction):
                        raise ValueError('Graph link endpoint changed')
        return list(rows.values())
    except (ValueError,TypeError,KeyError,RecursionError,UnicodeError) as error:
        raise ControlError('unavailable','Invalid or incomplete native PipeWire graph') from error


def _pw_snapshot():
    if not PW_GRAPH_HELPER.exists():
        return _parse_pw_dump(_read_pw_dump())  # Compatibility with older payloads only.
    if not PW_GRAPH_HELPER.is_file() or not os.access(PW_GRAPH_HELPER,os.X_OK):
        raise ControlError('unavailable','Native PipeWire graph reader is not executable')
    try:
        return _parse_native_graph(_read_graph_child([str(PW_GRAPH_HELPER)],strict=True))
    except UnicodeError as error:
        raise ControlError('unavailable','Native PipeWire graph reader returned invalid UTF-8') from error


def _legacy_pw_names(worker):
    dump = _pw_snapshot()
    clients={str(r['id']) for r in dump if isinstance(r,dict) and
             r.get('type')=='PipeWire:Interface:Client' and
             str((r.get('info',{}).get('props') or {}).get('application.process.id'))==str(worker)}
    names=set()
    for row in dump:
        if not isinstance(row,dict) or row.get('type')!='PipeWire:Interface:Node':continue
        props=row.get('info',{}).get('props') or {}
        if (str(props.get('client.id')) in clients or str(props.get('application.process.id'))==str(worker)):
            name=props.get('node.name')
            if isinstance(name,str):names.add(name)
    return names


def _legacy(snapshot, record):
    result = _base(snapshot, record)
    result['native'] = False
    result['settings_capabilities']['backends'] = list(backend_control.BACKENDS)
    session = runtime_state.read()
    supervisor = record.get('external_supervisor') or {}
    if not session or session.get('pid') != supervisor.get('pid') or session.get('process_start') != supervisor.get('process_start'):
        raise ControlError('stale', 'Historical UFX+ owner is unavailable or changed')
    process_identity(session['pid'], session['process_start'])
    if not node_control.native_attachment_current(record['attachment']):
        raise ControlError('stale', 'UFX+ attachment changed')
    result['settings'] = dict(backend=backend_control.read(), buffer_frames=buffer_control.read())
    result['state'] = session.get('state', 'unavailable')
    result['marker'].update(owner_pid=session['pid'], owner_process_start=session['process_start'],
                            session=session.get('session'), invocation=session.get('invocation'))
    if session.get('state') != 'running':
        return result
    worker = session.get('worker_pid')
    start = session.get('worker_process_start')
    if start is None:
        # Compatibility with the running historical supervisor: verify the
        # live child relationship and stable /proc identity, never PID alone.
        try:
            start = (PROC / str(worker) / 'stat').read_text().rsplit(')', 1)[1].split()[19]
        except (OSError, IndexError) as error:
            raise ControlError('stale', 'Historical audio worker is unavailable') from error
    command = (PROC / str(worker) / 'cmdline').read_bytes().split(b'\0')[0]
    if command not in (b'/usr/bin/ufxplus-live-capture', b'/usr/bin/ufxplus-alsa-server'):
        raise ControlError('stale', 'Historical audio worker identity is unknown')
    process_identity(worker, start, session['pid'])
    if runtime_state.read() != session:
        raise ControlError('stale', 'Historical audio session changed while reading')
    result['marker'].update(worker_pid=worker, worker_process_start=start)
    rate = session.get('rate_hz')
    if type(rate) is not int or rate not in (44100,48000,88200,96000,176400,192000):
        raise ControlError('unavailable', 'Historical stream rate is unknown')
    result['rate_capabilities'] = capabilities.DATA.get('rate_capabilities')
    formats = (result['rate_capabilities'] or {}).get('formats', [])
    active = next((f for f in formats if f.get('rate') == rate), None)
    # Older installations retain their previous read-only inventory. Changes
    # require the generated native format contract below.
    if active:
        result['channel_map'] = {d:active.get(d+'_native_channels', []) for d in ('capture','playback')}
    count = active['capture_channels'] if active else 94 if rate <= 48000 else 54 if rate <= 96000 else 34
    backend = session.get('backend')
    if backend not in backend_control.BACKENDS:
        raise ControlError('unavailable', 'Historical backend is unknown')
    executable = b'/usr/bin/ufxplus-alsa-server' if backend == 'alsa' else b'/usr/bin/ufxplus-live-capture'
    if command != executable:
        raise ControlError('stale', 'Historical backend and live worker executable disagree')
    card = ASOUND / 'UFXPlus'
    try:
        kernel = (card / 'id').read_text().strip() == 'UFXPlus'
    except OSError:
        kernel = False
    try:
        kernel = kernel and any(path.readlink() == Path('/dev/ufxplus-pcm') for path in (PROC/str(worker)/'fd').iterdir())
    except OSError:
        kernel = False
    try:
        index = int(card.resolve().name.removeprefix('card')) if kernel else None
    except ValueError:
        index = None
    result.update(rate=rate, capture_channels=count, playback_channels=count,
                  alsa=dict(ready=kernel and backend != 'pipewire', card_id='UFXPlus' if kernel else None,
                            card_index=index,rate=rate,capture_channels=count,playback_channels=count))
    names = None
    try:
        names = _legacy_pw_names(worker)
    except (OSError,ValueError,TypeError,ControlError,subprocess.SubprocessError):
        pass
    if backend == 'alsa':
        if names:
            raise ControlError('stale', 'ALSA-only worker unexpectedly publishes PipeWire nodes')
        # This positively identified executable only creates the direct ALSA
        # frontend. A PipeWire server is not needed to prove its non-usage.
        names = set()
    nodes = node_control.inventory(node_control.read(), rate, names)
    result['nodes'] = [dict(r,applied_enabled=(r['present'] if names is not None else None)) for r in nodes]
    result['pipewire'] = dict(ready=backend != 'alsa' and names is not None and any(r['present'] for r in nodes),
                              device_id=None,nodes=nodes,rate=rate if backend != 'alsa' else None,backend=backend,
                              state='not_requested' if backend == 'alsa' else 'ready' if names is not None else 'unavailable',
                              source='validated_alsa_worker' if backend == 'alsa' else 'worker_owned_pipewire_nodes')
    result['applied'] = dict(backend=backend,buffer_frames=session.get('buffer_frames'),
                             applied=True,source='historical_owner',buffer_scope='pipewire_stream',
                             buffer_active=backend!='alsa',observed_quantum_frames=None)
    result['midi'] = _legacy_midi()
    result.update(state='running',can_apply=True,error=None)
    return result


def status(uid=None):
    value = snapshot()
    records = value['devices']
    if len({r.get('uid') for r in records}) != len(records):
        raise ControlError('unavailable', 'Ambiguous device inventory')
    if uid is not None:
        uid_check(uid)
        records = [r for r in records if r.get('uid') == uid]
        if len(records) != 1:
            if uid in value.get('device_errors',{}):raise ControlError('unavailable','Device discovery failed: '+str(value['device_errors'][uid]))
            raise ControlError('unavailable', 'Selected RME device is disconnected')
    results = []
    for record in records:
        try:
            item = _legacy(value,record) if record.get('external_supervisor') else _native(value,record)
        except (ControlError,OSError,ValueError,TypeError,KeyError,AttributeError) as error:
            item = _base(value,record)
            if record.get('external_supervisor'):
                item['native'] = False
                item['settings_capabilities']['backends'] = list(backend_control.BACKENDS)
            item.update(state='unavailable',error=str(error),can_apply=False)
        if item.get('state') in ('running','recovering'):
            try:
                marker=item['marker']
                process_identity(marker['owner_pid'],marker['owner_process_start'])
                process_identity(marker['worker_pid'],marker['worker_process_start'],marker['owner_pid'])
                if not node_control.native_attachment_current(marker['attachment']):
                    raise ControlError('stale','Attachment changed while reading Linux state')
            except (ControlError,OSError,ValueError,KeyError) as error:
                item.update(state='unavailable',can_apply=False,error=str(error))
        transition=record.get('owner_change') or {}
        if record.get('status') in ('owner_changing','migration_blocked') or transition.get('phase') in ('waiting_legacy','starting','restoring_links','rolling_back'):
            item.update(state='migration_blocked' if record.get('status')=='migration_blocked' else 'owner_changing',can_apply=False,
                        error=transition.get('error') or record.get('reason'))
        if item.get('native') and item.get('state') in ('running','recovering','clock_idle'):
            try:
                hardware=hardware_control.read_current(item['uid'],item['marker']['attachment'],value)
                if not node_control.native_attachment_current(item['marker']['attachment']):raise ControlError('stale','Attachment changed during hardware readback')
                if hardware is not None:
                    for key in ('can_set_clock','can_set_digital'):
                        hardware['fields'][key]=bool(hardware['fields'].get(key) and (item['state']=='clock_idle' or item.get('can_apply')))
                    if item['state']=='clock_idle' and hardware.get('native_domain')!=hardware_control.DANTE_DOMAIN:
                        hardware['fields']['can_set_digital']=False
                        if hardware.get('schema')==2:
                            hardware['fields']['digital_reason']='Audio is stopped; confirm Internal clock before Digital I/O changes.'
                    if hardware.get('schema')==2:
                        admission=hardware['manager_admission']
                        admission['can_apply']=bool(hardware['fields']['can_set_clock'] or hardware['fields']['can_set_digital'])
                        if not admission['can_apply'] and not admission.get('reason'):
                            admission['reason']=hardware['fields'].get('clock_source_reason') or 'The selected card session is not ready for hardware changes.'
                        if not (item['state']=='clock_idle' or item.get('can_apply')):
                            for key in ('clock_source_reason','digital_reason'):
                                hardware['fields'][key]=hardware['fields'].get(key) or admission['reason']
                    item['hardware_settings']=hardware
            except (RuntimeError,OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError) as error:
                item['hardware_settings_error']=str(error)
        results.append(item)
    # Recheck the manager after reading its children and frontend metadata.
    process_identity(value['manager_pid'], value['manager_process_start'])
    return results[0] if uid is not None else dict(schema=1, devices=results,device_errors=value.get('device_errors',{}))


@contextmanager
def transaction(uid):
    path = config_path(uid).with_name('linux.lock')
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    fd = os.open(path,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    try:
        info = os.fstat(fd)
        if info.st_uid != os.getuid() or info.st_mode & 0o777 != 0o600:
            raise ControlError('invalid','Invalid settings transaction lock')
        try:
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ControlError('busy','Another settings change is in progress for this card') from error
        yield
    finally:
        os.close(fd)


def request_check(request, current):
    if not isinstance(request,dict) or not request or set(request)-{'backend','buffer_frames','enabled','node_selection','expected_revision'}:
        raise ControlError('invalid','Expected backend, buffer_frames or enabled settings')
    if 'node_selection' in request:
        if (current.get('pipewire_nodes_abi') != 2 or not current.get('native') or 'enabled' in request
                or type(request.get('expected_revision')) is not int
                or request['expected_revision'] != (current.get('settings') or {}).get('revision')):
            raise ControlError('stale','Category selection requires the current loaded ABI and Linux revision')
        try: category_nodes.validate(request['node_selection'],current['uid'],current['pipewire_node_catalog'])
        except ValueError as error: raise ControlError('invalid',str(error)) from error
    elif 'expected_revision' in request:
        raise ControlError('invalid','Expected revision requires a category selection')
    if 'backend' in request and request['backend'] not in current['settings_capabilities']['backends']:
        raise ControlError('invalid','Unsupported backend for this card')
    if 'buffer_frames' in request and (type(request['buffer_frames']) is not int or request['buffer_frames'] not in SIZES):
        raise ControlError('invalid','Unsupported buffer request')
    if 'enabled' in request:
        enabled = request['enabled']; names = {r['name'] for r in current['nodes']}
        if not isinstance(enabled,dict) or any(name not in names or type(v) is not bool for name,v in enabled.items()):
            raise ControlError('invalid','Invalid or inactive node selection')


def _acknowledged(current, settings, enabled, node_hash=None):
    applied = current.get('applied') or {}
    if any(applied.get(k) != settings.get(k) for k in ('revision','backend','buffer_frames')):
        return False
    if current.get('pipewire_nodes_abi') == 2:
        return (applied.get('node_selection_abi') == 2 and
                applied.get('node_selection_sha256') == current.get('node_selection_sha256') == node_hash and
                current.get('settings_state') == 'applied' and
                (applied.get('backend') != 'alsa' or not current['pipewire']['ready']))
    if applied.get('backend') == 'alsa':
        return not current['pipewire']['ready']
    return all(r['applied_enabled'] == enabled.get(r['name'],True) and r['present'] == enabled.get(r['name'],True)
               for r in current['nodes'])


def apply(uid, expected_marker, request, *, timeout=8, interval=0.1):
    uid_check(uid)
    if not isinstance(expected_marker,dict):
        raise ControlError('invalid','A current connection marker is required')
    with transaction(uid):
        current = status(uid)
        if current['marker'] != expected_marker:
            raise ControlError('stale','The card connection changed. Refresh before applying.')
        if not current['can_apply'] or current['state'] != 'running':
            pending=current.get('settings_state')=='pending'
            raise ControlError('busy' if pending else 'unavailable',current.get('error') or
                               ('A settings change is waiting for its audio-owner acknowledgement' if pending else 'Selected card is not ready'))
        request_check(request,current)
        if not current['native']:
            return _apply_legacy(uid,current,request,timeout,interval)
        settings = dict(current['settings'])
        if settings['revision'] == U64_MAX:
            raise ControlError('invalid','Linux settings revision exhausted')
        settings.update({k:v for k,v in request.items() if k not in ('enabled','expected_revision','node_selection')})
        settings['revision'] += 1
        nodes, old_nodes_hash = read_nodes_snapshot(uid)
        if 'node_selection' in request:
            nodes = category_nodes.merge(nodes,request['node_selection'],uid,current['pipewire_node_catalog'])
        elif nodes['schema'] == 1:
            nodes['enabled'].update(request.get('enabled',{}))
        wanted_nodes_hash = (hashlib.sha256((json.dumps(nodes,separators=(',',':'))+'\n').encode()).hexdigest()
                             if 'enabled' in request or 'node_selection' in request else old_nodes_hash)
        changed = False
        try:
            # Validate the whole request before either file changes. If a later
            # step fails, retain explicit uncertainty instead of silent rollback.
            validate_settings(settings,uid)
            node_control.native_validate(nodes,uid)
            if 'node_selection' in request and current.get('node_selection',{}).get('schema') == 2:
                backup_legacy_nodes(uid,old_nodes_hash)
            if 'enabled' in request or 'node_selection' in request:
                atomic_json(node_control.native_config_path(uid),nodes); changed=True
            atomic_json(config_path(uid),settings); changed=True
            deadline = time.monotonic()+timeout
            while True:
                observed = status(uid)
                if observed.get('marker') != expected_marker or observed.get('state') != 'running':
                    raise ControlError('stale','Card changed before settings acknowledgement',True)
                failure = observed.get('settings_error') or {}
                if failure.get('uid') == uid and failure.get('revision') == settings['revision']:
                    raise ControlError('uncertain',failure.get('error') or 'Owner refused Linux settings',True)
                if _acknowledged(observed,settings,nodes.get('enabled',{}),wanted_nodes_hash):
                    return dict(ok=True,**observed)
                if time.monotonic() >= deadline:
                    raise ControlError('uncertain','Settings saved, but the audio owner did not confirm them. Refresh before retrying.',True)
                time.sleep(interval)
        except (OSError,ValueError,ControlError) as error:
            if changed and not getattr(error,'uncertain',False):
                raise ControlError('uncertain',str(error)+' Saved settings may be partially applied; no automatic rollback.',True) from error
            raise


def rate_format(current, hz):
    """Admission and geometry are exported by the native producer, not inferred."""
    value = current.get('rate_capabilities')
    if (not isinstance(value, dict) or value.get('policy') not in ('native_format_change', 'verify_only')
            or not isinstance(value.get('rates'), list) or not isinstance(value.get('formats'), list)):
        raise ControlError('unavailable', 'This audio owner does not publish its native rate capabilities')
    rates = value['rates']
    if any(type(n) is not int or n <= 0 for n in rates) or len(set(rates)) != len(rates):
        raise ControlError('unavailable', 'Invalid native rate capabilities')
    if type(hz) is not int or hz not in rates:
        raise ControlError('invalid', 'Choose a frequency admitted by this interface and its current native mode')
    if value['policy'] == 'verify_only' and hz != current.get('rate'):
        raise ControlError('invalid', 'This interface follows its native clock; a different rate cannot be selected')
    matches = [f for f in value['formats'] if isinstance(f, dict) and f.get('rate') == hz]
    if len(matches) != 1 or any(type(matches[0].get(k)) is not int or not 0 < matches[0][k] <= 512
                               for k in ('capture_channels', 'playback_channels')):
        raise ControlError('unavailable', 'Native channel geometry is not confirmed for this frequency')
    return matches[0]


def _ensure_rate_clients_closed(current):
    alsa = current.get('alsa') or {}
    if alsa.get('ready'):
        index = alsa.get('card_index')
        if type(index) is not int or index < 0:
            raise ControlError('unavailable', 'Selected ALSA card identity is unavailable')
        path = ASOUND / ('card' + str(index))
        if (path / 'id').read_text().strip() != alsa.get('card_id'):
            raise ControlError('stale', 'Selected ALSA card changed')
        for state in path.glob('pcm*/sub*/status'):
            if state.read_text().strip() != 'closed':
                raise ControlError('busy', 'Close the selected card in ALSA applications before changing its frequency')
    if current.get('native'):
        clients = current.get('pcm_clients')
        if (not isinstance(clients, dict) or clients.get('uid') != current['uid']
                or clients.get('connection_generation') != current['marker'].get('audio_generation')
                or type(clients.get('clients')) is not int or clients['clients'] < 0):
            raise ControlError('unavailable', 'The audio owner has not confirmed its PCM client state')
        if clients['clients']:
            raise ControlError('busy', 'Close the selected card in ALSA applications before changing its frequency')
    else:
        try:owner_policy.legacy_clients_closed(settings_control.ensure_alsa_clients_closed,PROC)
        except ValueError as error:raise ControlError('busy',str(error)) from error


def change_rate(uid, expected_marker, hz, *, timeout=45, interval=0.2, force_same_rate=False):
    """One explicit rate transition; never write a persistent auto-retry policy."""
    uid_check(uid)
    # The native network clock is not a UFX DDS/source action. Reuse its
    # semantic owner for both visible sample-rate selectors and CLI callers.
    if not force_same_rate:
        current=status(uid);hardware=current.get('hardware_settings') or {}
        if hardware.get('native_domain')==hardware_control.DANTE_DOMAIN:
            rates=(hardware.get('native_capabilities') or {}).get('network_rates') or []
            if type(hz) is not int or hz not in rates:raise ControlError('invalid','Rate is outside the native network menu')
            return hardware_control.change(uid,expected_marker,'digital',snapshot=hardware['fields']['digital'],changes={'network_rate':rates.index(hz)},timeout=timeout,interval=interval)
    with transaction(uid):
        current = status(uid)
        if not isinstance(expected_marker, dict) or current['marker'] != expected_marker:
            raise ControlError('stale', 'The card connection changed. Refresh before applying.')
        if current['state'] != 'running' or not current['can_apply']:
            raise ControlError('busy', current.get('error') or 'The selected card is not ready for a frequency change')
        target = rate_format(current, hz)
        if force_same_rate and (not current.get('native') or current['rate'] != hz):
            raise ControlError('stale', 'Targeted reload requires the same current native audio rate')
        if current['rate'] == hz and not force_same_rate:
            return dict(ok=True, unchanged=True, **current)
        _ensure_rate_clients_closed(current)
        if not current.get('native'):
            return _change_rate_legacy(current, target, timeout, interval)
        saved_links = _capture_legacy_links(current)
        if status(uid)['marker'] != expected_marker:
            raise ControlError('stale','The card changed while capturing its audio routes')
        request_id = secrets.token_hex(16)
        directory = node_control.native_status_path().parent / 'rate-requests'
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        info = directory.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ControlError('unavailable', 'The rate request directory is not private')
        path = directory / (hashlib.sha256(uid.encode()).hexdigest() + '.json')
        request = dict(schema=1, uid=uid, request_id=request_id, expected=expected_marker,
                       requested_rate_hz=hz)
        atomic_json(path, request)
        deadline = time.monotonic() + timeout
        while True:
            try:
                observed = status(uid)
            except (OSError, ValueError, ControlError) as error:
                raise ControlError('uncertain', 'Frequency request sent, but its current session cannot be validated: ' + str(error), True) from error
            marker, ack = observed['marker'], observed.get('rate_change') or {}
            if any(marker.get(k) != expected_marker.get(k) for k in
                   ('manager_pid', 'manager_process_start', 'manager_nonce', 'attachment')):
                raise ControlError('stale', 'The card or its manager changed during the frequency transition', True)
            ours = ack.get('request_id') == request_id
            if marker.get('generation') != expected_marker['generation'] and not ours:
                raise ControlError('stale', 'Another session replaced the requested frequency transition', True)
            if ours and ack.get('phase') == 'error':
                raise ControlError('uncertain' if ack.get('uncertain', True) else 'busy',
                                   ack.get('error') or 'The native frequency change failed', ack.get('uncertain', True))
            if (ours and ack.get('phase') == 'applied' and ack.get('from_generation') == expected_marker['generation']
                    and ack.get('to_generation') == marker.get('generation')
                    and ack.get('observed_rate_hz') == hz and observed['state'] == 'running' and observed['can_apply']):
                _rate_result(observed, target)
                restored = _restore_legacy_links(saved_links, observed, allow_retired=True)
                if status(uid)['marker'] != marker:
                    raise ControlError('stale','The card changed while restoring its audio routes',True)
                return dict(ok=True, restored_links=restored, **observed)
            if time.monotonic() >= deadline:
                raise ControlError('uncertain', 'The native owner did not confirm the new frequency. Refresh before retrying.', True)
            time.sleep(interval)


def reload_native_owner(uid, expected_marker, *, timeout=45, interval=0.2):
    """Explicit same-rate native format cycle; no cold prefix or manager restart.

    Mixer cache/save and its restored-model ACK stay with the OSCmix UID owner,
    as for the existing format-change action. This helper attests only Linux
    identity/rate/frontend/link completion, never a saved or restored scene.
    """
    current = status(uid)
    if not current.get('native') or current.get('marker') != expected_marker:
        raise ControlError('stale', 'Reload requires the current native owner identity')
    result = change_rate(uid, expected_marker, current['rate'], timeout=timeout,
                         interval=interval, force_same_rate=True)
    result['reloaded'] = True
    result['mixer_restoration'] = 'oscmix_uid_owner_reconnect'
    return result


def _rate_result(observed, target):
    backend = (observed.get('applied') or {}).get('backend')
    if (observed.get('rate') != target['rate']
            or any(observed.get(k) != target[k] for k in ('capture_channels', 'playback_channels'))
            or (backend != 'pipewire' and not observed.get('alsa', {}).get('ready'))
            or (backend != 'alsa' and not observed.get('pipewire', {}).get('ready'))):
        raise ControlError('uncertain', 'The native rate, active channels and Linux frontends do not agree', True)


def _change_rate_legacy(current, target, timeout, interval):
    uid, expected = current['uid'], current['marker']
    saved_links = None
    def before_change():
        nonlocal saved_links
        fresh = status(uid)
        if fresh['marker'] != expected or not fresh['can_apply']:
            raise ControlError('stale', 'The UFX+ session changed before its frequency transaction')
        _ensure_rate_clients_closed(fresh)
        saved_links = _capture_legacy_links(fresh)
    # Reuse the existing guarded hardware command, readback, startup preference
    # and service transaction; its native cleanup and error policy stay intact.
    try:
        rate_control.change(target['rate'], before_change=before_change, expected_binding=dict(uid=uid, **expected['attachment']))
    except Exception as error:
        if getattr(error,'uncertain',False):
            raise ControlError('uncertain', str(error), True) from error
        raise
    try:
        deadline = time.monotonic() + timeout
        while True:
            observed = status(uid)
            marker = observed['marker']
            if any(marker.get(k) != expected.get(k) for k in
                   ('manager_pid', 'manager_process_start', 'manager_nonce', 'generation', 'attachment')):
                raise ControlError('stale', 'UFX+ disconnected or its manager changed during the frequency transaction', True)
            backend = (observed.get('applied') or {}).get('backend')
            frontends = ((backend == 'pipewire' or observed.get('alsa', {}).get('ready'))
                         and (backend == 'alsa' or (observed.get('pipewire', {}).get('ready')
                              and all(r['present'] is r['enabled'] for r in observed['nodes']))))
            if observed['state'] == 'running' and observed.get('rate') == target['rate'] and frontends:
                _rate_result(observed, target)
                if marker.get('worker_pid') == expected.get('worker_pid') and marker.get('worker_process_start') == expected.get('worker_process_start'):
                    raise ControlError('uncertain', 'The previous UFX+ worker has not stopped', True)
                try:
                    process_identity(expected['worker_pid'],expected['worker_process_start'])
                except ControlError:
                    pass
                else:
                    raise ControlError('uncertain', 'The previous UFX+ audio worker is still alive', True)
                links = _restore_legacy_links(saved_links, observed, allow_retired=True)
                final = status(uid)
                if final['marker'] != marker or final['state'] != 'running':
                    raise ControlError('stale', 'UFX+ changed while its previous routes were restored', True)
                return dict(ok=True, links=links, **final)
            if time.monotonic() >= deadline:
                raise ControlError('uncertain', 'UFX+ did not confirm its new frequency and active channels', True)
            time.sleep(interval)

    except Exception as error:
        if getattr(error, 'uncertain', False):
            raise
        raise ControlError('uncertain', 'The UFX+ frequency was applied, but its current session or routes cannot be confirmed: ' + str(error), True) from error


def _pw_socket_marker():
    remote=os.environ.get('PIPEWIRE_REMOTE','pipewire-0')
    if not remote or Path(remote).name!=remote:
        raise ControlError('unavailable','Cannot preserve routes on an unknown PipeWire remote')
    root=Path(os.environ.get('PIPEWIRE_RUNTIME_DIR') or os.environ.get('XDG_RUNTIME_DIR',''))
    path=root/remote
    info=path.stat()
    if not stat.S_ISSOCK(info.st_mode) or info.st_uid!=os.getuid():
        raise ControlError('unavailable','PipeWire socket identity is unavailable')
    return (str(path),info.st_dev,info.st_ino,info.st_ctime_ns)


def _pw_graph():
    value=_pw_snapshot()
    nodes={};ports={};links=set()
    for row in value:
        if not isinstance(row,dict):continue
        info=row.get('info') or {};props=info.get('props') or {}
        kind=row.get('type','').rsplit(':',1)[-1]
        if kind=='Node' and isinstance(props.get('node.name'),str):
            nodes[row['id']]=dict(id=row['id'],name=props['node.name'],serial=props.get('object.serial'))
        elif kind=='Port' and isinstance(props.get('port.name'),str):
            index=props.get('port.id')
            if isinstance(index,str) and index.isdecimal():index=int(index)
            if type(index) is not int or not 0 <= index < 512:index=None
            ports[row['id']]=dict(id=row['id'],node=int(props['node.id']),name=props['port.name'],
                                  direction=props.get('port.direction'),serial=props.get('object.serial'),
                                  channel_index=index)
        elif kind=='Link':
            output=info.get('output-port-id',props.get('link.output.port'))
            input_=info.get('input-port-id',props.get('link.input.port'))
            if output is not None and input_ is not None:links.add((int(output),int(input_)))
    return nodes,ports,links


def _link_projection(current, nodes, ports):
    """Join real graph IDs to stable native physical coordinates, never names alone.

    V1 stream ranges use channel_map; V2 uses the already-validated category
    publication. No graph objects, aliases or endpoint identities are created.
    """
    rows = current.get('categories', []) if current.get('pipewire_nodes_abi') == 2 else current['nodes']
    own = {r['name'] for r in rows}
    by_id, expected, known = {}, set(), set()
    if not current.get('native'):
        return own, by_id, expected, known
    if current.get('pipewire_nodes_abi') == 2:
        for row in rows:
            for bank, direction in (('capture', 'out'), ('playback', 'in')):
                for p in row[bank]:
                    key = (bank, p['native_channel'])
                    known.add(key)
                    if not (row['enabled'] and p['available'] and p['selected']): continue
                    expected.add(key)
                    port = ports.get(p.get('port_id'))
                    node = nodes.get(port['node']) if port else None
                    if (not p.get('present') or port is None or node is None
                            or node['id'] != row['node_id'] or node['name'] != row['name']
                            or port['direction'] != direction or port['name'] != bank+'_'+str(key[1])):
                        raise ControlError('stale', 'Category port identity changed while preserving routes')
                    by_id[port['id']] = key
    else:
        for bank, direction in (('capture', 'out'), ('playback', 'in')):
            mapping = (current.get('channel_map') or {}).get(bank)
            if not isinstance(mapping, list): raise ControlError('unavailable', 'Native route coordinates are unavailable')
            first = 0
            for row in (r for r in rows if r['direction'] == bank):
                count = row['channels']
                if type(count) is not int or count <= 0 or first+count > len(mapping):
                    raise ControlError('invalid', 'Native node range differs from physical geometry')
                coordinates = [(bank, c+1) for c in mapping[first:first+count]]
                known.update(coordinates)
                if row['enabled']:
                    expected.update(coordinates)
                    for port in ports.values():
                        node = nodes.get(port['node'])
                        if not node or node['name'] != row['name'] or port['direction'] != direction: continue
                        index = port.get('channel_index')
                        if type(index) is not int or not 0 <= index < count:
                            raise ControlError('unavailable', 'Native graph port has no physical coordinate')
                        by_id[port['id']] = coordinates[index]
                first += count
            if first != len(mapping): raise ControlError('invalid', 'Native node ranges do not cover PCM geometry')
    if len(set(by_id.values())) != len(by_id):
        raise ControlError('stale', 'Native route coordinate has multiple graph ports')
    return own, by_id, expected, known


def _capture_legacy_links(current):
    """Shared link snapshot for the historical and common Linux owners."""
    if (current.get('applied') or {}).get('backend')=='alsa':return None
    marker=_pw_socket_marker()
    nodes,ports,links=_pw_graph()
    own, coordinates, _, _ = _link_projection(current, nodes, ports)
    result=[]
    for output,input_ in links:
        pair=[ports.get(output),ports.get(input_)]
        if any(p is None or p['node'] not in nodes for p in pair):continue
        if not any(nodes[p['node']]['name'] in own for p in pair):continue
        endpoints=[]
        for port in pair:
            node=nodes[port['node']]
            native=node['name'] in own
            if not native and (port['serial'] is None or node['serial'] is None):
                raise ControlError('unavailable','Cannot identify an existing UFX+ route endpoint safely')
            endpoints.append(dict(node=node['name'],port=port['name'],direction=port['direction'],native=native,
                                  node_id=node['id'],node_serial=node['serial'],port_id=port['id'],port_serial=port['serial']))
            if native and current.get('native'):
                key = coordinates.get(port['id'])
                if key is None: raise ControlError('unavailable','Cannot preserve an unbound native route')
                endpoints[-1].update(native_direction=key[0], native_channel=key[1])
            if native and type(port.get('channel_index')) is int:
                endpoints[-1]['channel_index']=port['channel_index']
        result.append(endpoints)
    if _pw_socket_marker()!=marker:raise ControlError('stale','PipeWire restarted while reading UFX+ routes')
    return dict(marker=marker,links=result)


def _restore_legacy_links(saved,current,allow_retired=False):
    if saved is None:return dict(restored=0,retained=0,removed_by_request=0)
    if (current.get('applied') or {}).get('backend')=='alsa':
        return dict(restored=0,retained=0,removed_by_request=len(saved['links']))
    # A persisted snapshot returns its tuple as a JSON list. Preserve the
    # exact four-part authority check across that representation change.
    marker=saved.get('marker')
    if (not isinstance(marker,(list,tuple)) or len(marker)!=4 or type(marker[0]) is not str
            or any(type(value) is not int for value in marker[1:])):
        raise ControlError('uncertain','Saved PipeWire route identity is invalid',True)
    marker=tuple(marker)
    if _pw_socket_marker()!=marker:
        raise ControlError('uncertain','Audio settings applied, but PipeWire restarted; previous routes were not reconnected',True)
    nodes,ports,links=_pw_graph()
    own, coordinates, selected_coordinates, known_coordinates = _link_projection(current, nodes, ports)
    rows = current.get('categories', []) if current.get('pipewire_nodes_abi') == 2 else current['nodes']
    active={r['name'] for r in rows if r['enabled']}
    canonical={key:ports[identifier] for identifier,key in coordinates.items()}
    expected=[];restored=retained=removed=0
    for pair in saved['links']:
        if allow_retired:
            counts = {r['name']:r.get('channels') for r in rows if r['enabled']}
            def retired(e):
                index=e.get('channel_index')
                if type(index) is not int:
                    suffix = e['port'].rsplit('_AUX',1)
                    index=int(suffix[1]) if len(suffix)==2 and suffix[1].isdecimal() else None
                count = counts.get(e['node'])
                return (e['native'] and 'native_channel' not in e and type(index) is int and index>=0
                        and type(count) is int and index>=count)
            if any(retired(e) for e in pair):
                removed+=1
                continue
        if any(e['native'] and 'native_channel' not in e and e['node'] not in active for e in pair):
            removed+=1;continue
        keys=[]
        for e in pair:
            if e.get('native') and 'native_channel' in e:
                key=(e.get('native_direction'),e['native_channel'])
                if key[0] not in ('capture','playback') or type(key[1]) is not int or not 1<=key[1]<=256:
                    raise ControlError('uncertain','Saved native route coordinate is invalid',True)
                keys.append(key)
        if keys and not current.get('native'):
            raise ControlError('uncertain','Native route cannot be projected onto a historical owner',True)
        if any(k not in selected_coordinates for k in keys):
            if any(k not in known_coordinates for k in keys) and not allow_retired:
                raise ControlError('uncertain','Native physical route disappeared unexpectedly',True)
            removed+=1;continue
        resolved=[]
        for endpoint in pair:
            if endpoint['native'] and 'native_channel' in endpoint:
                port=canonical.get((endpoint['native_direction'],endpoint['native_channel']))
                if port is None or port['direction']!=endpoint['direction']:
                    raise ControlError('uncertain','Native route port is not actually published',True)
                resolved.append(port['id']);continue
            matches=[p for p in ports.values() if p['node'] in nodes and
                     nodes[p['node']]['name']==endpoint['node'] and
                     (p.get('channel_index')==endpoint['channel_index'] if endpoint['native'] and type(endpoint.get('channel_index')) is int else p['name']==endpoint['port']) and
                     p['direction']==endpoint['direction'] and
                     (endpoint['native'] or (nodes[p['node']]['id']==endpoint['node_id'] and
                       nodes[p['node']]['serial']==endpoint['node_serial'] and p['id']==endpoint['port_id'] and p['serial']==endpoint['port_serial']))]
            if len(matches)!=1:
                raise ControlError('uncertain','Audio settings applied, but a previous UFX+ route endpoint disappeared or changed; review the patchbay',True)
            resolved.append(matches[0]['id'])
        link=tuple(resolved);expected.append(link)
        if link in links:retained+=1;continue
        # Only recreate a link that existed before this explicit UFX+ change.
        subprocess.run(['pw-link',str(link[0]),str(link[1])],capture_output=True,text=True,timeout=3,check=True)
        restored+=1
    if expected:
        _,_,actual=_pw_graph()
        if _pw_socket_marker()!=marker or any(link not in actual for link in expected):
            raise ControlError('uncertain','Audio settings applied, but previous UFX+ routes were not confirmed',True)
    return dict(restored=restored,retained=retained,removed_by_request=removed)


def _migration_preflight(uid):
    current=status(uid)
    if current['native'] or current['state']!='running' or not current['can_apply']:
        raise ControlError('busy','The historical owner is not ready for migration')
    session=runtime_state.read()
    if not session or session.get('owner_handoff_abi')!=1:
        raise ControlError('unavailable','The historical supervisor must load the cooperative handoff adapter before migration')
    if current.get('midi',{}).get('ready') and (not hasattr(os,'pidfd_open') or not hasattr(__import__('signal'),'pidfd_send_signal')):
        raise ControlError('unavailable','This Linux/Python cannot safely hand off the existing MIDI process')
    try:kernel_ready=stat.S_ISCHR(NATIVE_PCM.stat().st_mode) and os.access(NATIVE_PCM,os.R_OK|os.W_OK)
    except OSError:kernel_ready=False
    if not kernel_ready:raise ControlError('unavailable','The common ALSA kernel frontend must be available before owner migration')
    _ensure_rate_clients_closed(current)
    backend=current['applied']['backend']
    settings=dict(schema=1,uid=uid,revision=read_settings(uid)['revision']+1,
                  backend='alsa' if backend=='alsa' else 'pipewire+alsa',buffer_frames=current['applied']['buffer_frames'])
    validate_settings(settings,uid)
    links=_capture_legacy_links(current)
    if links and links['links'] and any(not isinstance((current.get('channel_map') or {}).get(d),list) for d in ('capture','playback')):
        raise ControlError('unavailable','Native physical channel coordinates are needed to preserve existing routes')
    if status(uid)['marker']!=current['marker']:raise ControlError('stale','Historical owner changed during migration preflight')
    return dict(ok=True,current=current,settings=settings,legacy_nodes=node_control.read(),links=links)


def _migration_finish(uid,payload):
    """Translate only previously existing routes through physical coordinates."""
    current=status(uid);expected=payload['expected']
    if (current['marker']!=expected or not current['native'] or not current['alsa']['ready'] or
            not current['midi']['ready'] or current.get('settings_state')!='applied' or
            read_settings(uid)!=payload['settings'] or read_nodes(uid)!=payload['nodes'] or
            not _acknowledged(current,payload['settings'],payload['nodes']['enabled'])):
        raise ControlError('stale','New owner changed before route restoration')
    old=payload['previous'];saved=payload['links']
    if saved is None:return dict(ok=True,marker=current['marker'],links=_restore_legacy_links(None,current))
    # Audio metadata is already bound by status() to this UID/process/format.
    inventory=snapshot();row=next(r for r in inventory['devices'] if r['uid']==uid)
    audio=row['owner']['audio'];plans=audio['nodes'];topology=audio['topology']
    nodes,ports,_=_pw_graph()
    import copy
    translated=copy.deepcopy(saved)
    translated['marker']=tuple(translated['marker'])  # JSON transport of the existing server token
    for pair in translated['links']:
        for endpoint in pair:
            if not endpoint['native']:continue
            rows=[r for r in old['nodes'] if r['name']==endpoint['node']]
            suffix=endpoint['port'].rsplit('_AUX',1)
            if len(rows)!=1 or len(suffix)!=2 or not suffix[1].isdecimal():
                raise ControlError('unavailable','Cannot map an old route to a physical channel')
            legacy=rows[0];direction=legacy['direction'];local=int(suffix[1])
            ordered=sorted((r for r in old['nodes'] if r['direction']==direction),key=lambda r:r['index'])
            first=sum(r['channels'] for r in ordered if r['index']<legacy['index'])
            mapping=(old.get('channel_map') or {}).get(direction)
            if not isinstance(mapping,list) or local>=legacy['channels'] or first+local>=len(mapping):
                raise ControlError('unavailable','Previous physical route geometry is unavailable')
            physical=topology[direction]['physical_ports']
            coordinates=[i for i,p in enumerate(physical) if p['native_channel']-1==mapping[first+local]]
            if len(coordinates)!=1:raise ControlError('unavailable','Previous physical route is not active in the new owner')
            index=coordinates[0];matches=[p for p in plans if p['direction'].lower()==direction and p['first_physical_channel']<=index<p['first_physical_channel']+p['channels']]
            if len(matches)!=1:raise ControlError('unavailable','Physical route does not have one native node')
            plan=matches[0];offset=index-plan['first_physical_channel']
            # The common producer gives channels their RME names (AN 1,
            # ADAT 3, ...). PipeWire's direction-local port.id is the channel
            # coordinate; the display label cannot identify an audio slot.
            found=[p for p in ports.values() if p['node'] in nodes and nodes[p['node']]['name']==plan['name'] and p['direction']==endpoint['direction'] and p.get('channel_index')==offset]
            if len(found)!=1:raise ControlError('unavailable','Native physical route port is unavailable or ambiguous')
            endpoint.update(node=plan['name'],port=found[0]['name'],channel_index=offset)
    result=_restore_legacy_links(translated,current)
    if status(uid)['marker']!=expected:raise ControlError('stale','New owner changed while restoring routes',True)
    return dict(ok=True,marker=expected,links=result)


def migrate_owner(uid,expected_marker,target='native',*,timeout=80,interval=0.2):
    """Explicit one-shot handoff; the manager owns drain, admission and rollback."""
    uid_check(uid)
    if target not in ('native','legacy'):raise ControlError('invalid','Unknown Linux owner')
    with transaction(uid):
        current=status(uid)
        if current['marker']!=expected_marker:raise ControlError('stale','The selected session changed before owner migration')
        if target=='native':_migration_preflight(uid)
        elif current['state']!='migration_blocked':raise ControlError('invalid','Legacy recovery is only available for an interrupted handoff')
        request_id=secrets.token_hex(16)
        path=node_control.native_status_path().parent/'owner-requests'/(hashlib.sha256(uid.encode()).hexdigest()+'.json')
        atomic_json(path,dict(schema=1,uid=uid,request_id=request_id,owner=target,expected=expected_marker))
        deadline=time.monotonic()+timeout
        while True:
            try:observed=status(uid)
            except (ControlError,OSError,ValueError,KeyError) as error:
                raise ControlError('uncertain','Owner request was sent, but its current authority is unavailable: '+str(error),True) from error
            marker=observed['marker']
            if any(marker.get(k)!=expected_marker.get(k) for k in ('manager_pid','manager_process_start','manager_nonce','attachment')):
                raise ControlError('stale','The interface or manager changed during owner migration',True)
            change=observed.get('owner_change') or {}
            if change.get('request_id')==request_id:
                if change.get('phase')=='applied' and observed['state']=='running':return dict(ok=True,**observed)
                if change.get('phase')=='error':
                    raise ControlError('migration_failed',change.get('error') or 'Owner migration failed',change.get('uncertain',True))
            if time.monotonic()>=deadline:raise ControlError('uncertain','Owner migration has not been confirmed. Refresh before retrying.',True)
            time.sleep(interval)


def _migration_rollback(uid,payload):
    current=status(uid);old=payload['previous'];expected=old['marker']
    if (current['native'] or current.get('rate')!=old['rate'] or
            any(current['marker'].get(k)!=expected.get(k) for k in ('manager_pid','manager_process_start','manager_nonce','attachment','owner_pid','owner_process_start'))):
        raise ControlError('stale','Historical owner changed before rollback route restoration')
    saved=payload['links']
    if saved is not None:saved=dict(saved,marker=tuple(saved['marker']))
    return dict(ok=True,links=_restore_legacy_links(saved,current))


def _migration_drained(uid):
    current=status(uid)
    if current['native'] or current.get('state') not in ('owner_changing','delegated','migration_blocked'):
        raise ControlError('stale','Historical owner did not delegate the selected attachment')
    _ensure_rate_clients_closed(current)
    return dict(ok=True)


def _apply_legacy(uid,current,request,timeout,interval):
    expected=current['marker']
    changed=False
    saved_links=None
    def preflight():
        nonlocal saved_links
        fresh=status(uid)
        if fresh['marker']!=expected or not fresh['can_apply']:
            raise ControlError('stale','UFX+ session changed before the settings transaction')
        settings_control.ensure_alsa_clients_closed()
        saved_links=_capture_legacy_links(fresh)
    try:
        with settings_control.transaction(preflight):
            process_identity(expected['manager_pid'],expected['manager_process_start'])
            if not node_control.native_attachment_current(expected['attachment']):
                raise ControlError('stale','UFX+ disconnected before settings write')
            if 'backend' in request:
                path=backend_control.config_path();path.parent.mkdir(parents=True,exist_ok=True)
                temporary=None
                try:
                    with tempfile.NamedTemporaryFile(mode='w',dir=path.parent,delete=False) as stream:
                        temporary=Path(stream.name)
                        stream.write(request['backend']+'\n');stream.flush();os.fsync(stream.fileno())
                    os.replace(temporary,path);changed=True
                finally:
                    if temporary is not None:temporary.unlink(missing_ok=True)
            if 'buffer_frames' in request:
                buffer_control.save(request['buffer_frames']);changed=True
            if 'enabled' in request:
                nodes=node_control.read()
                for row in current['nodes']:
                    if row['name'] in request['enabled']:
                        nodes[row['direction']][row['index']]=request['enabled'][row['name']]
                node_control.save(nodes);changed=True
        deadline=time.monotonic()+timeout
        while True:
            observed=status(uid)
            marker=observed['marker']
            if any(marker.get(k)!=expected.get(k) for k in ('manager_pid','manager_process_start','manager_nonce','generation','attachment')):
                raise ControlError('stale','UFX+ attachment changed during restart',True)
            applied=observed.get('applied') or {}
            controls=all(applied.get(k)==v for k,v in request.items() if k!='enabled')
            backend=applied.get('backend')
            nodes=bool(observed['nodes']) and all(row['present'] is
                  (False if backend=='alsa' else row['enabled']) for row in observed['nodes'])
            kernel=backend=='pipewire' or observed.get('alsa',{}).get('ready') is True
            if observed['state']=='running' and controls and nodes and kernel:
                # A restarted direct owner cannot hide a surviving previous
                # worker, even when no PipeWire server is available to query.
                try:
                    process_identity(expected['worker_pid'],expected['worker_process_start'])
                    previous_stopped=False
                except ControlError:
                    previous_stopped=True
                if not previous_stopped:
                    raise ControlError('uncertain','Previous UFX+ audio worker has not stopped; new settings are not confirmed',True)
                restored=_restore_legacy_links(saved_links,observed)
                final=status(uid)
                if final['state']!='running' or final['marker']!=observed['marker']:
                    raise ControlError('stale','UFX+ session changed after route restoration',True)
                return dict(ok=True,links=restored,**final)
            if time.monotonic()>=deadline:
                raise ControlError('uncertain','UFX+ settings saved, but restarted audio was not confirmed',True)
            time.sleep(interval)
    except Exception as error:
        if changed and not getattr(error,'uncertain',False):
            raise ControlError('uncertain',str(error)+' Saved UFX+ settings may be partially applied; no automatic rollback.',True) from error
        if not changed and isinstance(error,RuntimeError) and not isinstance(error,ControlError) and any(word in str(error) for word in ('in progress','in use','transitioning')):
            raise ControlError('busy',str(error)) from error
        raise


def diagnose(uid=None):
    """Explain the existing per-UID observations without probing or changing USB."""
    observed=status(uid)
    devices=[observed] if uid is not None else observed['devices']
    rows=[]
    for current in devices:
        alsa=current.get('alsa') or {};pw=current.get('pipewire') or {};midi=current.get('midi') or {}
        applied=current.get('applied') or {};recovery=current.get('recovery') or {}
        settings=current.get('settings_state','unavailable')
        checks=[dict(component='session',state='ready' if current['state']=='running' else 'waiting' if current['state']=='recovering' else 'unavailable',detail=current.get('error')),
                dict(component='alsa',state='ready' if alsa.get('ready') else 'unavailable',card_id=alsa.get('card_id')),
                dict(component='pipewire',state='not_requested' if applied.get('backend')=='alsa' else 'ready' if pw.get('ready') else 'waiting' if current['state']=='recovering' else 'unavailable',device_id=pw.get('device_id')),
                dict(component='midi',state='ready' if midi.get('ready') else 'not_applicable' if midi.get('state')=='absent' else 'external_owner' if midi.get('state')=='existing_owner' else 'error' if midi.get('state')=='error' else 'unavailable',ports=midi.get('ports')),
                dict(component='settings',state='ready' if settings=='applied' else 'waiting' if settings=='pending' else 'error' if settings in ('invalid','refused') else 'unavailable',detail=current.get('settings_error'))]
        rows.append(dict(uid=current['uid'],model=current.get('model'),native=current.get('native'),
            state=current['state'],marker=current['marker'],rate=current.get('rate'),capture_channels=current.get('capture_channels'),playback_channels=current.get('playback_channels'),
            requested=current.get('settings'),applied=applied,rate_change=current.get('rate_change'),recovery=recovery or None,checks=checks,
            requires_attention=any(check['state'] in ('error','unavailable','waiting') for check in checks),
            measured_quantum_frames=applied.get('observed_quantum_frames')))
    return dict(schema=1,ok=True,read_only=True,hardware_writes=0,devices=rows,device_errors=observed.get('device_errors',{}) if uid is None else {})


def main(argv=None):
    parser=argparse.ArgumentParser(description='RME per-card Linux audio state and acknowledged settings')
    sub=parser.add_subparsers(dest='operation',required=True)
    read=sub.add_parser('status');read.add_argument('--uid')
    diagnostic=sub.add_parser('diagnose');diagnostic.add_argument('--uid')
    change=sub.add_parser('apply');change.add_argument('--uid',required=True)
    change.add_argument('--expected-marker',required=True);change.add_argument('--request',required=True)
    rate=sub.add_parser('rate');rate.add_argument('--uid',required=True)
    rate.add_argument('--expected-marker',required=True);rate.add_argument('--hz',required=True,type=int)
    reload=sub.add_parser('reload');reload.add_argument('--uid',required=True)
    reload.add_argument('--expected-marker',required=True)
    hardware=sub.add_parser('hardware');hardware.add_argument('--uid',required=True);hardware.add_argument('--expected-marker',required=True)
    hardware.add_argument('--request',required=True)
    owner=sub.add_parser('owner');owner.add_argument('--uid',required=True);owner.add_argument('--expected-marker',required=True)
    owner.add_argument('--target',choices=('native','legacy'),default='native')
    for operation in ('handoff-preflight','handoff-finish','handoff-rollback','handoff-drained'):
        internal=sub.add_parser(operation,help=argparse.SUPPRESS);internal.add_argument('--uid',required=True)
    args=parser.parse_args(argv)
    try:
        if args.operation=='status':result=status(args.uid)
        elif args.operation=='diagnose':result=diagnose(args.uid)
        elif args.operation=='rate':result=change_rate(args.uid,json.loads(args.expected_marker),args.hz)
        elif args.operation=='reload':result=reload_native_owner(args.uid,json.loads(args.expected_marker))
        elif args.operation=='hardware':
            request=json.loads(args.request)
            if not isinstance(request,dict) or request.get('operation') not in ('clock_source','digital'):raise ControlError('invalid','Expected a semantic hardware operation')
            result=hardware_control.change(args.uid,json.loads(args.expected_marker),**request)
        elif args.operation=='owner':result=migrate_owner(args.uid,json.loads(args.expected_marker),args.target)
        elif args.operation=='handoff-preflight':result=_migration_preflight(args.uid)
        elif args.operation=='handoff-drained':result=_migration_drained(args.uid)
        elif args.operation in ('handoff-finish','handoff-rollback'):
            payload=sys.stdin.read(1048577)
            if len(payload)>1048576:raise ControlError('invalid','Handoff route data is too large')
            operation=_migration_finish if args.operation=='handoff-finish' else _migration_rollback
            result=operation(args.uid,json.loads(payload))
        else:result=apply(args.uid,json.loads(args.expected_marker),json.loads(args.request))
    except (RuntimeError,OSError,ValueError,TypeError,KeyError,AttributeError,subprocess.SubprocessError) as error:
        result=dict(ok=False,code=getattr(error,'code','unavailable'),error=str(error),uncertain=getattr(error,'uncertain',False))
    print(json.dumps(result,separators=(',',':')))
    return 1 if result.get('ok') is False else 0


if __name__=='__main__':
    raise SystemExit(main())
