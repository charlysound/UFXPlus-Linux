#!/usr/bin/python3
"""Read-only desktop status; bounded status/revision reads, never USB writes."""
import json
from pathlib import Path
import re
import subprocess
import time
import buffer_control
import capabilities
import node_control
import startup_rate
import digital_control
import runtime_state
import backend_control

INPUT_NAMES = ("Word Clock", "AES", "ADAT 1", "ADAT 2", "MADI optical", "MADI coaxial")


class ModuloErrorCounter:
    """One bounded observation context; no USB access or invented lifetime total.

    Settings3.39 6764 accumulates the low-five-bit counter and subtracts its
    first value. As there too, multiple complete wraps between observations
    cannot be recovered. Missing/foreign observations start a new baseline.
    """
    def __init__(self):
        self.context = None
        self.last = None
        self.total = 0

    def observe(self, context, value):
        if context is None or type(value) is not int or not 0 <= value < 32:
            self.context, self.last, self.total = None, None, 0
            return None
        if context != self.context or self.last is None:
            self.context, self.last, self.total = context, value, 0
        else:
            self.total += (value - self.last) & 31
            self.last = value
        return self.total


def hardware_fields_v2(hardware, *, capabilities, clock_sources):
    """Native semantic facts, with no permission inferred from wire codes."""
    import clock_control
    labels = {} if clock_sources==[] and capabilities.get('clock_source_write') is False else dict(clock_control.source_choices(clock_sources))
    if not isinstance(hardware, dict):
        raise ValueError('Native clock status unavailable')
    clock = hardware.get('clock')
    if not isinstance(clock, dict) or hardware.get('input_transport') not in ('Bulk', 'Isochronous'):
        raise ValueError('Incomplete native clock status')
    for field in ('selected_source_id', 'current_source_id'):
        value = clock.get(field)
        if value is not None and (type(value) is not int or value not in labels):
            raise ValueError('Invalid native clock source ID')
    if (any(clock.get(field) not in ('internal', 'external', 'unknown') for field in ('selected_kind', 'current_kind')) or
            not isinstance(clock.get('current_source'), str) or not clock['current_source'] or
            ('current_internal_confirmed' in clock and type(clock['current_internal_confirmed']) is not bool) or
            (clock.get('native_selector') is not None and
             (type(clock['native_selector']) is not int or not 0 <= clock['native_selector'] <= 65535))):
        raise ValueError('Invalid native clock semantics')
    for field in ('reference_nominal_rate_hz', 'reference_selected_rate_hz'):
        hz = clock.get(field)
        if hz is not None and (type(hz) is not int or not 0 < hz <= 1000000):
            raise ValueError('Invalid native reference rate')
    inputs = hardware.get('inputs')
    if not isinstance(inputs, list) or len(inputs) > 64:
        raise ValueError('Native input clock inventory unavailable')
    ids = set()
    for row in inputs:
        if (not isinstance(row, dict) or type(row.get('id')) is not int or not 0 <= row['id'] <= 65535 or row['id'] in ids or
                not isinstance(row.get('label'), str) or not row['label'] or len(row['label']) > 256 or
                row.get('state') not in ('No Lock', 'Lock', 'Sync', 'Unknown') or
                (row.get('carrier_rate_hz') is not None and
                 (type(row['carrier_rate_hz']) is not int or not 0 < row['carrier_rate_hz'] <= 1000000)) or
                (row.get('format') is not None and not isinstance(row['format'], str))):
            raise ValueError('Invalid native input clock status')
        ids.add(row['id'])
    return dict(clock_source=clock['current_source'], selected_clock_source_id=clock['selected_source_id'],
                selected_clock_source=labels.get(clock['selected_source_id']), current_kind=clock['current_kind'],
                current_internal_confirmed=clock.get('current_internal_confirmed'),
                selected_kind=clock['selected_kind'], internal_rate_hz=clock['reference_nominal_rate_hz'],
                reference_selected_rate_hz=clock['reference_selected_rate_hz'], sample_rate=None,
                input_lock_sync=[dict(row, name=row['label'], carrier_rate_hz=None if row['state'] in ('No Lock', 'Unknown')
                                      else row.get('carrier_rate_hz')) for row in inputs],
                input_transport=hardware['input_transport'], clock_sources=clock_sources,
                hardware_status_available=True, can_set_clock=False, can_set_digital=False, can_set_rate=False,
                rate_source='Hardware reference setting; not an active audio rate or clock measurement')


def hardware_fields(hardware, *, capabilities=None, clock_sources=None):
    """Keep actual source, selected preference and internal rate distinct."""
    source = hardware["source"]
    if type(source) is not int or source not in range(8):
        raise ValueError("Invalid hardware source")
    hz = hardware["rate_hz"]
    if type(hz) is not int or hz not in (32000, 44100, 48000, 64000, 88200, 96000, 128000, 176400, 192000):
        raise ValueError("Invalid hardware nominal rate")
    inputs = hardware.get("inputs", [])
    native = capabilities is not None
    if native:
        import clock_control
        labels = dict(clock_control.source_choices(clock_sources))
        if (not isinstance(hardware.get('current_source'), str) or not hardware['current_source'] or
                hardware.get('selected_source') not in (None, *labels.values()) or
                type(hardware.get('external_locked')) is not bool or
                hardware.get('input_transport') not in ('Bulk', 'Isochronous') or
                not isinstance(inputs, list) or len(inputs) > 64):
            raise ValueError('Incomplete native clock status')
        ids = set()
        for row in inputs:
            if (not isinstance(row, dict) or type(row.get('id')) is not int or row['id'] < 0 or row['id'] in ids or
                    not isinstance(row.get('label'), str) or not row['label'] or
                    row.get('state') not in ('No Lock', 'Lock', 'Sync', 'Unknown') or
                    (row.get('carrier_rate_hz') is not None and
                     (type(row['carrier_rate_hz']) is not int or row['carrier_rate_hz'] <= 0))):
                raise ValueError('Invalid native input clock status')
            ids.add(row['id'])
        inputs = [dict(row, name=row['label']) for row in inputs]
    elif (len(inputs) != 6 or tuple(row.get("name") for row in inputs) != INPUT_NAMES
          or any(row.get("state") not in ("No Lock", "Lock", "Sync") for row in inputs)):
        raise ValueError("Incomplete hardware input status")
    # Coarse carrier frequencies must not be relabelled as active audio rates.
    inputs = [dict(row, carrier_rate_hz=None if row["state"] == "No Lock"
                   else row.get("carrier_rate_hz")) for row in inputs]
    fields = {
        "clock_source": hardware['current_source'] if native else ("Internal", *INPUT_NAMES, "Internal")[source],
        "selected_clock_source": hardware.get("selected_source"),
        "internal_rate_hz": hz,
        "sample_rate": hz if source == 7 else None,
        "input_lock_sync": inputs,
        "input_transport": hardware.get("input_transport"),
        "hardware_status_available": True,
        "can_set_clock": hardware.get("input_transport") == "Bulk",
        "can_set_rate": source == 7 and hardware.get("external_locked") is False
                        and hardware.get("input_transport") == "Bulk",
        "rate_source": "Hardware internal nominal setting; not a converter clock measurement",
    }
    if native:
        fields.update(clock_sources=clock_sources,
                      can_set_clock=capabilities['can_apply'] and capabilities['clock_source_write'],
                      can_set_digital=capabilities['can_apply'] and capabilities['digital_write'],
                      hardware_reason=capabilities.get('reason'),
                      clock_source_reason=capabilities.get('clock_source_reason'),
                      digital_reason=capabilities.get('digital_reason'))
    return fields

UNIT = "ufxplus-driver.service"
MIDI_UNIT = "ufxplus-midi.service"
PROGRESS = re.compile(r"USB running: (\d+) s; input bytes=(\d+); output completions=(\d+)(?:; rate=(\d+); channels=(\d+))?")


def command(args, timeout=2):
    try:
        result = subprocess.run(args, capture_output=True, text=True,
                                timeout=timeout, check=False)
        return result.stdout if result.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def parse_properties(text):
    return dict(line.split("=", 1) for line in text.splitlines() if "=" in line)


def parse_pipewire(text):
    values = {}
    for key, value in re.findall(r"key:'([^']+)' value:'([^']*)'", text):
        if key.startswith("clock.") and value.isdigit():
            values[key] = int(value)
    rate = values.get("clock.force-rate") or values.get("clock.rate")
    quantum = values.get("clock.force-quantum") or values.get("clock.quantum")
    return {"rate": rate, "quantum": quantum,
            "block_ms": round(1000 * quantum / rate, 2) if rate and quantum else None}


def parse_progress(text, now):
    latest = None
    for line in text.splitlines():
        try:
            item = json.loads(line)
            if not isinstance(item, dict):
                continue
            match = PROGRESS.fullmatch(item.get("MESSAGE", ""))
            if match:
                timestamp = int(item["__REALTIME_TIMESTAMP"]) / 1_000_000
                latest = {"uptime_s": int(match[1]), "input_bytes": int(match[2]),
                          "output_completions": int(match[3]),
                          "age_s": max(0, now - timestamp),
                          "rate": int(match[4]) if match[4] else 44100,
                          "channels": int(match[5]) if match[5] else 94}
        except (ValueError, TypeError, KeyError):
            continue
    return latest


def parse_timing(text, now):
    """Accept only fresh measured counters, never graph settings as callbacks."""
    latest = None
    for line in text.splitlines():
        try:
            item = json.loads(line)
            message = item.get("MESSAGE", "")
            if not isinstance(message, str) or not message.startswith("Audio timing: "):
                continue
            value = json.loads(message[len("Audio timing: "):])
            playback = value["playback"]
            result = {key: playback[key] for key in (
                "callback_min_frames", "callback_max_frames", "queued_frames", "running_underrun_frames")}
            result.update(rate_hz=value["rate_hz"], capture_missing_frames=value["capture_missing_frames"])
            if any(type(v) is not int or v < 0 for v in result.values()):
                continue
            if (result["rate_hz"] not in capabilities.RATES
                    or not 0 < result["callback_min_frames"] <= result["callback_max_frames"]):
                continue
            age = now - int(item["__REALTIME_TIMESTAMP"]) / 1e6
            if 0 <= age <= 6:
                latest = dict(result, age_s=age)
        except (ValueError, TypeError, KeyError, AttributeError):
            continue
    return latest


def failure_reason(text):
    # Present a useful diagnosis without exporting arbitrary journal messages.
    for line in text.splitlines():
        try:
            item = json.loads(line)
            message = item.get("MESSAGE", "") if isinstance(item, dict) else ""
            if not isinstance(message, str):
                continue
            if "requires current nominal rate 44100" in message:
                return "Hardware rate rejected: this alpha requires 44.1 kHz."
            if "supported rates: 44100" in message:
                return "Hardware nominal rate is unsupported. Select 44.1, 48, 88.2, 96, 176.4 or 192 kHz in Clock & Audio; no rate was changed automatically."
            preflight = re.search(r"audio preflight: interface ([0-3]) (is already claimed|must be at alternate 0)", message)
            if preflight:
                return "Audio preflight: interface " + preflight[1] + " " + preflight[2] + "."
            if "Permission denied" in message or "Access denied" in message or "LIBUSB_ERROR_ACCESS" in message:
                return "USB access denied. Check permissions on the exact device node."
            if "input transport tags disagree or frame count is invalid" in message:
                return "USB input packet format rejected. Audio stopped safely; clock readback alone does not prove stream initialization."
        except ValueError:
            continue
    return "Driver stopped on a fault. Inspect its user-service journal."


def usb_devices(root=Path("/sys/bus/usb/devices")):
    devices = []
    def read(path, name):
        try:
            return (path / name).read_text().strip()
        except OSError:
            return ""
    try:
        entries = list(root.iterdir())
    except OSError:
        return devices
    for path in entries:
        if read(path, "idVendor") == "2a39" and read(path, "idProduct") == "3fc1":
            # No serial, host USB address or personal identifier is exported.
            devices.append({"speed_mbps": read(path, "speed"),
                            "usb_revision": read(path, "bcdDevice")})
    return devices


def summarize(service, progress, pipewire, devices):
    active = service.get("ActiveState") == "active"
    fresh = active and progress is not None and progress["age_s"] <= 25
    state = ("Streaming" if fresh else "Active — waiting for USB progress") if active else (
        "Failed" if service.get("ActiveState") == "failed" else "Stopped")
    if active and not devices:
        state = "Waiting for UFX+"
    return {
        "schema": 1, "state": state, "active": active,
        "installed": service.get("LoadState") == "loaded",
        "sample_rate": progress.get("rate") if fresh else None,
        "rate_source": "Nominal rate verified at stream start; not a measured clock",
        "channels_in": progress.get("channels") if fresh else None, "channels_out": progress.get("channels") if fresh else None, "attenuation_db": 0.0,
        "pipewire": pipewire, "usb_devices": devices,
        "usb_queue_capacity": 32, "hardware_buffer_frames": None,
        "clock_source": None, "selected_clock_source": None, "input_lock_sync": None,
        "internal_rate_hz": None, "input_transport": None,
        "hardware_status_available": False,
        "usb_error_counter": None,
        "progress": progress if active else None,
        "exit_status": service.get("ExecMainStatus"),
    }


def collect():
    service = parse_properties(command([
        "systemctl", "--user", "show", UNIT,
        "-p", "LoadState", "-p", "ActiveState", "-p", "SubState",
        "-p", "MainPID", "-p", "InvocationID", "-p", "ExecMainStatus", "-p", "UnitFileState"]))
    invocation = service.get("InvocationID", "")
    session = runtime_state.read()
    if session and (str(session.get("pid")) != service.get("MainPID")
                    or session.get("invocation") != invocation):
        session = None
    progress = None
    timing = None
    journal = ""
    state = service.get("ActiveState")
    if (state in ("active", "failed") and re.fullmatch(r"[0-9a-f]{32}", invocation)
            and (not session or session.get("state") == "running")):
        # A previous invocation must never masquerade as a current stream.
        journal = command(["journalctl", "--user", "-u", UNIT,
                           "_SYSTEMD_INVOCATION_ID=" + invocation,
                           "-n", "30", "-o", "json", "--no-pager"])
        progress = parse_progress(journal, time.time())
        if session:
            # One supervisor invocation contains multiple USB sessions.
            # Never display the old session's progress/rate after reconnection.
            journal_lines = []
            for line in journal.splitlines():
                try:
                    item = json.loads(line)
                    if int(item.get("__REALTIME_TIMESTAMP", 0)) / 1e6 >= session["session_started_at"]:
                        journal_lines.append(line)
                except (ValueError, TypeError, KeyError):
                    continue
            progress = parse_progress("\n".join(journal_lines), time.time()) if session.get("state") == "running" else None
            timing = parse_timing("\n".join(journal_lines), time.time()) if session.get("state") == "running" else None
        else:
            timing = parse_timing(journal, time.time())
    result = summarize(service, progress,
                       parse_pipewire(command(["pw-metadata", "-n", "settings", "0"])),
                       usb_devices())
    result["stream_rate_hz"] = result["sample_rate"]
    result["session"] = session
    result["backend_error"] = None
    result["can_set_backend"] = state in ("active", "inactive", "failed")
    try:
        result["selected_audio_backend"] = backend_control.read()
    except (ValueError, OSError) as error:
        result["selected_audio_backend"] = None
        result["backend_error"] = str(error)
    result["audio_backend"] = (session or {}).get("backend", result["selected_audio_backend"])
    result["timing"] = timing if state == "active" and (not session or timing is None or timing["rate_hz"] == session.get("rate_hz")) else None
    if session and state == "active":
        hz = session.get("rate_hz")
        if session.get("state") == "running" and hz in capabilities.RATES:
            result["stream_rate_hz"] = hz
            result["channels_in"] = result["channels_out"] = 94 if hz <= 48000 else 54 if hz <= 96000 else 34
        result["state"] = {
            "absent": "Waiting for UFX+ native USB3",
            "permissions": "Waiting for USB permissions",
            "ambiguous": "Multiple UFX+ devices — selection required",
            "busy": "USB audio interface occupied",
            "waiting-pipewire": "Waiting for PipeWire",
            "preparing": "Preparing USB audio",
            "starting": "Starting USB audio",
            "settling": "Waiting for cold-start transport recovery",
            "running": "Streaming",
            "disconnecting": "Disconnecting",
            "blocked": "Recovery blocked",
            "stopped": "Stopped",
        }.get(session.get("state"), "Unknown session state")
    # The negotiated stream rate is evidence about startup, not a live clock read.
    result["sample_rate"] = None
    midi = parse_properties(command([
        "systemctl", "--user", "show", MIDI_UNIT,
        "-p", "LoadState", "-p", "ActiveState"]))
    result["capabilities"] = capabilities.DATA
    result["midi"] = {
        "installed": midi.get("LoadState") == "loaded",
        "active": midi.get("ActiveState") == "active",
        "state": midi.get("ActiveState", "unavailable"),
    }
    result["autostart"] = service.get("UnitFileState") in ("enabled", "enabled-runtime")
    result["can_set_rate"] = False
    result["can_set_clock"] = False
    result["can_set_digital"] = False
    result["digital"] = None
    result["digital_error"] = None
    result["hardware_status_error"] = None
    if (state in ("active", "inactive", "failed") and len(result["usb_devices"]) == 1
            and (not session or session.get("state") in ("running", "blocked"))):
        try:
            hardware = json.loads(command(["ufxplus-rate", "status"]))
            fields = hardware_fields(hardware)
            # While streaming, retain the transport's negotiated rate separately.
            result.update(fields)
            try:
                result["digital"] = digital_control.validate(hardware.get("digital"))
                result["can_set_digital"] = hardware.get("source") == 7 and hardware.get("selected_source") == "Internal" and hardware.get("input_transport") == "Bulk"
            except (ValueError, TypeError):
                result["digital_error"] = "Digital I/O readback unavailable; no cached settings shown."
            hz = result["sample_rate"]
            if hz in capabilities.RATES and state != "active":
                result["channels_in"] = result["channels_out"] = 94 if hz <= 48000 else 54 if hz <= 96000 else 34
        except (ValueError, KeyError, TypeError):
            result["can_set_rate"] = False
            result["hardware_status_error"] = "Hardware clock read unavailable; no cached source or input status shown."
    result["failure_reason"] = failure_reason(journal) if state == "failed" else None
    if session and session.get("detail"):
        result["failure_reason"] = session["detail"]
    result["can_set_buffer"] = result["audio_backend"] in ("pipewire", "pipewire+alsa") and state in ("active", "inactive", "failed")
    try:
        result["recovery_rate_hz"] = startup_rate.read()
        result["recovery_rate_error"] = None
    except (ValueError, OSError) as error:
        result["recovery_rate_hz"] = None
        result["recovery_rate_error"] = str(error)
    result["can_set_nodes"] = result["can_set_buffer"]
    result["node_error"] = None
    try:
        result["node_config"] = node_control.read()
        listing = command(["pw-cli", "ls", "Node"])
        present = set(re.findall(r'node.name = "([^"\n]+)"', listing)) if listing else None
        result["nodes"] = node_control.inventory(result["node_config"], result.get("stream_rate_hz") or result.get("sample_rate"), present)
    except (ValueError, OSError) as error:
        result["node_config"] = None
        result["nodes"] = []
        result["node_error"] = str(error)
        result["can_set_nodes"] = False
    result["buffer_error"] = None
    try:
        result["buffer_frames"] = buffer_control.read()
    except (ValueError, OSError) as error:
        result["buffer_frames"] = None
        result["buffer_error"] = "Cannot read saved buffer size: " + str(error)
    try:
        result["version"] = Path("/usr/share/ufxplus-driver/VERSION").read_text().strip()
    except OSError:
        result["version"] = "development"
    return result


if __name__ == "__main__":
    print(json.dumps(collect(), ensure_ascii=False))
