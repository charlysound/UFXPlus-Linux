"""Existing semantic hardware codec, bound to the selected common owner."""
import hashlib
import json
from pathlib import Path
import secrets
import stat
import os
import subprocess
import time
import digital_control
import clock_control
import driver_status

DANTE_DOMAIN='digiface_dante_settings_v1'


def read(uid,attachment,*,request_abi=1,native_domain=None):
    if type(request_abi) is not int or request_abi not in (1,2):raise ValueError('Unsupported hardware request ABI')
    tool=Path(__file__).resolve().parent.parent/'ufxplus-rate-guarded'
    if not tool.is_file():return None
    endpoint='hardware-status-v2-guarded' if request_abi==2 else 'hardware-status-guarded'
    if native_domain is not None:
        if request_abi!=2 or native_domain!=DANTE_DOMAIN:raise ValueError('Unknown native settings domain')
        endpoint='hardware-status-v2-dante-guarded'
    result=subprocess.run([str(tool),endpoint,uid,attachment['connection_marker'],attachment['descriptor_sha256']],capture_output=True,text=True,timeout=4)
    if len(result.stdout)>1048576:raise ValueError('Hardware metadata is too large')
    if result.returncode:raise RuntimeError(result.stderr.strip() or 'Hardware settings readback failed')
    value=json.loads(result.stdout)
    return validate_v2(value,uid,attachment) if request_abi==2 else validate(value, uid, attachment)


def loaded_abi2(inventory):
    """Called only after linux_control verified the publishing process identity."""
    caps=inventory.get('manager_capabilities')
    if not isinstance(caps,dict) or type(caps.get('schema')) is not int or caps['schema']!=1:return False
    abis,operations=caps.get('hardware_request_abis'),caps.get('operations')
    return bool(isinstance(abis,list) and all(type(abi) is int and abi>0 for abi in abis) and
                len(set(abis))==len(abis) and 2 in abis and isinstance(operations,list) and
                all(isinstance(op,str) for op in operations) and len(set(operations))==len(operations) and
                set(operations)=={'clock_source','digital'})


def admit(value,inventory):
    """Native writers are facts; the loaded manager alone admits their use."""
    if value is None or value.get('schema')!=2:return value
    loaded=loaded_abi2(inventory)
    domain=value.get('native_domain')
    domain_loaded=domain is None or (domain==DANTE_DOMAIN and domain in ((inventory.get('manager_capabilities') or {}).get('native_settings_domains') or []))
    enabled=loaded and domain_loaded and value.get('supported') is True
    reason=(value['fields'].get('hardware_reason') if value.get('supported') is False else None) if loaded else 'Read-only: the loaded manager does not publish hardware settings ABI2.'
    if not domain_loaded:reason='Read-only: the loaded manager has not admitted this native settings domain.'
    admission=dict(hardware_settings_abi=2 if loaded else None,can_apply=enabled,reason=reason)
    fields=dict(value['fields']);caps=value.get('native_capabilities') or {}
    fields.update(can_set_clock=enabled and caps.get('clock_source_write') is True,
                  can_set_digital=enabled and caps.get('digital_write') is True,
                  hardware_reason=reason,clock_source_reason=reason,digital_reason=reason)
    if fields['can_set_clock'] and (fields.get('selected_kind')=='unknown' or fields.get('current_kind')=='unknown'):
        fields.update(can_set_clock=False,clock_source_reason='Read-only: the native clock preference or current source is unknown.')
    if fields['can_set_digital'] and domain!=DANTE_DOMAIN and not (fields.get('selected_kind')=='internal' and
            fields.get('current_kind')=='internal' and fields.get('current_internal_confirmed') is True):
        fields.update(can_set_digital=False,digital_reason='Read-only: selected and current Internal clock must be confirmed before Digital I/O changes.')
    return dict(value,fields=fields,manager_admission=admission)


def read_current(uid,attachment,inventory):
    if loaded_abi2(inventory):
        # A V2 error is real: never retry through the historical write contract.
        value=read(uid,attachment,request_abi=2)
        domains=(inventory.get('manager_capabilities') or {}).get('native_settings_domains') or []
        if value and value.get('supported') is False and isinstance(value.get('dante_status'),dict) and DANTE_DOMAIN in domains:
            value=read(uid,attachment,request_abi=2,native_domain=DANTE_DOMAIN)
        return admit(value,inventory)
    value=read(uid,attachment)
    if value is not None and value.get('supported') is False:
        # The old helper rejects unsupported BF before any USB access. Preserve
        # that manager's ABI1 path for already admitted cards, without a PID table.
        return admit(read(uid,attachment,request_abi=2),inventory)
    return value


def validate_v2(value,uid,attachment):
    if (not isinstance(value,dict) or type(value.get('schema')) is not int or value['schema']!=2 or
            type(value.get('request_abi')) is not int or value['request_abi']!=2 or value.get('uid')!=uid or
            value.get('connection_marker')!=attachment['connection_marker'] or
            value.get('descriptor_sha256')!=attachment['descriptor_sha256'] or
            type(value.get('parameter_writes')) is not int or value['parameter_writes']!=0 or
            value.get('codec')!='rme_runtime_settings' or type(value.get('supported')) is not bool):
        raise ValueError('Hardware V2 settings belong to another attachment')
    if not value['supported']:
        return dict(value,fields=dict(can_set_clock=False,can_set_digital=False,hardware_status_available=False,
                                     hardware_reason=value.get('reason') or 'Detailed hardware settings are unavailable.'))
    caps=value.get('native_capabilities')
    if (not isinstance(caps,dict) or any(type(caps.get(key)) is not bool for key in ('clock_source_write','digital_write')) or
            any(not isinstance(value.get(key),str) or not value[key] for key in ('native_codec','native_profile')) or
            not isinstance(value.get('reference'),dict)):
        raise ValueError('Native hardware V2 capabilities unavailable')
    digital_control.settings_identity(dict(expected_settings=value.get('expected_settings')))
    raw=value['status']
    fields=driver_status.hardware_fields_v2(raw,capabilities=caps,clock_sources=value['clock_sources'])
    descriptors=digital_control.native_fields(caps.get('digital_fields'))
    fields['digital']=digital_control.validate(dict(raw['digital'],fields=descriptors,expected_settings=value['expected_settings']))
    if any(row['value']!=fields['digital']['values'][row['id']] for row in descriptors):
        raise ValueError('Digital I/O V2 capability and readback disagree')
    return dict(value,fields=fields)


def validate(value, uid, attachment):
    if (not isinstance(value,dict) or type(value.get('schema')) is not int or value['schema']!=1 or value.get('uid')!=uid or value.get('connection_marker')!=attachment['connection_marker'] or
            value.get('descriptor_sha256')!=attachment['descriptor_sha256'] or value.get('parameter_writes')!=0 or
            type(value.get('parameter_writes')) is not int or value.get('codec')!='rme_runtime_settings' or type(value.get('supported')) is not bool):
        raise ValueError('Hardware settings belong to another attachment')
    if not value['supported']:
        return dict(value,fields=dict(can_set_clock=False,can_set_digital=False,hardware_status_available=False,
                                     hardware_reason=value.get('reason') or 'Detailed hardware settings are not admitted for this interface.'))
    caps=value.get('capabilities')
    if (not isinstance(caps,dict) or any(type(caps.get(key)) is not bool for key in ('clock_source_write','digital_write','can_apply')) or
            any(caps.get(key) is not None and not isinstance(caps[key],str) for key in ('reason','clock_source_reason','digital_reason')) or
            any(not isinstance(value.get(key),str) or not value[key] for key in ('native_codec','native_profile')) or
            not isinstance(value.get('reference'),dict) or not isinstance(value.get('clock_sources'),list) or
            any(not isinstance(row,dict) for row in value['clock_sources'])):
        raise ValueError('Native hardware capabilities unavailable')
    raw=value['status'];fields=driver_status.hardware_fields(raw,capabilities=caps,clock_sources=value['clock_sources'])
    descriptors=digital_control.native_fields(caps.get('digital_fields'))
    fields['digital']=digital_control.validate(dict(raw['digital'],fields=descriptors))
    if any(row['value']!=fields['digital']['values'][row['id']] for row in descriptors):
        raise ValueError('Digital I/O capability and readback disagree')
    fields['can_set_digital']=bool(fields['can_set_digital'] and raw['source']==7 and raw.get('selected_source')=='Internal')
    return dict(value,fields=fields)


def change(uid,expected_marker,operation,*,source=None,snapshot=None,changes=None,timeout=45,interval=0.2):
    import linux_control as common
    common.uid_check(uid)
    with common.transaction(uid):
        current=common.status(uid)
        if current['marker']!=expected_marker:raise common.ControlError('stale','The card connection changed. Refresh before applying.')
        hardware=current.get('hardware_settings') or {};fields=hardware.get('fields') or {}
        if not current.get('native') or hardware.get('codec') not in ('rme_runtime_settings','ufxplus_runtime_settings') or hardware.get('supported') is False:raise common.ControlError('unavailable',fields.get('hardware_reason') or 'Selected owner has no admitted hardware settings codec')
        v2=hardware.get('schema')==2
        if v2 and (hardware.get('request_abi')!=2 or not (hardware.get('manager_admission') or {}).get('can_apply')):
            raise common.ControlError('unavailable','The loaded manager has not admitted hardware settings ABI2')
        if operation=='clock_source':
            sources=dict(clock_control.source_choices(hardware.get('clock_sources') or []))
            if not fields.get('can_set_clock'):raise common.ControlError('unavailable',fields.get('clock_source_reason') or fields.get('hardware_reason') or 'Clock source changes are unavailable')
            if type(source) is not int or source not in sources:raise common.ControlError('invalid','Choose an available native clock source')
            payload=dict(source=source)
        elif operation=='digital':
            snapshot=digital_control.validate(snapshot)
            if not fields.get('can_set_digital'):raise common.ControlError('unavailable',fields.get('digital_reason') or fields.get('hardware_reason') or 'Digital I/O changes are unavailable')
            if (digital_control.settings_identity(snapshot)!=digital_control.settings_identity(fields.get('digital',{})) or not digital_control.selections_valid(fields['digital'],changes)):
                raise common.ControlError('stale','Digital I/O changed or is unavailable. Refresh and review before applying.')
            payload=dict(changes=changes) if v2 else dict(expected_flags=snapshot['flags'],changes=changes)
            if hardware.get('native_domain')==DANTE_DOMAIN:
                descriptors={r['id']:r for r in hardware['native_capabilities']['digital_fields']}
                if any(descriptors[k].get('available') is not True for k in changes):raise common.ControlError('unavailable','Native setting is unavailable in the current network/device state')
                payload['native_domain']=DANTE_DOMAIN
        else:raise common.ControlError('invalid','Unsupported hardware operation')
        if v2:
            digital_control.settings_identity(dict(expected_settings=hardware.get('expected_settings')))
            payload['expected_settings']=hardware['expected_settings']
        if current['state'] not in ('running','clock_idle') or (current['state']=='running' and not current['can_apply']):raise common.ControlError('busy','The selected audio owner is not ready')
        route_path=common.node_control.native_status_path().parent/'hardware-links'/(hashlib.sha256(uid.encode()).hexdigest()+'.json')
        saved_links=None
        if current['state']=='running':
            common._ensure_rate_clients_closed(current)
            saved_links=common._capture_legacy_links(current)
        else:
            try:
                saved=common.read_json(route_path,private=True)
                if saved.get('schema')!=1 or saved.get('uid')!=uid or not isinstance(saved.get('marker'),dict):raise common.ControlError('invalid','Invalid saved hardware transition routes')
                if all(saved['marker'].get(k)==expected_marker.get(k) for k in ('manager_pid','manager_process_start','manager_nonce','attachment')):
                    saved_links=saved.get('links')
                    if saved_links is not None:saved_links=dict(saved_links,marker=tuple(saved_links['marker']))
            except FileNotFoundError:pass
        request_id=secrets.token_hex(16)
        directory=common.node_control.native_status_path().parent/'hardware-requests';directory.mkdir(mode=0o700,parents=True,exist_ok=True)
        info=directory.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077:raise common.ControlError('unavailable','Hardware request directory is not private')
        request=dict(schema=2 if v2 else 1,uid=uid,request_id=request_id,expected=expected_marker,operation=operation,**payload)
        common.atomic_json(directory/(hashlib.sha256(uid.encode()).hexdigest()+'.json'),request)
        deadline=time.monotonic()+timeout
        while True:
            observed=common.status(uid);marker=observed['marker'];ack=observed.get('hardware_change') or {}
            if any(marker.get(k)!=expected_marker.get(k) for k in ('manager_pid','manager_process_start','manager_nonce','attachment')):raise common.ControlError('stale','The selected card or manager changed during hardware settings',True)
            ours=ack.get('request_id')==request_id
            if ours and ack.get('phase') in ('applied','error') and v2 and (type(ack.get('request_abi')) is not int or ack['request_abi']!=2):
                raise common.ControlError('uncertain','Hardware settings ACK did not confirm request ABI2',True)
            if marker.get('generation')!=expected_marker['generation'] and not ours:raise common.ControlError('stale','Another session replaced this hardware transaction',True)
            if ours and ack.get('phase')=='error':raise common.ControlError('uncertain' if ack.get('uncertain',True) else 'busy',ack.get('error') or 'Hardware settings failed',ack.get('uncertain',True))
            if (ours and ack.get('phase')=='applied' and ack.get('from_generation')==expected_marker['generation'] and ack.get('to_generation')==marker.get('generation')):
                ready=observed['state']=='running' and observed['can_apply']
                idle=observed['state']=='clock_idle' and ack.get('audio_resumed') is False and (v2 or operation=='clock_source')
                fresh=(observed.get('hardware_settings') or {}).get('status') or {}
                if v2 and ready:
                    clock=fresh.get('clock') or {}
                    domain_ready=(observed.get('hardware_settings') or {}).get('native_domain')==DANTE_DOMAIN and ((observed.get('hardware_settings') or {}).get('native_capabilities') or {}).get('audio_clock_ready') is True
                    if not domain_ready and not (clock.get('selected_kind')=='internal' and clock.get('current_kind')=='internal' and
                            clock.get('current_internal_confirmed') is True and
                            type(clock.get('reference_nominal_rate_hz')) is int and clock['reference_nominal_rate_hz']>0):
                        raise common.ControlError('uncertain','Hardware changed, but Internal clock was not confirmed for audio resume',True)
                confirmed=((fresh.get('clock',{}).get('selected_source_id')==source if v2 else fresh.get('selected_source')==sources[source]) if operation=='clock_source' else
                           all(fresh.get('digital',{}).get('values',{}).get(k)==v for k,v in changes.items()))
                if (ready or idle) and confirmed:
                    if idle:
                        common.atomic_json(route_path,dict(schema=1,uid=uid,marker=marker,links=saved_links))
                        return dict(ok=True,**observed)
                    try:
                        links=common._restore_legacy_links(saved_links,observed)
                        final=common.status(uid)
                        if final['marker']!=marker or final['state']!='running':raise common.ControlError('stale','The interface changed while restoring previous routes',True)
                        route_path.unlink(missing_ok=True)
                    except (OSError,ValueError,RuntimeError,subprocess.SubprocessError) as error:
                        raise common.ControlError('uncertain','Hardware settings were applied, but previous audio routes could not be confirmed: '+str(error),True) from error
                    return dict(ok=True,links=links,**final)
            if time.monotonic()>=deadline:raise common.ControlError('uncertain','The current owner did not confirm the hardware settings. Refresh before retrying.',True)
            time.sleep(interval)
