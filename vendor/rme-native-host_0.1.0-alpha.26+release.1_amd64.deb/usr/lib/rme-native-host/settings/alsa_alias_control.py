#!/usr/bin/python3
"""Publish readable ALSA aliases from the admitted Linux status,no audio open."""
import argparse,json,os
from pathlib import Path
import alsa_names
import linux_control

def refresh(root=None,reader=linux_control.status):
    observed=reader();rows=[]
    for current in observed['devices']:
        kernel=current.get('alsa') or {}
        if current.get('native') is not True or not kernel.get('ready'):continue
        marker=current.get('marker') or {};uid=current['uid']
        rows.append(dict(uid=uid,model=current['model'],label=current.get('display_name'),
            kernel=dict(schema=1,uid=uid,generation=marker.get('audio_generation'),
                        **{k:kernel[k] for k in ('card_id','rate','capture_channels','playback_channels')})))
    directory=root or Path(os.environ['XDG_RUNTIME_DIR'])/'rme-native'
    return alsa_names.publish(directory,rows)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--enable',action='store_true',help='Link the generated view from an absent ~/.asoundrc;never overwrite a custom configuration')
    args=parser.parse_args()
    try:
        result=dict(ok=True,**refresh())
        if args.enable:result['user_view_enabled']=alsa_names.enable(Path(result['path']).parent,Path.home()/'.asoundrc')
    except (OSError,ValueError,RuntimeError,KeyError,TypeError) as error:result=dict(ok=False,error=str(error))
    print(json.dumps(result,ensure_ascii=False));return 0 if result['ok'] else 1
if __name__=='__main__':raise SystemExit(main())
