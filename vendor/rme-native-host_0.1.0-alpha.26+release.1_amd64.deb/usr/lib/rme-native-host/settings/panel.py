#!/usr/bin/python3
"""Single-instance UFX+ USB Settings. No firmware or raw USB controls."""
import argparse
import json
from functools import wraps
import subprocess
import threading
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gio
import driver_status
import rate_control
import buffer_control
import clock_control
import node_control
import node_selection_view as node_view
import digital_control
import linux_control
import selection_control


def model_update(callback):
    """GTK model fills emit changed/toggled too;none are user intentions."""
    @wraps(callback)
    def guarded(self, *args, **kwargs):
        self._render_depth = getattr(self, '_render_depth', 0) + 1
        try:
            return callback(self, *args, **kwargs)
        finally:
            self._render_depth -= 1
    return guarded


# Fireface USB Settings3.39 uses system fonts13/11 and NSBox group frames,
# not the TotalMix bitmap skin. Scope the host adaptation to this application.
def reference_style(dark):
    colors = dict(bg='#282828', group='#363636', text='#e0e0e0', muted='#b8b8b8',
                  border='#515151', control='#686868', hover='#757575',
                  inactive='#444444', disabled='#aaaaaa', accent='#0a84ff') if dark else dict(
                  bg='#ececec', group='#f4f4f4', text='#222222', muted='#555555',
                  border='#b6b6b6', control='#ffffff', hover='#f7f7f7',
                  inactive='#e4e4e4', disabled='#707070', accent='#007aff')
    # Mac13point metrics map to13logical pixels,not13GTK points at96DPI.
    # Pango renders glyphs directly at the final GDK scale; no bitmap resampling.
    css = '''
    #rme-usb-settings { background: @bg@; color: @text@; font-size: 13px; }
    #rme-usb-settings label { color: @text@; text-shadow: none; }
    #rme-usb-settings .rme-note,
    #rme-usb-settings .rme-group-title { font-size: 11px; color: @muted@; }
    #rme-usb-settings .rme-group-title { padding: 0 5px; }
    #rme-usb-settings .rme-group > border {
        border: 1px solid @border@; border-radius: 4px;
        background: @group@; box-shadow: none;
    }
    #rme-usb-settings .rme-group { padding: 0; }
    #rme-usb-settings scrolledwindow,
    #rme-usb-settings viewport,
    #rme-usb-settings notebook,
    #rme-usb-settings notebook > stack { background: @bg@; border: none; }
    #rme-usb-settings notebook > header {
        background: @bg@; border: none; box-shadow: none; padding: 3px 0;
    }
    #rme-usb-settings notebook > header tab {
        background: @group@; border: 1px solid @border@;
        border-radius: 4px; padding: 4px 9px; margin: 0 2px;
        min-height: 18px; box-shadow: none;
    }
    #rme-usb-settings notebook > header tab:checked {
        background: @control@; border-color: @accent@;
    }
    #rme-usb-settings notebook > header tab:checked label { color: @text@; }
    #rme-usb-settings button,
    #rme-usb-settings combobox button,
    #rme-usb-settings entry {
        color: @text@; background: @control@; background-image: none;
        border: 1px solid @border@; border-radius: 4px;
        min-height: 20px; min-width: 12px; padding: 1px 8px;
        box-shadow: none; text-shadow: none;
    }
    #rme-usb-settings button:hover { background: @hover@; }
    #rme-usb-settings button:active { background: @group@; }
    #rme-usb-settings button:focus,
    #rme-usb-settings entry:focus { border-color: @accent@; }
    #rme-usb-settings checkbutton { min-height: 20px; padding: 1px 0; }
    #rme-usb-settings checkbutton check {
        min-width: 12px; min-height: 12px; border-radius: 3px;
        color: @text@; border: 1px solid @border@; background: @control@;
    }
    #rme-usb-settings checkbutton check:checked {
        background: @accent@; color: white; border-color: @accent@;
    }
    #rme-usb-settings button:disabled,
    #rme-usb-settings entry:disabled,
    #rme-usb-settings checkbutton check:disabled {
        background: @inactive@; color: @disabled@; opacity: 1;
    }
    #rme-usb-settings :disabled label,
    #rme-usb-settings label:disabled { color: @disabled@; opacity: 1; }
    #rme-usb-settings .dim-label { color: @muted@; opacity: 1; }
    #rme-usb-settings scrollbar { background: @bg@; }
    #rme-usb-settings scrollbar slider {
        background: @control@; min-width: 6px; min-height: 6px;
        border-radius: 4px; margin: 2px;
    }
    /* Combo popups are separate GTK windows,not descendants of the panel.
       The provider is process-local; these rules do not theme the desktop. */
    menu { background: @group@; color: @text@; padding: 3px; font-size: 13px; }
    menu menuitem { color: @text@; padding: 3px 8px; }
    menu menuitem label { color: @text@; }
    menu menuitem:hover { background: @accent@; color: white; }
    menu menuitem:hover label { color: white; }
    menu menuitem:disabled label { color: @disabled@; }
    '''
    for name, value in colors.items():
        css = css.replace('@' + name + '@', value)
    return css.encode('utf-8')


class Panel(Gtk.ApplicationWindow):
    def __init__(self, application=None):
        super().__init__(application=application, title="UFX+ USB Settings")
        self.set_default_size(520, 680)
        self.set_border_width(10)
        self.set_name('rme-usb-settings')
        self._style_provider = Gtk.CssProvider()
        self._style_settings = Gtk.Settings.get_default()
        self._style_handlers = [self._style_settings.connect('notify::' + name, self._reference_theme)
                                for name in ('gtk-theme-name', 'gtk-application-prefer-dark-theme')]
        self._reference_theme()
        Gtk.StyleContext.add_provider_for_screen(self.get_screen(), self._style_provider,
                                                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self._alive = True
        self._render_depth = 1
        self._status_epoch = 0
        self._busy = False
        self._control_busy = False
        self._nodes_dirty = False
        self._nodes_updating = False
        self._node_draft_context = None
        self._node_layout_signature = None
        self.category_switches = {}
        self.category_presence = {}
        self._node_mode = 1
        self._selected_uid = None
        self._native_marker = None
        self._hardware_marker = None
        self._crc_counter = driver_status.ModuloErrorCounter()
        self._linux_status = None
        self._rate_marker = None
        self._backend_options = None
        self._device_choices = []
        self._updating_devices = False
        self._digital_snapshot = None
        self._digital_base = None
        self._digital_loading = False
        self._digital_pending = {}
        self.connect("destroy", self.close)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add(content)
        header = Gtk.Box(spacing=8)
        title = Gtk.Label(xalign=0)
        title.set_markup("<b>Fireface UFX+ · USB3</b>")
        self.device_title = title
        header.pack_start(title, True, True, 0)
        patchbay = Gtk.Button(label="Open qpwgraph")
        patchbay.connect("clicked", lambda _: self.launch(["qpwgraph"]))
        header.pack_end(patchbay, False, False, 0)
        content.pack_start(header, False, False, 0)
        self.device_choice = Gtk.ComboBoxText()
        self.device_choice.append('legacy', 'Fireface UFX+')
        self.device_choice.set_active_id('legacy')
        self.device_choice.connect('changed', self.device_changed)
        content.pack_start(self.device_choice, False, False, 0)
        self.banner = Gtk.Label(label="Reading device status…", xalign=0)
        self.banner.get_style_context().add_class('rme-note')
        content.pack_start(self.banner, False, False, 0)
        self.diagnosis = Gtk.Label(xalign=0)
        self.diagnosis.set_line_wrap(True)
        self.diagnosis.set_max_width_chars(62)
        self.diagnosis.set_no_show_all(True)
        content.pack_start(self.diagnosis, False, False, 0)
        notebook = Gtk.Notebook()
        self.notebook = notebook
        content.pack_start(notebook, True, True, 0)
        self.labels = {}
        self.page_containers = {}
        general = self.page(notebook, "Clock & Audio")
        clock = self.section(general, "Clock", [
            ("rate", "Device nominal rate"), ("clock", "Current Clock"),
            ("internal_rate", "Internal nominal setting"),
            ("recovery_rate", "32 kHz startup recovery"),
        ])
        self.rate_choice, self.rate_apply = self.selector(
            clock, "Sample Rate", [(str(hz), f"{hz / 1000:g} kHz") for hz in rate_control.RATES], self.set_rate)
        self._rate_options = None
        self.rate_note = self.note(clock, "Reading the selected interface's native rate capabilities…")
        self.rate_choice.connect('changed', lambda *_: self.update_rate_note(self._linux_status))
        self.source_choice, self.source_apply = self.selector(
            clock, "Clock Source", [(str(i), name) for i, name in enumerate(clock_control.SOURCES)], self.set_source)
        self.source_choice.set_tooltip_text("Preferred clock source. Current Clock and Lock/Sync show what the hardware actually uses. External-clock audio streaming is not yet validated; a locked external source leaves the Linux audio driver stopped.")
        self.source_note = self.note(clock, "Reading the selected interface's clock sources…")
        grid = Gtk.Grid(column_spacing=24, row_spacing=5)
        for col, label in enumerate(("Input Status", "Lock / Sync", "Carrier")):
            grid.attach(Gtk.Label(label=label, xalign=0), col, 0, 1, 1)
        self.input_grid = grid
        self._input_rows = []
        self._update_input_status([dict(name=name, state='Unknown', carrier_rate_hz=None) for name in driver_status.INPUT_NAMES])
        grid.set_tooltip_text("Incoming carrier frequency, not necessarily the audio rate (ADAT S/MUX and single-speed Word Clock).")
        general.pack_start(grid, False, False, 0)
        buffering = self.section(general, "Linux audio", [
            ("pw_rate", "PipeWire stream rate"), ("quantum", "Observed stream block"),
            ("channels", "Active USB topology"),
        ])
        self.backend_choice, self.backend_apply = self.selector(
            buffering, "Audio access", [], self.set_backend)
        self.backend_note = self.note(buffering, "")
        self.buffer_choice, self.buffer_apply = self.selector(
            buffering, "Buffer request", [(str(n), f"{n} frames" if n else "Auto (PipeWire)") for n in buffer_control.SIZES], self.set_buffer)
        self.buffer_note = self.note(buffering, "")
        change_note = self.note(general, "Changes briefly pause audio; channel-count changes may break links.")
        change_note.set_tooltip_text("Applications may need to reconnect after a channel-count change. This is not a gapless transition.")
        nodes = self.page(notebook, "PipeWire Nodes")
        self.note(nodes, "Choose PipeWire categories and channels for this interface. Saved choices and visible ports are shown separately. ALSA channels and hardware direct monitoring keep their existing settings.")
        self.category_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.category_box.set_no_show_all(True)
        nodes.pack_start(self.category_box, True, True, 0)
        self.node_switches = {}
        self.node_presence = {}
        self.node_groups = {}
        for direction, title in (("capture", "Inputs · Capture"), ("playback", "Outputs · Playback")):
            box = self.section(nodes, title, [])
            self.node_groups[direction] = box
            for row in node_control.inventory(node_control.DEFAULT, None):
                if row["direction"] != direction:
                    continue
                key = (direction, row["index"])
                check = Gtk.CheckButton(label=row["label"])
                check.connect("toggled", self.nodes_edited)
                present = Gtk.Label(label="Checking…")
                line = Gtk.Box(spacing=8)
                line.pack_start(check, True, True, 0)
                line.pack_end(present, False, False, 0)
                box.pack_start(line, False, False, 0)
                self.node_switches[key] = check
                self.node_presence[key] = present
        self.node_note = self.note(nodes, "Applying briefly restarts audio. Removed nodes lose their links; applications or your patchbay may need to reconnect. Disabled outputs send silence, but hardware direct monitoring is unchanged.")
        self.nodes_apply = Gtk.Button(label="Apply node selection")
        # Kept as an internal admission indicator for the existing backend;
        # no Apply/Discard widget is attached to the visible interface.
        digital = self.page(notebook, "Digital I/O")
        digital.set_spacing(6)
        self.digital_note = self.note(digital, "Reading hardware Digital I/O settings…")
        self.digital_controls = {}
        self.digital_current = {}
        self.digital_fields_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        digital.pack_start(self.digital_fields_box, False, False, 0)
        self._digital_rows_key = None
        self.section(digital, "Hardware status", [("madi_current", "Current MADI Input"),
            ("digital_bus", "USB input transport")])
        self.note(digital, "Changes apply immediately and may briefly pause this card's audio. Only settings reported by the selected interface are shown.")
        self.digital_apply = Gtk.Button(label="Apply Digital I/O")
        self.digital_discard = Gtk.Button(label="Discard changes")
        diagnostics = self.page(notebook, "Status")
        self.section(diagnostics, "Device and driver", [
            ("version", "Linux driver"), ("autostart", "Start at login"),
            ("stream_backend", "Applied audio access"), ("alsa_status", "ALSA"),
            ("pw_status", "PipeWire"),
            ("usb", "USB connection"), ("revision", "USB descriptor revision"),
            ("firmware", "USB firmware revision"), ("midi", "MIDI"),
            ("transport", "USB input transport"), ("crc", "Hardware CRC errors"),
        ])
        self.section(diagnostics, "Streaming diagnostics", [
            ("stream_rate", "Negotiated stream rate"), ("elapsed", "Last reported stream time"),
            ("input", "USB bytes received"), ("output", "Output transfers completed"),
            ("freshness", "Progress report age"), ("queue", "USB host queue capacity"),
            ("hardware_buffer", "Hardware buffer"), ("attenuation", "Playback attenuation"),
        ])
        self.note(diagnostics, "PipeWire block size, USB queue capacity and macOS Short Safety Offset are different quantities. None is a measured round-trip latency. USB descriptor revision is not a decoded firmware version.")
        self.labels["rate"].set_tooltip_text("Rate negotiated by the validated USB owner; not an independent physical clock measurement. External carrier rates are listed separately.")
        self.labels["quantum"].set_tooltip_text("Measured callback size only when published by this owner; the requested PipeWire quantum is shown separately below.")
        self.labels["queue"].set_tooltip_text("32 transfers per direction, approximately 32 ms. Not the RME device buffer setting.")
        self.labels["crc"].set_tooltip_text("Observed native USB CRC counter increments since this observation context started. Five-bit hardware counter: complete extra wraps between status reads cannot be recovered. A missing observation, device selection or session change starts a new baseline. Not a lifetime total.")
        self.note(content, "Independent Linux driver · experimental · status refreshed every 3 s")
        self.build_dante_page(notebook)
        self.show_all()
        self._render_depth = 0
        self.refresh()
        self._timer = GLib.timeout_add_seconds(3, self.refresh)

    def page(self, notebook, title):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_border_width(6)
        scroll.add(box)
        container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        container.pack_start(scroll, True, True, 0)
        self.page_containers[title] = container
        notebook.append_page(container, Gtk.Label(label=title))
        # Conditional pages may suppress the outer show_all; initialize their
        # viewport/scroller too, not only the later content box's descendants.
        scroll.show_all()
        return box

    def note(self, parent, text):
        label = Gtk.Label(label=text, xalign=0)
        label.set_line_wrap(True)
        label.set_max_width_chars(60)
        label.get_style_context().add_class('rme-note')
        parent.pack_start(label, False, False, 0)
        return label

    def row(self, parent, caption, widget):
        row = Gtk.Box(spacing=8)
        label = Gtk.Label(label=caption, xalign=0)
        label.set_line_wrap(True)
        label.set_max_width_chars(26)
        row.pack_start(label, True, True, 0)
        row.pack_end(widget, False, False, 0)
        parent.pack_start(row, False, False, 0)

    def section(self, parent, title, rows):
        frame = Gtk.Frame()
        frame.get_style_context().add_class('rme-group')
        label = Gtk.Label(label=title, xalign=0)
        label.get_style_context().add_class('rme-group-title')
        frame.set_label_widget(label)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        box.set_border_width(8)
        frame.add(box)
        # Existing capability code owns the returned box's visibility.
        box.connect('notify::visible', lambda box, _: frame.set_visible(box.get_visible()))
        for key, caption in rows:
            value = Gtk.Label(label="—", xalign=0)
            value.set_selectable(True)
            self.labels[key] = value
            self.row(box, caption, value)
        parent.pack_start(frame, False, False, 0)
        return box

    def _reference_theme(self, *_):
        settings = self._style_settings
        dark = settings.get_property('gtk-application-prefer-dark-theme') or 'dark' in (
            settings.get_property('gtk-theme-name') or '').lower()
        self._style_dark = bool(dark)
        self._style_provider.load_from_data(reference_style(self._style_dark))

    def build_dante_page(self, notebook):
        """Settings3.39 NIB1745;do not alias Dante network writes to UFX."""
        body = self.page(notebook, 'Dante')
        self.dante_container = self.page_containers['Dante']
        self.dante_container.set_no_show_all(True)
        self.dante_controls = {}
        self.dante_status = {}
        self.dante_note=self.note(body, 'Native Dante feedback is read-only until admitted by the loaded settings owner.')
        options = self.section(body, 'Options', [])
        for key, label, choices in (
                ('madi_format','MADI Format',('56 (28) ch.','64 (32) ch.')),
                ('bnc_io','BNC I/O',('Word Clock','MADI')),
                ('madi_frame','MADI Frame',('96K Frame','48K Frame'))):
            control = Gtk.ComboBoxText()
            for index, text in enumerate(choices):control.append(str(index),text)
            control.set_sensitive(False)
            self.row(options,label,control);self.dante_controls[key]=control
        for key,label,parent in [('termination','Termination',options),('iso_mode','Iso Transfer Mode',self.section(body,'Bus',[]))]:
            control=Gtk.CheckButton(label=label);control.set_inconsistent(True);control.set_sensitive(False)
            parent.pack_start(control,False,False,0);self.dante_controls[key]=control
        status=self.section(body,'Input Status',[])
        for key,label in [('bnc_in','BNC In'),('input_rate','Frequency'),('input_format','MADI Format')]:
            value=Gtk.Label(label='Unavailable',xalign=0);value.set_selectable(True)
            self.row(status,label,value);self.dante_status[key]=value
        status=self.section(body,'Dante & Clock Status',[])
        for key,label in [('primary','Primary'),('secondary','Secondary'),('mode','Mode'),('clock','Clock')]:
            value=Gtk.Label(label='Unavailable',xalign=0);value.set_selectable(True)
            self.row(status,label,value);self.dante_status[key]=value
        network=self.section(body,'Dante Clock Options (only to be changed when network down)',[])
        control=Gtk.ComboBoxText()
        for hz in (44100,48000,88200,96000,176400,192000):control.append(str(hz),f'{hz} Hz')
        control.set_sensitive(False);self.row(network,'Set Sample Rate',control)
        self.dante_controls['network_rate']=control
        for key,label in [('preferred_leader','Preferred Leader'),('external_sync','Sync to WCK/MADI')]:
            control=Gtk.CheckButton(label=label);control.set_inconsistent(True);control.set_sensitive(False)
            network.pack_start(control,False,False,0);self.dante_controls[key]=control
        self._dante_snapshot=None;self._dante_context=None
        for key,control in self.dante_controls.items():
            control.connect('changed' if isinstance(control,Gtk.ComboBox) else 'toggled',self.dante_edited,key)
        body.show_all()
        self.dante_container.hide()

    @model_update
    def update_dante_page(self, data):
        # Exact common model names,not a new USB PID or transport table.
        model=(data or {}).get('model')
        applicable=model in ('digiface_dante','DigifaceDante','Digiface Dante')
        self.dante_container.set_visible(applicable)
        self._dante_snapshot=None;self._dante_context=None
        self.dante_note.set_text('Native Dante feedback is read-only until admitted by the loaded settings owner.')
        for control in self.dante_controls.values():
            control.set_sensitive(False)
            if isinstance(control,Gtk.ComboBox):control.set_active(-1)
            else:control.set_active(False);control.set_inconsistent(True)
        # Never substitute USB stream rate or retain another UID's feedback.
        for value in self.dante_status.values():value.set_text('Unavailable')
        feedback=((data or {}).get('hardware_settings') or {}).get('dante_status')
        if not applicable or not isinstance(feedback,dict) or feedback.get('schema')!=1:return
        status=feedback.get('status')
        if not isinstance(status,dict):return
        wc,madi=status.get('word_clock'),status.get('madi')
        if isinstance(wc,dict) and isinstance(madi,dict):
            self.dante_status['bnc_in'].set_text('WCK: '+str(wc.get('state') or 'Unavailable')+' · MADI: '+str(madi.get('state') or 'Unavailable'))
            def rate(row):
                hz=row.get('rate_hz')
                return f'{hz} Hz' if type(hz) is int and hz>0 else '—'
            self.dante_status['input_rate'].set_text('WCK: '+rate(wc)+' · MADI: '+rate(madi))
            if madi.get('state')=='No Lock':
                self.dante_status['input_format'].set_text('—')
            elif (madi.get('format') in ('64 channels','56 channels','32 channels','28 channels') and
                    madi.get('frame') in ('48K frame','96K frame')):
                self.dante_status['input_format'].set_text(madi['format']+', '+madi['frame'])
        hz=status.get('rate_hz')
        if type(hz) is int:self.dante_controls['network_rate'].set_active_id(str(hz))
        hardware=(data or {}).get('hardware_settings') or {}
        if hardware.get('native_domain')==linux_control.hardware_control.DANTE_DOMAIN:
            fields=hardware.get('fields') or {};snapshot=fields.get('digital')
            try:
                snapshot=digital_control.validate(snapshot)
                descriptors={r['id']:r for r in snapshot['fields']}
                for key,control in self.dante_controls.items():
                    descriptor=descriptors.get(key)
                    if not descriptor:continue
                    value=snapshot['values'].get(key)
                    if isinstance(control,Gtk.ComboBox):
                        control.remove_all()
                        for option in descriptor['choices']:control.append(str(option['id']),option['label'])
                        control.set_active_id(str(value) if value is not None else None)
                    else:
                        control.set_active(value==1);control.set_inconsistent(value is None)
                    control.set_sensitive(bool(fields.get('can_set_digital') and descriptor.get('available') is True and value is not None and not self._control_busy))
                self._dante_snapshot=snapshot;self._dante_context=(data.get('uid'),data.get('marker'))
                prefs=feedback.get('preferences') or {}
                message={'native_defaults':'Native defaults, not yet applied. Editing a local option applies the complete local preference set.',
                    'saved':'Saved local preferences; these values are not a hardware register readback.',
                    'unconfirmed':'Last local transfer is unconfirmed. An explicit local edit reapplies the full preference set; no automatic retry.'}.get(prefs.get('provenance'),'Local preference provenance is unavailable.')
                self.dante_note.set_text(message+(' Changes apply immediately.' if fields.get('can_set_digital') else ' '+str(fields.get('digital_reason') or fields.get('hardware_reason') or 'Settings are read-only.')))
            except (ValueError,KeyError,TypeError):
                for control in self.dante_controls.values():control.set_sensitive(False)
        network=status.get('network')
        if not isinstance(network,dict):return
        for key in ('preferred_leader','external_sync'):
            value=network.get(key)
            if type(value) is bool:
                self.dante_controls[key].set_active(value);self.dante_controls[key].set_inconsistent(False)
        mode=network.get('mode')
        if mode in ('Switched','Redundancy'):
            self.dante_status['mode'].set_text(mode+(' - AES67' if network.get('aes67') is True else '')+(' - muted' if network.get('muted') is True else ''))
        clock=network.get('clock')
        if clock in ('Local','Leader','Follower'):
            self.dante_status['clock'].set_text(clock+(' - WCK/MADI synced' if network.get('external_synced') is True else ''))
        for key in ('primary','secondary'):
            link=network.get(key)
            if key=='secondary' and mode=='Switched':self.dante_status[key].set_text('—');continue
            if not isinstance(link,dict):continue
            ip,mac=link.get('ipv4'),link.get('native_mac_word')
            if any(not isinstance(v,list) or len(v)!=4 or any(type(b) is not int or not 0<=b<=255 for b in v) for v in (ip,mac)):continue
            if link.get('state') not in ('','down','100 MBit','1 GBit'):continue
            self.dante_status[key].set_text(link['state']+', IP '+'.'.join(map(str,ip))+', Mac '+'.'.join(f'{b:02X}' for b in mac))

    def dante_edited(self,control,key):
        if not self._alive or self._render_depth or self._control_busy or not control.is_sensitive():return
        current=self._linux_status or {};hardware=current.get('hardware_settings') or {}
        if hardware.get('native_domain')!=linux_control.hardware_control.DANTE_DOMAIN or self._dante_context!=(current.get('uid'),current.get('marker')) or self._dante_snapshot is None:return
        if isinstance(control,Gtk.ComboBox):
            selected=control.get_active_id()
            if selected is None:return
            value=int(selected)
        else:
            if control.get_inconsistent():return
            value=int(control.get_active())
        snapshot=self._dante_snapshot
        if snapshot['values'].get(key)==value:return
        uid,marker=current['uid'],current['marker']
        self.perform_change(lambda:linux_control.hardware_control.change(uid,marker,'digital',snapshot=snapshot,changes={key:value}))

    def selector(self, parent, caption, choices, callback):
        widgets = Gtk.Box(spacing=6)
        choice = Gtk.ComboBoxText()
        for key, label in choices:
            choice.append(key, label)
        button = Gtk.Button(label="Apply")
        widgets.pack_start(choice, False, False, 0)
        choice.connect('changed', self.choice_edited, callback)
        self.row(parent, caption, widgets)
        return choice, button

    def choice_edited(self, choice, callback):
        if (not self._alive or self._render_depth or self._control_busy or
                not choice.is_sensitive() or choice.get_active_id() is None):
            return
        callback()

    def refresh(self):
        if not self._alive:
            return False
        if self._busy or self._control_busy:
            return True
        self._busy = True
        selected = self._selected_uid
        epoch = self._status_epoch
        def work():
            try:
                actual_selection = selection_control.current()
                common_error = None
                try:
                    inventory = linux_control.status()['devices']
                except (ValueError, OSError, RuntimeError, TypeError, KeyError) as error:
                    inventory = []
                    common_error = str(error)
                choices = [dict(uid=r['uid'], label=r['model'] + ' · ' + r['uid'], legacy=r.get('native') is False) for r in inventory]
                wanted = actual_selection or selected or (inventory[0]['uid'] if inventory else None)
                common = next((r for r in inventory if r['uid'] == wanted), None) if wanted else next((r for r in inventory if r.get('native') is False), None)
                if wanted and (common is None or common.get('native') is not False):
                    data = dict(common) if common else dict(native=True, uid=wanted, state='unavailable', nodes=[], can_apply=False, error=common_error or 'Selected card is disconnected')
                else:
                    data = driver_status.collect()
                data['_linux_status'] = common
                data['_linux_error'] = common_error
                data['_selection_uid'] = wanted
                data['_selection_requested'] = selected
                data['_native_devices'] = choices
                GLib.idle_add(self.accept_status, epoch, data, None)
            except Exception as error:
                GLib.idle_add(self.accept_status, epoch, None, str(error))
        threading.Thread(target=work, daemon=True).start()
        return True

    def accept_status(self, epoch, data, error):
        self._busy = False
        if not self._alive:
            return False
        if epoch != self._status_epoch:
            # A pre-command snapshot/error is never post-command readback.
            self.refresh()
            return False
        if error is not None:
            return self.failed(error)
        return self.update(data)

    @model_update
    def update(self, data):
        self._busy = False
        if not self._alive or self._control_busy:
            return False
        if data.get('_selection_requested',data.get('_selection_uid')) != self._selected_uid:
            self.refresh()
            return False
        if data.get('_selection_uid') != self._selected_uid:self._use_uid(data.get('_selection_uid'))
        self.update_device_choices(data.get('_native_devices', []))
        self._linux_status = data.get('_linux_status')
        self.update_dante_page(self._linux_status or data)
        if self._selected_uid and data.get('native') is not False and not (self._linux_status and self._linux_status.get('native') is False):
            self._linux_status = self._linux_status or data
            return self.update_native(data)
        self.banner.set_text(data["state"])
        diagnosis = data.get("failure_reason") or data.get("node_error") or data.get("hardware_status_error") or data.get("digital_error") or data.get("buffer_error") or data.get("recovery_rate_error") or ""
        self.diagnosis.set_text(diagnosis)
        self.diagnosis.set_visible(bool(diagnosis))
        pw, progress, devices = data["pipewire"], data["progress"] or {}, data["usb_devices"]
        alsa = data.get("audio_backend") == "alsa"
        timing = data.get("timing")
        hz = lambda n: f"{n:,} Hz" if n else "Unavailable"
        values = {
            "rate": hz(data["sample_rate"]), "clock": data.get("clock_source") or "Unavailable",
            "recovery_rate": hz(data.get("recovery_rate_hz")) + " · Internal only",
            "pw_rate": hz(pw["rate"]),
            "quantum": f'{pw["quantum"]} frames' + (f' · {pw["block_ms"]} ms' if pw["block_ms"] else "") if pw["quantum"] else "Unavailable",
            "channels": f'{data["channels_in"]} in / {data["channels_out"]} out' if data["channels_in"] else "Unavailable",
            "version": data["version"], "autostart": "Enabled" if data.get("autostart") else "Not enabled",
            "usb": devices[0]["speed_mbps"] + " Mbit/s" if len(devices) == 1 else "Not uniquely connected",
            "revision": devices[0]["usb_revision"] if len(devices) == 1 else "—",
            "firmware": str((data.get("digital") or {}).get("firmware_revision") or "Unavailable"), "transport": data.get("input_transport") or "Unavailable",
            "madi_current": (data.get("digital") or {}).get("current_madi_input", "Unavailable"),
            "digital_bus": data.get("input_transport") or "Unavailable",
            "crc": self.crc_status(data), "midi": "Running · 4 ports" if data.get("midi", {}).get("active") else data.get("midi", {}).get("state", "Unavailable"),
            "stream_rate": hz(data.get("stream_rate_hz")),
            "elapsed": f'{progress["uptime_s"]} s' if progress else "—",
            "input": f'{progress["input_bytes"] / 1024**3:.3f} GiB' if progress else "—",
            "output": f'{progress["output_completions"]:,}' if progress else "—",
            "freshness": f'{progress["age_s"]:.0f} s · report interval 10 s' if progress else "No current report",
            "queue": "32 transfers / direction · ~32 ms",
            "hardware_buffer": "Not exposed", "attenuation": "0 dB · unity gain",
        }
        for name in driver_status.INPUT_NAMES:
            values[name + "state"] = "—"
            values[name + "rate"] = "—"
        for row in data.get("input_lock_sync") or []:
            values[row["name"] + "state"] = row["state"]
            values[row["name"] + "rate"] = hz(row.get("carrier_rate_hz")) if row["state"] != "No Lock" else "—"
        observed = (f'{timing["callback_min_frames"]}–{timing["callback_max_frames"]} frames'
                    if timing else "Unavailable")
        if alsa:
            values["pw_rate"] = "Not used · ALSA backend"
            values["quantum"] = "ALSA periods negotiated by application"
        elif timing:
            values["quantum"] += " · observed " + observed
        self.labels["quantum"].set_tooltip_text("Observed playback callbacks: " + observed +
            ". PipeWire metadata, application periods and hardware buffer are separate quantities.")
        self.labels["queue"].set_tooltip_text(
            f'Playback queued: {timing["queued_frames"]} frames; missing while running: {timing["running_underrun_frames"]}; capture missing: {timing["capture_missing_frames"]}.'
            if timing else "Live queue measurements unavailable; displayed value is host USB capacity.")
        for key, value in values.items():
            self.labels[key].set_text(value)
        for choice, button, can_set in (
                (self.rate_choice, self.rate_apply, data.get("can_set_rate")),
                (self.source_choice, self.source_apply, data.get("can_set_clock")),
                (self.buffer_choice, self.buffer_apply, data.get("can_set_buffer"))):
            choice.set_sensitive(bool(can_set))
            button.set_sensitive(bool(can_set))
        if not self.rate_choice.get_active_id() and data["sample_rate"]:
            self.rate_choice.set_active_id(str(data["sample_rate"]))
        selected = data.get("selected_clock_source")
        if not self.source_choice.get_active_id() and selected in clock_control.SOURCES:
            self.source_choice.set_active_id(str(clock_control.SOURCES.index(selected)))
        frames = data.get("buffer_frames")
        if not self.buffer_choice.get_active_id() and frames is not None:
            self.buffer_choice.set_active_id(str(frames))
        saved = "Unavailable" if frames is None else (str(frames) + " frames" if frames else "Auto")
        self.buffer_note.set_text("ALSA applications negotiate their own periods and buffers." if alsa else
            data.get("buffer_error") or "Saved request: " + saved + " · shared graph; not a hardware buffer.")
        self.update_node_controls(self._linux_status or {})
        self.labels['internal_rate'].set_text(hz(data.get('internal_rate_hz')))
        self._set_clock_sources(tuple(enumerate(clock_control.SOURCES)), data.get('selected_clock_source'))
        self.source_note.set_text('Selected preference: ' + str(data.get('selected_clock_source') or 'Unavailable'))
        self._update_input_status(data.get('input_lock_sync') or [])
        self.update_digital(data)
        self.update_audio_status(self._linux_status, data)
        self.update_linux_controls(self._linux_status)
        return False

    @model_update
    def _set_clock_sources(self, options, selected, selected_id=None):
        if getattr(self, '_clock_options', None) != options:
            self.source_choice.remove_all()
            for key, label in options:
                self.source_choice.append(str(key), label)
            self._clock_options = options
        if self.source_choice.get_active_id() is None:
            chosen = selected_id if selected_id is not None else next((key for key, label in options if label == selected), None)
            if chosen is not None:
                self.source_choice.set_active_id(str(chosen))

    def _update_input_status(self, rows):
        for widget in self._input_rows:
            widget.destroy()
        self._input_rows = []
        for index, row in enumerate(rows, 1):
            name = row.get('label', row.get('name'))
            carrier = row.get('carrier_rate_hz')
            text = (name, row['state'], f'{carrier:,} Hz' if carrier and row['state'] not in ('No Lock', 'Unknown') else '—')
            for column, value in enumerate(text):
                label = Gtk.Label(label=value, xalign=0)
                label.set_hexpand(True)
                self.input_grid.attach(label, column, index, 1, 1)
                self._input_rows.append(label)
                if column:
                    self.labels[name + ('state' if column == 1 else 'rate')] = label
        self.input_grid.show_all()

    @model_update
    def _set_digital_fields(self, rows):
        key = tuple((row['id'], row['label'], row['group']) for row in rows)
        if key == self._digital_rows_key:
            return
        for widget in self.digital_fields_box.get_children():
            widget.destroy()
        self.digital_controls.clear(); self.digital_current.clear()
        groups = {}
        sizes = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.HORIZONTAL)
        for row in rows:
            key, title = row['id'], row['group']
            if title not in groups:
                groups[title] = self.section(self.digital_fields_box, title, [])
            control = Gtk.ComboBoxText(); sizes.add_widget(control)
            control.set_sensitive(False)
            control.connect('changed', self.digital_edited, key)
            current = Gtk.Label(label='Unavailable', xalign=1)
            current.get_style_context().add_class('dim-label')
            widgets = Gtk.Box(spacing=8)
            widgets.pack_start(current, False, False, 0)
            widgets.pack_start(control, False, False, 0)
            self.row(groups[title], row['label'], widgets)
            self.digital_controls[key] = control; self.digital_current[key] = current
        self._digital_rows_key = tuple((row['id'], row['label'], row['group']) for row in rows)
        self.digital_fields_box.show_all()

    @model_update
    def update_digital(self, data):
        snapshot = data.get("digital")
        self._digital_snapshot = snapshot
        self._digital_can_set = bool(data.get("can_set_digital"))
        conflict = bool(self._digital_pending and snapshot and self._digital_base and
                        digital_control.settings_identity(snapshot) != digital_control.settings_identity(self._digital_base))
        self._digital_loading = True
        rows = snapshot.get('fields') if snapshot else []
        if snapshot is not None and rows is None:
            rows = [dict(id=key, label=label, group=title,
                         choices=[dict(id=i, label=value) for i, value in enumerate(digital_control.choices(key, snapshot.get('modern_optical')))])
                    for title, options in digital_control.GROUPS for key, label, _ in options]
        self._set_digital_fields(rows)
        domains = {row['id']: row for row in rows}
        # Hardware status follows admitted functions, including on cards that
        # have no MADI connector. Transport status remains visible.
        madi = self.labels['madi_current'].get_parent()
        madi.set_no_show_all('madi_input' not in domains)
        madi.set_visible('madi_input' in domains)
        if snapshot and self._digital_pending and not digital_control.selections_valid(snapshot, self._digital_pending):
            conflict = True
        for key, control in self.digital_controls.items():
            actual = snapshot["values"].get(key) if snapshot else None
            options = tuple((item['id'], item['label']) for item in domains[key]['choices'])
            if getattr(control, "_digital_options", None) != options:
                control.remove_all()
                for index, label in options:
                    control.append(str(index), label)
                control._digital_options = options
            self.digital_current[key].set_text("Now: " + dict(options)[actual] if actual is not None else "Unavailable")
            selected = self._digital_pending.get(key, actual)
            if selected is not None and selected in dict(options):
                control.set_active_id(str(selected))
            else:
                control.set_active(-1)
            control.set_sensitive(self._digital_can_set and actual is not None and not self._control_busy)
        self._digital_loading = False
        self.digital_apply.set_sensitive(bool(self._digital_pending) and self._digital_can_set and not conflict and not self._control_busy)
        self.digital_discard.set_sensitive(bool(self._digital_pending) and not self._control_busy)
        self.digital_note.set_text("Hardware changed — discard and review before applying." if conflict else
            data.get("digital_error") or data.get('digital_reason') or data.get('hardware_reason') or ("Applying change · waiting for hardware confirmation." if self._digital_pending else
            "Hardware readback · changes apply immediately." if snapshot and self._digital_can_set else
            "Read-only · changes are not admitted for the current card session." if snapshot else "Hardware readback unavailable."))

    def digital_edited(self, control, key):
        if (self._render_depth or self._digital_loading or self._control_busy or
                not control.is_sensitive() or not self._digital_snapshot):
            return
        value = control.get_active_id()
        if value is None:
            return
        if not self._digital_pending:
            self._digital_base = self._digital_snapshot
        if int(value) == self._digital_base["values"][key]:
            self._digital_pending.pop(key, None)
        else:
            self._digital_pending[key] = int(value)
        self.update_digital({"digital": self._digital_snapshot, "can_set_digital": self._digital_can_set})
        self.set_digital()

    def discard_digital(self, *_):
        self._digital_pending.clear()
        self._digital_base = None
        self.refresh()

    def set_digital(self, *_):
        if not self._digital_pending or self._control_busy:
            return
        snapshot, pending = self._digital_base, dict(self._digital_pending)
        current=self._linux_status
        if current and current.get('native'):
            if not ((current.get('hardware_settings') or {}).get('fields') or {}).get('can_set_digital'):return
            uid,marker=current['uid'],current['marker']
            self.perform_change(lambda: linux_control.hardware_control.change(uid,marker,'digital',snapshot=snapshot,changes=pending))
        elif self._digital_can_set:
            self.perform_change(lambda: digital_control.change(snapshot, pending))

    @model_update
    def failed(self, message):
        self._busy = False
        if self._alive:
            self.banner.set_text("Status unavailable: " + message[:100])
            for widget in (self.rate_choice, self.rate_apply, self.buffer_choice, self.buffer_apply, self.backend_choice, self.backend_apply, self.source_choice, self.source_apply):
                widget.set_sensitive(False)
            self.nodes_apply.set_sensitive(False)
            for check in self._all_node_switches():
                check.set_sensitive(False)
            self.update_digital({"digital_error": message})
        return False

    def set_rate(self, *_):
        current = self._linux_status
        value = self.rate_choice.get_active_id()
        if self._control_busy or not current or not current.get('can_apply') or value is None:
            return
        uid, marker, rate = current['uid'], current['marker'], int(value)
        self.perform_change(lambda: linux_control.change_rate(uid, marker, rate))

    def set_buffer(self, *_):
        value = self.buffer_choice.get_active_id()
        if value is not None:
            self.change_linux({'buffer_frames': int(value)})

    def set_backend(self, *_):
        value = self.backend_choice.get_active_id()
        if value is not None:
            self.change_linux({'backend': value})

    def change_linux(self, request):
        current = self._linux_status
        if self._control_busy or not current or not current.get('can_apply'):
            return
        uid, marker = current['uid'], current['marker']
        self.perform_change(lambda: linux_control.apply(uid, marker, request))

    def set_source(self, *_):
        current=self._linux_status
        if current and current.get('native'):
            selected=self.source_choice.get_active_id()
            if self._control_busy or selected is None or not ((current.get('hardware_settings') or {}).get('fields') or {}).get('can_set_clock'):return
            uid,marker,source=current['uid'],current['marker'],int(selected)
            self.perform_change(lambda: linux_control.hardware_control.change(uid,marker,'clock_source',source=source))
        elif self.source_apply.get_sensitive():
            self.change(self.source_choice, clock_control.change)

    def change(self, choice, callback):
        if self._selected_uid and not (self._linux_status and self._linux_status.get('native') is False):
            return
        selected = choice.get_active_id()
        if self._control_busy or selected is None:
            return
        self.perform_change(lambda: callback(int(selected)))

    def _all_node_switches(self):
        return list(self.node_switches.values()) + list(self.category_switches.values())

    def nodes_edited(self, *_):
        if self._render_depth or self._nodes_updating or self._control_busy:
            return
        current = self._linux_status or {}
        if not self._nodes_dirty and self._node_mode == 2:
            try:self._node_draft_context = node_view.context(current)
            except ValueError:return
        self._nodes_dirty = True
        self.nodes_apply.set_sensitive(bool(current.get('can_apply')))
        if self._node_mode == 2:self._category_sensitivity(current)
        self.set_nodes()

    def set_nodes(self, *_):
        current = self._linux_status
        if not current or not current.get('can_apply') or self._control_busy:
            return
        if self._node_mode == 2:
            try:
                desired=node_view.selection(current)
                for row in node_view.categories(current):
                    entry=desired['categories'][row['category']]
                    entry['enabled']=self.category_switches[row['category']].get_active()
                    for direction in ('capture','playback'):
                        for port in row[direction]:
                            entry[direction][str(port['native_channel'])]=self.node_switches[(row['category'],direction,port['native_channel'])].get_active()
                request=node_view.request(current,desired,self._node_draft_context)
            except ValueError as error:
                self._nodes_dirty=False;self._node_draft_context=None
                self.node_note.set_text(str(error));self.nodes_apply.set_sensitive(False)
                self.refresh();return
            self.change_linux(request)
        else:
            enabled = {row['name']: self.node_switches[(row['direction'],row['index'])].get_active()
                       for row in current['nodes']}
            self.change_linux({'enabled': enabled})

    @model_update
    def update_device_choices(self, choices):
        if choices == self._device_choices and self.device_choice.get_active_id()==(self._selected_uid or 'legacy'):
            return
        self._device_choices = choices
        self._updating_devices = True
        self.device_choice.remove_all()
        legacy = next((row['uid'] for row in choices if row.get('legacy')),None)
        if legacy is None:
            self.device_choice.append('legacy', 'Fireface UFX+ · historical service')
        for row in choices:
            self.device_choice.append(row['uid'], row['label'])
        if self._selected_uid and not any(r['uid'] == self._selected_uid for r in choices):
            self.device_choice.append(self._selected_uid, self._selected_uid + ' · disconnected')
        self.device_choice.set_active_id(self._selected_uid or legacy or 'legacy')
        self._updating_devices = False

    def device_changed(self, choice):
        if self._render_depth or self._updating_devices:
            return
        selected = choice.get_active_id()
        if selected is None:
            return
        if selected == 'legacy':return
        self.perform_change(lambda: selection_control.select(selected,linux_control.status()['devices']))

    @model_update
    def _use_uid(self, uid):
        self._status_epoch += 1
        self._selected_uid = uid
        self._rate_marker = None
        self.rate_choice.set_active(-1)
        self._native_marker = None
        self._hardware_marker = None
        self._linux_status = None
        self.update_dante_page(None)
        self._digital_pending.clear();self._digital_base=None;self._digital_snapshot=None;self._digital_can_set=False
        self.source_choice.set_active(-1)
        self._nodes_dirty = False
        self._node_draft_context = None
        self.backend_choice.set_active(-1)
        self.buffer_choice.set_active(-1)
        self.nodes_apply.set_sensitive(False)
        native = self._selected_uid is not None
        self.set_title('RME USB Settings' if native else 'UFX+ USB Settings')
        self.device_title.set_text(uid if native else 'Fireface UFX+ · USB3')
        self.page_containers['Clock & Audio'].set_sensitive(True)
        self.page_containers['Digital I/O'].set_sensitive(not native)
        for widget in (self.rate_choice,self.rate_apply,self.source_choice,self.source_apply,self.backend_apply,self.buffer_apply):
            widget.set_sensitive(False)
        for label in self.labels.values():
            label.set_text('—')
        if native:
            self.notebook.set_current_page(0)
        else:
            self.node_note.set_text('Applying briefly restarts audio. Removed nodes lose their links; applications or your patchbay may need to reconnect. Disabled outputs send silence, but hardware direct monitoring is unchanged.')

    @model_update
    def build_node_rows(self, rows):
        keys = {(row['direction'], row['index']) for row in rows}
        if keys == set(self.node_switches):
            return
        self._nodes_dirty = False
        for box in self.node_groups.values():
            # Section titles now belong to the frame,not the row container.
            for child in box.get_children():
                child.destroy()
        self.node_switches, self.node_presence = {}, {}
        for row in rows:
            key = (row['direction'], row['index'])
            check = Gtk.CheckButton(label=row['label'])
            check.connect('toggled', self.nodes_edited)
            present = Gtk.Label(label='Checking…')
            line = Gtk.Box(spacing=8)
            line.pack_start(check, True, True, 0)
            line.pack_end(present, False, False, 0)
            self.node_groups[row['direction']].pack_start(line, False, False, 0)
            self.node_switches[key], self.node_presence[key] = check, present
            line.show_all()

    def select_uid(self, uid):
        linux_control.uid_check(uid)
        with_selection = list(self._device_choices)
        if not any(r['uid'] == uid for r in with_selection):
            with_selection.append(dict(uid=uid,label=uid))
        self.update_device_choices(with_selection)
        self.device_choice.set_active_id(uid)

    def update_rate_note(self, data):
        data = data or {}
        change = data.get('rate_change') or {}
        if data.get('state') == 'rate_changing':
            self.rate_note.set_text(f"Changing this interface to {change.get('requested_rate_hz', '?'):,} Hz · {change.get('phase', 'waiting')}…")
            return
        if change.get('phase') == 'error':
            self.rate_note.set_text(str(change.get('error') or 'Frequency change not confirmed'))
            return
        value = self.rate_choice.get_active_id()
        try:
            target = linux_control.rate_format(data, int(value)) if value else None
        except (RuntimeError, ValueError, TypeError):
            target = None
        if target:
            self.rate_note.set_text(f"{target['capture_channels']} active inputs / {target['playback_channels']} outputs at {target['rate'] / 1000:g} kHz · changes apply immediately")
        else:
            self.rate_note.set_text('Native frequency selection unavailable for this session')

    @model_update
    def update_rate_controls(self, data):
        data = data or {}
        caps = data.get('rate_capabilities') or {}
        rates = tuple(caps.get('rates') or [])
        if rates != self._rate_options:
            self._rate_options = rates
            self.rate_choice.remove_all()
            for hz in rates:
                if type(hz) is int and hz > 0:
                    self.rate_choice.append(str(hz), f'{hz / 1000:g} kHz')
        marker = data.get('marker') or {}
        key = (data.get('uid'), data.get('rate'), marker.get('worker_pid'), marker.get('worker_process_start'))
        if key != self._rate_marker:
            self._rate_marker = key
            self.rate_choice.set_active_id(str(data.get('rate')))
        ready = bool(data.get('can_apply') and rates and caps.get('policy') != 'verify_only')
        hardware=data.get('hardware_settings') or {}
        if hardware.get('dante_status'):
            fields=(hardware.get('native_capabilities') or {}).get('digital_fields') or []
            ready=bool(ready and (hardware.get('fields') or {}).get('can_set_digital') and any(r.get('id')=='network_rate' and r.get('available') is True for r in fields))
        self.rate_choice.set_sensitive(ready)
        self.rate_apply.set_sensitive(ready)
        self.update_rate_note(data)

    @model_update
    def update_linux_controls(self, data):
        capable = bool(data and data.get('can_apply'))
        options = tuple((data or {}).get('settings_capabilities',{}).get('backends',[]))
        if options != self._backend_options:
            self.backend_choice.remove_all()
            for backend in options:
                self.backend_choice.append(backend, {'alsa':'ALSA', 'pipewire':'PipeWire', 'pipewire+alsa':'PipeWire + ALSA'}[backend])
            self._backend_options = options
        settings = (data or {}).get('settings') or {}
        applied = (data or {}).get('applied') or {}
        if self.backend_choice.get_active_id() is None and settings.get('backend'):
            self.backend_choice.set_active_id(settings['backend'])
        if self.buffer_choice.get_active_id() is None and settings.get('buffer_frames') is not None:
            self.buffer_choice.set_active_id(str(settings['buffer_frames']))
        for widget in (self.backend_choice,self.backend_apply,self.buffer_choice,self.buffer_apply):
            widget.set_sensitive(capable)
        self.backend_note.set_text('Applied: ' + str(applied.get('backend') or 'not confirmed') +
                                   (' · requested: ' + settings['backend'] if settings.get('backend') != applied.get('backend') and settings.get('backend') else ''))
        frames = settings.get('buffer_frames')
        confirmed = applied.get('buffer_frames')
        self.buffer_note.set_text(('Saved for return to PipeWire: ' if applied.get('backend') == 'alsa' else 'PipeWire stream request: ') + ('Auto' if frames == 0 else str(frames) + ' frames' if frames is not None else 'unavailable') +
                                  ('' if applied.get('backend') == 'alsa' else ' · confirmed' if frames is not None and confirmed == frames else ' · not confirmed') +
                                  '. ALSA applications choose their own periods.')
        if not data:
            self.nodes_apply.set_sensitive(False)
        self.update_rate_controls(data)
        return capable

    def crc_status(self, data):
        feedback=(data.get('hardware_settings') or {}).get('dante_status')
        value=None
        marker=data.get('marker') or {}
        attachment=marker.get('attachment') or {}
        context=None
        if isinstance(feedback,dict) and feedback.get('schema')==1:
            status=feedback.get('status')
            if isinstance(status,dict):value=status.get('crc_counter_mod32')
            if all(isinstance(v,str) and v for v in (data.get('uid'),attachment.get('connection_marker'),attachment.get('descriptor_sha256'))):
                # Snapshot the full owner identity: a mutable marker cannot move
                # a previous observation into another generation or attachment.
                context=(data['uid'],json.dumps(marker,sort_keys=True))
        total=self._crc_counter.observe(context,value)
        return (f'{total} · since observation started' if total is not None else
                'Unavailable' if isinstance(feedback,dict) else 'Not exposed')

    @model_update
    def update_native(self, data):
        self.update_dante_page(data)
        if getattr(self, '_hardware_marker', None) != data.get('marker'):
            self._hardware_marker = data.get('marker')
            self._digital_pending.clear(); self._digital_base = None
            self.source_choice.set_active(-1)
        self.node_note.set_text("Selection changes only this card's PipeWire nodes. USB and ALSA keep running. Removed nodes lose their links.")
        self.update_node_controls(data)
        self.page_containers['Digital I/O'].set_sensitive(False)
        for widget in (self.rate_choice,self.rate_apply,self.source_choice,self.source_apply):
            widget.set_sensitive(False)
        values = {'clock':'Hardware clock settings unavailable', 'recovery_rate':'Not requested',
                  'usb':'Native RME · ' + data['state'], 'version':'Common Linux audio owner',
                  'transport':'Native RME USB', 'firmware':'Not reported', 'revision':'Not reported',
                  'autostart':'Managed per connection', 'elapsed':'Not reported', 'input':'Not reported',
                  'output':'Not reported', 'queue':'Not measured', 'hardware_buffer':'Not exposed',
                  'attenuation':'Hardware mixer state', 'crc':self.crc_status(data)}
        for key,value in values.items(): self.labels[key].set_text(value)
        self.update_audio_status(data)
        self.update_linux_controls(data)
        hardware=data.get('hardware_settings') or {};fields=hardware.get('fields') or {}
        self.page_containers['Digital I/O'].set_sensitive(True)
        self.page_containers['Digital I/O'].set_visible(hardware.get('native_domain')!=linux_control.hardware_control.DANTE_DOMAIN)
        reason = fields.get('hardware_reason') or data.get('hardware_settings_error') or 'Detailed hardware settings are unavailable for this interface.'
        self.update_digital(fields or {'digital_error':reason})
        available=bool(fields.get('can_set_clock'))
        self.source_choice.set_sensitive(available and not self._control_busy);self.source_apply.set_sensitive(available and not self._control_busy)
        selected=fields.get('selected_clock_source')
        sources = hardware.get('clock_sources') or []
        # Historical envelopes remain readable, but no source list is guessed
        # for an unsupported native card.
        if not sources and hardware.get('codec') == 'ufxplus_runtime_settings':
            sources = list(clock_control.SOURCES)
        self._set_clock_sources(clock_control.source_choices(sources) if sources else (), selected, fields.get('selected_clock_source_id'))
        self.source_note.set_text(('Audio is stopped; a confirmed Internal preference is required to resume. ' if data.get('state')=='clock_idle' else '') +
                                 ('Selected preference: ' + selected + ' · ' if selected else '') +
                                 (fields.get('clock_source_reason') or fields.get('hardware_reason') or
                                  ('Changes apply immediately.' if available else reason)))
        if hardware.get('native_domain')==linux_control.hardware_control.DANTE_DOMAIN:
            self.source_note.set_text('Dante clock is controlled in the Dante tab. Network clock options are available only while the network is down.')
        self._update_input_status(fields.get('input_lock_sync') or [])
        nominal = fields.get('internal_rate_hz')
        selected_rate = fields.get('reference_selected_rate_hz')
        reference = f'{nominal:,} Hz · nominal reference' if nominal else 'Unavailable'
        if selected_rate is not None:
            reference += f' · selected reference {selected_rate:,} Hz'
        self.labels['internal_rate'].set_text(reference)
        if fields:
            self.labels['clock'].set_text(fields.get('clock_source') or 'Unavailable')
            self.labels['transport'].set_text(fields.get('input_transport') or 'Unavailable')
            self.labels['digital_bus'].set_text(fields.get('input_transport') or 'Unavailable')
            digital=fields.get('digital') or {}
            self.labels['firmware'].set_text(str(digital.get('firmware_revision') or 'Unavailable'))
            self.labels['madi_current'].set_text(digital.get('current_madi_input') or 'Unavailable')
        return False

    @model_update
    def build_category_rows(self, rows, context):
        signature=(context[:2] if context else None,node_view.signature(rows))
        if self._node_mode == 2 and signature == self._node_layout_signature:
            return
        for child in self.category_box.get_children():child.destroy()
        self.node_switches={};self.node_presence={};self.category_switches={};self.category_presence={}
        self._node_mode=2;self._node_layout_signature=signature
        for row in rows:
            frame=Gtk.Frame(label=row['label']);body=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=6);body.set_border_width(8);frame.add(body)
            header=Gtk.Box(spacing=8);check=Gtk.CheckButton(label='Expose this category');check.connect('toggled',self.nodes_edited);header.pack_start(check,True,True,0)
            present=Gtk.Label(xalign=1);header.pack_end(present,False,False,0);body.pack_start(header,False,False,0)
            self.category_switches[row['category']]=check;self.category_presence[row['category']]=present
            columns=Gtk.Box(spacing=8);body.pack_start(columns,True,True,0)
            for direction,label in (('capture','Inputs · Capture'),('playback','Outputs · Playback')):
                column=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4);column.pack_start(Gtk.Label(label=label,xalign=0),False,False,0)
                scroll=Gtk.ScrolledWindow();scroll.set_policy(Gtk.PolicyType.AUTOMATIC,Gtk.PolicyType.AUTOMATIC);scroll.set_min_content_height(min(210,max(42,42*min(5,max(len(row['capture']),len(row['playback']))))));scroll.set_max_content_height(260)
                ports=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=2);scroll.add(ports);column.pack_start(scroll,True,True,0);columns.pack_start(column,True,True,0)
                if not row[direction]:ports.pack_start(Gtk.Label(label='No channels in this direction',xalign=0),False,False,0)
                for port in row[direction]:
                    key=(row['category'],direction,port['native_channel']);check=Gtk.CheckButton(label=f"{port['native_channel']} · {port['label']}");check.connect('toggled',self.nodes_edited)
                    present=Gtk.Label(xalign=0);line=Gtk.Box(orientation=Gtk.Orientation.VERTICAL);line.pack_start(check,False,False,0);line.pack_start(present,False,False,0);ports.pack_start(line,False,False,0)
                    self.node_switches[key]=check;self.node_presence[key]=present
            self.category_box.pack_start(frame,True,True,0);frame.show_all()

    def _category_sensitivity(self, data):
        try:bound=node_view.context(data) is not None
        except ValueError:bound=False
        allowed=bool(data.get('can_apply')) and not self._control_busy and bound
        for row in node_view.categories(data) or []:
            check=self.category_switches[row['category']]
            check.set_sensitive(allowed and any(p['available'] for d in ('capture','playback') for p in row[d]))
            for direction in ('capture','playback'):
                for port in row[direction]:self.node_switches[(row['category'],direction,port['native_channel'])].set_sensitive(allowed and check.get_active() and port['available'])

    @model_update
    def update_node_controls(self, data):
        try:categories=node_view.categories(data)
        except ValueError as error:
            self.node_note.set_text(str(error));self.nodes_apply.set_sensitive(False)
            for check in self._all_node_switches():check.set_sensitive(False)
            return
        if categories is not None:
            try:context=node_view.context(data)
            except ValueError:context=None
            changed=self._nodes_dirty and self._node_draft_context is not None and self._node_draft_context != context
            if changed:self._nodes_dirty=False;self._node_draft_context=None
            before_signature=self._node_layout_signature
            self.build_category_rows(categories,context)
            if before_signature != self._node_layout_signature:self._nodes_dirty=False;self._node_draft_context=None
            self.category_box.show()
            for box in self.node_groups.values():box.hide()
            self._nodes_updating=True
            for row in categories:
                if not self._nodes_dirty:self.category_switches[row['category']].set_active(row['enabled'])
                self.category_presence[row['category']].set_text('Visible' if row['present'] else 'Not published')
                for direction in ('capture','playback'):
                    for port in row[direction]:
                        key=(row['category'],direction,port['native_channel'])
                        if not self._nodes_dirty:self.node_switches[key].set_active(port['selected'])
                        self.node_presence[key].set_text(node_view.presence(port,(data.get('applied') or {}).get('backend')))
            self._nodes_updating=False;self._category_sensitivity(data)
            self.node_note.set_text(('The interface or settings changed; the draft was refreshed. ' if changed else '') + 'One PipeWire node per category, with its selected inputs and outputs. Unavailable choices remain saved. Removing a port removes its links; USB and ALSA keep running.')
            self.nodes_apply.set_sensitive(bool(data.get('can_apply')) and context is not None and self._nodes_dirty and not self._control_busy)
            return
        if self._node_mode != 1:
            self._node_mode=1;self._node_layout_signature=None;self._node_draft_context=None;self.node_switches={};self.node_presence={};self.category_switches={};self._nodes_dirty=False
        self.category_box.hide()
        for box in self.node_groups.values():box.show()
        rows = data.get('nodes', [])
        self.build_node_rows(rows)
        if not rows:
            self.node_note.set_text('PipeWire nodes are unavailable: '+str(data.get('error') or
                'the selected audio owner is '+data.get('state','unavailable'))+'. Selecting a card does not restart its audio session.')
        marker = data.get('marker')
        if self._native_marker != marker:self._nodes_dirty = False
        self._native_marker = marker
        dirty = self._nodes_dirty;self._nodes_updating=True
        for row in rows:
            key = (row['direction'], row['index']);check = self.node_switches[key]
            check.set_label(row['label'])
            if not dirty:check.set_active(row['enabled'])
            check.set_sensitive(bool(data.get('can_apply')) and not self._control_busy)
            self.node_presence[key].set_text('Visible' if row['present'] else 'Saved · ALSA only' if (data.get('applied') or {}).get('backend') == 'alsa' else 'Enabled — pending' if row['enabled'] else 'Disabled')
        self._nodes_updating=False;self._nodes_dirty = dirty
        self.nodes_apply.set_sensitive(bool(data.get('can_apply')) and dirty and not self._control_busy)

    def update_audio_status(self, data, legacy_details=None):
        """One validated state authority for both native and historical owners."""
        data = data or {}
        running = data.get('state') == 'running'
        error = data.get('error') or (data.get('settings_error') or {}).get('error') or data.get('hardware_settings_error') or ''
        if not data:
            error = (legacy_details or {}).get('_linux_error') or 'Common Linux device state is unavailable'
        detail_error = next(((legacy_details or {}).get(k) for k in
                             ('hardware_status_error','digital_error','recovery_rate_error')
                             if (legacy_details or {}).get(k)), '')
        self.banner.set_text((data.get('model') or 'RME') + ' · ' + data.get('state','unavailable'))
        self.diagnosis.set_text(' · '.join(e for e in (error,detail_error) if e))
        self.diagnosis.set_visible(bool(error or detail_error))
        rate = data.get('rate') if running else None
        capture = data.get('capture_channels') if running else None
        playback = data.get('playback_channels') if running else None
        alsa, pw, midi = (data.get(k) or {} for k in ('alsa','pipewire','midi'))
        applied = data.get('applied') or {}
        backend = applied.get('backend')
        observed = applied.get('observed_quantum_frames')
        values = {
            'rate':f'{rate:,} Hz · active USB session' if rate else 'Unavailable',
            'stream_rate':f'{rate:,} Hz' if rate else 'Unavailable',
            'channels':f'{capture} in / {playback} out' if capture and playback else 'Unavailable',
            'stream_backend':backend or 'Not confirmed',
            'alsa_status':('Ready · ' + str(alsa.get('card_id'))) if running and alsa.get('ready') else 'Not active',
            'pw_status':'Ready' if running and pw.get('ready') else 'Not active',
            'pw_rate':f"{pw['rate']:,} Hz · published streams" if running and pw.get('ready') and pw.get('rate') else 'Not active',
            'quantum':'ALSA clients choose their periods' if backend == 'alsa' else
                      f'{observed} frames · observed' if type(observed) is int else 'Stream request shown below · callback size not measured',
            'midi':('Ready' + (f" · {midi['ports']} ports" if midi.get('ports') is not None else '')) if midi.get('ready') else midi.get('state','Unavailable'),
            'freshness':'Owner and connection validated' if running else 'No current validated audio session',
        }
        for key,value in values.items():self.labels[key].set_text(value)
        self.labels['quantum'].set_tooltip_text('Measured callback size only when published by this owner; ALSA clients negotiate their own periods.')

    def perform_change(self, callback):
        if not self._alive or self._control_busy:
            return
        self._status_epoch += 1
        self._control_busy = True
        self.device_choice.set_sensitive(False)
        self.banner.set_text("Applying settings · stream may briefly pause…")
        for widget in (self.rate_choice, self.rate_apply, self.buffer_choice, self.buffer_apply, self.backend_choice, self.backend_apply, self.source_choice, self.source_apply):
            widget.set_sensitive(False)
        self.nodes_apply.set_sensitive(False)
        for check in self._all_node_switches():
            check.set_sensitive(False)
        for control in self.digital_controls.values():
            control.set_sensitive(False)
        for control in self.dante_controls.values():control.set_sensitive(False)
        self.digital_apply.set_sensitive(False)
        self.digital_discard.set_sensitive(False)
        def work():
            try:
                result = callback()
                if isinstance(result, dict) and result.get('ok') is False:
                    raise RuntimeError(result.get('error') or 'Settings change was not confirmed')
                message = ""
            except Exception as error:
                message = str(error)
            GLib.idle_add(self.control_finished, message)
        threading.Thread(target=work, daemon=True).start()

    @model_update
    def control_finished(self, message):
        self._control_busy = False
        if not self._alive:
            return False
        self.device_choice.set_sensitive(True)
        self._nodes_dirty = False
        # A rejected/uncertain command is not a pending draft to replay.
        self._digital_pending.clear()
        self._digital_base = None
        if self._alive:
            self.rate_choice.set_active(-1)
            self.buffer_choice.set_active(-1)
            self.backend_choice.set_active(-1)
            self.source_choice.set_active(-1)
            if message:
                dialog = Gtk.MessageDialog(transient_for=self, modal=True,
                    message_type=Gtk.MessageType.ERROR, buttons=Gtk.ButtonsType.CLOSE,
                    text="Settings change failed")
                dialog.format_secondary_text(message)
                dialog.run()
                dialog.destroy()
            self.refresh()
        return False

    def launch(self, args):
        try:
            subprocess.Popen(args)
        except OSError as error:
            self.failed(str(error))

    def close(self, *_):
        self._alive = False
        if hasattr(self, "_timer"):
            GLib.source_remove(self._timer)
        for handler in self._style_handlers:
            self._style_settings.disconnect(handler)
        self._style_handlers = []
        Gtk.StyleContext.remove_provider_for_screen(self.get_screen(), self._style_provider)


class SettingsApplication(Gtk.Application):
    def __init__(self, quit_after=0, uid=None):
        super().__init__(application_id="io.github.charlysound.UfxplusUsbSettings", flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.requested_uid = uid
        self.window = None
        self.quit_after = quit_after

    def do_activate(self):
        if self.window is None:
            self.window = Panel(application=self)
            self.window.connect("destroy", self.clear_window)
            if self.quit_after:
                GLib.timeout_add_seconds(self.quit_after, lambda: (self.quit(), False)[1])
        if self.requested_uid:
            self.window.select_uid(self.requested_uid)
            self.requested_uid = None
        self.window.present()

    def do_command_line(self, command_line):
        parser = argparse.ArgumentParser()
        parser.add_argument('--uid')
        parser.add_argument('--quit-after',type=int,default=0)
        try:
            args = parser.parse_args(command_line.get_arguments()[1:])
            if args.uid: linux_control.uid_check(args.uid)
        except (SystemExit,ValueError,RuntimeError):
            return 2
        self.requested_uid = args.uid or self.requested_uid
        self.activate()
        return 0

    def clear_window(self, *_):
        self.window = None


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--quit-after", type=int, default=0, help="GUI smoke-test duration in seconds")
    parser.add_argument('--uid',help='Open the selected RME card by stable UID')
    args = parser.parse_args()
    raise SystemExit(SettingsApplication(args.quit_after,args.uid).run(__import__('sys').argv))
