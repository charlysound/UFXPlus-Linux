// SPDX-License-Identifier: GPL-2.0
/* Common ALSA frontend for RME userspace USB engines. The USB completion
 * owner advances PCM positions; there is no software audio clock here.
 * Adapted from the existing UFX+ frontend, retaining its sample/ring rules.
 * Independent open files own independent cards and immutable generations.
 */
#include <linux/module.h>
#include <linux/device.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/compat.h>
#include <linux/mutex.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/vmalloc.h>
#if __has_include(<linux/unaligned.h>)
#include <linux/unaligned.h>
#else
#include <asm/unaligned.h>
#endif
#include <sound/core.h>
#include <sound/pcm.h>
#include <sound/pcm_params.h>
#include "rme_pcm_uapi.h"
#define MAX_FRAMES 32768
#define MAX_TRANSFER_FRAMES 4096
struct direction {
    struct mutex mutex;
    spinlock_t lock;
    struct snd_pcm_substream *substream;
    void *area;
    s32 *scratch;
    u64 frames, generation;
    bool running;
};
struct rme_chip {
    struct snd_card *card;
    struct snd_pcm *pcm;
    struct mutex configuration;
    struct direction dir[2];
    struct list_head entry;
    struct rme_pcm_setup_v1 setup;
    bool active;
    u32 rate, channels[2];
    u64 generation;
};
struct bridge_file { struct mutex mutex; struct rme_chip *chip; };
static DEFINE_MUTEX(cards_mutex);
static LIST_HEAD(cards);
static struct device *parent;
static const struct snd_pcm_hardware hardware = {
    .info = SNDRV_PCM_INFO_INTERLEAVED | SNDRV_PCM_INFO_MMAP |
            SNDRV_PCM_INFO_MMAP_VALID | SNDRV_PCM_INFO_BLOCK_TRANSFER | SNDRV_PCM_INFO_BATCH,
    .formats = SNDRV_PCM_FMTBIT_S32_LE | SNDRV_PCM_FMTBIT_S16_LE |
               SNDRV_PCM_FMTBIT_S24_LE | SNDRV_PCM_FMTBIT_S24_3LE,
    .rates = SNDRV_PCM_RATE_CONTINUOUS,
    .rate_min = 32000, .rate_max = 192000,
    .channels_min = 1, .channels_max = RME_PCM_MAX_CHANNELS,
    .buffer_bytes_max = MAX_FRAMES * RME_PCM_MAX_CHANNELS * 4,
    .period_bytes_min = 32 * 2, .period_bytes_max = 8192 * RME_PCM_MAX_CHANNELS * 4,
    .periods_min = 2, .periods_max = 1024,
};
static int pcm_open(struct snd_pcm_substream *s)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    int ret = 0;
    mutex_lock(&chip->configuration);
    if (!chip->active) { ret = -ENODEV; goto out; }
    s->runtime->hw = hardware;
    s->runtime->hw.channels_min = s->runtime->hw.channels_max = chip->channels[s->stream];
    s->runtime->hw.period_bytes_min = 32 * chip->channels[s->stream] * 2;
    s->runtime->hw.period_bytes_max = 8192 * chip->channels[s->stream] * 4;
    s->runtime->hw.buffer_bytes_max = MAX_FRAMES * chip->channels[s->stream] * 4;
    ret = snd_pcm_hw_constraint_single(s->runtime, SNDRV_PCM_HW_PARAM_RATE, chip->rate);
    if (ret < 0) goto out;
    ret = snd_pcm_hw_constraint_integer(s->runtime, SNDRV_PCM_HW_PARAM_PERIODS);
    if (ret < 0) goto out;
    ret = snd_pcm_hw_constraint_minmax(s->runtime, SNDRV_PCM_HW_PARAM_PERIOD_SIZE, 32, 8192);
    if (ret < 0) goto out;
    ret = snd_pcm_hw_constraint_minmax(s->runtime, SNDRV_PCM_HW_PARAM_BUFFER_SIZE, 64, MAX_FRAMES);
    if (ret < 0) goto out;
    mutex_lock(&d->mutex);
    d->substream = s;
    mutex_unlock(&d->mutex);
    ret = 0;
 out:
    mutex_unlock(&chip->configuration);
    return ret;
}
static int pcm_close(struct snd_pcm_substream *s)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    unsigned long flags;
    mutex_lock(&chip->configuration);
    mutex_lock(&d->mutex);
    spin_lock_irqsave(&d->lock, flags);
    d->running = false; d->generation++;
    spin_unlock_irqrestore(&d->lock, flags);
    d->substream = NULL;
    mutex_unlock(&d->mutex);
    mutex_unlock(&chip->configuration);
    return 0;
}
static int pcm_params(struct snd_pcm_substream *s, struct snd_pcm_hw_params *p)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    if (!READ_ONCE(chip->active) || params_channels(p) != READ_ONCE(chip->channels[s->stream]) ||
        params_rate(p) != READ_ONCE(chip->rate) || params_buffer_bytes(p) > MAX_FRAMES * chip->channels[s->stream] * 4)
        return -EINVAL;
    mutex_lock(&d->mutex);
    s->runtime->dma_area = d->area;
    s->runtime->dma_bytes = params_buffer_bytes(p);
    memset(d->area, 0, PAGE_ALIGN(s->runtime->dma_bytes));
    mutex_unlock(&d->mutex);
    return 0;
}
static int pcm_free(struct snd_pcm_substream *s)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    mutex_lock(&d->mutex);
    s->runtime->dma_area = NULL; s->runtime->dma_bytes = 0;
    mutex_unlock(&d->mutex);
    return 0;
}
static int pcm_prepare(struct snd_pcm_substream *s)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    unsigned long flags;
    if (!READ_ONCE(chip->active)) return -ENODEV;
    mutex_lock(&d->mutex);
    spin_lock_irqsave(&d->lock, flags);
    d->frames = 0; d->running = false; d->generation++;
    spin_unlock_irqrestore(&d->lock, flags);
    mutex_unlock(&d->mutex);
    return 0;
}
static int pcm_trigger(struct snd_pcm_substream *s, int cmd)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    unsigned long flags;
    bool running;
    switch (cmd) {
    case SNDRV_PCM_TRIGGER_START: running = true; break;
    case SNDRV_PCM_TRIGGER_STOP: running = false; break;
    default: return -EINVAL;
    }
    if (running && !READ_ONCE(chip->active)) return -ENODEV;
    spin_lock_irqsave(&d->lock, flags);
    d->running = running; d->generation++;
    spin_unlock_irqrestore(&d->lock, flags);
    return 0;
}
static snd_pcm_uframes_t pcm_pointer(struct snd_pcm_substream *s)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    unsigned long flags; u64 frames;
    spin_lock_irqsave(&d->lock, flags); frames = d->frames; spin_unlock_irqrestore(&d->lock, flags);
    return s->runtime->buffer_size ? frames % s->runtime->buffer_size : 0;
}
static int pcm_mmap(struct snd_pcm_substream *s, struct vm_area_struct *vma)
{
    if (!s->runtime->dma_area) return -ENODEV;
    if (vma->vm_pgoff || vma->vm_end - vma->vm_start > PAGE_ALIGN(s->runtime->dma_bytes))
        return -EINVAL;
    vm_flags_set(vma, VM_DONTEXPAND | VM_DONTDUMP);
    return remap_vmalloc_range(vma, s->runtime->dma_area, 0);
}
static struct page *pcm_page(struct snd_pcm_substream *s, unsigned long offset)
{
    return vmalloc_to_page(s->runtime->dma_area + offset);
}
static int pcm_sync_stop(struct snd_pcm_substream *s)
{
    struct rme_chip *chip = snd_pcm_substream_chip(s);
    struct direction *d = &chip->dir[s->stream];
    mutex_lock(&d->mutex);
    mutex_unlock(&d->mutex);
    return 0;
}
static const struct snd_pcm_ops pcm_ops = {
    .open = pcm_open, .close = pcm_close, .ioctl = snd_pcm_lib_ioctl,
    .hw_params = pcm_params, .hw_free = pcm_free, .prepare = pcm_prepare,
    .trigger = pcm_trigger, .pointer = pcm_pointer, .sync_stop = pcm_sync_stop,
    .page = pcm_page, .mmap = pcm_mmap,
};
static long transfer(struct rme_chip *chip, unsigned long arg, int direction)
{
    struct rme_pcm_transfer_v1 p;
    struct direction *d = &chip->dir[direction];
    struct snd_pcm_substream *s;
    struct snd_pcm_runtime *r;
    unsigned long flags;
    u64 frames, available, appl, boundary;
    u64 generation;
    size_t bytes, offset, first;
    bool running, elapsed = false, drain_end = false;
    int ret = 0;
    void __user *user;
    if (copy_from_user(&p, (void __user *)arg, sizeof(p))) return -EFAULT;
    if (!p.frames || p.frames > 4096 || p.channels != READ_ONCE(chip->channels[direction]) ||
        p.abi_version != RME_PCM_ABI_VERSION || p.reserved) return -EINVAL;
    if (!READ_ONCE(chip->active)) return -ENODEV;
    if (p.generation != chip->generation) return -ESTALE;
    bytes = (size_t)p.frames * p.channels * 4;
    user = u64_to_user_ptr(p.samples);
    mutex_lock(&d->mutex);
    s = d->substream;
    if (!s || !s->runtime || !s->runtime->dma_area) goto inactive;
    r = s->runtime;
    /* Setup may race with a transfer that began while no PCM was open. */
    if (p.channels != r->channels || !READ_ONCE(chip->active)) {
        ret = -EINVAL; goto out;
    }
    spin_lock_irqsave(&d->lock, flags);
    running = d->running; frames = d->frames; generation = d->generation;
    spin_unlock_irqrestore(&d->lock, flags);
    if (!running) goto inactive;
    boundary = r->boundary;
    if (!boundary || !r->buffer_size || !r->period_size) { ret = -EINVAL; goto out; }
    appl = READ_ONCE(r->control->appl_ptr);
    if (direction == SNDRV_PCM_STREAM_PLAYBACK)
        available = (appl + boundary - frames % boundary) % boundary;
    else available = r->buffer_size - min_t(u64, r->buffer_size,
                                 (frames % boundary + boundary - appl) % boundary);
    drain_end = direction == SNDRV_PCM_STREAM_PLAYBACK &&
        r->status->state == SNDRV_PCM_STATE_DRAINING && available <= p.frames;
    if (p.frames > available) {
        /* ALSA draining may finish on a partial USB batch. */
        if (direction == SNDRV_PCM_STREAM_PLAYBACK && r->status->state == SNDRV_PCM_STATE_DRAINING) {
            p.frames = min_t(u64, available, p.frames);
            if (clear_user(user, bytes)) { ret = -EFAULT; goto out; }
            bytes = (size_t)p.frames * p.channels * 4;
        } else {
            snd_pcm_stop_xrun(s); ret = -EPIPE; goto out;
        }
    }
    if (r->format != SNDRV_PCM_FORMAT_S32_LE) {
        unsigned int f, ch, width = snd_pcm_format_physical_width(r->format) / 8;
        if (direction == SNDRV_PCM_STREAM_CAPTURE && copy_from_user(d->scratch, user, bytes)) {
            ret = -EFAULT; goto out;
        }
        for (f = 0; f < p.frames; f++) for (ch = 0; ch < p.channels; ch++) {
            u8 *sample = d->area + (((frames + f) % r->buffer_size) * p.channels + ch) * width;
            size_t i = (size_t)f * p.channels + ch;
            if (direction == SNDRV_PCM_STREAM_PLAYBACK) {
                u32 value = width == 2 ? get_unaligned_le16(sample) : width == 3 ?
                    sample[0] | (u32)sample[1] << 8 | (u32)sample[2] << 16 : get_unaligned_le32(sample);
                d->scratch[i] = value << (r->format == SNDRV_PCM_FORMAT_S16_LE ? 16 : 8);
            } else {
                u32 value = d->scratch[i] >> (r->format == SNDRV_PCM_FORMAT_S16_LE ? 16 : 8);
                if (width == 2) put_unaligned_le16(value, sample);
                else if (width == 4) put_unaligned_le32(value, sample);
                else { sample[0] = value; sample[1] = value >> 8; sample[2] = value >> 16; }
            }
        }
        if (direction == SNDRV_PCM_STREAM_PLAYBACK && copy_to_user(user, d->scratch, bytes)) {
            ret = -EFAULT; goto out;
        }
        goto advanced;
    }
    offset = (frames % r->buffer_size) * p.channels * 4;
    first = min_t(size_t, bytes, r->dma_bytes - offset);
    if (direction == SNDRV_PCM_STREAM_PLAYBACK) {
        if (copy_to_user(user, d->area + offset, first) ||
            copy_to_user((char __user *)user + first, d->area, bytes - first)) ret = -EFAULT;
    } else if (copy_from_user(d->area + offset, user, first) ||
               copy_from_user(d->area, (char __user *)user + first, bytes - first)) ret = -EFAULT;
    if (ret) goto out;
 advanced:
    spin_lock_irqsave(&d->lock, flags);
    if (d->generation == generation && d->running) {
        d->frames += p.frames;
        elapsed = drain_end || frames / r->period_size != d->frames / r->period_size;
    }
    spin_unlock_irqrestore(&d->lock, flags);
    goto out;
 inactive:
    if (direction == SNDRV_PCM_STREAM_PLAYBACK && clear_user(user, bytes)) ret = -EFAULT;
 out:
    if (elapsed) snd_pcm_period_elapsed(s);
    mutex_unlock(&d->mutex);
    return ret;
}
/* ALSA holds the card until all PCM files (including mmap-held files) close.
 * In particular, owner disconnect never frees memory still mapped by a client. */
static void card_private_free(struct snd_card *card)
{
    struct rme_chip *chip = card->private_data;
    int i;
    for (i = 0; i < 2; i++) {
        vfree(chip->dir[i].area);
        vfree(chip->dir[i].scratch);
    }
}
static void disconnect_card(struct rme_chip *chip)
{
    int i;
    mutex_lock(&cards_mutex);
    list_del_init(&chip->entry);
    mutex_unlock(&cards_mutex);
    mutex_lock(&chip->configuration);
    WRITE_ONCE(chip->active, false);
    for (i = 0; i < 2; i++) {
        struct direction *d = &chip->dir[i];
        mutex_lock(&d->mutex);
        if (d->substream) snd_pcm_stop_xrun(d->substream);
        mutex_unlock(&d->mutex);
    }
    mutex_unlock(&chip->configuration);
    snd_card_disconnect(chip->card);
    snd_card_free_when_closed(chip->card);
    /* chip may have been freed: do not access it after this point. */
}
static bool valid_rate(u32 rate)
{
    switch (rate) {
    case 32000: case 44100: case 48000: case 64000: case 88200:
    case 96000: case 128000: case 176400: case 192000: return true;
    default: return false;
    }
}
static bool terminated(const char *s, size_t n)
{
    return s[0] && memchr(s, 0, n);
}
static long setup(struct bridge_file *owner, unsigned long arg, struct rme_pcm_setup_v1 *p)
{
    struct snd_card *card;
    struct rme_chip *chip, *other;
    unsigned int i;
    int ret;
    if (p->abi_version != RME_PCM_ABI_VERSION || p->flags || p->reserved0 ||
        p->reserved1[0] || p->reserved1[1] || p->reserved1[2] ||
        !p->generation || !valid_rate(p->rate) ||
        !p->capture_channels || p->capture_channels > RME_PCM_MAX_CHANNELS ||
        !p->playback_channels || p->playback_channels > RME_PCM_MAX_CHANNELS ||
        !terminated(p->uid, sizeof(p->uid)) ||
        !terminated(p->card_id, sizeof(p->card_id)) ||
        !terminated(p->card_name, sizeof(p->card_name))) return -EINVAL;
    for (i = 0; p->card_id[i]; i++)
        if (!((p->card_id[i] >= 'A' && p->card_id[i] <= 'Z') ||
              (p->card_id[i] >= 'a' && p->card_id[i] <= 'z') ||
              (p->card_id[i] >= '0' && p->card_id[i] <= '9'))) return -EINVAL;
    if (owner->chip) {
        chip = owner->chip;
        if (strcmp(chip->setup.uid, p->uid) || p->generation != chip->generation ||
            p->rate != chip->rate || p->capture_channels != chip->channels[1] ||
            p->playback_channels != chip->channels[0] ||
            strcmp(chip->setup.card_id, p->card_id) ||
            strcmp(chip->setup.card_name, p->card_name)) return -EBUSY;
        return copy_to_user((void __user *)arg, &chip->setup, sizeof(*p)) ? -EFAULT : 0;
    }
    if (p->card_index != -1) return -EINVAL;
    mutex_lock(&cards_mutex);
    list_for_each_entry(other, &cards, entry) {
        if (!strcmp(other->setup.uid, p->uid)) { ret = -EBUSY; goto unlock; }
    }
    ret = snd_card_new(parent, -1, p->card_id, THIS_MODULE, sizeof(*chip), &card);
    if (ret) goto unlock;
    chip = card->private_data;
    chip->card = card;
    card->private_free = card_private_free;
    mutex_init(&chip->configuration);
    INIT_LIST_HEAD(&chip->entry);
    chip->setup = *p;
    chip->rate = p->rate;
    chip->generation = p->generation;
    chip->channels[0] = p->playback_channels;
    chip->channels[1] = p->capture_channels;
    for (i = 0; i < 2; i++) {
        struct direction *d = &chip->dir[i];
        mutex_init(&d->mutex);
        spin_lock_init(&d->lock);
        d->area = vmalloc_user((size_t)MAX_FRAMES * chip->channels[i] * 4);
        d->scratch = vzalloc((size_t)MAX_TRANSFER_FRAMES * chip->channels[i] * 4);
        if (!d->area || !d->scratch) { ret = -ENOMEM; goto free; }
    }
    strscpy(card->driver, "RMEPCM", sizeof(card->driver));
    strscpy(card->shortname, p->card_name, sizeof(card->shortname));
    snprintf(card->longname, sizeof(card->longname), "%.46s / native RME userspace transport", p->card_name);
    ret = snd_pcm_new(card, "RME PCM", 0, 1, 1, &chip->pcm);
    if (ret) goto free;
    chip->pcm->private_data = chip;
    strscpy(chip->pcm->name, p->card_name, sizeof(chip->pcm->name));
    snd_pcm_set_ops(chip->pcm, SNDRV_PCM_STREAM_PLAYBACK, &pcm_ops);
    snd_pcm_set_ops(chip->pcm, SNDRV_PCM_STREAM_CAPTURE, &pcm_ops);
    WRITE_ONCE(chip->active, true);
    ret = snd_card_register(card);
    if (ret) goto free;
    chip->setup.card_index = card->number;
    strscpy(chip->setup.card_id, card->id, sizeof(chip->setup.card_id));
    list_add_tail(&chip->entry, &cards);
    owner->chip = chip;
    mutex_unlock(&cards_mutex);
    if (copy_to_user((void __user *)arg, &chip->setup, sizeof(*p))) {
        owner->chip = NULL;
        disconnect_card(chip);
        return -EFAULT;
    }
    return 0;
 free:
    snd_card_free(card);
 unlock:
    mutex_unlock(&cards_mutex);
    return ret;
}
static int bridge_open(struct inode *inode, struct file *file)
{
    struct bridge_file *owner = kzalloc(sizeof(*owner), GFP_KERNEL);
    if (!owner) return -ENOMEM;
    mutex_init(&owner->mutex);
    file->private_data = owner;
    return 0;
}
static int bridge_release(struct inode *inode, struct file *file)
{
    struct bridge_file *owner = file->private_data;
    if (owner->chip) disconnect_card(owner->chip);
    kfree(owner);
    return 0;
}
static long bridge_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct bridge_file *owner = file->private_data;
    long ret;
    struct rme_pcm_setup_v1 *p;
    mutex_lock(&owner->mutex);
    switch (cmd) {
    case RME_PCM_SETUP:
        p = memdup_user((void __user *)arg, sizeof(*p));
        if (IS_ERR(p)) ret = PTR_ERR(p);
        else { ret = setup(owner, arg, p); kfree(p); }
        break;
    case RME_PCM_PLAY: case RME_PCM_CAPTURE:
        ret = owner->chip ? transfer(owner->chip, arg,
              cmd == RME_PCM_PLAY ? SNDRV_PCM_STREAM_PLAYBACK : SNDRV_PCM_STREAM_CAPTURE) : -ENODEV;
        break;
    default: ret = -ENOTTY;
    }
    mutex_unlock(&owner->mutex);
    return ret;
}
static loff_t bridge_no_llseek(struct file *file, loff_t offset, int whence)
{
    return -ESPIPE;
}
static const struct file_operations bridge_ops = {
    .owner = THIS_MODULE, .open = bridge_open, .release = bridge_release,
    .unlocked_ioctl = bridge_ioctl,
#ifdef CONFIG_COMPAT
    .compat_ioctl = compat_ptr_ioctl,
#endif
    .llseek = bridge_no_llseek,
};
static struct miscdevice bridge = { .minor = MISC_DYNAMIC_MINOR, .name = "rme-pcm",
    .fops = &bridge_ops, .mode = 0600 };
static int __init rme_init(void)
{
    int ret;
    parent = root_device_register("rme-pcm");
    if (IS_ERR(parent)) return PTR_ERR(parent);
    ret = misc_register(&bridge);
    if (ret) root_device_unregister(parent);
    return ret;
}
static void __exit rme_exit(void)
{
    misc_deregister(&bridge);
    root_device_unregister(parent);
}
module_init(rme_init); module_exit(rme_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Common RME ALSA PCM frontend for userspace native USB transport");
MODULE_AUTHOR("RME Linux driver contributors");
