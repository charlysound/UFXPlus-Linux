/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef RME_PCM_UAPI_H
#define RME_PCM_UAPI_H
#include <linux/types.h>
#include <linux/ioctl.h>

#define RME_PCM_ABI_VERSION 1
#define RME_PCM_MAX_CHANNELS 256
#define RME_PCM_UID_SIZE 1024
/* Each open owns one immutable device/format generation. SETUP returns the
 * allocated ALSA index and ID; no USB discovery or control occurs here. */
struct rme_pcm_setup_v1 {
    __u32 abi_version, flags, rate, capture_channels, playback_channels, reserved0;
    __aligned_u64 generation;
    __s32 card_index;
    __u32 reserved1[3];
    char uid[RME_PCM_UID_SIZE];
    char card_id[16];
    char card_name[80];
};
/* Samples are interleaved, full-scale signed S32, in physical channel order. */
struct rme_pcm_transfer_v1 {
    __u32 abi_version, frames, channels, reserved;
    __aligned_u64 generation, samples;
};
#define RME_PCM_SETUP _IOWR('R', 0x70, struct rme_pcm_setup_v1)
#define RME_PCM_PLAY _IOWR('R', 0x71, struct rme_pcm_transfer_v1)
#define RME_PCM_CAPTURE _IOW('R', 0x72, struct rme_pcm_transfer_v1)
#endif
