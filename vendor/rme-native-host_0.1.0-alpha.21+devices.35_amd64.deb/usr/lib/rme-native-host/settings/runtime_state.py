"""Atomic session status. No USB access and no periodic disk writes."""
import json
import os
from pathlib import Path
import tempfile


def path():
    return Path(os.environ["XDG_RUNTIME_DIR"]) / "ufxplus-session.json"


def start_ticks(pid):
    return (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()[19]


def read():
    try:
        value = json.loads(path().read_text())
        if (not isinstance(value, dict) or value.get("schema") != 1 or type(value.get("pid")) is not int
                or value.get("process_start") != start_ticks(value["pid"])):
            return None
        return value
    except (OSError, ValueError, KeyError, IndexError, TypeError):
        return None


def write(value):
    target = path()
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", dir=target.parent, delete=False) as stream:
            temporary = Path(stream.name)
            worker = value.get("worker_pid")
            if worker:
                try:
                    value = dict(value, worker_process_start=start_ticks(worker))
                except (OSError,ValueError,IndexError):
                    value = dict(value, worker_process_start=None)
            json.dump(dict(value, schema=1, pid=os.getpid(),
                           process_start=start_ticks(os.getpid()),
                           invocation=os.environ.get("INVOCATION_ID", "")), stream)
            stream.write("\n")
        os.replace(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
