"""Fast host-only native FX control. No subprocess, hardware helper or FX store."""
import copy
import json
import os
from pathlib import Path
import re
import socket
import stat
import struct
import time

U64_MAX = 2**64 - 1
MAX_REQUEST_BYTES = 16384
MAX_REPLY_BYTES = 65536
_COUNTERS = {'accepted_input_frames', 'consumed_input_frames', 'produced_output_frames',
             'delivered_output_frames', 'underruns', 'overruns', 'discarded_input_frames',
             'discarded_output_frames'}
_IDENTITY = {'uid', 'connection_generation', 'format_generation', 'nonce'}


class FxError(RuntimeError):
    def __init__(self, code, message, *, uncertain=False):
        super().__init__(message)
        self.code, self.uncertain = code, uncertain


def _integer(value, low=0, high=U64_MAX):
    return type(value) is int and low <= value <= high


def _identity(value, uid, generation, format_generation):
    if (not isinstance(uid,str) or not uid.startswith('rme:') or not 0<len(uid)<=512 or '\0' in uid
            or not _integer(generation,1) or not _integer(format_generation,1)
            or not isinstance(value, dict) or set(value) != _IDENTITY or value.get('uid') != uid
            or not _integer(value.get('connection_generation'), 1)
            or value['connection_generation'] != generation
            or not _integer(value.get('format_generation'), 1)
            or value['format_generation'] != format_generation
            or not isinstance(value.get('nonce'), str)
            or re.fullmatch(r'[a-fA-F0-9]{32}', value['nonce']) is None):
        raise FxError('stale', 'Software effects belong to another audio owner')


def _status(value, identity, rate):
    if (not _integer(rate,1,384000) or not isinstance(value, dict) or type(value.get('schema')) is not int or value['schema'] != 1
            or value.get('identity') != identity or not _integer(value.get('revision'))
            or type(value.get('rate_hz')) is not int or value['rate_hz'] != rate
            or value.get('host_intentions') is not True or value.get('hardware_confirmed') is not False
            or value.get('initial_parameters_source') != 'native_software_engine_constructor'
            or value.get('state') not in ('waiting_reset', 'error', 'ready', 'active')):
        raise FxError('invalid', 'Invalid software effects status or binding')
    _identity(value['identity'], identity['uid'], identity['connection_generation'], identity['format_generation'])
    q, capacity = value.get('native_block_frames'), value.get('capacity_frames')
    if (type(q) is not int or q not in (128, 256, 512) or type(capacity) is not int
            or not 2*q <= capacity <= 8192
            or type(value.get('native_nominal_delay_frames')) is not int
            or value['native_nominal_delay_frames'] != 2*q
            or any(not _integer(value.get(k)) for k in ('requested_transport_generation', 'acknowledged_transport_generation'))):
        raise FxError('invalid', 'Invalid software effects processing geometry')
    params, counters, error = value.get('parameters'), value.get('counters'), value.get('error')
    if (not isinstance(params, dict) or len(params) != 21
            or any(not isinstance(k, str) or re.fullmatch(r'(reverb|echo)_[a-z_]{1,40}', k) is None
                   or not _integer(v, -32768, 32767) for k, v in params.items())
            or not isinstance(counters, dict) or set(counters) != _COUNTERS
            or any(not _integer(v) for v in counters.values())
            or (error is not None and (not isinstance(error, str) or not error or len(error) > 4096))
            or (value['state'] == 'error') != (error is not None)):
        raise FxError('invalid', 'Invalid software effects intentions/counters/error')
    return copy.deepcopy(value)


def _socket_identity(path):
    path = Path(path)
    if not path.is_absolute() or '\0' in str(path) or len(os.fsencode(path)) >= 108:
        raise FxError('invalid', 'Invalid software effects socket path')
    try:
        parent, info = path.parent.lstat(), path.lstat()
        if (not stat.S_ISDIR(parent.st_mode) or stat.S_ISLNK(parent.st_mode)
                or parent.st_uid != os.getuid() or stat.S_IMODE(parent.st_mode) != 0o700
                or not stat.S_ISSOCK(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600):
            raise FxError('stale', 'Software effects endpoint is not private')
        return info.st_dev, info.st_ino
    except OSError as error:
        raise FxError('unavailable', 'Software effects endpoint is unavailable') from error


def validate_metadata(value, uid, audio_generation, format_generation, rate):
    """Validate only a live Server envelope; static Native capabilities never admit it."""
    if not isinstance(value, dict):
        raise FxError('unavailable', 'The loaded audio owner has no software effects endpoint')
    _identity(value.get('identity'), uid, audio_generation, format_generation)
    value = _status(value, value['identity'], rate)
    if (type(value.get('control_abi')) is not int or value['control_abi'] != 1
            or type(value.get('maximum_request_bytes')) is not int
            or value['maximum_request_bytes'] != MAX_REQUEST_BYTES
            or not isinstance(value.get('control_socket'), str)):
        raise FxError('invalid', 'Invalid software effects control ABI')
    _socket_identity(value['control_socket'])
    return value


def _json(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise FxError('invalid', 'Duplicate software effects reply field')
            result[key] = value
        return result
    try:
        return json.loads(data, object_pairs_hook=unique)
    except (ValueError, UnicodeError) as error:
        raise FxError('invalid', 'Malformed software effects reply') from error


class Client:
    @classmethod
    def from_uid(cls, uid, expected_marker, *, timeout=0.5):
        import linux_control
        authority = lambda: linux_control.software_effects_authority(uid)
        try:return cls(authority(), expected_marker, authority, timeout=timeout)
        except FxError:raise
        except (OSError,RuntimeError,ValueError,TypeError,KeyError) as error:
            raise FxError(getattr(error,'code','unavailable'),str(error)) from error

    def __init__(self, snapshot, expected_marker, authority, *, timeout=0.5):
        if not isinstance(expected_marker, dict) or snapshot.get('marker') != expected_marker:
            raise FxError('stale', 'The audio owner changed before opening software effects')
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 0 < timeout <= 2:
            raise FxError('invalid', 'Invalid software effects timeout')
        self._authority, self._marker = authority, copy.deepcopy(expected_marker)
        self._uid = snapshot['uid']
        self._metadata = validate_metadata(snapshot.get('software_effects'), self._uid,
                                           expected_marker.get('audio_generation'),
                                           expected_marker.get('audio_format_generation'), snapshot['rate'])
        self._worker = expected_marker.get('worker_pid')
        if not _integer(self._worker, 1, 2**31-1):
            raise FxError('stale', 'The software effects audio worker is missing')
        self._identity = copy.deepcopy(self._metadata['identity'])
        self._path, self._inode = self._metadata['control_socket'], _socket_identity(self._metadata['control_socket'])
        self._last = copy.deepcopy(self._metadata)
        self._timeout, self._uncertain = timeout, False

    def _current(self):
        try:current = self._authority()
        except FxError:raise
        except (OSError,RuntimeError,ValueError,TypeError,KeyError) as error:
            raise FxError(getattr(error,'code','unavailable'),str(error)) from error
        if current.get('uid') != self._uid or current.get('marker') != self._marker:
            raise FxError('stale', 'Software effects audio authority changed')
        metadata = validate_metadata(current.get('software_effects'), self._uid,
                                     self._identity['connection_generation'], self._identity['format_generation'], self._metadata['rate_hz'])
        for key in ('identity', 'control_socket', 'control_abi', 'maximum_request_bytes', 'rate_hz', 'native_block_frames', 'capacity_frames'):
            if metadata.get(key) != self._metadata.get(key):
                raise FxError('stale', 'Software effects endpoint identity changed')
        if _socket_identity(self._path) != self._inode:
            raise FxError('stale', 'Software effects socket was replaced')

    @staticmethod
    def _remaining(deadline):
        remaining = deadline-time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Software effects reply timed out')
        return remaining

    def _receive(self, stream, deadline):
        data = bytearray()
        while True:
            stream.settimeout(self._remaining(deadline))
            chunk = stream.recv(min(4096, MAX_REPLY_BYTES+1-len(data)))
            if not chunk:
                raise ConnectionError('Software effects closed without an acknowledgement')
            data.extend(chunk)
            if len(data) > MAX_REPLY_BYTES:
                raise FxError('invalid', 'Software effects reply is too large')
            if b'\n' in data:
                line, rest = data.split(b'\n', 1)
                if rest.strip():
                    raise FxError('invalid', 'Ambiguous software effects acknowledgement')
                return _json(line)

    def _rpc(self, operation, **fields):
        self._current()
        request = dict(schema=1, op=operation, identity=self._identity, **fields)
        raw = json.dumps(request, separators=(',', ':'), allow_nan=False).encode()+b'\n'
        if len(raw) > MAX_REQUEST_BYTES:
            raise FxError('invalid', 'Software effects request is too large')
        sent = False
        try:
            deadline = time.monotonic()+self._timeout
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
                stream.settimeout(self._remaining(deadline)); stream.connect(self._path)
                pid, uid, _ = struct.unpack('=iII', stream.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
                if pid != self._worker or uid != os.getuid():
                    raise FxError('stale', 'Software effects socket peer is not the admitted audio worker')
                self._current()
                stream.settimeout(self._remaining(deadline)); sent = True; stream.sendall(raw)
                reply = self._receive(stream, deadline)
            self._current()
            if (not isinstance(reply, dict) or type(reply.get('schema')) is not int or reply['schema'] != 1
                    or reply.get('identity') != self._identity or reply.get('hardware_confirmed') is not False
                    or type(reply.get('ok')) is not bool or type(reply.get('host_accepted')) is not bool):
                raise FxError('invalid', 'Software effects acknowledgement is invalid or foreign')
            _identity(reply['identity'], self._uid, self._identity['connection_generation'], self._identity['format_generation'])
            if reply['ok'] is False and reply['host_accepted'] is False:
                raise FxError('rejected', str(reply.get('error') or 'Software effects request rejected'))
            if reply['ok'] is not True or reply['host_accepted'] is not True:
                raise FxError('invalid', 'Software effects acceptance was not confirmed')
            return _status(reply, self._identity, self._metadata['rate_hz'])
        except (OSError, TimeoutError, ConnectionError, FxError) as error:
            uncertain = operation == 'set' and sent and not (isinstance(error, FxError) and error.code == 'rejected')
            if uncertain:
                self._uncertain = True
            if isinstance(error, FxError):
                raise FxError(error.code, str(error), uncertain=uncertain) from error
            raise FxError('uncertain' if uncertain else 'unavailable', str(error), uncertain=uncertain) from error

    def status(self):
        reply = self._rpc('status')
        if reply['revision'] < self._last['revision']:
            raise FxError('stale', 'Software effects status revision regressed')
        self._last, self._uncertain = reply, False
        return copy.deepcopy(reply)

    def set(self, expected_revision, parameters):
        if self._uncertain:
            raise FxError('uncertain', 'Reread software effects status before another explicit change', uncertain=True)
        if (not _integer(expected_revision, 0, U64_MAX-1) or expected_revision != self._last['revision']
                or not isinstance(parameters, dict) or not parameters
                or not set(parameters).issubset(self._last['parameters'])
                or any(not _integer(v, -32768, 32767) for v in parameters.values())):
            raise FxError('invalid', 'Invalid software effects parameters or unobserved revision')
        expected = dict(self._last['parameters'], **parameters)
        reply = self._rpc('set', expected_revision=expected_revision, parameters=parameters)
        if reply['revision'] != expected_revision+1 or reply['parameters'] != expected:
            self._uncertain = True
            raise FxError('uncertain', 'Software effects intentions were not exactly confirmed', uncertain=True)
        self._last = reply
        return copy.deepcopy(reply)
