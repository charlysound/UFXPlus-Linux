#!/usr/bin/python3
"""Persist PipeWire group visibility; no mixer, clock or firmware writes."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import hashlib
import fcntl
import stat
import settings_control

DIRECTIONS = ("capture", "playback")
DEFAULT = {"schema": 1, "capture": [True] * 5, "playback": [True] * 5}


def config_path():
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "ufxplus-driver/nodes.json"


def validate(value):
    if (not isinstance(value, dict) or set(value) != {"schema", *DIRECTIONS}
            or type(value["schema"]) is not int or value["schema"] != 1
            or any(not isinstance(value[d], list) or len(value[d]) != 5
                   or any(type(v) is not bool for v in value[d]) for d in DIRECTIONS)):
        raise ValueError("Invalid PipeWire node selection; expected schema 1 and five input/output switches")
    return value


def read():
    try:
        return validate(json.loads(config_path().read_text()))
    except FileNotFoundError:
        return copy.deepcopy(DEFAULT)


def save(value):
    validate(value)
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False) as f:
            temporary = Path(f.name)
            json.dump(value, f)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def change(value):
    validate(value)
    with settings_control.transaction():
        save(value)
    return {"ok": True, "nodes": read(), "applies": "active_or_next_start"}


def toggle(direction, index, enabled):
    if direction not in DIRECTIONS or type(index) is not int or index not in range(5) or type(enabled) is not bool:
        raise ValueError("Invalid node group")
    # Read/modify/write under the same settings lock: concurrent applets cannot
    # overwrite each other's selections.
    with settings_control.transaction():
        value = read()
        value[direction][index] = enabled
        save(value)
    return {"ok": True, "nodes": read(), "applies": "active_or_next_start"}


def inventory(config, rate, present=None):
    counts = [8, 4, 2, 16, 64] if not rate or rate <= 48000 else (
        [8, 4, 2, 8, 32] if rate <= 96000 else [8, 4, 2, 4, 16])
    rows = []
    for direction in DIRECTIONS:
        names = ["Analog 1–8", "Mic/Inst 9–12" if direction == "capture" else "Phones 9–12",
                 "AES", f"ADAT 1–{counts[3]}", f"MADI 1–{counts[4]}"]
        for index, label in enumerate(names):
            name = (f"ufxplus_live_capture_{index}" if direction == "capture" else
                    "ufxplus_live_playback_analog" if index == 0 else f"ufxplus_live_playback_pending_{index}")
            rows.append({"direction": direction, "index": index, "label": label,
                         "channels": counts[index] if rate else None, "name": name,
                         "enabled": config[direction][index],
                         "present": name in present if present is not None else None})
    return rows


def native_status_path():
    return Path(os.environ.get('OSCMIX_RME_RUNTIME_STATUS') or
                Path(os.environ.get('XDG_RUNTIME_DIR', '/run/user/' + str(os.getuid()))) / 'rme-native/devices.json')


def native_snapshot():
    # Compatibility entry point: all consumers now share PID/start validation.
    from linux_control import snapshot
    return snapshot()


def native_devices():
    from linux_control import status
    try:
        return [dict(uid=row['uid'],label=row['model']+' · '+row['uid'])
                for row in status()['devices'] if row.get('native') is not False]
    except (OSError,ValueError,RuntimeError,TypeError,KeyError):
        return []


def native_attachment_current(attachment, root=Path('/sys/bus/usb/devices')):
    name = attachment.get('usb_path')
    if not isinstance(name, str) or Path(name).name != name or name in ('', '.', '..'):
        return False
    try:
        path = root / name
        before = path.stat()
        raw = (path / 'descriptors').read_bytes()
        current = dict(sysfs_inode=before.st_ino, sysfs_ctime_ns=before.st_ctime_ns,
                       bus=int((path/'busnum').read_text()), address=int((path/'devnum').read_text()),
                       descriptor_sha256=hashlib.sha256(raw).hexdigest())
        after = path.stat()
        return ((before.st_ino, before.st_ctime_ns) == (after.st_ino, after.st_ctime_ns)
                and all(attachment.get(k) == v for k, v in current.items()))
    except (OSError, ValueError, TypeError):
        return False


def native_config_path(uid):
    if not isinstance(uid, str) or not uid.startswith('rme:') or len(uid) > 512:
        raise ValueError('Invalid native device identity')
    root = Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')
    return root / 'rme-native/devices' / hashlib.sha256(uid.encode()).hexdigest() / 'nodes.json'


def native_validate(value, uid, names=None):
    if isinstance(value, dict) and value.get('schema') == 2:
        import category_nodes
        return category_nodes.validate(value, uid)
    prefix = 'rme.' + uid.encode().hex() + '.'
    if (not isinstance(value, dict) or set(value) != {'schema', 'uid', 'enabled'}
            or type(value.get('schema')) is not int or value['schema'] != 1 or value['uid'] != uid
            or not isinstance(value['enabled'], dict)
            or any(not isinstance(name, str) or not name.startswith(prefix) or type(enabled) is not bool
                   or (names is not None and name not in names) for name, enabled in value['enabled'].items())):
        raise ValueError('Invalid native node selection')
    return value


def native_read_config(uid):
    try:
        return native_validate(json.loads(native_config_path(uid).read_text()), uid)
    except FileNotFoundError:
        return dict(schema=1, uid=uid, enabled={})


def native_inventory(uid):
    from linux_control import status
    result = status(uid)
    return dict(result,can_set_nodes=result.get('can_apply',False),node_error=result.get('error'))


def native_change(uid, enabled, expected):
    # A saved file is not an acknowledgement. Retain the old Python API while
    # routing it through the common transaction/owner confirmation contract.
    from linux_control import apply
    return apply(uid,expected,dict(enabled=enabled))


if __name__ == "__main__":
    try:
        if len(sys.argv) != 4 or sys.argv[3] not in ("on", "off"):
            raise ValueError("Usage: ufxplus-driver-nodes capture|playback GROUP_INDEX on|off")
        result = toggle(sys.argv[1], int(sys.argv[2]), sys.argv[3] == "on")
    except (ValueError, RuntimeError, OSError, subprocess.SubprocessError) as error:
        result = {"ok": False, "error": str(error)}
    print(json.dumps(result))
    sys.exit(0 if result["ok"] else 1)
