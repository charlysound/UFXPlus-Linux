"""Presentation/draft helpers for the common loaded-worker node selection.

No files, services or independent settings store. Canonical identities and
availability come entirely from linux_control.status().
"""
import copy
import json


def categories(data):
    abi = data.get('pipewire_nodes_abi')
    if abi is None or (type(abi) is int and abi == 1):
        return None
    if type(abi) is not int or abi != 2 or not isinstance(data.get('categories'), list):
        raise ValueError('Invalid PipeWire category inventory')
    result, seen, channels = [], set(), {'capture': set(), 'playback': set()}
    for row in data['categories']:
        if not isinstance(row, dict):raise ValueError('Invalid PipeWire category')
        for key in ('category', 'name', 'label'):
            if not isinstance(row.get(key), str) or not row[key]:raise ValueError('Missing category identity or label')
        if row['category'] in seen:raise ValueError('Duplicate PipeWire category')
        seen.add(row['category'])
        if type(row.get('enabled')) is not bool or type(row.get('present')) is not bool:
            raise ValueError('Invalid category preference or presence')
        for direction in ('capture', 'playback'):
            ports = row.get(direction)
            if not isinstance(ports, list) or len(ports) > 256:raise ValueError('Invalid category channels')
            for port in ports:
                if not isinstance(port, dict):raise ValueError('Invalid category channel')
                channel = port.get('native_channel')
                if type(channel) is not int or not 1 <= channel <= 256 or channel in channels[direction]:
                    raise ValueError('Invalid or duplicate native channel')
                channels[direction].add(channel)
                if not isinstance(port.get('label'), str) or not port['label']:raise ValueError('Missing channel label')
                if any(type(port.get(k)) is not bool for k in ('available', 'selected', 'present')):
                    raise ValueError('Invalid channel preference, availability or presence')
                if port['present'] and not port['available']:raise ValueError('Unavailable channel reported present')
        result.append(copy.deepcopy(row))
    return result


def context(data):
    uid, marker, revision = data.get('uid'), data.get('marker'), (data.get('settings') or {}).get('revision')
    if not isinstance(uid, str) or not uid or not isinstance(marker, dict) or not marker:
        raise ValueError('The selected interface connection is unavailable')
    if type(revision) is not int or revision < 0:raise ValueError('The settings revision is unavailable')
    return uid, json.dumps(marker, sort_keys=True, separators=(',', ':')), revision


def selection(data):
    rows = categories(data)
    if rows is None:raise ValueError('This worker does not support individual PipeWire channels')
    context(data)
    return dict(schema=2, uid=data['uid'], categories={row['category']:dict(
        enabled=row['enabled'], **{direction:{str(p['native_channel']):p['selected'] for p in row[direction]}
                                 for direction in ('capture','playback')}) for row in rows})


def request(data, desired, expected):
    if context(data) != expected:raise ValueError('The interface or settings changed. Refresh the selection.')
    rows = categories(data)
    if rows is None or not isinstance(desired, dict) or desired.get('uid') != data['uid'] or type(desired.get('schema')) is not int or desired['schema'] != 2:
        raise ValueError('Invalid PipeWire selection draft')
    entries = desired.get('categories')
    if not isinstance(entries, dict) or set(entries) != {r['category'] for r in rows}:raise ValueError('The category inventory changed')
    for row in rows:
        entry=entries[row['category']]
        if not isinstance(entry,dict) or set(entry) != {'enabled','capture','playback'} or type(entry['enabled']) is not bool:
            raise ValueError('Invalid category selection')
        for direction in ('capture','playback'):
            wanted=entry[direction]
            if not isinstance(wanted,dict) or set(wanted) != {str(p['native_channel']) for p in row[direction]} or any(type(v) is not bool for v in wanted.values()):
                raise ValueError('The channel inventory changed')
            for port in row[direction]:
                if not port['available'] and wanted[str(port['native_channel'])] != port['selected']:
                    raise ValueError('Unavailable channel preferences must be preserved')
    return dict(expected_revision=expected[2], node_selection=copy.deepcopy(desired))


def signature(rows):
    return [(r['category'],r['name'],r['label'],[(d,p['native_channel'],p['label'],p['available'])
             for d in ('capture','playback') for p in r[d]]) for r in rows]


def presence(port, backend):
    if not port['available']:return 'Saved · unavailable at this format'
    if port['present']:return 'Visible'
    if not port['selected']:return 'Not selected'
    return 'Saved · ALSA only' if backend == 'alsa' else 'Waiting for publication'
