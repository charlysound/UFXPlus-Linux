#!/usr/bin/python3
"""Cinnamon view of the existing per-UID Linux status and acknowledged API."""
import argparse
import json
import subprocess
import driver_status
import linux_control as common
import selection_control as selection
import node_selection_view as node_view


def collect(uid=None):
    inventory = common.status()['devices']
    if uid is None:uid=selection.current()
    choices = [dict(uid=row['uid'], label=str(row.get('model') or 'RME'), state=row['state']) for row in inventory]
    selected = next((row for row in inventory if row['uid'] == uid), None) if uid else next(iter(inventory), None)
    if selected is None:
        return dict(ok=True, schema=1, uid=uid, devices=choices, native=None, state='Selected card disconnected' if uid else 'No RME card',
                    marker=None, can_set_rate=False, can_set_buffer=False, can_set_backend=False, can_set_nodes=False,
                    capabilities=dict(rates=[], buffer_frames=[]), backend_choices=[], nodes=[], sample_rate=None,
                    model='RME', error='Choose a connected card' if uid else 'Waiting for an RME interface')
    row=selected
    # Legacy readback is allowed only after the common reader established its
    # historical owner. Failed common inventory never selects a legacy fallback.
    legacy = row.get('native') is False
    data = driver_status.collect() if legacy and row.get('can_apply') else {}
    if legacy and row.get('can_apply'):
        if common.status(row['uid'])['marker'] != row['marker']:
            raise common.ControlError('stale', 'The selected historical owner changed during status')
    settings=row.get('settings') or {};applied=row.get('applied') or {}
    caps=row.get('settings_capabilities') or {};rates=[]
    for hz in (row.get('rate_capabilities') or {}).get('rates', []):
        try:common.rate_format(row,hz)
        except (RuntimeError,KeyError,TypeError,ValueError):continue
        rates.append(hz)
    ready=row.get('can_apply') is True and row['state']=='running'
    hardware=(row.get('hardware_settings') or {}).get('fields') or {}
    if not legacy:
        data.update(clock_source=hardware.get('clock_source'),input_lock_sync=hardware.get('input_lock_sync',[]),
                    pipewire=dict(rate=row.get('pipewire',{}).get('rate'),quantum=applied.get('observed_quantum_frames')),
                    progress=None,timing=None,usb_devices=[],digital=hardware.get('digital'),recovery_rate_hz=None,
                    midi=dict(active=row.get('midi',{}).get('ready'),state=row.get('midi',{}).get('state'),ports=row.get('midi',{}).get('ports')))
    categories=node_view.categories(row)
    nodes=[] if categories is not None else [dict(node,index=node['name']) for node in row.get('nodes',[])]
    data.update(ok=True,schema=1,uid=row['uid'],devices=choices,model=str(row.get('model') or 'RME'),native=not legacy,
                marker=row['marker'],state=row['state'],active=row['state']=='running',sample_rate=row.get('rate'),
                channels_in=row.get('capture_channels'),channels_out=row.get('playback_channels'),version='RME common Linux',
                nodes=nodes,pipewire_nodes_abi=2 if categories is not None else 1,categories=categories or [],settings_revision=settings.get('revision'),can_set_nodes=ready,can_set_backend=ready,can_set_buffer=ready,can_set_rate=ready and len(rates)>1 and (not legacy or data.get("can_set_rate") is True),
                capabilities=dict(rates=rates,buffer_frames=caps.get('buffer_frames',[])),backend_choices=caps.get('backends',[]),
                audio_backend=applied.get('backend'),selected_audio_backend=settings.get('backend'),buffer_frames=applied.get('buffer_frames'),
                failure_reason=row.get('error') or row.get('settings_error') or row.get('hardware_settings_error'))
    return data


def action(uid,marker,request):
    if not isinstance(request,dict) or not request:
        raise common.ControlError('invalid','A settings request is required')
    if set(request)=={'rate_hz'}:
        return common.change_rate(uid,marker,request['rate_hz'])
    # This API validates marker/owner again under its existing UID transaction,
    # dispatches to the historical adapter only for a historical owner and
    # returns success only after the actual frontend acknowledgement.
    return common.apply(uid,marker,request)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='operation',required=True)
    status=sub.add_parser('status');status.add_argument('--uid')
    select=sub.add_parser('select');select.add_argument('--uid',required=True)
    change=sub.add_parser('action');change.add_argument('--uid',required=True)
    change.add_argument('--expected-marker',required=True);change.add_argument('--request',required=True)
    args=parser.parse_args(argv)
    try:
        if args.uid:common.uid_check(args.uid)
        if args.operation=='status':result=collect(args.uid)
        elif args.operation=='select':result=selection.select(args.uid,common.status()['devices'])
        else:result=action(args.uid,json.loads(args.expected_marker),json.loads(args.request))
    except (RuntimeError,OSError,ValueError,TypeError,KeyError,AttributeError,subprocess.SubprocessError) as error:
        result=dict(ok=False,code=getattr(error,'code','unavailable'),error=str(error),uncertain=getattr(error,'uncertain',False))
    print(json.dumps(result,separators=(',',':')))
    return 0 if result.get('ok') is not False else 1


if __name__=='__main__':raise SystemExit(main())
