#!/usr/bin/python3
"""Persist one explicit frontend choice under the existing audio settings lock."""
import json
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import settings_control

BACKENDS = ("pipewire", "alsa", "pipewire+alsa")


def config_path():
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "ufxplus-driver/audio-backend"


def validate(value):
    if value not in BACKENDS:
        raise ValueError("Choose pipewire, alsa or pipewire+alsa")
    return value


def read():
    try:
        value = config_path().read_text().strip()
    except FileNotFoundError:
        value = os.environ.get("UFXPLUS_AUDIO_BACKEND", "pipewire")
    return validate(value)


def change(value):
    validate(value)
    with settings_control.transaction(settings_control.ensure_alsa_clients_closed):
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False) as f:
                temporary = Path(f.name)
                f.write(value + "\n")
                f.flush()
                os.fsync(f.fileno())
            os.replace(temporary, path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    return {"ok": True, "audio_backend": value}


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise ValueError("Usage: ufxplus-driver-backend pipewire|alsa|pipewire+alsa")
        result = change(sys.argv[1])
    except (ValueError, RuntimeError, OSError, subprocess.SubprocessError) as error:
        result = {"ok": False, "error": str(error)}
    print(json.dumps(result))
    sys.exit(0 if result["ok"] else 1)
