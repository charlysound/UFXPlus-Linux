"""Serialize explicit settings changes and quiesce the user audio service.

Never reset USB, retry writes or resume after an uncertain hardware change.
The Rust device lease and idle checks remain the final authority for writes.
"""
from contextlib import contextmanager
import fcntl
import os
from pathlib import Path
import subprocess
import runtime_state

UNIT = "ufxplus-driver.service"
ALSA_CARD = Path("/proc/asound/UFXPlus")


def ensure_alsa_clients_closed():
    """Reject topology changes before stopping an open kernel-card client."""
    for direction in ("p", "c"):
        try:
            status = (ALSA_CARD / f"pcm0{direction}/sub0/status").read_text().strip()
        except FileNotFoundError:
            continue  # Optional kernel-card frontend is not installed/present.
        if status != "closed":
            raise RuntimeError("Fireface UFX+ is in use by an ALSA application. "
                               "Close the DAW audio device before changing mode or sample rate.")


def state():
    return subprocess.run(
        ["systemctl", "--user", "show", UNIT, "--property=ActiveState", "--value"],
        capture_output=True, text=True, timeout=3, check=True).stdout.strip()


def service(action):
    result = subprocess.run(["systemctl", "--user", action, UNIT],
                            capture_output=True, text=True, timeout=25)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or f"Driver {action} failed")


@contextmanager
def transaction(preflight=None, *, resume_failed=False):
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if not runtime:
        raise RuntimeError("The desktop user runtime directory is unavailable")
    fd = os.open(Path(runtime) / "ufxplus-settings.lock",
                 os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError("Another settings change is in progress") from error
        session=runtime_state.read()
        if session and session.get('state') in ('delegated','delegation-error'):
            raise RuntimeError('This interface uses the common RME owner. Choose its UID in RME Settings or use rme-linux-settings hardware; the historical service is not stopped.')
        initial = state()
        if initial not in ("active", "inactive", "failed"):
            raise RuntimeError("The driver is transitioning; try again when it is ready")
        if preflight:
            preflight()
        was_active = initial == "active"
        restart = was_active or (resume_failed and initial == "failed")
        if was_active:
            service("stop")
            if state() != "inactive":
                raise RuntimeError("Driver did not stop cleanly; no settings were changed")
        try:
            yield
        except Exception as error:
            if restart:
                raise RuntimeError(f"{error} Driver left stopped; no automatic retry or rollback.") from error
            raise
        if restart:
            try:
                service("start")
                if state() != "active":
                    raise RuntimeError("The driver did not remain active")
            except Exception as error:
                raise RuntimeError(f"Setting applied, but driver restart failed: {error}") from error
    finally:
        os.close(fd)
