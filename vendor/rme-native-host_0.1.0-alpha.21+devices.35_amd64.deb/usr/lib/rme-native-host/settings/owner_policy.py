"""Linux owner preference and cooperative handoff. No RME command encoding."""
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import tempfile


def directory(uid):
    if not isinstance(uid, str) or not uid.startswith('rme:') or not 0 < len(uid) <= 512 or '\0' in uid:
        raise ValueError('Invalid RME UID')
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')/'rme-native/devices'/hashlib.sha256(uid.encode()).hexdigest()


def read_json(path):
    with os.fdopen(os.open(path, os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC), 'r') as stream:
        info=os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077 or info.st_size>1048576:
            raise ValueError('Owner transaction file must be private and bounded')
        value=json.load(stream)
    if not isinstance(value,dict):raise ValueError('Invalid owner transaction object')
    return value


def save_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',dir=path.parent,delete=False) as stream:
            temporary=Path(stream.name);json.dump(value,stream,separators=(',',':'));stream.write('\n');stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
        fd=os.open(path.parent,os.O_DIRECTORY|os.O_CLOEXEC)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def validate(value,uid):
    device=value.get('device') if isinstance(value,dict) else None
    if (not isinstance(value,dict) or value.get('schema')!=1 or type(value['schema']) is not int or value.get('uid')!=uid or
            value.get('owner') not in ('native','legacy') or value.get('phase') not in ('pending','committed','error') or
            not isinstance(value.get('request_id'),str) or len(value['request_id'])!=32 or any(c not in '0123456789abcdef' for c in value['request_id']) or
            not isinstance(device,dict) or set(device)!={'vendor_id','product_id','serial','usb_path'} or
            any(type(device.get(k)) is not int or not 0<=device[k]<=65535 for k in ('vendor_id','product_id')) or
            (device.get('serial') is not None and (not isinstance(device['serial'],str) or not device['serial'])) or
            not isinstance(device.get('usb_path'),str) or Path(device['usb_path']).name!=device['usb_path'] or device['usb_path'] in ('','.','..')):
        raise ValueError('Invalid Linux owner preference')
    midi=value.get('midi')
    if midi is not None and (not isinstance(midi,dict) or type(midi.get('pid')) is not int or midi['pid']<=0 or not isinstance(midi.get('process_start'),str)):
        raise ValueError('Invalid previous MIDI owner identity')
    if value['phase']=='pending' and not isinstance(value.get('expected'),dict):raise ValueError('Missing previous owner authority')
    return value


def resume_binding(value,pid,start,path):
    """A one-shot manager-confirmed numeric-format conversion, never a clock replay."""
    resume=value.get('legacy_resume')
    if (value.get('owner')!='legacy' or value.get('phase')!='committed' or not isinstance(resume,dict) or
            resume.get('schema')!=1 or type(resume['schema']) is not int or resume.get('request_id')!=value.get('request_id') or
            resume.get('supervisor_pid')!=pid or type(resume.get('supervisor_pid')) is not int or
            resume.get('supervisor_process_start')!=start or not isinstance(start,str) or
            resume.get('pcm_format')!='signed-pcm24-in-32le' or resume.get('preparation_confirmed') is not True or
            type(resume.get('rate_hz')) is not int or resume['rate_hz']<=0 or not isinstance(resume.get('attachment'),dict) or
            not attachment_current(resume['attachment'],path)):
        raise ValueError('Legacy resume has no current guarded PCM24 preparation authority')
    return resume


def read(uid):
    try:return validate(read_json(directory(uid)/'owner.json'),uid)
    except FileNotFoundError:return None


def matches(value,device):
    saved=value['device']
    return (all(saved[k]==device.get(k) for k in ('vendor_id','product_id','serial')) and
            (saved['serial'] is not None or saved['usb_path']==device.get('usb_path')))


def attachment_current(expected,path):
    path=Path(path);before=path.stat();raw=(path/'descriptors').read_bytes()
    seconds,nanos=divmod(before.st_ctime_ns,1000000000)
    result=(expected.get('connection_marker')==f'{before.st_dev}:{before.st_ino}:{seconds}:{nanos}' and
            expected.get('descriptor_sha256')==hashlib.sha256(raw).hexdigest() and
            expected.get('bus')==int((path/'busnum').read_text()) and expected.get('address')==int((path/'devnum').read_text()))
    after=path.stat()
    return result and (before.st_dev,before.st_ino,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_ctime_ns)


def import_nodes(catalogue,device,legacy):
    """Map the old five switches to producer stream IDs, including idle ports.

    The five boundaries belong to the existing Linux adapter. Native stream
    descriptions/IDs remain in the producer catalogue, never a Linux PID table.
    """
    profiles=[p for p in catalogue['profiles'] if p['product_id']==device['product_id']]
    if catalogue.get('schema')!=1 or len(profiles)!=1:raise ValueError('Native profile unavailable for owner migration')
    profile=profiles[0];enabled={};spans=[]
    for direction,key in (('capture','input_lists'),('playback','output_lists')):
        flags=legacy.get(direction)
        if not isinstance(flags,list) or len(flags)!=5 or any(type(x) is not bool for x in flags):raise ValueError('Invalid legacy node switches')
        boundaries=[0,8,12,14,30,94]  # existing node_control.inventory SS layout
        for index in catalogue[key][profile['stream_list']]:
            group=catalogue['stream_groups'][index]
            if group['host_fx']:continue
            start=group['channel_start'];count=group['declared_channels'][0]
            choices=[i for i in range(5) if boundaries[i]<=start and start+count<=boundaries[i+1]]
            if len(choices)!=1 or count<=0:raise ValueError('Native stream crosses a legacy node switch; migration refused')
            for part,offset in enumerate(range(0,count,64)):
                name=f"rme.{device['uid'].encode().hex()}.{direction}.{group['native_id']}.{part}"
                enabled[name]=flags[choices[0]]
                spans.append(dict(name=name,direction=direction,legacy_index=choices[0],native_first=start+offset+1,channels=min(64,count-offset)))
    if not spans:raise ValueError('No physical native streams for owner migration')
    return dict(schema=1,uid=device['uid'],enabled=enabled),spans


def for_usb(path):
    """Legacy adapter checks producer-issued identities; it does not invent UIDs."""
    root=directory('rme:policy-root').parent
    files=list(root.glob('*/owner.json'))
    if not files:return None
    path=Path(path)
    device=dict(vendor_id=int((path/'idVendor').read_text().strip(),16),product_id=int((path/'idProduct').read_text().strip(),16),usb_path=path.name)
    try:device['serial']=(path/'serial').read_text().strip() or None
    except FileNotFoundError:device['serial']=None
    found=[]
    for filename in files:
        value=read_json(filename);uid=value.get('uid');validate(value,uid)
        if filename.parent!=directory(uid):raise ValueError('Owner preference directory differs from UID')
        if matches(value,device):found.append(value)
    if len(found)>1:raise ValueError('Ambiguous Linux owner preference')
    return found[0] if found else None


def legacy_clients_closed(check_alsa,proc=Path('/proc')):
    check_alsa()
    socket=os.fsencode(Path(os.environ['XDG_RUNTIME_DIR'])/'ufxplus-alsa/pcm.sock')
    for line in (proc/'net/unix').read_bytes().splitlines()[1:]:
        fields=line.split(None,7)
        if len(fields)==8 and fields[5]==b'03' and fields[7]==socket:
            raise ValueError('Close the UFX+ ALSA plugin before migrating its owner')


def stop_midi(expected,usb_path,proc=Path('/proc')):
    """Signal only the already identified companion that holds this USB node.

    pidfd prevents PID reuse between validation and signalling. IF2 availability
    is independently required by the new owner, even when no MIDI was active.
    """
    if expected is None:return
    pid=expected.get('pid');start=expected.get('process_start')
    if type(pid) is not int or pid<=0 or not isinstance(start,str):raise ValueError('Missing MIDI process identity')
    if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal'):
        raise ValueError('Safe MIDI handoff needs pidfd support on this Linux/Python')
    fd=os.pidfd_open(pid,0)
    try:
        path=proc/str(pid)
        def current():return (path/'stat').read_text().rsplit(')',1)[1].split()[19]
        if (path.stat().st_uid!=os.getuid() or current()!=start or
                (path/'cmdline').read_bytes().split(b'\0')[0]!=b'/usr/bin/ufxplus-midi' or
                not any(p.readlink()==usb_path for p in (path/'fd').iterdir()) or current()!=start):
            raise ValueError('MIDI companion identity or USB attachment changed')
        signal.pidfd_send_signal(fd,signal.SIGTERM)
    finally:os.close(fd)
