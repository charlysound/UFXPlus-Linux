#!/usr/bin/python3
"""Keep Linux settings transactions outside the RME services they may stop."""
import os
from pathlib import Path
import subprocess
import sys

CGROUP = Path('/proc/self/cgroup')
PANEL = '/usr/lib/rme-native-host/settings/panel.py'
MANAGED_UNITS = {b'oscmix-with-driver.service', b'ufxplus-driver.service',
                 b'rme-native-devices.service'}
FORWARDED_ENV = ('DISPLAY', 'WAYLAND_DISPLAY', 'XAUTHORITY', 'DBUS_SESSION_BUS_ADDRESS',
                 'XDG_RUNTIME_DIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME',
                 'XDG_STATE_HOME', 'XDG_CONFIG_DIRS', 'XDG_DATA_DIRS',
                 'LANG', 'LC_ALL', 'PATH', 'GDK_BACKEND')


def managed_cgroup():
    try:
        lines = CGROUP.read_bytes().splitlines()
    except FileNotFoundError:
        return False
    return any(MANAGED_UNITS.intersection(fields[2].split(b'/'))
               for line in lines if len(fields := line.split(b':', 2)) == 3)


def main(argv=None):
    arguments = ['/usr/bin/python3', PANEL, *(sys.argv[1:] if argv is None else argv)]
    try:
        if managed_cgroup():
            command = ['systemd-run', '--user', '--collect', '--quiet', '--property=Type=exec']
            command.extend('--setenv=' + key + '=' + os.environ[key]
                           for key in FORWARDED_ENV if key in os.environ)
            # A transient service has no PartOf relationship with the RME
            # services. Do not use --scope/--wait or a same-cgroup fallback.
            return subprocess.run([*command, '--', *arguments], check=False).returncode
        os.execv(arguments[0], arguments)
        return 0  # execv only returns in the pure tests
    except OSError as error:
        print('Could not launch the RME settings panel: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
