#!/usr/bin/python3
"""Explicit rate change; quiesce and resume a running user audio service."""
import json
import subprocess
import sys
from pathlib import Path
import settings_control
import startup_rate

from capabilities import RATES
def change(hz, *, before_change=None, expected_binding=None):
    if type(hz) is not int or hz not in RATES:
        raise ValueError("Unsupported frequency")
    def preflight():
        settings_control.ensure_alsa_clients_closed()
        if before_change is not None:
            before_change()
        result = subprocess.run(["ufxplus-rate", "status"], capture_output=True, text=True, timeout=3)
        if result.returncode:
            raise RuntimeError(result.stderr.strip() or "Cannot read the hardware clock")
        status = json.loads(result.stdout)
        if status.get("source") != 7 or status.get("external_locked") is not False:
            raise RuntimeError("Rate changes currently require Internal clock with no external input lock")
        if status.get("input_transport") != "Bulk":
            raise RuntimeError("The audio backend requires Bulk input; device left unchanged")
    # An explicit, successfully read-back rate selection also recovers a
    # failed login startup (e.g. unsupported cold-state 32 kHz). This is one
    # user-requested attempt, never an automatic retry after a failed write.
    command=["ufxplus-rate", "set", str(hz)]
    if expected_binding is not None:
        tool=Path(__file__).resolve().parent.parent/'ufxplus-rate-guarded'
        if not tool.is_file():
            raise RuntimeError('The guarded UFX+ rate helper is not installed')
        command=[str(tool),'set-guarded',str(hz),expected_binding['uid'],
                 expected_binding['connection_marker'],expected_binding['descriptor_sha256']]
    dispatched = False
    try:
        with settings_control.transaction(preflight, resume_failed=True):
            dispatched = True
            result = subprocess.run(command, capture_output=True, text=True, timeout=5)
            if result.returncode:
                raise RuntimeError(result.stderr.strip() or "Frequency change failed; refresh hardware status.")
            report = json.loads(result.stdout)
            if report["after"]["rate_hz"] != hz or report["after"]["source"] != 7:
                raise RuntimeError("Hardware did not confirm the requested frequency.")
            startup_rate.save(hz)
    except Exception as error:
        if dispatched:
            error.uncertain = True
        raise
    return {"ok": True, "rate_hz": hz}

if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise ValueError("Choose a frequency listed in the driver settings")
        result = change(int(sys.argv[1]))
    except (ValueError, RuntimeError, OSError, subprocess.SubprocessError, KeyError, TypeError) as error:
        result = {"ok": False, "error": str(error)}
    print(json.dumps(result))
    sys.exit(0 if result["ok"] else 1)
