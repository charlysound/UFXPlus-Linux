"""Explicit Clock Source preference; current lock is reported separately."""
import json
import subprocess
import settings_control

SOURCES = ("Internal", "Word Clock", "AES", "ADAT 1", "ADAT 2", "MADI optical", "MADI coaxial")


def source_choices(rows):
    """Keep native menu IDs separate from the current-clock status code."""
    if not isinstance(rows, list) or not 0 < len(rows) <= 64:
        raise ValueError("Clock source inventory unavailable")
    choices = []
    for index, row in enumerate(rows):
        # Compatibility with the historical settings envelope only.
        if isinstance(row, str):
            row = dict(id=index, label=row)
        if (not isinstance(row, dict) or type(row.get('id')) is not int or
                not 0 <= row['id'] <= 65535 or not isinstance(row.get('label'), str) or
                not row['label'] or len(row['label']) > 256):
            raise ValueError("Invalid native clock source")
        choices.append((row['id'], row['label']))
    if len({key for key, _ in choices}) != len(choices) or len({label for _, label in choices}) != len(choices):
        raise ValueError("Duplicate native clock source")
    return tuple(choices)


def change(source):
    if type(source) is not int or source not in range(len(SOURCES)):
        raise ValueError("Unsupported clock source")
    with settings_control.transaction():
        result = subprocess.run(["ufxplus-rate", "source", str(source)],
                                capture_output=True, text=True, timeout=5)
        if result.returncode:
            raise RuntimeError(result.stderr.strip() or "Clock Source change failed")
        after = json.loads(result.stdout)["after"]
        if after.get("selected_source") != SOURCES[source]:
            raise RuntimeError("Hardware did not confirm the requested Clock Source")
        if after.get("source") != 7:
            raise RuntimeError("Clock Source applied. External-clock audio streaming is not yet validated; driver left stopped. Select Internal to return to the supported audio mode.")
    return {"ok": True, "selected_source": SOURCES[source]}
