"""One confirmed Linux selection shared with OSCmix; no hardware operation."""
import configparser
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile

UID = re.compile(r'rme:[0-9a-f]{4}:[0-9a-f]{4}:(?:serial|port):[0-9a-f]+\Z')
GIO = r'''
import json,sys
from gi.repository import Gio,GLib
uid=json.loads(sys.argv[1]);bus=Gio.bus_get_sync(Gio.BusType.SESSION,None)
name='io.github.charlysound.Oscmix.Control.native'
owner=bus.call_sync('org.freedesktop.DBus','/org/freedesktop/DBus','org.freedesktop.DBus','NameHasOwner',GLib.Variant('(s)',(name,)),GLib.VariantType.new('(b)'),Gio.DBusCallFlags.NONE,3000,None).unpack()[0]
if not owner:print(json.dumps(dict(running=False)))
else:
 method='GetSelectedDevice' if uid is None else 'SelectDevice'
 params=None if uid is None else GLib.Variant('(s)',(uid,))
 answer=bus.call_sync(name,'/io/github/charlysound/Oscmix/Window','io.github.charlysound.Oscmix.Window',method,params,GLib.VariantType.new('(s)' if uid is None else '(bs)'),Gio.DBusCallFlags.NO_AUTO_START,10000,None).unpack()
 print(json.dumps(dict(running=True,uid=answer[-1],accepted=True if uid is None else answer[0])))
'''


def check(uid):
    if not isinstance(uid,str) or not UID.fullmatch(uid):raise ValueError('Invalid exact RME selection UID')
    return uid


def path():
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')/'rme-native/selection.ini'


def read():
    target=path()
    try:
        with os.fdopen(os.open(target,os.O_RDONLY|os.O_NOFOLLOW),'r',encoding='utf-8') as stream:
            info=os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_size>4096:raise ValueError('Invalid shared selection file')
            text=stream.read(4097)
    except FileNotFoundError:return None
    try:
        data=configparser.ConfigParser(interpolation=None);data.read_string(text)
        return check(data['selection']['uid'])
    except (configparser.Error,KeyError) as error:raise ValueError('Invalid shared selection file') from error


def write(uid):
    check(uid)
    if read()==uid:return
    target=path();target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',dir=target.parent,delete=False) as stream:
            temporary=Path(stream.name);os.chmod(temporary,0o600)
            stream.write('[selection]\nuid='+uid+'\n');stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,target)
    finally:
        if temporary is not None:temporary.unlink(missing_ok=True)


def live(uid=None):
    if uid is not None:check(uid)
    value=json.loads(subprocess.check_output(['/usr/bin/python3','-c',GIO,json.dumps(uid)],text=True,timeout=14))
    if type(value.get('running')) is not bool:raise ValueError('Invalid OSCmix selection reply')
    if value['running']:
        if value.get('uid'):check(value['uid'])
        if uid is not None and (value.get('accepted') is not True or value.get('uid')!=uid):
            raise RuntimeError('OSCmix refused this selection; wait for its current operation to finish')
    return value


def current():
    value=live()
    return value.get('uid') or None if value['running'] else read()


def select(uid,inventory):
    check(uid)
    if uid not in {row['uid'] for row in inventory}:raise ValueError('The selected RME interface is no longer present')
    value=live(uid)
    # A running GUI persists only after its existing selection guards accepted.
    # A closed GUI has no concurrent selected state; the same file seeds startup.
    if not value['running']:
        previous=read()
        write(uid)
        written=path().stat().st_ino
        # A GUI can acquire its bus name during a closed-window choice. If it
        # did, request the same UID through its guards before confirming.
        try:
            again=live(uid)
        except (RuntimeError,OSError,ValueError,subprocess.SubprocessError):
            # Undo only our unchanged file if a newly opened GUI refused it.
            if path().stat().st_ino==written and read()==uid:
                if previous is None:path().unlink()
                else:write(previous)
            raise
        if again['running']:value=again
    if read()!=uid:raise RuntimeError('The shared confirmed selection was not persisted')
    return dict(ok=True,uid=uid,running=value['running'],confirmed=True)
