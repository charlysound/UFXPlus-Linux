#!/usr/bin/python3
"""Save the UFX+ PipeWire block size, restarting an active stream safely."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import settings_control

from capabilities import BUFFER_FRAMES as SIZES


def config_path():
    root = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(root) / "ufxplus-driver" / "buffer-frames"


def read():
    try:
        value = int(config_path().read_text().strip())
    except FileNotFoundError:
        return 0
    if value not in SIZES:
        raise ValueError("Unsupported saved buffer size")
    return value


def change(frames):
    if type(frames) is not int or frames not in SIZES:
        raise ValueError("Choose a buffer size listed in the driver settings")
    with settings_control.transaction():
        save(frames)
    return {"ok": True, "buffer_frames": read(), "applies": "active_or_next_start"}


def save(frames):
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False) as f:
            temporary = Path(f.name)
            f.write(str(frames) + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise ValueError("Usage: ufxplus-driver-buffer auto|FRAMES")
        result = change(0 if sys.argv[1] == "auto" else int(sys.argv[1]))
    except (ValueError, RuntimeError, OSError, subprocess.SubprocessError) as error:
        result = {"ok": False, "error": str(error)}
    print(json.dumps(result))
    sys.exit(0 if result["ok"] else 1)
