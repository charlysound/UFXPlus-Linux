"""Semantic Digital I/O changes with fresh-state conflict detection."""
import json
import re
import subprocess
import settings_control

# key, label, semantic values; protocol masks live only in the Rust boundary.
GROUPS = (
    ("Input", (
        ("word_clock_termination", "Word Clock termination", ("Off", "75 Ω")),
        ("aes_input", "AES Input", ("XLR", "Optical 2")),
        ("madi_input", "MADI Input", ("Optical", "Coaxial", "Auto", "Split")),
        ("dsp_record", "DSP Record EQ+D", ("Off", "On")),
    )),
    ("Output", (
        ("aes_format", "AES Format", ("Consumer", "Professional")),
        ("optical_1_out", "Optical 1 Out", ("ADAT", "SPDIF")),
        ("optical_2_out", "Optical 2 Out", ("ADAT", "SPDIF", "AES")),
        ("madi_output", "MADI Output", ("Optical", "Mirror", "Split")),
        ("madi_format", "MADI Format", ("56 channels", "64 channels")),
        ("madi_frame", "MADI Frame", ("48K", "96K")),
    )),
    ("Clock", (("word_clock_single_speed", "Word Clock Single Speed", ("Off", "On")),)),
)
CHOICES = {key: choices for _, rows in GROUPS for key, _, choices in rows}


def choices(key, modern):
    if modern is False and key == "optical_2_out":
        return ("ADAT", "AES")
    return CHOICES[key]


def settings_identity(snapshot):
    """V2 guards are opaque; only the historical envelope uses a flags word."""
    if not isinstance(snapshot, dict):
        raise ValueError('Digital I/O readback unavailable')
    if 'expected_settings' in snapshot:
        token = snapshot['expected_settings']
        if not isinstance(token, str) or not token or len(token) > 8192 or '\0' in token:
            raise ValueError('Invalid hardware settings guard')
        return ('settings', token)
    flags = snapshot.get('flags')
    if type(flags) is not int or not 0 <= flags <= 0xffffffff:
        raise ValueError("Digital I/O readback unavailable")
    return ('flags', flags)


def validate(snapshot):
    settings_identity(snapshot)
    values = snapshot.get("values")
    fields = snapshot.get('fields')
    domains = {row['id']: {choice['id'] for choice in row['choices']} for row in native_fields(fields)} if fields is not None else None
    if not isinstance(values, dict) or set(values) != set(domains if domains is not None else CHOICES):
        raise ValueError("Incomplete Digital I/O readback")
    for key, value in values.items():
        domain = domains[key] if domains is not None else range(len(choices(key, snapshot.get("modern_optical"))))
        if value is not None and (type(value) is not int or value not in domain):
            raise ValueError("Invalid Digital I/O readback")
    return snapshot


def native_fields(rows):
    """Validate producer descriptors; unknown values remain unavailable."""
    if not isinstance(rows, list) or len(rows) > 64:
        raise ValueError('Digital I/O inventory unavailable')
    ids = set()
    for row in rows:
        if (not isinstance(row, dict) or not isinstance(row.get('id'), str) or
                not re.fullmatch(r'[a-z][a-z0-9_]{0,63}', row['id']) or row['id'] in ids or
                any(not isinstance(row.get(key), str) or not row[key] or len(row[key]) > 256 for key in ('label', 'group'))):
            raise ValueError('Invalid Digital I/O descriptor')
        ids.add(row['id'])
        options = row.get('choices')
        if not isinstance(options, list) or not 0 < len(options) <= 64:
            raise ValueError('Digital I/O choices unavailable')
        keys = set()
        for option in options:
            if (not isinstance(option, dict) or type(option.get('id')) is not int or not 0 <= option['id'] <= 65535 or
                    option['id'] in keys or not isinstance(option.get('label'), str) or not option['label'] or len(option['label']) > 256):
                raise ValueError('Invalid Digital I/O choice')
            keys.add(option['id'])
        if 'value' not in row or (row['value'] is not None and (type(row['value']) is not int or row['value'] not in keys)):
            raise ValueError('Invalid Digital I/O value')
    return rows


def selections_valid(snapshot, selections):
    validate(snapshot)
    if not isinstance(selections, dict) or not selections:
        return False
    domains = ({row['id']: {choice['id'] for choice in row['choices']} for row in snapshot['fields']}
               if 'fields' in snapshot else {key: range(len(choices(key, snapshot.get('modern_optical')))) for key in CHOICES})
    return all(key in domains and type(value) is int and value in domains[key] and
               snapshot['values'].get(key) is not None for key, value in selections.items())


def status():
    result = subprocess.run(["ufxplus-rate", "status"], capture_output=True, text=True, timeout=4)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or "Digital I/O read failed")
    return json.loads(result.stdout)


def change(snapshot, selections):
    snapshot = validate(snapshot)
    if not selections or any(key not in CHOICES or type(value) is not int or
            value not in range(len(choices(key, snapshot.get("modern_optical")))) or
            snapshot["values"][key] is None for key, value in selections.items()):
        raise ValueError("Unsupported Digital I/O change")
    pending = {key: value for key, value in selections.items() if snapshot["values"][key] != value}
    if not pending:
        return {"ok": True}

    def preflight():
        current = status()
        if validate(current.get("digital"))["flags"] != snapshot["flags"]:
            raise RuntimeError("Hardware settings changed since displayed. Refresh and review your selections.")
        if current.get("source") != 7 or current.get("selected_source") != "Internal" or current.get("input_transport") != "Bulk":
            raise RuntimeError("Digital I/O changes currently require Internal clock and Bulk input transport")

    with settings_control.transaction(preflight):
        result = subprocess.run(["ufxplus-rate", "digital", str(snapshot["flags"]),
            *[f"{key}={value}" for key, value in sorted(pending.items())]],
            capture_output=True, text=True, timeout=8)
        if result.returncode:
            raise RuntimeError(result.stderr.strip() or "Digital I/O change failed")
        after = validate(json.loads(result.stdout)["after"]["digital"])
        if any(after["values"][key] != value for key, value in pending.items()):
            raise RuntimeError("Hardware did not confirm Digital I/O settings")
    return {"ok": True, "digital": after}
