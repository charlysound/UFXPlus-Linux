"""UI inventory generated from `ufxplus-rate capabilities` (no USB access)."""
import json
from pathlib import Path

DATA = json.loads(Path(__file__).with_name("capabilities.json").read_text())
RATES = tuple(DATA["rates"])
BUFFER_FRAMES = tuple(DATA["buffer_frames"])
