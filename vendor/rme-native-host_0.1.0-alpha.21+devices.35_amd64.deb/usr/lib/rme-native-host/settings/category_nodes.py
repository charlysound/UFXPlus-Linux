"""Pure projection of the loaded worker's category catalog and preferences.

No model table, store, USB, process, graph mutation or independent UI state.
"""
import re

ABI = 2
DIRECTIONS = ('capture', 'playback')


def catalog(audio, uid):
    value = audio.get('pipewire_node_layout')
    if (audio.get('pipewire_nodes_abi') != ABI or not isinstance(value, dict)
            or value.get('schema') != ABI or not isinstance(value.get('categories'), list)):
        raise ValueError('Loaded audio worker has no category-node ABI')
    prefix = 'rme.' + uid.encode().hex() + '.category.'
    seen_categories, seen_channels = set(), {d: set() for d in DIRECTIONS}
    for row in value['categories']:
        if (not isinstance(row, dict) or not isinstance(row.get('category'), str)
                or not re.fullmatch('[a-z][a-z0-9_]{0,31}', row['category'])
                or row['category'] in seen_categories or row.get('name') != prefix + row['category']
                or not isinstance(row.get('label'), str) or not row['label']):
            raise ValueError('Invalid category identity from audio worker')
        seen_categories.add(row['category'])
        for direction in DIRECTIONS:
            ports = row.get(direction)
            bank = (audio.get('topology') or {}).get(direction) or {}
            physical = bank.get('physical_ports')
            if not isinstance(ports, list) or not isinstance(physical, list):
                raise ValueError('Category PCM inventory is missing')
            for port in ports:
                channel = port.get('native_channel') if isinstance(port, dict) else None
                available = port.get('available') if isinstance(port, dict) else None
                index = port.get('physical_index') if isinstance(port, dict) else None
                if (type(channel) is not int or not 1 <= channel <= 256
                        or channel in seen_channels[direction] or type(available) is not bool
                        or not isinstance(port.get('label'), str) or not port['label']
                        or port.get('port_name') != direction + '_' + str(channel)
                        or not isinstance(port.get('legacy_node_name'), str)
                        or not port['legacy_node_name'].startswith('rme.' + uid.encode().hex() + '.' + direction + '.')):
                    raise ValueError('Invalid registered category channel')
                seen_channels[direction].add(channel)
                if available:
                    if (type(index) is not int or not 0 <= index < len(physical)
                            or physical[index].get('native_channel') != channel
                            or physical[index].get('category') != row['category']
                            or physical[index].get('wire_channel') != port.get('wire_channel')):
                        raise ValueError('Category and physical channel coordinates disagree')
                elif index is not None or port.get('wire_channel') is not None:
                    raise ValueError('Inactive channel has an active PCM coordinate')
    for direction in DIRECTIONS:
        physical = ((audio.get('topology') or {}).get(direction) or {}).get('physical_ports') or []
        projected = {p['native_channel'] for c in value['categories'] for p in c[direction] if p['available']}
        if projected != {p['native_channel'] for p in physical}:
            raise ValueError('Category inventory does not cover the physical PCM channels')
    return value['categories']


def validate(value, uid, plans=None):
    if (not isinstance(value, dict) or set(value) != {'schema', 'uid', 'categories'}
            or type(value.get('schema')) is not int or value['schema'] != ABI or value['uid'] != uid
            or not isinstance(value.get('categories'), dict) or len(value['categories']) > 32):
        raise ValueError('Invalid category-node selection')
    known = {p['category']: p for p in plans} if plans is not None else None
    for name, choice in value['categories'].items():
        if (not isinstance(name, str) or not re.fullmatch('[a-z][a-z0-9_]{0,31}', name)
                or known is not None and name not in known
                or not isinstance(choice, dict) or set(choice) != {'enabled', *DIRECTIONS}
                or type(choice.get('enabled')) is not bool):
            raise ValueError('Unknown or invalid node category')
        for direction in DIRECTIONS:
            mask = choice[direction]
            allowed = {p['native_channel'] for p in known[name][direction]} if known is not None else None
            if not isinstance(mask, dict) or len(mask) > 256:
                raise ValueError('Invalid category channel mask')
            for channel, selected in mask.items():
                if (not isinstance(channel, str) or not channel.isascii() or not channel.isdecimal()
                        or not 1 <= int(channel) <= 256 or str(int(channel)) != channel
                        or type(selected) is not bool or allowed is not None and int(channel) not in allowed):
                    raise ValueError('Unknown or noncanonical category channel')
    return value


def normalize(value, uid, plans):
    old = value.get('schema') == 1
    if old:
        if (set(value) != {'schema', 'uid', 'enabled'} or value.get('uid') != uid
                or not isinstance(value.get('enabled'), dict)
                or any(not isinstance(k, str) or not k.startswith('rme.' + uid.encode().hex() + '.')
                       or type(v) is not bool for k, v in value['enabled'].items())):
            raise ValueError('Invalid legacy node selection')
    else:
        validate(value, uid, plans)
    categories = {}
    for plan in plans:
        saved = {} if old else value['categories'].get(plan['category'], {})
        choice = {'enabled': saved.get('enabled', True)}
        for direction in DIRECTIONS:
            choice[direction] = {
                str(p['native_channel']): (value['enabled'].get(p['legacy_node_name'], True) if old
                                          else saved.get(direction, {}).get(str(p['native_channel']), True))
                for p in plan[direction]}
        categories[plan['category']] = choice
    return dict(schema=ABI, uid=uid, categories=categories)


def merge(current, request, uid, plans):
    validate(request, uid, plans)
    result = normalize(current, uid, plans)
    for name, choice in request['categories'].items():
        result['categories'][name]['enabled'] = choice['enabled']
        for direction in DIRECTIONS:
            result['categories'][name][direction].update(choice[direction])
    return validate(result, uid, plans)


def project(plans, selection, published):
    """Validate actual publication against selected available ports before UI ACK."""
    by_category, identities = {}, {published['device_id']} if published is not None else set()
    if published is not None:
        if published.get('node_layout_abi') != ABI or not isinstance(published.get('nodes'), list):
            raise ValueError('Category publication has no loaded ABI')
        for row in published['nodes']:
            if not isinstance(row, dict) or row.get('category') in by_category:
                raise ValueError('Duplicate or invalid published category')
            by_category[row.get('category')] = row
        if set(by_category) != {p['category'] for p in plans}:
            raise ValueError('Incomplete category publication')
    rows, matches = [], True
    for plan in plans:
        choice = selection['categories'][plan['category']]
        expected = {(direction, p['native_channel']): p for direction in DIRECTIONS for p in plan[direction]
                    if choice['enabled'] and choice[direction][str(p['native_channel'])] and p['available']}
        actual, bound = {}, by_category.get(plan['category'])
        if bound is not None:
            active = bool(expected)
            if (bound.get('name') != plan['name'] or type(bound.get('enabled')) is not bool
                    or not isinstance(bound.get('ports'), list)
                    or (bound['enabled'] and (type(bound.get('id')) is not int or not 0 <= bound['id'] < 2**32-1))
                    or (not bound['enabled'] and bound.get('id') is not None)):
                raise ValueError('Invalid published category node')
            if bound['enabled']:
                if bound['id'] in identities: raise ValueError('Duplicate PipeWire object identity')
                identities.add(bound['id'])
            for port in bound['ports']:
                key = (port.get('direction'), port.get('native_channel')) if isinstance(port, dict) else None
                if (key is None or key in actual or key[0] not in DIRECTIONS or type(key[1]) is not int
                        or type(port.get('id')) is not int or not 0 <= port['id'] < 2**32-1
                        or port['id'] in identities or port.get('name') != key[0] + '_' + str(key[1])):
                    raise ValueError('Invalid published category port identity')
                if key not in {(d, p['native_channel']) for d in DIRECTIONS for p in plan[d] if p['available']}:
                    raise ValueError('Published channel is unavailable or foreign')
                actual[key] = port
                identities.add(port['id'])
            matches &= bound['enabled'] == active and set(actual) == set(expected)
        row = dict(category=plan['category'], name=plan['name'], label=plan['label'], enabled=choice['enabled'],
                   present=bool(bound and bound['enabled']), node_id=bound['id'] if bound and bound['enabled'] else None)
        for direction in DIRECTIONS:
            row[direction] = [dict(native_channel=p['native_channel'], label=p['label'], available=p['available'],
                                   selected=choice[direction][str(p['native_channel'])], present=(direction,p['native_channel']) in actual,
                                   port_id=actual.get((direction,p['native_channel']), {}).get('id')) for p in plan[direction]]
        rows.append(row)
    return rows, matches
