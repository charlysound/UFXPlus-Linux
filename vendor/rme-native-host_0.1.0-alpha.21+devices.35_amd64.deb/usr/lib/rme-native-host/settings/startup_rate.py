"""One guarded recovery of the observed Internal / 32 kHz startup state."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
from capabilities import RATES

DEFAULT = 48000


def config_path():
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "ufxplus-driver/recovery-rate"


def validate(hz):
    if type(hz) is not int or hz not in RATES:
        raise ValueError("Invalid saved startup recovery rate")
    return hz


def read():
    try:
        return validate(int(config_path().read_text().strip()))
    except FileNotFoundError:
        return DEFAULT


def save(hz):
    validate(hz)
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False) as f:
            temporary = Path(f.name)
            f.write(f"{hz}\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def prepare(hz):
    validate(hz)
    result = subprocess.run(["ufxplus-rate", "status"], check=True,
                            capture_output=True, text=True, timeout=3)
    status = json.loads(result.stdout)
    if type(status.get("rate_hz")) is not int:
        raise RuntimeError("Hardware nominal rate unavailable; no startup rate write")
    if status["rate_hz"] != 32000:
        return False  # Do not replace an already valid user/hardware choice.
    if (status.get("source") != 7 or status.get("selected_source") != "Internal"
            or status.get("external_locked") is not False or status.get("input_transport") != "Bulk"):
        raise RuntimeError("32 kHz startup recovery refused: external/unknown clock preference, lock or transport; no rate write")
    print(f"Recovering Internal 32000 Hz startup state to {hz} Hz (one guarded attempt).", flush=True)
    # Do not call the desktop rate helper: it manages this very service.
    # The native command rechecks the 32 kHz state under its device lease.
    result = subprocess.run(["ufxplus-rate", "recover-32k", str(hz)], check=True,
                            capture_output=True, text=True, timeout=5)
    after = json.loads(result.stdout)["after"]
    if (after.get("rate_hz") != hz or after.get("source") != 7
            or after.get("selected_source") != "Internal" or after.get("external_locked") is not False
            or after.get("input_transport") != "Bulk"):
        raise RuntimeError("Startup recovery readback mismatch; audio not started")
    print(f"Startup recovery confirmed by hardware: {hz} Hz, Internal.", flush=True)
    return True
