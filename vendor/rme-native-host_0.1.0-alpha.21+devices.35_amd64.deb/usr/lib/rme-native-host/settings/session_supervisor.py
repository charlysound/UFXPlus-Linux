"""Recover physical re-enumeration without blindly retrying hardware writes.

udev + child output + signals share one blocking selector. The 30 s fallback
only inspects sysfs; no polling USB control requests and no realtime work.
"""
import fcntl
import os
from pathlib import Path
import selectors
import signal
import subprocess
import time
import node_control
import startup_rate
import buffer_control
import runtime_state
import backend_control
import owner_policy
import settings_control


def discover(root=Path("/sys/bus/usb/devices"), dev_root=Path("/dev/bus/usb")):
    matches = []
    for path in root.iterdir():
        try:
            if ((path / "idVendor").read_text().strip() == "2a39"
                    and (path / "idProduct").read_text().strip() == "3fc1"):
                matches.append(path)
        except FileNotFoundError:
            continue
    if len(matches) > 1:
        return "ambiguous", None
    if not matches:
        return "absent", None
    try:
        path = matches[0]
        bus, device = [int((path / name).read_text()) for name in ("busnum", "devnum")]
        # Enumeration token, NOT a fixed controller/port identity.
        token = (str(path), bus, device, path.stat().st_ino)
        fd = os.open(dev_root / f"{bus:03d}/{device:03d}", os.O_RDWR | os.O_CLOEXEC)
        os.close(fd)
        return "available", token
    except PermissionError:
        return "permissions", token
    except FileNotFoundError:
        return "absent", None


def audio_busy(token):
    path = Path(token[0])
    # Rust's exact descriptor preflight and atomic claim are still authoritative.
    return any((path / (path.name + f":1.{index}") / "driver").is_symlink()
               for index in (0, 3))


def pipewire_token():
    remote = os.environ.get("PIPEWIRE_REMOTE", "pipewire-0")
    path = Path(remote) if remote.startswith("/") else Path(os.environ["XDG_RUNTIME_DIR"]) / remote
    try:
        stat = path.stat()
        return stat.st_dev, stat.st_ino, stat.st_ctime_ns
    except FileNotFoundError:
        return None


def companion(action):
    try:
        subprocess.run(["systemctl", "--user", action, "ufxplus-midi.service"],
                       check=True, timeout=6, stdout=subprocess.DEVNULL)
    except (OSError, subprocess.SubprocessError) as error:
        print(f"MIDI companion {action} unavailable: {error}", flush=True)


class Supervisor:
    def __init__(self):
        self.backend = backend_control.read()
        self.buffer_frames = buffer_control.read()
        self.child = None
        self.token = self.blocked = self.prepared = None
        self.session = 0
        self.started_at = 0
        self.last_state = None
        self.stopping = False
        self.buffer = b""
        self.pw_lost = False
        self.pw_retries = 0
        self.next_attempt = 0
        self.retry_delay = 1
        self.rate_hz = None
        self.startup_retries = 0
        self.was_ready = False
        self.delegation = None
        self.owner_policy_signature = None
        self.legacy_resume_applied = None

    def publish(self, state, detail=""):
        value = dict(state=state, detail=detail, session=self.session, backend=self.backend,owner_handoff_abi=1,
                     buffer_frames=self.buffer_frames,
                     worker_pid=self.child.pid if self.child else None,
                     session_started_at=self.started_at,
                     rate_hz=self.rate_hz if state == "running" else None)
        if self.delegation is not None:value['delegation']=self.delegation
        if self.legacy_resume_applied is not None:value['legacy_resume_request_id']=self.legacy_resume_applied[0]
        if value != self.last_state:
            runtime_state.write(value)
            self.last_state = value
            print(f"UFX+ session: {state}" + (f" — {detail}" if detail else ""), flush=True)

    def prepare(self):
        if self.backend != "alsa":
            node_control.read()
            buffer_control.read()
        startup_rate.prepare(startup_rate.read())
        subprocess.run(["ufxplus-rate", "prepare-pcm"], check=True,
                       stdout=subprocess.DEVNULL, timeout=5)

    def start(self, selector, token):
        self.token = token
        self.session += 1
        self.rate_hz = None
        self.started_at = time.time()
        self.publish("preparing")
        try:
            if self.prepared != token:
                self.prepare()
                self.prepared = token
            if self.stopping:
                return
            command = (["/usr/bin/ufxplus-alsa-server", str(Path(os.environ["XDG_RUNTIME_DIR"]) / "ufxplus-alsa" / "pcm.sock"), "--continuous"]
                       if self.backend == "alsa" else ["/usr/bin/ufxplus-live-capture", "--continuous"])
            environment = dict(os.environ)
            environment.pop("UFXPLUS_SHARED_ALSA_SOCKET", None)
            if self.backend == "pipewire+alsa":
                environment["UFXPLUS_SHARED_ALSA_SOCKET"] = str(Path(os.environ["XDG_RUNTIME_DIR"]) / "ufxplus-alsa" / "pcm.sock")
            self.child = subprocess.Popen(
                command, env=environment,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0)
            os.set_blocking(self.child.stdout.fileno(), False)
            selector.register(self.child.stdout, selectors.EVENT_READ, "worker")
            self.buffer = b""
            self.pw_lost = False
            self.publish("starting")
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
            # An uncertain write must not be retried on this enumeration.
            self.blocked = token
            self.publish("blocked", f"Initialization failed; no automatic write retry: {error}")

    def line(self, data):
        line = data.decode("utf-8", errors="replace")
        print(line, flush=True)
        if (line.startswith("UFXPLUS_READY ") and not self.stopping
                and (self.last_state or {}).get("state") == "starting"):
            try:
                self.rate_hz = startup_rate.validate(int(line.split()[1]))
            except (ValueError, IndexError):
                return
            self.publish("running")
            self.was_ready = True
            companion("start")
        elif line == "UFXPLUS_PIPEWIRE_LOST":
            self.pw_lost = True

    def drain(self, selector):
        try:
            data = os.read(self.child.stdout.fileno(), 65536)
        except BlockingIOError:
            return
        if not data:
            selector.unregister(self.child.stdout)
            self.child.stdout.close()
            if self.buffer:
                self.line(self.buffer)
                self.buffer = b""
            return
        self.buffer += data
        while b"\n" in self.buffer:
            line, self.buffer = self.buffer.split(b"\n", 1)
            self.line(line)
        if len(self.buffer) > 65536:
            self.line(self.buffer[:65536])
            self.buffer = b""

    def retire(self, selector, stop_companion=True):
        if not self.child:
            return True
        self.publish("disconnecting")
        if self.child.poll() is None:
            self.child.terminate()
            try:
                self.child.wait(timeout=4)
            except subprocess.TimeoutExpired:
                self.child.kill()
                self.child.wait(timeout=2)
                self.blocked = self.token
        if not self.child.stdout.closed:
            try:
                selector.unregister(self.child.stdout)
            except KeyError:
                pass
            self.child.stdout.close()
        self.last_exit=self.child.returncode
        self.child = None
        self.buffer = b""
        if stop_companion:companion("stop")
        return self.blocked != self.token and self.last_exit == 0

    def delegate(self, selector, token):
        """Release audio/MIDI cooperatively, leaving the unit and mixer alive."""
        try:
            policy=owner_policy.for_usb(Path(token[0]))
            if policy is None or policy['owner']=='legacy':
                was_delegated=self.delegation is not None
                if policy is not None and policy.get('phase')=='error':
                    self.owner_policy_signature=policy
                    self.publish('blocked',policy.get('error') or 'Historical rollback failed; explicit recovery required')
                    return True
                if policy is not None and not self.child and (was_delegated or (self.blocked==token and policy.get('legacy_resume') is not None)):
                    resume=owner_policy.resume_binding(policy,os.getpid(),runtime_state.start_ticks(os.getpid()),Path(token[0]))
                    key=(resume['request_id'],token)
                    if key==self.legacy_resume_applied:
                        self.publish('blocked','Legacy resume was already attempted; explicit recovery required')
                        return True
                    self.legacy_resume_applied=key
                    self.token=self.prepared=token  # Exact attachment prepared; first tick must not replay startup clock.
                    self.pw_retries=self.startup_retries=0;self.was_ready=False
                    self.blocked=None;self.next_attempt=0;self.retry_delay=1
                self.delegation=None
                self.owner_policy_signature=policy
                if was_delegated and self.child and self.child.poll() is None and self.rate_hz is not None:self.publish('running')
                return False
            self.owner_policy_signature=policy
            request=policy['request_id']
            if self.child:
                expected=policy.get('expected') or {}
                if (not isinstance(expected,dict) or policy['phase']!='pending' or expected.get('owner_pid')!=os.getpid() or
                        expected.get('owner_process_start')!=runtime_state.start_ticks(os.getpid()) or
                        expected.get('worker_pid')!=self.child.pid or
                        expected.get('worker_process_start')!=runtime_state.start_ticks(self.child.pid) or
                        not owner_policy.attachment_current(expected.get('attachment') or {},Path(token[0]))):
                    raise ValueError('Owner preference does not authorize retiring this legacy session')
                # Recheck at the final boundary: a client may have opened after
                # the caller/manager preflight. Refusal leaves audio untouched.
                owner_policy.legacy_clients_closed(settings_control.ensure_alsa_clients_closed)
                self.delegation=dict(request_id=request,state='draining',clean=False)
                clean=self.retire(selector,stop_companion=False)
                if not clean:raise ValueError('Historical audio did not confirm a clean drain')
                # Keep the known-attachment check immediately before PID-safe
                # MIDI retirement. A foreign MIDI owner is never signalled.
                if discover()[1]!=token or not owner_policy.attachment_current(expected['attachment'],Path(token[0])):
                    raise ValueError('USB attachment changed before MIDI handoff')
                node=Path('/dev/bus/usb')/f'{token[1]:03}/{token[2]:03}'
                owner_policy.stop_midi(policy.get('midi'),node)
                self.delegation=dict(request_id=request,state='drained',clean=True)
            elif self.delegation is None or self.delegation.get('request_id')!=request:
                # Starting with pending/error is a retired transaction, never a
                # reason to reissue preparation or claim USB after a crash.
                self.delegation=dict(request_id=request,state='reserved',clean=False)
            self.token=token  # Track a reserved attachment so policy polling also works after keeper replacement.
            self.publish('delegated','Audio/MIDI reserved for the common per-device owner')
        except (OSError,ValueError,RuntimeError) as error:
            self.delegation=dict(request_id=(locals().get('policy') or {}).get('request_id'),state='error',clean=False,error=str(error))
            self.publish('delegation-error',str(error))
        return True

    def tick(self, selector, removed=False):
        state, token = discover()
        if token and self.delegate(selector,token):return
        if self.child:
            # Revoking seat ACLs (screen lock / session switch) does not
            # invalidate an already-open USB handle. Do not cut healthy audio
            # just because opening another handle is temporarily forbidden.
            if removed or token != self.token or state not in ("available", "permissions"):
                self.retire(selector)
            elif self.child.poll() is None:
                return
            else:
                # Drain all queued output before classifying the child exit.
                while not self.child.stdout.closed:
                    self.drain(selector)
                code = self.child.returncode
                self.retire(selector)
                if (code == 75 and not self.was_ready and self.startup_retries == 0
                        and self.prepared == token):
                    # Worker exit 75 means exact empty cold-start flag, no PCM
                    # delivered, and successful cleanup. No preparation/clock
                    # write is repeated: prepared remains set for this token.
                    self.startup_retries = 1
                    self.next_attempt = time.monotonic() + 1
                    self.publish("settling", "Empty startup transport fault; one delayed audio reopen, no repeated clock writes")
                elif self.pw_lost and code == 0 and self.pw_retries < 3:
                    self.pw_retries += 1
                    self.next_attempt = time.monotonic() + 2 ** self.pw_retries
                    self.publish("waiting-pipewire", "PipeWire disconnected; bounded recovery pending")
                else:
                    self.blocked = token
                    self.publish("blocked", "Audio worker stopped on a fault; waiting for a new USB connection or explicit service restart")
        if token != self.token or removed:
            self.token = token
            self.blocked = self.prepared = None
            self.pw_retries = 0
            self.next_attempt = 0
            self.retry_delay = 1
            self.startup_retries = 0
            self.was_ready = False
        if state != "available":
            self.publish(state)
            return
        if self.blocked == token or time.monotonic() < self.next_attempt:
            return
        if audio_busy(token):
            self.publish("busy", "Audio interface is owned elsewhere; no forced release")
            self.next_attempt = time.monotonic() + self.retry_delay
            self.retry_delay = min(self.retry_delay * 2, 30)
            return
        if self.backend != "alsa" and pipewire_token() is None:
            self.publish("waiting-pipewire", "PipeWire socket unavailable")
            return
        self.start(selector, token)

    def run(self):
        import pyudev
        monitor = pyudev.Monitor.from_netlink(pyudev.Context())
        monitor.filter_by(subsystem="usb", device_type="usb_device")
        monitor.start()  # Subscribe BEFORE enumeration; no missed-startup race.
        read_fd, write_fd = os.pipe2(os.O_NONBLOCK | os.O_CLOEXEC)
        old_wakeup = signal.set_wakeup_fd(write_fd)
        old_handlers = {}
        def shutdown(*_):
            self.stopping = True
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGCHLD, signal.SIGUSR1):
            old_handlers[sig] = signal.signal(sig, shutdown if sig in (signal.SIGTERM,signal.SIGINT) else lambda *_: None)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(monitor.fileno(), selectors.EVENT_READ, "usb")
                selector.register(read_fd, selectors.EVENT_READ, "signal")
                try:
                    self.tick(selector)
                    check_at = time.monotonic() + 30
                    policy_at = time.monotonic() + 1
                    while not self.stopping:
                        state = (self.last_state or {}).get("state")
                        timeout = max(0, min(check_at,policy_at) - time.monotonic())
                        if state in ("permissions", "waiting-pipewire", "starting"):
                            timeout = min(timeout, self.retry_delay)
                        if self.next_attempt > time.monotonic():
                            timeout = min(timeout, self.next_attempt - time.monotonic())
                        events = selector.select(timeout)
                        # Continuous worker logs must not starve reconciliation.
                        reconcile, removed = not events or time.monotonic() >= check_at, False
                        for key, _ in events:
                            if key.data == "worker":
                                self.drain(selector)
                            elif key.data == "signal":
                                while True:
                                    try:
                                        if not os.read(read_fd, 4096):
                                            break
                                    except BlockingIOError:
                                        break
                                reconcile = True
                            else:
                                while True:
                                    event = monitor.poll(timeout=0)
                                    if event is None:
                                        break
                                    relevant = event.get("ID_VENDOR_ID") == "2a39" or event.get("PRODUCT", "").startswith("2a39/")
                                    owned = self.token and event.sys_name == Path(self.token[0]).name
                                    reconcile |= bool(relevant or owned)
                                    removed |= bool(owned and event.action == "remove")
                        if time.monotonic()>=policy_at:
                            policy_at=time.monotonic()+1
                            if self.token:
                                try:policy=owner_policy.for_usb(Path(self.token[0]))
                                except (OSError,ValueError):policy='invalid'
                                reconcile |= policy!=self.owner_policy_signature
                        if reconcile and not self.stopping:
                            self.tick(selector, removed)
                            check_at = time.monotonic() + 30
                            if (self.last_state or {}).get("state") in ("permissions", "waiting-pipewire"):
                                self.retry_delay = min(self.retry_delay * 2, 30)
                finally:
                    self.retire(selector)
                    self.publish("stopped")
        finally:
            signal.set_wakeup_fd(old_wakeup)
            for sig, handler in old_handlers.items():
                signal.signal(sig, handler)
            os.close(read_fd)
            os.close(write_fd)


def main():
    node_control.read()
    buffer_control.read()
    startup_rate.read()
    lock = os.open(Path(os.environ["XDG_RUNTIME_DIR"]) / "ufxplus-supervisor.lock",
                   os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        Supervisor().run()
    finally:
        os.close(lock)
