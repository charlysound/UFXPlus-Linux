#!/usr/bin/python3
"""Compatibility adapter: the legacy MIDI unit respects the shared owner UID."""
import os
import sys
from pathlib import Path
import owner_policy
import session_supervisor


def run(arguments,discover=session_supervisor.discover,lookup=owner_policy.for_usb,execute=os.execv):
    state,token=discover()
    if state=='ambiguous':raise ValueError('Historical MIDI identity is ambiguous')
    if token is not None:
        value=lookup(Path(token[0]))
        if value is not None and value['owner']=='native':
            print('MIDI delegated to the common per-device owner.',flush=True)
            return 0
    execute('/usr/bin/ufxplus-midi',['/usr/bin/ufxplus-midi',*arguments])
    return 0


if __name__=='__main__':
    try:raise SystemExit(run(sys.argv[1:]))
    except (OSError,ValueError) as error:
        print(str(error),file=sys.stderr);raise SystemExit(1)
