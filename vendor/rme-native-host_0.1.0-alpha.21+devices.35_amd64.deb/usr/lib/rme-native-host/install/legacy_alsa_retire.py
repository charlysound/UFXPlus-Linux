#!/usr/bin/python3
"""Privileged, explicit post-commit retirement of the unused Linux frontend.

No USB, audio service, other module, DKMS removal or user preference changes.
Run through the project's installation guard. Rollback restores this frontend
and its previous boot configuration; it does not switch a USB owner.
"""
import argparse
import base64
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shutil
import stat
import subprocess
import tempfile

MODULE='snd_ufxplus_pcm'
MASK='/etc/modules-load.d/ufxplus-pcm.conf'
REGISTRY='/var/lib/rme-native-host/legacy-alsa-retirement.json'
SYSTEM_PATH='/usr/sbin:/usr/bin:/sbin:/bin'


def private_json(path,owner,limit=2097152):
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC),'r') as stream:
        info=os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=owner or stat.S_IMODE(info.st_mode)!=0o600 or info.st_size>limit:
            raise ValueError('Invalid private migration record')
        payload=stream.read(limit+1)
        if len(payload)>limit:raise ValueError('Migration record is too large')
        value=json.loads(payload)
    if not isinstance(value,dict):raise ValueError('Invalid migration record')
    return value


class Retirement:
    def __init__(self,uid,user_id,config_home,runtime,*,root=Path('/'),admin_uid=0,authority=None,command=None):
        self.uid=uid;self.user_id=user_id;self.config=Path(config_home);self.runtime=Path(runtime)
        self.root=Path(root);self.admin_uid=admin_uid;self.authority=authority or self.user_status
        self.command=command or self.module_command
        if not isinstance(uid,str) or not uid.startswith('rme:') or len(uid)>512 or '\0' in uid:raise ValueError('Invalid UID')
    def path(self,name):return self.root/name.lstrip('/')
    def directory(self,path):
        # Never follow an administrator-path symlink when replacing a mask.
        for item in reversed([path,*path.parents]):
            if item==self.root.parent and item!=self.root:continue
            try:info=item.lstat()
            except FileNotFoundError:
                item.mkdir(mode=0o700 if 'var/lib/rme-native-host' in str(item) else 0o755)
                info=item.lstat()
            if not stat.S_ISDIR(info.st_mode) or info.st_uid!=self.admin_uid or info.st_mode&0o022:
                # Test roots are private; production paths are root-owned.
                if item in self.root.parents:continue
                raise ValueError('Unsafe installation directory: '+str(item))
    def sync(self,path):
        fd=os.open(path,os.O_DIRECTORY|os.O_CLOEXEC)
        try:os.fsync(fd)
        finally:os.close(fd)
    def write(self,path,value):
        self.directory(path.parent)
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='w',dir=path.parent,delete=False) as stream:
                temporary=Path(stream.name);json.dump(value,stream,separators=(',',':'));stream.write('\n');stream.flush();os.fsync(stream.fileno())
            os.replace(temporary,path);self.sync(path.parent)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)
    def saved_mask(self):
        path=self.path(MASK)
        try:info=path.lstat()
        except FileNotFoundError:return dict(kind='absent')
        if info.st_uid!=self.admin_uid:raise ValueError('Boot mask belongs to another administrator')
        if stat.S_ISLNK(info.st_mode):return dict(kind='symlink',target=os.readlink(path),uid=info.st_uid,gid=info.st_gid)
        if not stat.S_ISREG(info.st_mode) or info.st_mode&0o022 or info.st_size>1048576:raise ValueError('Unsupported existing boot configuration')
        with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC),'rb') as stream:
            after=os.fstat(stream.fileno())
            if (info.st_ino,info.st_dev,info.st_mtime_ns)!=(after.st_ino,after.st_dev,after.st_mtime_ns):raise ValueError('Boot configuration changed while reading')
            data=stream.read(1048577)
        if len(data)>1048576:raise ValueError('Boot configuration is too large')
        return dict(kind='file',content=base64.b64encode(data).decode(),mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid)
    def ours(self,value):return value.get('kind')=='symlink' and value.get('target')=='/dev/null'
    def replace_mask(self,value):
        path=self.path(MASK);self.directory(path.parent)
        if value['kind']=='absent':path.unlink(missing_ok=True);self.sync(path.parent);return
        fd,name=tempfile.mkstemp(prefix='.rme-owner-',dir=path.parent);temporary=Path(name)
        try:
            if value['kind']=='symlink':os.close(fd);temporary.unlink();temporary.symlink_to(value['target'])
            elif value['kind']=='file':
                with os.fdopen(fd,'wb') as stream:
                    stream.write(base64.b64decode(value['content'],validate=True));stream.flush();os.fsync(stream.fileno())
                    os.fchmod(stream.fileno(),value['mode'])
            else:os.close(fd);raise ValueError('Invalid saved boot configuration')
            if os.geteuid()==0:os.chown(temporary,value.get('uid',0),value.get('gid',0),follow_symlinks=False)
            os.replace(temporary,path);self.sync(path.parent)
        finally:temporary.unlink(missing_ok=True)
    def load(self):
        try:value=private_json(self.path(REGISTRY),self.admin_uid)
        except FileNotFoundError:return None
        if value.get('schema')!=1 or value.get('uid')!=self.uid or value.get('user_id')!=self.user_id or value.get('component')!='rme-native-host-legacy-alsa':
            raise ValueError('Retirement registry belongs to another operation or UID')
        return value
    def user_status(self):
        user=pwd.getpwuid(self.user_id)
        environment=dict(PATH=SYSTEM_PATH,HOME=user.pw_dir,USER=user.pw_name,LOGNAME=user.pw_name,LANG='C.UTF-8',
                         XDG_CONFIG_HOME=str(self.config),XDG_RUNTIME_DIR=str(self.runtime))
        result=subprocess.run(['/usr/bin/rme-linux-settings','status','--uid',self.uid],
            user=self.user_id,group=user.pw_gid,extra_groups=os.getgrouplist(user.pw_name,user.pw_gid),
            env=environment,capture_output=True,text=True,timeout=5,check=True)
        if len(result.stdout)>1048576:raise ValueError('Linux status is too large')
        return json.loads(result.stdout)
    def binding(self,expected):
        value=self.authority()
        if (value.get('schema')!=1 or value.get('uid')!=self.uid or value.get('native') is not True or value.get('state')!='running' or
                value.get('can_apply') is not True or value.get('marker')!=expected or not value.get('alsa',{}).get('ready') or
                not value.get('midi',{}).get('ready') or not value.get('applied',{}).get('applied') or
                (value['applied'].get('backend')!='alsa' and not value.get('pipewire',{}).get('ready'))):
            raise ValueError('The committed common owner and Linux frontends are not ready at this marker')
        path=self.config/'rme-native/devices'/hashlib.sha256(self.uid.encode()).hexdigest()/'owner.json'
        preference=private_json(path,self.user_id,1048576)
        if preference.get('schema')!=1 or preference.get('uid')!=self.uid or preference.get('owner')!='native' or preference.get('phase')!='committed':
            raise ValueError('The native owner preference is not committed')
        return value
    def clients_closed(self):
        module=self.path('/sys/module/'+MODULE)
        if not module.exists():return
        if (module/'refcnt').read_text().strip()!='0':raise ValueError('The old ALSA module still has users; no removal performed')
        card=self.path('/proc/asound/UFXPlus')
        if (card/'id').read_text().strip()!='UFXPlus':raise ValueError('Historical ALSA identity is not confirmed')
        statuses=list(card.glob('pcm*/sub*/status'))
        if not statuses or any(p.read_text().strip()!='closed' for p in statuses):raise ValueError('An application still uses the old ALSA PCM')
        index=card.resolve().name
        if not index.startswith('card') or not index[4:].isdigit():raise ValueError('Historical ALSA card index is unavailable')
        pattern=re.compile(r'(?:controlC'+index[4:]+r'|(?:pcm|hw|midi)C'+index[4:]+r'D\d+[pc]?)$')
        devices=[self.path('/dev/ufxplus-pcm'),*(p for p in self.path('/dev/snd').iterdir() if pattern.fullmatch(p.name))]
        targets={str(p) for p in devices};numbers=set()
        for path in devices:
            try:info=path.stat()
            except FileNotFoundError:continue
            if stat.S_ISCHR(info.st_mode):numbers.add(info.st_rdev)
        for process in self.path('/proc').iterdir():
            if not process.name.isdecimal():continue
            try:
                for fd in (process/'fd').iterdir():
                    try:
                        target=str(fd.readlink()).removesuffix(' (deleted)');info=fd.stat()
                    except FileNotFoundError:continue
                    if target in targets or stat.S_ISCHR(info.st_mode) and info.st_rdev in numbers:
                        raise ValueError('A process still holds the old ALSA frontend')
            except FileNotFoundError:continue
        if (module/'refcnt').read_text().strip()!='0':raise ValueError('The old ALSA frontend acquired a new user')
    def module_command(self,action):
        name='rmmod' if action=='remove' else 'modprobe'
        executable=shutil.which(name,path=SYSTEM_PATH)
        if executable is None:raise ValueError(name+' is unavailable')
        info=Path(executable).stat()
        if info.st_uid!=0 or info.st_mode&0o022:raise ValueError('Unsafe module loader')
        result=subprocess.run([executable,MODULE],capture_output=True,text=True,timeout=10)
        if result.returncode:raise ValueError((result.stderr or result.stdout)[:2000] or 'Module operation failed')
    def apply(self,expected):
        self.binding(expected);self.clients_closed()
        record=self.load();current=self.saved_mask()
        if record is None or record.get('state')=='restored':
            record=dict(schema=1,component='rme-native-host-legacy-alsa',uid=self.uid,user_id=self.user_id,
                        before=current,state='prepared',marker=expected,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
            self.write(self.path(REGISTRY),record)
        elif current!=record['before'] and not self.ours(current):raise ValueError('Administrator boot configuration changed; preserving it')
        self.binding(expected);self.clients_closed()
        if self.path('/sys/module/'+MODULE).exists():self.command('remove')
        if any(self.path(name).exists() for name in ('/sys/module/'+MODULE,'/dev/ufxplus-pcm','/proc/asound/UFXPlus')):
            raise ValueError('Historical frontend removal was not confirmed; boot mask unchanged')
        record.update(state='kernel_unloaded',marker=expected);self.write(self.path(REGISTRY),record)
        self.binding(expected)
        current=self.saved_mask()
        if current!=record['before'] and not self.ours(current):raise ValueError('Administrator boot configuration changed during retirement')
        self.replace_mask(dict(kind='symlink',target='/dev/null',uid=self.admin_uid,gid=os.getegid()))
        record['state']='retired';self.write(self.path(REGISTRY),record)
        return dict(ok=True,state='retired',uid=self.uid,module=MODULE,boot_mask=MASK,
                    initrd='regenerate only if this vendor configuration is embedded',usb_changed=False)
    def rollback(self):
        record=self.load()
        if record is None:raise ValueError('No retirement to roll back')
        current=self.saved_mask()
        if current!=record['before'] and not self.ours(current):raise ValueError('Administrator boot configuration changed; preserving it')
        self.replace_mask(record['before'])
        record['state']='rollback_pending';self.write(self.path(REGISTRY),record)
        if not self.path('/sys/module/'+MODULE).exists():self.command('load')
        if (self.path('/proc/asound/UFXPlus/id')).read_text().strip()!='UFXPlus' or not self.path('/dev/ufxplus-pcm').exists():
            raise ValueError('Historical frontend restore was not confirmed')
        record['state']='restored';self.write(self.path(REGISTRY),record)
        return dict(ok=True,state='restored',uid=self.uid,usb_changed=False,owner_changed=False)
    def perform(self,operation,expected=None):
        self.directory(self.path(REGISTRY).parent)
        fd=os.open(self.path(REGISTRY).with_suffix('.lock'),os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:
            info=os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_uid!=self.admin_uid or stat.S_IMODE(info.st_mode)!=0o600:raise ValueError('Invalid installation lock')
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            return self.apply(expected) if operation=='apply' else self.rollback()
        finally:os.close(fd)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=('apply','rollback'));parser.add_argument('--uid',required=True)
    parser.add_argument('--user-id',required=True,type=int);parser.add_argument('--expected-marker')
    parser.add_argument('--config-home',type=Path);parser.add_argument('--runtime-dir',type=Path)
    args=parser.parse_args()
    if os.geteuid()!=0:raise ValueError('This explicit installation operation requires root')
    if args.user_id<=0:raise ValueError('Select the desktop user, not root')
    if args.operation=='apply' and args.expected_marker is None:raise ValueError('The current native marker is required')
    user=pwd.getpwuid(args.user_id)
    adapter=Retirement(args.uid,args.user_id,args.config_home or Path(user.pw_dir)/'.config',args.runtime_dir or Path('/run/user')/str(args.user_id))
    result=adapter.perform(args.operation,json.loads(args.expected_marker) if args.expected_marker else None)
    print(json.dumps(result,separators=(',',':')))


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,KeyError,subprocess.SubprocessError) as error:
        print(json.dumps(dict(ok=False,error=str(error))));raise SystemExit(1)
