# Retire the obsolete static ALSA frontend

`packaging/legacy_alsa_retire.py` is an explicit privileged installation adapter.
Use the installation guard. It never opens USB, switches an audio owner,
changes user preferences, stops a service, removes shared ALSA modules or
uninstalls DKMS. Run only after the common owner migration has committed.

Arguments for `apply`:

- `--uid`: exact migrated RME UID.
- `--user-id`: numeric desktop user; root itself is refused.
- `--expected-marker`: current complete marker JSON from that user's
  `rme-linux-settings status --uid`.
- Optional `--config-home` and `--runtime-dir` for nondefault XDG locations.

The adapter asks the installed status helper under the desktop user's actual
credentials. It requires the same native running marker, applied settings and
ready ALSA/PipeWire (or ALSA-only)/MIDI, plus private owner.json committed to
native. It verifies closed legacy PCM, zero old-module references and no
remaining bridge/control/PCM handle across users. It runs only
`rmmod snd_ufxplus_pcm`, without force or dependency removal. The kernel's
in-use refusal is authoritative against a client opening during the check.

After module, bridge and UFXPlus card disappearance are confirmed and the
native binding is rechecked, it atomically creates the same-name administrator
mask `/etc/modules-load.d/ufxplus-pcm.conf -> /dev/null`. This is the documented
modules-load.d override of the vendor file. No blacklist is introduced;
explicit restoration can still load the old frontend.

The root-only registry
`/var/lib/rme-native-host/legacy-alsa-retirement.json` stores the previous
administrator file bytes/mode/owner or symlink target/absence, UID, marker,
script hash and phase. A root installation lock serializes operations. An
existing changed administrator file is preserved and refused. Repeating apply
does not replace the original backup. An interruption after kernel removal is
recoverable without losing that backup.

`rollback --uid ... --user-id ...` restores the previous mask and explicitly
loads this module if needed, then confirms its static card/bridge. Repeating
rollback is harmless. It restores the Linux frontend only; it does not stop the
current native USB owner or change owner.json. Return of actual USB ownership
is a separate coordinated operation. Automatic handoff rollback happens before
post-commit retirement and already has the old frontend available.

The mask relies on the installation's modules-load.d precedence. If its vendor
file is embedded in initrd, the distribution adapter must also regenerate that
image. Detect this before calling retirement complete; do not assume Debian
initramfs tools and Fedora dracut are interchangeable. A non-systemd boot
loader needs its own matching configuration adapter. The script reports this
remaining conditional step and never rewrites initrd itself.

Six inert tests use a private filesystem and injected module commands. They
cover exact backup/restore, idempotence, busy references/PCM/FD refusal, changed
authority/commit refusal, administrator changes and interrupted removal. They
do not qualify actual unloading, a reboot, another distribution or audio.
