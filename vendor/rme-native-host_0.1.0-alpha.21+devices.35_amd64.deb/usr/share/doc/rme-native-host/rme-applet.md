# Common RME Cinnamon applet

The existing applet UUID and menu layout are retained. A device selector chooses
one stable UID. Status, rate, active channel counts, MIDI ports, backend, buffer
and node names come from the same Linux API as the settings panel. No Babyface
rate/channel defaults are copied from UFX+.

`rme-driver-applet status [--uid UID]` returns the current selection and display
state. A missing selected UID stays disconnected; it never silently switches
an action to another card. Invalid inventory disables all actions.

`rme-driver-applet action --uid UID --expected-marker JSON --request JSON`
delegates to the existing common acknowledged apply/rate transaction. Native
and historical owners are selected there from their validated identity. The
historical read-only status provider is used only after a historical owner was
identified; no legacy mutation command is called directly by the applet.
During a change, selection/actions are disabled and status is refreshed after
the transaction replies. A refused or uncertain result is never retried.

The optional Cinnamon payload uses the existing
`ufxplus-driver@charlysound` UUID to preserve panel placement. The host DEB owns
reversible diversions for the two previous applet files; removing the host
restores the historical package's files. The portable installer preserves any
foreign files and does not bypass an existing historical package. Cinnamon
must reload the applet after upgrading its source. Installing this package does
not enable an applet, change the user's panel layout or restart Cinnamon.

The provider requires the common device manager's validated inventory, also
when the selected card still uses its historical owner. A standalone old driver
without that inventory is reported unavailable rather than guessed. ALSA,
PipeWire and mixer ownership stay independent of the applet's lifetime.
