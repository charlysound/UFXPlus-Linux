# Portable Linux host archive

The host archive and DEB consume one FHS payload generator. The portable archive
contains install.py, preflight.py, a source.json file manifest, and usr/etc payload.
It includes the common settings panel, guarded legacy-rate helper, native ALSA
module sources, access rules and metadata. It does not require the historical
ufxplus-driver package for a native-only interface. The existing UFX+ service is
preserved while its migration remains dependent on the native core qualification.
The matching native runtime bundle and user service come from the OSCmix package;
there is no second USB owner, autostart policy or model catalogue in this archive.

Build from clean committed matching sources and a matching compiled rate helper:

```
python3 packaging/build-native-host-portable.py --version VERSION --output host.tar.gz
```

The archive is deterministic for the same source/binary/metadata: stable order,
root ownership, normalized permissions, commit timestamp and gzip timestamp.
It carries source identity and per-file digests; the archive checksum is emitted
beside it. --rate-binary and --capabilities permit explicitly identified artifacts
from a separate build. A binary built on one distribution is not automatically
ABI-compatible with another: rebuild/qualify there when necessary. No Fedora,
Arch or openSUSE hardware qualification is claimed by producing an archive.
The manifest also records the shipped ELF architecture, interpreter and required
symbol versions (including GLIBC). Build-time `readelf` comes from binutils; the
target machine does not need it. This metadata describes the actual binary, not
an assumed minimum distribution version.

After extracting, preflight.py reads tools/libraries and, with --build-kernel,
the exact running kernel build tree. It also reads the archive's guarded binary
and asks its dynamic loader to list dependencies without running the program.
An incompatible architecture, missing loader/library or unavailable symbol
version is an explicit failure, even when a similarly named library is present.
`--binary PATH` selects another explicitly supplied binary for this check.
It never installs packages, opens USB,
restarts PipeWire, loads a module or changes a service. ALSA-only operation does
not require a running PipeWire server. The hybrid binary still links its host
libraries, which are reported separately from a server process.

install.py defaults to --check. --root DESTDIR supports staging fixtures without
system changes. Explicit --install/--remove use one registry per component under
/var/lib/rme-portable and one shared lock. Unowned files, symlinks, modified owned
files and invalid payloads are refused before changes. Upgrade failure restores
the previous files and registry. User XDG preferences are never installation
payload and are preserved. Portable installation does not overwrite or divert
files owned by a distribution package: migrate/remove that package explicitly
before choosing this distribution adapter. The DEB retains its existing package
diversions for legacy command compatibility.

The kernel component is installed from usr/src/rme-pcm-0.1.0 using the shipped DKMS
configuration when DKMS is available. Otherwise its Makefile uses the standard
external-module build tree /lib/modules/$(uname -r)/build. Build/install/load and
udev/service activation are explicit administration steps after the read-only
preflight; the file installer never runs system hooks or unloads a running module.
A rejected module load must be resolved through the distribution's signing and
kernel policy; the installer does not disable those policies.

| Target family | Kernel adaptation and verification state |
| --- | --- |
| Debian/Ubuntu | DEB adapter; running-kernel headers, optional header metapackages. Portable file cycle is fixture-tested. New distribution installations remain to qualify. |
| Fedora | Matching kernel-devel supplies the external-module build tree, distinct from userspace kernel-headers. FHS/preflight adapter supplied, not run on Fedora. [Fedora kernel documentation](https://fedoraproject.org/wiki/Building_a_custom_kernel). |
| Arch | Install headers matching the actual kernel variant before DKMS/build; linux and linux-lts use different header packages. Adapter supplied, not run on Arch. [Arch DKMS documentation](https://wiki.archlinux.org/title/Dynamic_Kernel_Module_Support). |
| openSUSE | Match kernel-devel and the kernel flavor's development package. Adapter supplied, not run on openSUSE. [SUSE kernel module manual](https://documentation.suse.com/sbp/systems-management/pdf/KMP-Manual-SLES16_en.pdf). |
| Other/non-systemd | Standard FHS, ALSA, PipeWire and XDG contracts; foreground manifest-verified native manager instead of assuming a systemd user service. Not a distribution compatibility claim. |

The portable installer is component-generic: OSCmix may ship the exact same
reviewed install.py with its own source.json and usr/lib/oscmix-ufxplus payload.
Separate ownership registries prevent one component from claiming another's
files. Service units and desktop startup remain distribution/application adapters.
The native RME format, commands, mixer state and USB ownership are unaffected.
