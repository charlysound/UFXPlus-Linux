const Applet = imports.ui.applet;
const PopupMenu = imports.ui.popupMenu;
const Mainloop = imports.mainloop;
const Util = imports.misc.util;
const Tooltips = imports.ui.tooltips;

class UfxplusApplet extends Applet.TextIconApplet {
    constructor(orientation, panelHeight, instanceId) {
        super(orientation, panelHeight, instanceId);
        this.set_applet_icon_symbolic_name("audio-card-symbolic");
        this.set_applet_label("RME");
        this.set_applet_tooltip("RME native interfaces");
        this._alive = true;
        this._busy = false;
        this._selecting = false;
        this._settingRate = false;
        this._settingBuffer = false;
        this._settingNodes = false;
        this._settingBackend = false;
        this._menuManager = new PopupMenu.PopupMenuManager(this);
        this.menu = new Applet.AppletPopupMenu(this, orientation);
        this._menuManager.addMenu(this.menu);
        this._selectedUid = null;
        this._data = null;
        this._updating = false;
        this._cards = new PopupMenu.PopupSubMenuMenuItem("RME interface");
        this.menu.addMenuItem(this._cards);
        this._rows = {};
        for (const key of ["state", "rate", "clock", "sync", "pipewire", "quantum", "usb", "midi", "uptime", "diagnosis"]) {
            const item = new PopupMenu.PopupMenuItem("Checking…", {reactive: false});
            this.menu.addMenuItem(item);
            this._rows[key] = item.label;
        }
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._backend = new PopupMenu.PopupSubMenuMenuItem("Audio mode");
        this._backendItems = {};
        this._backendTooltips = [];
        this.menu.addMenuItem(this._backend);
        for (const [mode, label, explanation] of [
            ["pipewire", "PipeWire only", "Historical owner only: PipeWire audio without direct ALSA."],
            ["alsa", "ALSA only", "Direct ALSA for the selected interface. Its native rate determines active channels. Close applications before changing the rate."],
            ["pipewire+alsa", "PipeWire + ALSA", "ALSA and PipeWire share one native owner for the selected interface. Close applications before changing the rate."]
        ]) {
            const item = new PopupMenu.PopupMenuItem(label);
            item.connect("activate", () => this.setBackend(mode));
            this._backendItems[mode] = item;
            this._backend.menu.addMenuItem(item);
            this._backendTooltips.push(new Tooltips.Tooltip(item.actor, explanation));
        }
        this._backend.menu.addMenuItem(new PopupMenu.PopupMenuItem("Switching pauses audio; connections may need restoring", {reactive: false}));
        this._frequency = new PopupMenu.PopupSubMenuMenuItem("Sample rate");
        this._rateItems = {};
        this.menu.addMenuItem(this._frequency);
        this._buffer = new PopupMenu.PopupSubMenuMenuItem("Audio buffer · samples");
        this._bufferItems = {};
        this.menu.addMenuItem(this._buffer);
        this._nodes = new PopupMenu.PopupSubMenuMenuItem("PipeWire nodes");
        this.menu.addMenuItem(this._nodes);
        this._nodeItems = {};
        this._nodes.menu.addMenuItem(new PopupMenu.PopupMenuItem("Node selection for the selected interface", {reactive: false}));
        const open = new PopupMenu.PopupMenuItem("Open RME USB Settings");
        open.connect("activate", () => Util.spawn(["rme-driver-panel", ...(this._selectedUid ? ["--uid", this._selectedUid] : [])]));
        this.menu.addMenuItem(open);
        const refresh = new PopupMenu.PopupMenuItem("Refresh status");
        refresh.connect("activate", () => this.refresh());
        this.menu.addMenuItem(refresh);
        this.refresh();
        this._timer = Mainloop.timeout_add_seconds(3, () => {
            this.refresh();
            return true;
        });
    }

    _populateCapabilities(capabilities) {
        const signature = JSON.stringify(capabilities);
        if (signature === this._capabilitiesSignature)
            return;
        this._frequency.menu.removeAll();
        this._buffer.menu.removeAll();
        this._rateItems = {};
        this._bufferItems = {};
        for (const hz of capabilities.rates) {
            const item = new PopupMenu.PopupMenuItem((hz / 1000) + " kHz");
            item.connect("activate", () => this.setRate(hz));
            this._frequency.menu.addMenuItem(item);
            this._rateItems[hz] = item;
        }
        for (const frames of capabilities.buffer_frames) {
            const item = new PopupMenu.PopupMenuItem(frames ? String(frames) : "Auto (PipeWire)");
            item.connect("activate", () => this.setBuffer(frames));
            this._buffer.menu.addMenuItem(item);
            this._bufferItems[frames] = item;
        }
        this._buffer.menu.addMenuItem(new PopupMenu.PopupMenuItem("Changes apply to the selected interface", {reactive: false}));
        this._capabilitiesSignature = signature;
    }

    on_applet_clicked() {
        this.menu.toggle();
        this.refresh();
    }

    _mutating() { return this._selecting || this._settingNodes || this._settingRate || this._settingBuffer || this._settingBackend; }

    _runCli(argv, callback) {
        // Cinnamon's spawn_async drops its callback on a nonzero exit. Every
        // guarded refusal must complete here so it cannot latch the applet.
        try {
            Util.spawnCommandLineAsyncIO(null, (stdout, stderr, code) =>
                callback(stdout || "", stderr || "", code), {argv});
        } catch (error) {
            callback("", String(error), -1);
        }
    }

    _reply(output, stderr, code) {
        let value;
        try { value = JSON.parse(output); }
        catch (_) { throw Error(stderr || "No valid response from RME settings"); }
        if (!value || typeof value !== "object" || Array.isArray(value))
            throw Error("Invalid response from RME settings");
        if (code !== 0 || value.ok !== true)
            throw Error(value.error || stderr || "RME settings command failed");
        return value;
    }

    _choose(uid) {
        if (!this._alive || this._mutating()) return;
        this._selecting = true;
        this._invalidateStatus();
        this._runCli(["rme-driver-applet", "select", "--uid", uid], (output, stderr, code) => {
            this._selecting = false;
            if (!this._alive) return;
            try {
                const reply = this._reply(output, stderr, code);
                if (!reply.ok || !reply.confirmed || reply.uid !== uid)
                    throw Error(reply.error || "Selection not confirmed");
                this._selectedUid = uid;
            }
            catch (error) { imports.ui.main.notifyError("RME interface", String(error)); }
            this.refresh();
        });
    }

    _populateCards(data) {
        const signature = JSON.stringify([data.uid, data.devices]);
        if (signature === this._cardSignature) return;
        this._cards.menu.removeAll();
        for (const device of data.devices) {
            const item = new PopupMenu.PopupMenuItem(device.label + " · " + device.uid);
            item.setShowDot(device.uid === data.uid);
            item.connect("activate", () => this._choose(device.uid));
            this._cards.menu.addMenuItem(item);
        }
        this._cards.label.set_text("Interface · " + (data.model || "RME"));
        this._cardSignature = signature;
    }

    refresh() {
        if (!this._alive || this._busy || this._mutating()) return;
        this._busy = true;
        const selected = this._selectedUid;
        this._runCli(["rme-driver-applet", "status"], (output, stderr, code) => {
            this._busy = false;
            if (!this._alive || this._selecting) return;
            if (selected !== this._selectedUid) { this.refresh(); return; }
            try {
                const data = this._reply(output, stderr, code);
                if (!data.ok || data.schema !== 1 || !Array.isArray(data.devices)) throw Error("Invalid status");
                this._selectedUid = data.uid;
                this._populateCards(data);
                this._data = data;
                this._populateNodes(data);
                this._populateCapabilities(data.capabilities);
                this._canSetBackend = !!data.can_set_backend;this._selectedBackend = data.selected_audio_backend;
                this._canSetNodes = !!data.can_set_nodes;this._canSetRate = !!data.can_set_rate;this._canSetBuffer = !!data.can_set_buffer;
                this._backend.label.set_text("Audio mode · " + (data.audio_backend || "unavailable"));
                for (const [mode, item] of Object.entries(this._backendItems)) {
                    const allowed = data.backend_choices.includes(mode);item.actor.visible = allowed;
                    item.setSensitive(this._canSetBackend && allowed);item.setShowDot(mode === this._selectedBackend);
                }
                for (const [hz, item] of Object.entries(this._rateItems)) {
                    item.setSensitive(this._canSetRate);item.setShowDot(Number(hz) === data.sample_rate);
                }
                for (const [frames, item] of Object.entries(this._bufferItems)) {
                    item.setSensitive(this._canSetBuffer);item.setShowDot(Number(frames) === data.buffer_frames);
                }
                const label = data.model || "RME", rate = data.sample_rate ? data.sample_rate / 1000 + " kHz" : "unavailable";
                const pw = data.pipewire || {}, midi = data.midi || {}, timing = data.timing || {};
                this.set_applet_label(label + (data.sample_rate ? " " + data.sample_rate / 1000 + "k" : " …"));
                this.set_applet_tooltip(label + " · " + (data.uid || "no card") + "\n" + data.state + "\n" + rate);
                this._buffer.label.set_text("Audio buffer · " + (data.buffer_frames === null || data.buffer_frames === undefined ? "unavailable" : data.buffer_frames || "Auto"));
                this._rows.state.set_text(data.state + " · " + data.version);
                this._rows.rate.set_text("Device nominal rate: " + rate + (data.channels_in ? " · " + data.channels_in + " in / " + data.channels_out + " out" : ""));
                this._rows.clock.set_text("Current Clock: " + (data.clock_source || "unavailable"));
                const inputs = data.input_lock_sync || [];
                this._rows.sync.set_text(inputs.length ? "External inputs: " + inputs.filter(i => i.state !== "No Lock").length + " locked / " + inputs.filter(i => i.state === "Sync").length + " synced" : "Input Lock / Sync: unavailable");
                this._rows.pipewire.set_text("Audio backend: " + (data.audio_backend || "unavailable"));
                this._rows.quantum.set_text(data.audio_backend === "alsa" ? "ALSA periods: negotiated by application" : "Observed quantum: " + (pw.quantum || "unavailable"));
                this._rows.usb.set_text(data.native ? "USB: selected native owner · " + data.state : "USB: historical owner · " + data.state);
                this._rows.midi.set_text("MIDI: " + (midi.active ? "running" + (midi.ports !== null && midi.ports !== undefined ? " · " + midi.ports + " ports" : "") : midi.state || "unavailable"));
                this._rows.uptime.set_text(data.progress ? "Last USB report: " + data.progress.uptime_s + " s streamed" : "No current timing report");
                this._rows.diagnosis.set_text(data.error || data.failure_reason || data.node_error || data.hardware_status_error || data.digital_error || data.buffer_error || "");
            } catch (error) { this._updating = false;this._invalidateStatus(error); }
        });
    }

    _nodeContext(data) {
        return JSON.stringify([data.uid, data.marker, data.settings_revision]);
    }

    _populateNodes(data) {
        const v2 = data.pipewire_nodes_abi === 2;
        if (data.pipewire_nodes_abi !== undefined && ![1, 2].includes(data.pipewire_nodes_abi))
            throw Error("Invalid PipeWire selection capability");
        if (v2 && (!Array.isArray(data.categories) || !Number.isSafeInteger(data.settings_revision) || data.settings_revision < 0))
            throw Error("Invalid PipeWire category inventory or revision");
        const rows = v2 ? data.categories : data.nodes;
        if (!Array.isArray(rows)) throw Error("Missing PipeWire inventory");
        const layout = v2 ? rows.map(r => [r.category, r.name, r.label,
            r.capture.map(p => [p.native_channel, p.label, p.available]),
            r.playback.map(p => [p.native_channel, p.label, p.available])])
            : rows.map(r => [r.direction, r.name, r.label]);
        const signature = JSON.stringify([data.uid, v2, layout]);
        this._updating = true;
        if (signature !== this._nodeSignature) {
            this._nodes.menu.removeAll(); this._nodeItems = {};
            this._nodes.menu.addMenuItem(new PopupMenu.PopupMenuItem(v2 ? "Categories and individual channels" : "Node selection for this interface", {reactive:false}));
            for (const row of rows) {
                if (!v2) {
                    const key = row.direction + ":" + row.index;
                    const item = new PopupMenu.PopupSwitchMenuItem(row.label, row.enabled);
                    item.connect("toggled", (_, enabled) => this.setNode(row.direction, row.index, enabled));
                    this._nodes.menu.addMenuItem(item); this._nodeItems[key] = item;
                    continue;
                }
                const group = new PopupMenu.PopupSubMenuMenuItem(row.label);
                this._nodes.menu.addMenuItem(group);
                const category = new PopupMenu.PopupSwitchMenuItem("Expose this category", row.enabled);
                category.connect("toggled", (_, enabled) => this.setCategory(row.category, enabled, category._nodeContext));
                group.menu.addMenuItem(category); this._nodeItems["category:" + row.category] = category;
                for (const [direction, title] of [["capture", "Inputs · Capture"], ["playback", "Outputs · Playback"]]) {
                    const bank = new PopupMenu.PopupSubMenuMenuItem(title);
                    group.menu.addMenuItem(bank);
                    if (!row[direction].length) bank.menu.addMenuItem(new PopupMenu.PopupMenuItem("No channels in this direction", {reactive:false}));
                    for (const port of row[direction]) {
                        const key = "port:" + row.category + ":" + direction + ":" + port.native_channel;
                        const item = new PopupMenu.PopupSwitchMenuItem(port.label, port.selected);
                        item.connect("toggled", (_, selected) => this.setChannel(row.category, direction, port.native_channel, selected, item._nodeContext));
                        bank.menu.addMenuItem(item); this._nodeItems[key] = item;
                    }
                }
            }
            this._nodeSignature = signature;
        }
        for (const row of rows) {
            if (!v2) {
                const item = this._nodeItems[row.direction + ":" + row.index];
                item.label.set_text((row.direction === "capture" ? "Input · " : "Output · ") + row.label + (row.present ? " · visible" : row.enabled ? " · requested" : " · disabled"));
                item.setToggleState(row.enabled); item.setSensitive(!!data.can_set_nodes);
                continue;
            }
            const category = this._nodeItems["category:" + row.category];
            category._nodeContext = this._nodeContext(data);
            category.label.set_text("Expose this category" + (row.present ? " · visible" : " · not published"));
            category.setToggleState(row.enabled);
            category.setSensitive(!!data.can_set_nodes && [...row.capture, ...row.playback].some(p => p.available));
            for (const direction of ["capture", "playback"]) for (const port of row[direction]) {
                const item = this._nodeItems["port:" + row.category + ":" + direction + ":" + port.native_channel];
                item._nodeContext = this._nodeContext(data);
                const state = !port.available ? "saved · unavailable at this format" : port.present ? "visible" : !port.selected ? "not selected" : data.audio_backend === "alsa" ? "saved · ALSA only" : "waiting for publication";
                item.label.set_text(port.native_channel + " · " + port.label + " · " + state);
                item.setToggleState(port.selected); item.setSensitive(!!data.can_set_nodes && row.enabled && port.available);
            }
        }
        this._updating = false;
    }

    _categoryRequest(context) {
        const data = this._data;
        if (this._updating || !this._canSetNodes || !data || data.pipewire_nodes_abi !== 2 || context !== this._nodeContext(data)) return null;
        const categories = {};
        for (const row of data.categories) {
            const value = {enabled:row.enabled, capture:{}, playback:{}};
            for (const direction of ["capture", "playback"])
                for (const port of row[direction]) value[direction][String(port.native_channel)] = port.selected;
            categories[row.category] = value;
        }
        return {expected_revision:data.settings_revision, node_selection:{schema:2, uid:data.uid, categories}};
    }

    setCategory(category, enabled, context) {
        const request = this._categoryRequest(context);
        if (!request) return;
        const row = this._data && this._data.categories.find(r => r.category === category);
        if (!request || !row || ![...row.capture, ...row.playback].some(p => p.available)) return;
        request.node_selection.categories[category].enabled = enabled;
        this._change("_settingNodes", request);
    }

    setChannel(category, direction, channel, selected, context) {
        const request = this._categoryRequest(context);
        if (!request) return;
        const row = this._data && this._data.categories.find(r => r.category === category);
        const port = row && ["capture", "playback"].includes(direction) && row[direction].find(p => p.native_channel === channel);
        if (!request || !port || !row.enabled || !port.available) return;
        request.node_selection.categories[category][direction][String(channel)] = selected;
        this._change("_settingNodes", request);
    }

    _invalidateStatus(error = null) {
        this._data = null;
        this._nodeSignature = null;
        this._canSetRate = false;
        this._canSetBuffer = false;
        this._canSetNodes = false;
        this._canSetBackend = false;
        this._backend.label.set_text("Audio mode · unavailable");
        this.set_applet_label("RME ?");
        this.set_applet_tooltip("Driver status unavailable. Open driver settings.");
        for (const row of Object.values(this._rows))
            row.set_text("Unavailable · refresh status");
        this._rows.state.set_text("Status unavailable");
        this._rows.diagnosis.set_text(error ? String(error) : "");
        for (const item of [...Object.values(this._rateItems), ...Object.values(this._bufferItems), ...Object.values(this._nodeItems), ...Object.values(this._backendItems)])
            item.setSensitive(false);
        for (const item of [...Object.values(this._rateItems), ...Object.values(this._bufferItems), ...Object.values(this._backendItems)])
            item.setShowDot(false);
        this._buffer.label.set_text("Audio buffer · unavailable");
    }

    _change(flag, request) {
        if (!this._alive || this._busy || this._mutating() || !this._data || !this._data.uid || !this._data.marker) return;
        const data = this._data;
        this[flag] = true;
        this._cards.setSensitive(false);
        for (const item of [...Object.values(this._backendItems), ...Object.values(this._rateItems), ...Object.values(this._bufferItems), ...Object.values(this._nodeItems)]) item.setSensitive(false);
        this._rows.diagnosis.set_text("Waiting for the selected interface to confirm…");
        this._runCli(["rme-driver-applet", "action", "--uid", data.uid, "--expected-marker", JSON.stringify(data.marker), "--request", JSON.stringify(request)], (output, stderr, code) => {
            this[flag] = false;
            if (!this._alive) return;
            this._cards.setSensitive(true);
            try { this._reply(output, stderr, code); }
            catch (error) { imports.ui.main.notifyError("RME interface", String(error)); }
            this.refresh();
        });
    }

    setRate(hz) { if (this._canSetRate) this._change("_settingRate", {rate_hz:hz}); }
    setBuffer(frames) { if (this._canSetBuffer) this._change("_settingBuffer", {buffer_frames:frames}); }
    setNode(direction, index, enabled) {
        if (this._updating || !this._canSetNodes || (this._data && this._data.pipewire_nodes_abi === 2)) return;
        const request = {enabled:{}};request.enabled[index] = enabled;
        this._change("_settingNodes", request);
    }
    setBackend(mode) { if (this._canSetBackend && mode !== this._selectedBackend) this._change("_settingBackend", {backend:mode}); }

    on_applet_removed_from_panel() {
        this._alive = false;
        if (this._timer)
            Mainloop.source_remove(this._timer);
        for (const tooltip of this._backendTooltips) tooltip.destroy();
        this.menu.destroy();
    }
}

function main(metadata, orientation, panelHeight, instanceId) {
    return new UfxplusApplet(orientation, panelHeight, instanceId);
}
