# TotalMixLike

**TotalMixLike** is the new public name of OSCmix UFX+ Unified. The GitHub
repository was renamed from `oscmix-ufxplus-usb3`. For upgrade compatibility,
the application still uses the `oscmix-ufxplus` package, `oscmix-*` commands and
services, existing configuration/snapshot directories and desktop/D-Bus IDs.
Published tags and release asset filenames are unchanged. Do not reuse the
former repository name: its redirects preserve older links and Git remotes.

Development prerelease: **0.2.0-alpha.67+commands.2**. The five native
menus, per-device predicates and shared light/dark dialog contrast are adapted
through the existing guarded owners. Linux-only configuration has a separate
host-tools button. The local payload includes the qualified checkpoint below;
installation does not replace or restart an already running mixer session.

The qualified native checkpoint through `eb94d31` adds full strip-body colors in all
three rows, observed UFX+ Device Info, permanent Channel Layout hiding in
MIDI/OSC banks and a read-only Remote Controller permission column. Software
checks cover these increments; they are included in the alpha67 release candidate.
Native executed-pixel parity, editable remote masks, remaining
Graphics consumers and original ARC/device keys are not claimed. The native
Light resource pack is a prerequisite only: Light/Brightness controls remain
unavailable until their complete rendering path is implemented and verified.

The source also includes the subsequent mono/stereo and GTK lifetime fixes,
native Room EQ snapshot inclusion, the regular-save preference and guarded
individual ARC preamp assignments. This checkpoint adds programmable F4–F8
with native action choices and atomic saved drafts, plus model-specific ARC
Dynamics Gain 1–4 and paired Mic Gain 1+2 / Inst. Gain 3+4. The latter follow
the selected card's physical capabilities; they do not add preamps or Dynamics
to other interfaces. ARC USB ownership and protocol handover now discard stale
SysEx replies while preserving the paired gain and function-key command paths.
Existing inputs 9–12 retain their command owners.
See [function keys](doc/function-keys.md) and [ARC preamp actions](doc/arc-preamp-actions.md).
Software qualification does not establish native executed pixels or real ARC/
preamp/button/LED/wheel qualification. Local installation preserves the active mixer/audio
session and card settings; the new GUI takes effect on the next full launch.

### What's New since alpha.51 — alpha.67

- Adds per-device controller owners, native snapshot banks/workspaces, scoped
  channel FX Paste/Reset, factory banks and capability-guarded Recall Safe.
- Adds Room EQ presets, calibrated recalls and native preset files, snapshot
  inclusion and the regular-save preference, plus guarded AUX accessory controls.
- Restores the five native menus, fonts and window geometry; improves compact
  EQ/Dynamics artwork and console text, with persistent Control Room width and
  the native shared-row divider.
- Adds observed UFX+ Device Info, channel body colors and read-only remote
  permissions; permanently hidden channels are excluded from remote banks.
- Fixes stale chooser/menu/settings callbacks, mono/stereo state handling and
  retained DSP widgets. Nested FX preset menus keep the native rows aligned on
  GTK 4.6, while the ordinary GTK view retains keyboard-focus scrolling.
- Makes the simulated USB service test independent of CI scheduler pauses,
  retaining cadence, timeout, pipe-priority and no-retry checks.
- Bounds GUI test event pumping under continuous redraw load and runs offline
  GUI checks on a private session bus.
- Adds ARC assignments, paired preamp gains, Dynamics Gain 1–4, programmable
  F4–F8, and safe ARC USB protocol handover that ignores stale SysEx replies.

Existing DuRec, Loopback and OSC Remote functions remain available. The binary
package includes the manifest-verified native audio/MIDI runtime and the control
producer used by the qualified alpha.66 installation.

The release notes describe the software coverage and the remaining hardware and
visual qualification limits. The three-family implementation is not a claim
that every function or card has completed physical qualification.

A GTK4 mixer remote for the **RME Fireface UFX+**, with native USB3 and
Class Compliant transports behind one launcher. This is independent software,
not TotalMix FX, an official RME application, or an audio driver.

**Current release: [v0.2.0-alpha.26+menus.2](https://github.com/charlysound/TotalMixLike/releases/tag/v0.2.0-alpha.26+menus.2).**
The binary package targets **Linux Mint 22 / Ubuntu 24.04 amd64**. This remains
an experimental release; source builds require GTK 4.6 or newer.

**Three-family development prerelease:**
[v0.2.0-alpha.67+commands.2](https://github.com/charlysound/TotalMixLike/releases/tag/v0.2.0-alpha.67%2Bcommands.2)
bundles the shared RME audio/MIDI supervisor and native mixer producer. It
requires `rme-native-host` from the matching
[driver prerelease](https://github.com/charlysound/RME-UFX-Plus-Linux-driver-USB3/releases/tag/v0.1.0-alpha.13%2Bdevices.35);
the [three-package suite](https://github.com/charlysound/UFXPlus-Linux/releases/tag/v0.1.0-alpha.5%2Bdevices.35)
pins them together. Offline checks passed; the three-card bundle and remaining
model-specific mixer behavior need hardware qualification.

Native audio and PipeWire ports require the separate
[UFX+ USB3 driver](https://github.com/charlysound/RME-UFX-Plus-Linux-driver-USB3), currently
[v0.1.0-alpha.11+alsa.6](https://github.com/charlysound/RME-UFX-Plus-Linux-driver-USB3/releases/tag/v0.1.0-alpha.11+alsa.6).
Class Compliant audio uses Linux USB audio support. OSCmix does not process PCM,
change the hardware mode, or start/stop the audio driver.

## Native RME development branch

The long-term goal is to port TotalMix behavior for every interface family
supported by the identified original RME driver. Current development is focused
on **Fireface UFX+**, **original Babyface** and **Digiface Dante**. Recognition of
other RME models does not mean their mixer is operational or qualified.

| Family | Current development state | Work remaining |
| --- | --- | --- |
| UFX+ | Established native USB3 mixer path and the broadest OSCmix control coverage | Complete visual/interaction parity and hardware qualification of remaining combinations |
| Original Babyface | Shared device selection, scalar mixer path and Linux audio integration are present in the development branch | Complete and qualify model-specific processing, controls and interactions |
| Digiface Dante | Shared selection and native mixer/FX candidate are present in the development branch | Complete DSP/GUI parity and qualify USB audio and Dante-network behavior separately; no Dante network was attached during the current USB checks |

The next work is to close the three-family mixer and GUI gaps before extending
the shared architecture to more RME profiles. Development source now includes
per-device MIDI/OSC ownership, scalar workspaces and explicit OSCmix snapshot
banks, scoped channel FX operations and dimension-aware Output Mirror. Native
file codecs, stereo conversions and other incomplete operations retain their
documented guards; exact TotalMix window/gesture parity is not yet established.
Software checks do not imply installation or hardware qualification. Release
history below remains specific to the versions it describes.

## Current local development build

`0.2.0-alpha.61+rows.1` adds the draggable vertical divider in two-row mode:
Inputs | Playback in the upper variant, or Playback | Outputs in the lower
variant. It changes their relative widths while keeping the common strip
height and independent horizontal scrollbars. The existing per-device/workspace
owner remembers native SplitPosition and floating SplitRatio (times 1000),
separately from the Linux Control Room width. UI lock protects the gesture;
arrow keys adjust a focused divider and Home restores its 50/50 ratio.
The lower view preserves the nested Control Room's usable minimum. Moving its
separate divider does not move the shared divider or leave a later resize jump.

The preceding alpha60 build adds a horizontal divider between ordinary outputs
and the entire Control Room viewport. Drag it to change the available width;
the role strips, command column and footer stay together. Native proportions
and readable text are preserved; horizontal scrolling keeps hidden roles
reachable. Width is remembered by the existing per-device/workspace view
preferences. With the divider focused, arrow keys adjust it and Home restores
natural width. UI lock also locks this divider. This is a Linux viewport
adaptation, not a claim of an identical native TotalMix free-width control.

The preceding alpha59 correction restores native glyph size throughout the console,
not only button labels: names, values, Control Room, sidebar, FX and DSP views
share the correct 60-unit font normalization, physical-height rounding and
2x small-font coverage. Native strip font constants replace old compensating
sizes. Text retains floating horizontal placement and clips without squeezing;
control dimensions, palette and command guards are unchanged. See
[native text rendering](doc/native-text-rendering.md).

This includes the preceding three-row EQ/Dynamics corrections:
the native EQ grid and rotary detail are restored, reduced graphics retain
fine strokes, and row/Control Room caches use the effective display density
when interface zoom changes. Panel dimensions and parameter ownership are
unchanged. Double-click resets rotary controls to their defined defaults;
faders return to nominal 0 dB and stay there on repeated double-clicks.
Numeric text and right-click editing remain available.

This build retains the previous native output/AUX Settings, EQ/Dynamics
inspectors and detachable windows, and Highlight submix frame. Verification
includes the combined GTK suite, independent raster arithmetic/state tests,
and real-pointer three-row fixtures at 1920×968 with 282 px strips,
100/135% zoom and DPI 1/2. See [resource scope](doc/native-vector-raster.md).

These are bounded software-verified changes, not complete native runtime
pixel parity or new hardware qualification. Only EQ/rotary atlases 4/14 are
migrated; other legacy resources, Brightness/Light Theme, other density entry
sites, capability bridging and some menu/OS-control details remain open.
Exact executed native divider-extreme pixel parity remains open. The Linux audio
driver is unchanged. This development version does not create a GitHub release.

## Changes since alpha.23

- **DuRec:** OSC transport and recorder controls, native Record/Play selections,
  guarded Seek availability, response handling and a corrected position rail.
  OSCmix does not claim the reference application's complete recorder GUI parity.
- **MIDI and ARC:** per-profile Mackie REC selection, master Mute/Solo/Cue actions,
  MIDI submix selection and channel exclusions, plus guarded ARC USB commands.
- **OSC Remote:** additional TotalMix OSC pages and channel/room controls, with
  shared command owners and guards. See [OSC remote](doc/osc-remote.md) and
  [MIDI/ARC scope](doc/midi-arc.md).
- **Loopback:** native UFX+ Loopback command, observed strip indicators and
  snapshot state. Physical command qualification is documented separately.
- **Menus and presentation:** TotalMix preferences and strip Mute/Solo/Cue
  descriptors, additional window scale ownership, persistent interface lock,
  snapshot preference confirmation and fixes to startup pipe handling.
- **Routing fixes:** preserve explicit FX Send silence while following channel
  faders, restore legacy FX Send state before Straight Playback, and retain
  observed Loopback state across sparse feedback.

Offline tests cover OSC/USB simulations, snapshots, recorder state, routing,
menus and GTK behavior. Physical Loopback, DuRec and ARC behavior is reported
only where explicitly qualified in the linked notes. Native GUI exact parity
remains under review: total window/control hierarchy and interactions require
separate comparison against the identified TotalMix FX 2.03 reference. The
static analysis and ported controls do not establish full GUI equivalence.
See [release notes](doc/releases/v0.2.0-alpha.26+menus.2.md),
[DuRec validation](doc/osc-durec-validation.md), [menus](doc/totalmix-menus.md),
[OSC Remote](doc/osc-remote.md) and [MIDI/ARC](doc/midi-arc.md).

## Mixer skins

Open **OSCmix menu → Appearance → TotalMix skin** to switch Hardware Inputs,
Software Playback and Hardware Outputs (including Main and Phones) together.
**Skin 1** keeps the original presentation. The preference is stored separately
from snapshots in `~/.config/oscmix/appearance.ini`; switching sends no audio.

The skin uses the local TotalMix FX 2.03 vector atlases for strip bodies, pan,
faders, M/S/Cue, T and Settings/EQ/D tabs. Native body/pitch/height are 81/82/352;
clipping, integer cell boundaries and a common scale keep adjacent strips aligned.
Settings/EQ/Dynamics panels fit the row height. Playback has Settings only.
Stereo input settings share gain, +48V and Inst; **link** temporarily separates
or reunites gain controls. Phase stays independent for L/R.

Source faders and pan address the selected submix. Their bottom menu selects a
destination and marks active sends. **T** adjusts active sends relatively, skipping
outputs with **no trim**, and refuses to start from unknown routing/No Trim state.
Double-click a fader (or Ctrl-click) toggles 0 dB/silence. Double-click pan centers
it; Shift-click sets left, Shift-Ctrl-click right. Double-click other knobs or the
volume number opens numerical entry. Shift-drag bypasses fader pixel rounding; knobs use their native parameter step.
Ctrl-click Settings/EQ/D or the width button applies the view to channels on the
right. Multiple inline panels can be open. Escape dismisses a popup first, then
closes panels. Right-click opens channel controls; its menu exposes the supported Copy/Mirror/Paste/Clear and Channel Layout
actions. Native EQ/Dynamics preset banks remain unavailable. The panel menu
opens the existing separate DSP editor; Room EQ opens its existing editor.
Unknown parameters stay unavailable. Native Crossfeed remains limited to Phones.

**Options → Channel Layout** offers the native eight-color selector. Color
applies to the strip name and body in Input, Playback and Output rows, in both
strip widths. The tint stays below the pan, meters and fader; the selected
submix frame remains independent. Colors follow the existing Layout Preset
and Workspace presentation state, not DSP audio settings.

Permanent Channel Layout hiding also removes channels from MIDI/OSC banks;
temporary All/Sub views do not rewrite the remote layout. Paired channels share
their logical hide state without collapsing physical CC positions. The Remote
Controller column displays the current owners' permitted M1/O1 through M4/O4
slots in native order, independently of controller enable status. It is a
read-only snapshot; the eight mask-editing checkboxes remain unavailable.

For UFX+, **Help → Device Info** becomes available after both DSP software
revision and Active Nodes have actually been observed from the device.
Disconnected, stale and unobserved values stay unknown. Other device-specific
formatters and optional driver telemetry are not yet supplied by this path.

See `doc/totalmix-skin.md` for decompilation/manual references and limits, and
`gtk4/totalmix/PROVENANCE.txt` for reproducible local asset extraction. Tests use
synthetic OSC observations, captured writes and an isolated X11 display; they
exercise three-row rendering, menu dismissal, mono/stereo, source routing, Trim,
Control Room identity, edit locks and preference round trips. Pixel equivalence
in every state and at every desktop scale is not certified.

## Mixer controls

- Hardware Input, Software Playback and Hardware Output rows, with stereo pairs,
  pan/balance, mute and transport-dependent Solo/Cue controls.
- Double-click a fader for nominal level or pan for center. Use Ctrl for fine
  knob adjustments. Channel settings adapt to the selected hardware channel.
- Inline/sidebar/detached EQ and Dynamics panels, editable EQ graphs, Room EQ,
  delay, global reverb/echo and mapped DSP Control Room parameters.
- The Settings gear opens a compact panel beside the strip. Click again, click
  outside or press Escape to close. It contains compatible Stereo, gain,
  phantom/Inst/AutoSet/reference, Width, FX Send/Return, M/S and polarity controls.
  Controls fit the minimum strip height without vertical scrolling, including
  separate L/R gains displayed side by side.
  Unknown settings remain unavailable. Opening the panel writes no settings.
- One gain control serves a linked pair; its small link button exposes L/R
  gains without changing their values. The inspector shares this link mode.
- Native hardware Peak/RMS meters reject incomplete snapshots. Gain-reduction
  displays are estimates where available, not a qualified compressor envelope.

### Solo, PFL and Cue

Input and Playback share per-submix Solo. Solo Master suspends the selection
without deleting it. Monitoring offers Live PFL, Exclusive selection and the
listening destination; Output strips provide Cue. Desired sends remain editable
and are restored when monitoring ends. Playback Mute uses dedicated registers
and does not rewrite sends.

Control Room sits at the right of the same Hardware Outputs row, following the
TotalMix FX 2 command layout. Assign gives Main, Main B and Phones 1–4 unique
physical pairs and normalizes an explicitly assigned output to stereo. Opening
the view alone does not change pairing. Speaker B switches the listening path;
A/B submix edits stay linked independently of the relative-volume Link button.
DIM remembers/moves/restores the Main A fader; Recall exits DIM and applies the
reference level through the same volume path. Mute FX shares its level memory
with External Input, and editing FX Return can cancel Mute FX.

Talkback and Listenback share one activation. Configure their sources and DIM
amounts in the inspector's **System** page; adjust their global source levels
using the input faders. Phones receive Talkback by default, with an explicit
Talkback option in every output's Settings. External Input has a stereo source
and gain in System. Buttons require the corresponding assignment. Cue uses the
identified UFX+ hardware command and follows the assigned listening role.

Local development build **0.2.0-alpha.19** includes these controls, logical session
state and TotalMix exchange. This build is not yet a published GitHub release.
Audio parity with TotalMix, particularly Cue/DSP/Talkback combinations and higher
sample rates, remains unqualified. See [monitoring scope](doc/monitoring.md).

## Snapshots and history

Native UFX+ has eight slots. Click to recall, choose **Store** then a slot to
capture, and double-click its name to rename. Snapshot shortcuts are editable
and have no default F-key assignment. F1 opens Help, F2 Level Meters and F3
Mixer Settings; Alt+1–8 loads Quick Select workspaces. Custom saved shortcuts
override these defaults. Empty slots remain visibly empty. Loading a saved bank
at startup never recalls a slot automatically.

The common history covers supported mixer edits, recalls, Store and names.
Use Ctrl+Z for Undo and Ctrl+Y/Ctrl+Shift+Z for Redo outside text entry. Meter
updates are not history events. Recall locks audio edits while metering,
selection and scrolling remain available.

**Recall safe** can preserve Main Volume (default), Main/Phones Volumes, or
Control Room Settings. Room EQ/output delay/Crossfeed recall is separately
optional. **Store** changes memory; **Save session**, successful Quit or opt-in
**Save on changes** persists the bank. A failed save retains its previous
committed generation and prevents a confirmed normal quit.

Load/Save Snapshot supports the mapped UFX+ subset of TotalMix `.tmss` files;
older OSCmix `.ini` imports remain supported. Native UFX+ **Preload all Snapshots**
can read one exact matching device bank from a `.tmws` workspace, with eight
existing destination slots, atomic validation and one Undo/Redo, without Recall
or live mix writes. Room EQ/Crossfeed are preserved by this native preload.
Historical OSCmix nine-column `.tmss` banks remain a separately identified
legacy format, not native workspaces. Their export requires eight stored slots.
Scalar-profile banks use explicit `.oscbank` files. Full native workspace export,
other-model `.tmss` codecs and complete TotalMix file interoperability remain
unqualified or guarded. See the linked documentation for the exact scope;
CC snapshots are not implemented.

Coefficient-only profiles with a complete producer-issued Full pairing template
now initialize eight independent factory slots before loading saved banks. They
do not copy the current mix or its cache, mark a slot active, or write hardware.
Saved slots take precedence; an invalid saved slot remains unavailable. Original
Babyface inputs 1/2 and the reviewed UFX-family microphone exceptions use the shared
producer metadata in the engine and GUI. Tagged DSP and fixed UFX+ factory banks
remain guarded until their full snapshot seed is represented.

Save Session persists initialized factory slots as well as user-stored slots.
The internal bank records occupied slots explicitly: an intentionally empty
slot stays empty after reload, even if an older slot file is left on disk.
Missing or corrupt saved slots are never replaced with factory settings.
Legacy bank metadata keeps its original missing-slot behavior. No bank load
or factory construction recalls a mix or sends device commands.

A bounded physical A/B, Undo/Redo and save test at 48 kHz succeeded with muted
Analog 1/2. This was not an audible transition test or independent Playback
readback. See [snapshot behavior and qualification](doc/snapshots.md).

## Hardware feedback and Sync

**Use device settings** stages and validates fresh supported observations,
then updates OSCmix without mixer parameter writes. It adopts Input/Output/DSP
state and explicitly reported Input routes, preserving unreported Input routes,
Playback values and host monitoring. Disconnects, invalid acquisitions and
conflicting operations prevent adoption. Playback readback is not required for
this supported action or for application snapshots.

| State | What is established | Remaining limit |
| --- | --- | --- |
| Input/Output channel and DSP | Scoped hardware observations with origin/freshness; 9,287 mapped paths and 94 output levels observed in guarded 48 kHz tests | Not every parameter transition, rate or destination is physically qualified |
| Input sends/pan | Explicit gain-and-pan pairs; tested Analog/Phones routes at 48 kHz | Missing-route semantics, especially active-to-silent transitions, remain unresolved |
| Playback sends and six channel controls | Known host values, bounded writes, persistence and snapshot support | No independent hardware readback in the tested acquisition paths |
| Saved/imported state | Host or historical origin retained | Never promoted to a fresh hardware observation |
| Solo/PFL/Cue | Host selections and temporary routing tracked separately from desired sends | Complete audible TotalMix equivalence is unqualified |

A completed matrix response need not explicitly describe every route. An
omission is neither proof of a USB error nor evidence of silence. The former
orange Input marker represented an inferred value; it did not prove that a
snapshot recall had failed. Missing gain or pan now leaves the known value
unchanged, and partial readback is reported. Green readback marks identify
qualified observations, not continuous or exhaustive synchronization.

The official macOS 3.39/TotalMix 2.03 Device-choice experiments, including a
complete handshake, also retained/replayed application Playback values.
This can be the normal behavior of that path; it does not prove that every
possible path lacks Playback recovery. Complete recovery of unknown Playback
changes and an automatic two-way mismatch resolver remain open research.

See [hardware feedback](doc/hardware-feedback.md),
[protocol investigation](doc/native-matrix-investigation.md) and the
[Input omission handoff](doc/handoff-orange-input-readback.md).

### Applying OSCmix state

**Always init DSP devices with OSCmix settings** is opt-in and off by default.
On a new native connection it validates and applies the saved device-bound DSP
profile and send cache. An upgrade preserves this preference. Hardware changes
made while disconnected can be overwritten when the option is enabled.

**Apply OSCmix settings now** freezes the current complete session state;
it does not reload an older disk profile. Restoration writes output mutes first,
then supported DSP and sends, and final output levels/mutes last. USB completion
precedes background DSP verification. A partial failure stops the operation
without automatic rollback/retry and cannot replace the previous saved profile.

The scope includes mapped channel/DSP, Room EQ, FX and DSP Control Room values.
USB clock/settings, firmware, stored hardware setups, unsupported Loopback and
DURec are excluded. Unknown values are never replaced with default writes.
The old sends-only startup policy was removed in alpha.9 and remains ignored.
See [DSP initialization and state handling](doc/dsp-initialization.md).

## Window, applet and reconnection

**× and Alt+F4 minimize OSCmix.** Its session and reconnect wait continue.
Launching it again restores the existing window. Use **Quit OSCmix** or
**Ctrl+Q** to save and exit; quitting leaves the audio driver running.

The package includes an optional **OSCmix** Cinnamon applet. Add it in Applets
settings; click to show/start and right-click for Show, Minimize or Quit.
Other desktops use their taskbar and the application menu. The launcher also
supports `--show`, `--minimize`, `--quit` and `--status`; select a transport when
multiple mixer sessions exist.

With the supervised USB3 driver, disconnection keeps the mixer window alive.
The backend reconnects only when a new driver session has received valid audio
frames. It does not retry a failed backend on the same session or reset USB.

To opt into launch alongside the audio driver:

```sh
systemctl --user daemon-reload
systemctl --user enable --now oscmix-with-driver.service
```

The companion waits for actual driver readiness and the audio interface to be
open, rather than just an active systemd unit. It never starts the driver itself.
Stopping/restarting the driver stops/restarts its enabled companion. To opt out:
`systemctl --user disable --now oscmix-with-driver.service`.

## Install or upgrade

Download `oscmix-ufxplus_0.2.0-alpha.26+menus.2_amd64.deb`, `install-oscmix.sh` and
`SHA256SUMS` from the [release](https://github.com/charlysound/TotalMixLike/releases/tag/v0.2.0-alpha.26+menus.2)
into one directory. **Quit OSCmix first; closing its window only minimizes.**
Then run `bash install-oscmix.sh`, or install manually:

```sh
sha256sum --ignore-missing -c SHA256SUMS
sudo apt install ./oscmix-ufxplus_0.2.0-alpha.26+menus.2_amd64.deb
oscmix-ufxplus
```

The package installs to `/usr/lib/oscmix-ufxplus/` and preserves user settings.
Installation itself does not start hardware control. The separate USB3 driver
is not bundled. Driver alpha.7+ has unity PCM gain; users upgrading from driver
alpha.6 or earlier must lower monitoring because the former −30.1 dB test pad
is gone. OSCmix has no hidden playback attenuation or meter compensation.

The canonical desktop/icon identity is `io.github.charlysound.OscmixUfxplusUsb3`.
X11 window class and Wayland application ID match it. The executable embeds
the artwork, and installers provide SVG/PNG icons in the standard hicolor theme.
The old launcher remains hidden for pinned-shortcut compatibility. If a prior
per-user installation overrides system files, update it from the same release
with `make install-local`; the legacy CC application is separate.

## Build and test

```sh
sudo apt install build-essential pkg-config libgtk-4-dev libusb-1.0-0-dev \
  libasound2-dev alsa-utils python3 iproute2 util-linux zenity desktop-file-utils \
  libglib2.0-bin xvfb xauth dbus-x11 metacity wmctrl xdotool x11-utils weston
git clone https://github.com/charlysound/TotalMixLike.git oscmix-ufxplus-usb3
cd oscmix-ufxplus-usb3
git checkout v0.2.0-alpha.26+menus.2
xvfb-run -a env GTK_A11Y=none GSK_RENDERER=cairo \
  python3 packaging/build-deb.py --source
```

The package builder compiles and runs the complete offline engine/GTK/launcher
suite with temporary state/config directories, then creates a `.deb`, matching
source archive and checksums under `dist/`. Tests do not need a USB device.
For a per-user source installation, run `make install-local` after building.
It uses `~/Applications/oscmix/oscmix-ufxplus-usb3/` and the standard user data
locations for desktop entries, icons and the optional Cinnamon applet.

Additional isolated desktop checks:

```sh
dbus-run-session --config-file gtk4/window-test-bus.conf -- \
  xvfb-run -a python3 gtk4/test_window_lifecycle.py
# Requires Weston 13+ (Ubuntu 24.04):
dbus-run-session --config-file gtk4/window-test-bus.conf -- \
  python3 gtk4/test_wayland_identity.py
```

CI builds/tests on Ubuntu 22.04 and 24.04; the distributed `.deb` targets 24.04.

## Transport, state and troubleshooting

```sh
oscmix-ufxplus --list-devices
oscmix-ufxplus --native-usb3
oscmix-ufxplus --class-compliant --cc-port CLIENT:PORT
```

Automatic selection requires one unambiguous device/control port. A userspace
MIDI bridge is not treated as a CC port. OSC binds to loopback, normally using
available port pairs starting at 7224/8224. Unified CC selection has offline
coverage, but still needs fresh physical qualification.

State defaults to `~/.local/state/oscmix/` (or `$XDG_STATE_HOME/oscmix/`):
`ufxplus-native-matrix.ini`, `ufxplus-native-dsp.ini`, Playback workspace state
and device-specific `snapshots/` banks. CC uses its separate matrix cache.
Initialization preferences live in `~/.config/oscmix/host-sync.ini` (or the
corresponding `$XDG_CONFIG_HOME`). Successful Quit saves current state;
forced termination can lose recent changes. Loading cached routes without
explicit initialization updates memory only, not hardware.

- **No connection:** check hardware mode, permissions and competing control owners.
- **No audio:** check the separate driver, PipeWire links and hardware submix.
- **Partial Input readback:** known omitted routes are retained; this does not
  demonstrate a failed recall. Active-to-silent omission semantics remain open.
- **Different Playback values elsewhere:** external Playback recovery is not proven.
- **Window will not exit:** use Quit; a failed session save is reported instead
  of silently discarding it.
- **Control failure:** inspect the first error in runtime logs before reopening.

The native helper bounds allowlisted writes and does not claim audio, MIDI or
firmware interfaces, reset USB, clear halts or detach kernel drivers. Experimental
acquisition-handshake commands remain behind a source-only laboratory flag and
are excluded from release builds. Raw captures and proprietary reference files
remain outside the repository; sanitize runtime logs before sharing.

## Development and attribution

`gtk4/` contains the frontend, `oscmix.c` the engine, `alsaseqio.c` the CC
transport, and `tools/ufxplus-native.c` the native bridge. UI and published
documentation are in English.

[Roadmap](doc/roadmap.md) · [Transport notes](doc/native-usb3.md) ·
[Release notes](doc/releases/v0.2.0-alpha.26+menus.2.md) · [Contributing](CONTRIBUTING.md)

Based on [Michael Forney's OSCmix](https://github.com/michaelforney/oscmix),
the [huddx01 fork](https://github.com/huddx01/oscmix), and the
[UFX+ GTK4/CC application](https://github.com/charlysound/oscmix-ufxplus-linux).
Upstream notices remain in [LICENSE](LICENSE) and the source. No proprietary
driver, firmware or private capture is included.
