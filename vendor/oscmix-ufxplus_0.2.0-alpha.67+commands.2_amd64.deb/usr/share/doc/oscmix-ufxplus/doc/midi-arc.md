# MIDI / ARC remote control

MIDI/Mackie settings are in **Options → Mixer Settings… → MIDI**; Linux-only
options are under **OSCmix → Linux / OSCmix Tools → Linux MIDI Options…**.
ARC USB assignments are in **Options → ARC & Key Command Settings…**, in its
native two-tab frame. Complete host routing and the four controller profiles
remain under **OSCmix → Linux / OSCmix Tools → Linux ARC Configuration…**.
Keyboard shortcuts have their own **Keyboard Shortcuts…** host-tools entry.
Enable an input profile, choose its route, then Apply and enable control. For an ARC plugged
into the UFX+ USB host port, choose **ARC via UFX+ (USB host)**; no ALSA port
is required. MIDI CC, Mackie and ARC on the computer use explicit ALSA ports.
Four profiles are available, with at most one UFX+ host ARC profile.
Both application skins use these controls. In the OSCmix skin, the settings
are also available from the main menu button.

An optional output port enables Mackie motor fader and Mute/Solo feedback.
Ports are remembered by client and port names. Missing or ambiguous endpoints
wait for a unique match, with reconnection when they return. A returned MIDI
loop marker blocks that profile, including after restarting OSCmix. Disable
and enable control to retry after fixing the connection.

## MIDI CC

- CC7 on MIDI channel 1 sets the currently assigned Main volume.
- CC102–117 on channels 1–4 controls Inputs, 5–8 Playback, 9–12 Outputs,
  in groups of sixteen physical channel positions. Both members of an included stereo pair retain their CC positions; each controls the same canonical channel.
- CC102–117 on MIDI channels 13–16 selects the controller submix. `BC 68 xx` or `BC 69 xx` selects Output 1/2 in stereo, `BC 6A xx` or `BC 6B xx` selects Output 3/4. The value is ignored. The two reserved Trim selectors are kept separate.
- Value 0 is silence, 104 is 0 dB, and 127 is +6 dB, using the native curve.
- Input and Playback commands preserve the observed pan for the controller's
  submix. Uninitialized routes and communication-source faders reject edits.

## Mackie Control

Eight pitchbend faders control the current bank; the ninth controls Main.
Vpots change pan. Mute, Solo, channel selection, pan reset, row selection,
bank steps and single-channel steps are supported. REC buttons 1–8 on the Output row select their bank destination. Button actions occur on
release, matching the native handler.

**Submix Selection in Input/Playback Row** enables REC selection from either
source row for each Mackie profile. It is off by default, including for older
preferences files. The source bank's physical channel position selects the
corresponding output; an output stereo pair selects its canonical left member.
Different stereo layouts in the source and output rows can therefore select
different numbered submixes. Source exclusions determine the source bank,
while output exclusions determine the Output bank. Selection itself writes no
audio parameter. Unknown or out-of-layout destinations are rejected by the
existing controller; Follow the selected local submix retains its behavior.

Notes 54–61 recall snapshots through the
same transaction controller as the local interface, regardless of Store.
Mono, Speaker B, Dim, Talkback and Recall use the shared Control Room paths.
Master Solo (note 43) and Master Mute (note 44) use the same observed global
states as ARC. Master Mute toggles the global Mute enable, separately from Main
Out mute. Cue Main (note 62) and Cue Phones 1–4 (notes 63–66) use the current
Control Room assignments and toggle the selected Cue off when pressed again.
Unknown, invalid or conflicting assignments reject the command. These commands
also act on release and retain the existing connection and transaction guards.

Each profile starts on Inputs and submix 1. **Follow the selected local
submix** links its destination to the local selection. The menu's MIDI submix
command toggles this preference for each of the four profiles. A direct MIDI selection updates the local submix when this link is enabled; otherwise it stays private to that profile. Selection itself sends no audio command.

The settings expose exclusions for Hardware Inputs, Software Playback and Hardware Outputs separately in each MIDI profile. Enter physical numbers or ranges, such as `1,3-6`. Excluding either side excludes its whole stereo pair. CC retains the included physical positions; Mackie folds the pair into its existing bank position. Explicit Main volume and ARC assignments remain independent of these bank exclusions. Apply validates every field before changing preferences; Cancel discards the draft. Old files without exclusions mean no exclusions. Malformed persisted lists disable control and keep existing key assignments for review, without rewriting the file.

## ARC USB connected to the computer

Choose **ARC USB on computer** and both ARC MIDI ports. OSCmix enters ARC
SysEx mode on connection, resets its button baseline on reconnect, and clears
the LEDs and leaves that mode when disabled. A button already held when the
first event arrives performs no action. Encoder movement still acts.

The native **ARC & Key Command Settings → ARC USB** page also exposes:

- **Usage of host-connected ARC USB**: Shared (default), Ignore host-connected
  ARC USB, or Disable when device is offline. Here “host-connected” means the
  ARC plugged into the computer, not the UFX+ USB-host socket. These policies
  act on the configured computer ARC profile; they do not disable the separate
  interface-host route. Physical MIDI endpoints remain exclusively owned by
  one device owner to avoid duplicate commands across devices.
- **SysEx only**: require the native SysEx protocol. When unchecked, a connection
  with no valid SysEx report falls back once to the native three-byte MIDI ARC
  protocol after one second. A valid SysEx report prevents this fallback.
  After handover, delayed packets from the previous protocol are discarded.
  This Linux timeout is bounded connection handling, not a measured copy of
  the native application's poll cadence. No USB reset is performed.
- **SE active**: displayed only after an actual valid SysEx report, never merely
  because OSCmix sent the handshake. The interface-host route is not SysEx and
  does not fabricate this indication.

Apply saves these options atomically with the assignments. Cancel, Default,
All Off and assignment-file loading do not overwrite connection policies.
Older preferences without these options use Shared and allow protocol fallback.
Malformed persisted options disable control while preserving the assignments
for explicit review. The generic Linux routing window preserves these options.

The encoder initially controls the assigned Main output. Its level dependent
steps match the native 55-entry table. Buttons can select Main or Phones 1–4
as its target. The fifteen buttons and footswitch have explicit assignments;
press a button and its number appears in the settings status, so it can be
identified on the actual controller. No physical ordering or default key map is assumed.

Assignments include Dim, Mono, Speaker B, External Input, Talkback, Main Mute,
Recall, snapshots, volume target selection and DuRec Record/Play/Stop. Stateful
switches support Toggle, On, Off and Hold. Hold restores the value observed at
press, on the original target, and cancels even a press released before its
feedback arrives. A newer independent change or another engine session takes
precedence. Disabling or disconnecting releases owned holds when the shared
controller permits writes. Snapshot and DuRec assignments retain their normal
availability checks. One-shot assignments act only on press.

Feedback follows received engine state, including snapshot and recorder state.
A sent command is never treated as hardware readback. Volume target selection
is local controller state. Unknown levels produce no fabricated fader value.
The mixer’s connection state, edit locks and active transactions apply to all
commands.

## ARC USB connected to the UFX+

Leave the ARC on the USB host port of the UFX+. Choose **ARC via UFX+
(USB host)**, mark that profile **In use**, assign the buttons, check **Enable
MIDI / ARC Control**, then **Apply**. Port selectors are hidden for this route.
Opening the window does not enable the controller. The native USB session must
be connected and ready. An idle register alone does not prove ARC presence.

This route uses the same actions, volume step table, assignments and observed
feedback described above. The encoder initially controls Main. The device
reports its signed six-bit wheel displacement in register `0x3203` and its
active-high key mask in `0x3204`; these are distinct from the PC SysEx format.
The footswitch is bit 15 and has no polarity inversion on this route.

The native ARC control word contains fifteen LED states and bit 15, which
hands the encoder to software. An enabled UFX+ host profile normally keeps that bit
set, including with a No function assignment or an edit lock: the firmware
must not apply a second volume change behind the software controller. Disabling
the profile releases the bit. This is separate from accepting a DSP session;
session acceptance and LED-only refresh do not disable autonomous wheel edits.

**Volume Main (Device)** is the native exception: on a supported interface it
leaves wheel ownership with the firmware and sends no duplicate software volume
command. A temporary Main/Phones encoder assignment takes ownership, then
returns it to Device when released. This is not the same as No function.
Availability follows the native family/firmware predicate; unknown firmware
does not unlock firmware ownership. A session reset clears temporary encoder
ownership and button history. No new USB reader, polling thread or firmware
operation is introduced.

Live wheel and button reports remain separate from DSP snapshot observations,
including while a DSP response is being drained. The host input queue is
serviced every 10 ms and submits at most one wheel command per turn. It waits
while the shared Control Room owner is busy; queued gestures retain the normal
age limit and are never replayed after expiry. The timer is a scheduling
interval, not a measured end-to-end latency guarantee.

Press/release reports are edge detected. Identical consecutive wheel movements
remain separate events. The transport has a bounded, ordered queue; a session
change, overflow or event older than 500 ms discards incomplete input history,
releases owned holds when safe, and waits for a fresh key baseline before
accepting wheel movement again. No delayed burst is replayed into the mix.

The LED/control intent at `0x3e02` stays separate from snapshots, DSP profiles
and mix transactions. Read-only DSP/matrix acquisition does not block indicator
updates. During an audio write transaction the helper retains the latest intent
and submits it when the owner finishes, including a pending release when control
is disabled. An unchanged mask is refreshed once per second. A USB error ends
control without retrying the write; normal helper shutdown releases a confirmed
software takeover. USB completion and sent LED intent are not hardware readback
or proof that a physical LED has changed.

The engine also excludes the LED command from the DSP edit journal. UFX+
uses the same numeric address `0x3e02` for LED writes and for the Room EQ
band 9 type readback of output 79. The regression test exercises the real
OSC command and verifies that LED writes preserve that observation, while
actual Room EQ edits still enter the normal journal.

## Remaining compatibility and qualification

The PC and UFX+ host routes are implemented. Legacy non-USB ARC requires its
own device path. Native
Mackie LCD/meters, additional button LED feedback and native Trim mode remain
incomplete. REC selection from
source rows, direct CC submix selection and per-profile MIDI exclusions are
implemented. Global Mute/Solo, Cue and the expanded assignments are already
provided by the ARC action controller described below. External MIDI controller
qualification remains separate.

Software tests exercise virtual ALSA ports, the actual OSC receiver thread,
shared SnapshotPanel transactions, and the USB LED writer with a simulated
USB boundary. On 2026-10-18, user gestures on the ARC connected to the UFX+
were received through the running native bridge: 98 nonzero wheel reports
and ten press/release cycles on wire bit 8 (software Button 9). The physical
caption of that key was not identified. This validates physical reception;
audio actions and visible LED behavior require their separate hardware recipe.

Native reference: TotalMix FX 2.03 Intel x86_64, SHA-256
`75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265`.
The project cartography retains the REA handlers and numeric fixtures.

## ARC & Key Command Settings

Options → ARC & Key Command Settings has the two native tabs, **ARC and
Function Keys** and **ARC USB**, in the extracted 505 × 692 client frame.
The ARC USB catalog follows TotalMix2.03's native device class and, where
required, its attributed firmware revision. Unknown revision is not zero.
Functions without a corresponding Linux implementation remain unavailable;
original non-USB ARC/device keys and native F4–F8 assignment controls remain
disabled. This does not claim identical AppKit painting or native `.tmkb`
compatibility. Host-only routing and additional assignments remain in
**Linux ARC Configuration…**; shortcuts are separate under **Keyboard Shortcuts…**.
These views use the same controller preferences. Opening settings never enables
remote control and never sends mixer commands.

Each of the fifteen numbered keys (SNAP 1–8, MONO, PHONES 1/2, EXT IN,
TALKBACK, SPEAK B, DIM) and the footswitch has its own Function and Action.
Default restores the verified TotalMix USB assignments in the draft, including
momentary Talkback; All Off disables keys and the wheel in the draft. **OK**
saves assignments; Cancel discards unapplied changes. The native window keeps
the current global control switch and unrelated settings. Concurrent changes
to edited assignments/routes are rejected instead of overwritten. Linux ARC
Configuration retains its **Apply** button, and Keyboard Save buttons save
their own shortcuts immediately.

The wheel supports assigned Main/Phones, Main 0.1/0.5 dB, No function,
Mic/Instrument 9–12 (including linked pairs), and dynamics gain 9–12.
Encoder actions can latch a target or select it only while a key is held.
Global Mute/Solo, Mute/Solo/Fader groups, Link AB, Cue, Phones mute, Main FX mute,
Reverb/Echo, Room EQ, input 9–12 phantom/instrument, Undo, layouts, mixer/matrix,
and DuRec navigation reuse the existing guarded mixer controllers. Unknown
values never become zero; snapshots and layouts always recall, even if Store
is latched. Existing MIDI CC, Mackie and ARC-on-computer routes are preserved.

Toggle, Enable, Disable, Push and the native OR/inverted edge modes are
available for boolean assignments. The earlier OSCmix Hold mode still restores
the previous value and remains separate from native Push. Push-off or-on
reverses edges before updating the shared per-function OR counter.

Load/Save use `.oscarc` assignment files with a versioned format and validated
sixteen-key lists. They contain no routes, enable flags or mixer state. Loading
changes only the draft. These files do not claim TotalMix `.tmkb` compatibility.
Software tests cover GTK, persistence and real local OSC dispatch; physical
ARC audio actions and visible LEDs retain their separate hardware qualification.
