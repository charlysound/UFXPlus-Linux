# OSCmix development priorities

## Release baseline: alpha.17 (2026-10-12)

Snapshots, common history, partial device adoption, six Playback controls,
channel Settings, window management and desktop identity are implemented.
Input routes require explicit gain and pan; missing values preserve known
state. Bounded muted hardware snapshot tests passed at 48 kHz. Full Input
omission semantics, Playback readback and TotalMix file interoperability
remain open. The older dated entries below describe their historical state;
current behavior is summarized in the README and snapshots.md.

The proposed right-hand Control Room layout is still documentation only; see
[the plan](control-room-plan.md). No extra Output row is planned.

## Priority 1: event-driven hardware / OSCmix synchronization

Current plan (2026-10-10). This supersedes the upload-watchdog approach as
the intended live synchronization mechanism. The existing watchdog is a
fallback, not the solution to physical-control responsiveness.

Baseline: all 94 hardware output-volume observations matched the GTK fader
model in the remote comparison. A complete DSP upload originally took about
9.3 seconds; bounded receive bursts did not improve it. The subsequent
reference-cadence fix reduced a read-only hardware check to **1.85 seconds**.
Neither result proves physical
control tracking. The TotalMix reference has a normal receive/update path
distinct from complete state import, but the required native-session setup
and actual event delivery still need to be established.

Implementation progress (2026-10-10): the official macOS trace services the
native heartbeat every ~20 ms, not our previous 100 ms. This cadence is now
used by the native bridge and read-only diagnostics. Fresh verification
replies for every mapped DSP parameter are forwarded incrementally rather
than withheld until the entire profile comparison finishes. Cancelled
watchdog replies cannot overwrite gain/EQ/etc while draining after a host
edit. Offline tests cover all mapped DSP registers at the pipe boundary and
representative channel/FX/control families through the real OSC encoder,
with no feedback parameter writes.

The front-panel hypothesis explicitly has two branches: an absolute new-value
event, or a change/relative-control notification that TotalMix interprets.
The UFX+ receiver contains both ordinary parameter decoding and ARC delta/
button paths (`3203`/`3204`). These ARC paths are **not** yet identified as
the physical front-panel mechanism. Do not turn relative ARC events into
blind output writes or assume their values are absolute output levels.
OSC is downstream feedback, not an independent hardware read transport.

### 1. Establish the notification protocol before changing it

- Follow the UFX+ USB branch in the supplied TotalMix decompilation, then the
  corresponding macOS driver: session opening, any notification activation,
  heartbeat/subscription lifetime, receive queue and callback delivery.
- Correlate those paths with existing macOS captures. Produce a small evidence
  map for commands, endpoints, payload decoding and lifecycle. Keep USB and
  Thunderbolt implementations distinct; do not infer UFX+ behavior from UCX II.
- Classify every proposed command as a proven read, notification/session
  operation, parameter write or unknown. A constant seen in decompiled code
  alone does not authorize sending it. No speculative session commands.

### 2. Locate the break with a complete, timed trace

- Trace hardware IN packets -> decoded parameter/channel -> OSC -> model ->
  rendered control, using bounded diagnostics and monotonic timestamps.
- Distinguish unsolicited events, full-upload replies, accepted-write echoes
  and saved values. A local write followed by an echo is not a facade test.
- Use existing captures/replay while the user is away. Keep checking current
  hardware/display agreement remotely. A quiet device alone cannot prove
  whether notifications are enabled or missing.
- Once a physical change is available, identify whether it produces no USB
  event, a dropped/misdecoded event, a missing OSC update or a stale UI state.
  If reference evidence is insufficient, specify the exact required macOS
  capture before requesting another VM/hardware handover; do not start one
  automatically as part of this plan.

### 3. Implement continuous incremental reception

- Fix the demonstrated break first, initially for Analog/Phones output
  volume and pan, then generalize the same observation path.
- If measurement shows receive starvation, use a continuously armed bounded
  receive queue; do not rewrite the audio backend merely to add a control
  notification listener. Preserve command ordering and control ownership.
- Dispatch changed controls immediately and update only affected widgets.
  Coalesce redundant updates without losing the final value; meter traffic,
  input-send reads and full uploads must not starve control events.
- Keep full reads for bootstrap/reconnect and bounded recovery after loss or
  uncertainty. Once the event path is qualified, remove frequent full uploads
  as the normal steady-state mechanism. No shorter overlapping upload loops.

### 4. Qualify every parameter family, not only the output row

Maintain a coverage table: parameter, hardware address/encoding, notification
support, UI destination, mono/stereo semantics, test evidence and limitations.
Cover output levels/pan/mutes, input gain/phase/Hi-Z/phantom state, pairing,
EQ, Dynamics/AutoLevel, Room EQ, global FX and supported Control Room fields.
Track hardware-input sends and Playback sends separately. Playback hardware
readback remains unresolved and must not acquire a live label from cached
values. Clock/digital-I/O status belongs to USB Settings/the driver and needs
its own qualified observation route rather than a second competing USB owner.
For settings without demonstrated notifications, investigate a qualified
targeted read; otherwise explicitly mark the limitation, never invent state.

### 5. Preserve explicit authority and handle disagreements

- Initialization enabled: saved OSCmix settings win once at connection or
  explicit Apply. Afterwards a physical edit updates OSCmix; a UI edit writes
  that edit to hardware. Initialization disabled: import only proven device
  values and leave unsupported readback visibly unknown/unverified.
- Separate requested values, observed values, session identity and pending
  edits. Reject stale upload replies without discarding genuinely newer
  physical changes. An incoming observation never triggers parameter replay.
- A physical edit is not a startup conflict and must not open a mismatch
  dialog each time. Report a persistent confirmed disagreement or readback
  failure without silently overwriting either side. The startup two-way
  resolver must still respect incomplete Playback readback.

### 6. Acceptance, installation and evidence

- Offline replay: all mapped addresses, mono/stereo pairs, event ordering,
  missing/duplicate packets, stale reads, reconnects, both initialization
  policies, interleaved physical/UI edits, and zero feedback writes.
- Live remote check: current device values versus the actual model supplying
  controls; report mismatches and missing coverage independently of a saved
  profile comparison. Preserve audio settings and measure CPU/USB overhead.
- Physical qualification: measured control-change-to-display latency target
  below 100 ms, with median, p95 and maximum under idle and streaming load.
  Distinguish USB-arrival-to-render latency (measurable remotely) from total
  knob-to-render latency (requires a timestamped physical witness).
- No lost final value, no unsolicited parameter rewrite and no new audio
  underruns in the validation interval. Do not declare all parameters live
  from one successfully tested output pair.
- Install the verified local build and document the coverage and remaining
  gaps in English. Publishing/committing is a separate requested action.

Safety throughout: no firmware/preset writes, USB reset, automatic rollback,
generated audio or phantom switching. In particular, never enable Mic 9
phantom power. Phantom command/event tests use replay unless a separately
confirmed safe physical test is authorized. Preserve the current user policy.

## Output-fader live readback (development)

### Next: front-panel agreement and initialization/readback policy

**Priority 1 (reconfirmed by the user, 2026-10-10):** hardware/front-panel
settings and the corresponding OSCmix display must agree. Qualify this before
lower-priority UI work or feature additions. Check present-state agreement
remotely now; physical control-change responsiveness is a separate test, not
an excuse to defer the present-state comparison.

Plan update (2026-10-10): fixing receive gating does not establish that the
displayed output fader follows the physical front-panel control. Investigate
that disagreement together with the apparently conflicting initialization and
readback labels, without conflating output volume with input/Playback sends.

1. Trace the UFX+ output-volume path in the TotalMix reference and recorded
   macOS evidence. Identify per-channel volume, stereo balance, output pairing
   and Main/Phones assignment semantics. Do not assume that copying the left
   value to the right, averaging them or taking the maximum is correct.
2. Add bounded diagnostics across received USB registers, decoded channel
   values, OSC messages, model state and the visible fader. Distinguish fresh
   hardware observations from saved intent and local write echoes. Determine
   whether front-panel changes arrive spontaneously or require a known read
   request; measure latency before choosing a refresh strategy.
3. Audit authority transitions explicitly: **Always init DSP devices with
   OSCmix settings** applies saved supported DSP/mix settings once on a new
   connection (or on an explicit Apply), not continuously. After restoration,
   hardware observations must update the display without replaying saved
   values. **Input sends read from device** describes readback provenance,
   not an opposing startup policy. With initialization enabled, startup reads
   after restoration describe the restored state; they cannot preserve device
   edits that the selected initialization policy has already overwritten.
4. Test initialization enabled and disabled, reconnects, repeated Apply,
   delayed pre-restore replies, edits during/after restoration, and background
   mismatch/timeout. Ensure stale reads cannot undo newer edits and incoming
   readback cannot trigger write-back loops. Preserve saved intent separately;
   do not silently rewrite the profile to conceal a mismatch. No repeated
   automatic restore on ordinary polls or mismatch reports.
5. Clarify the English UI labels/tooltips: startup overwrite policy versus
   current readback source, restore-in-progress status, and unknown Playback
   send state. Warn that enabling startup initialization replaces supported
   standalone changes. Do not claim whole-mixer synchronization from partial
   input/output readback; the two-way mismatch resolver remains separate.
6. Correct only the mapping, pairing, event delivery or state transition that
   the evidence identifies. Replay recorded responses in offline tests, then
   qualify physical Analog and Phones controls in mono/stereo configurations:
   matching numeric values, correct strip, measured update latency and no
   unsolicited hardware overwrite. A simulated write is not proof of physical
   knob tracking; final front-panel validation requires a real knob change.

Safety: no firmware operations, USB resets, phantom changes or generated
audio for this investigation. Start with local evidence and read-only traces;
use a macOS test only if a specific unanswered protocol question requires it.
This section is a plan, not a claim that front-panel agreement is fixed.

Implementation follow-up: the reference receiver confirms signed 0.1 dB
output-volume registers and the left-channel live stereo-fader path. Added a
serialized read-only DSP-upload watchdog, changed-control filtering, bounded
register/model diagnostics, a pre-restore observation fence, and explicit
startup-versus-live-source explanations. Offline tests cover missed-event
recovery scheduling, busy/timeout backoff, stale uploads and no repeated
initialization from device changes with the policy enabled or disabled.
The user is away: physical knob tracking and measured knob-to-fader latency
remain unqualified; do not mark this entire section complete.

Remote comparison: all 94 hardware output observations matched the GTK fader
model (no missing channel), with initialization disabled and no parameter
writes. Recovery uploads take about 9.3 s, so rapid front-panel tracking is
still **Priority 1**, not completed. A bounded receive-burst experiment showed
no improvement and was removed. Next identify/qualify the spontaneous update
path; do not assume a complete-upload interval is the event latency.

Implemented: separate hardware output-volume observations from host intent;
remove permanent receive gating after global DSP mismatch/timeout. Preserve
the restore/drain fence, timestamp newer edits, and report provenance per
output instead of marking the entire row from a global comparison result.
Offline bridge/engine/GTK regressions cover 94 output identities, paired
left/right ordering and stale/invalid replies. Physical front-panel tracking
and event latency still require qualification; Playback send readback is a
different unresolved issue. No new USB commands or firmware operations.

## Retire sends-only initialization (alpha.9, 2026-10-10)

Removed the temporary sends-only checkbox and startup policy. Legacy
`force-sends-on-connect` values are ignored, never converted into broader
DSP restoration. The explicit full DSP policy, its saved state, and its
DSP-before-sends/output-after-sends ordering remain unchanged. Regression
tests cover old preferences with full restore absent, disabled and enabled.
Playback hardware readback and the two-way mismatch resolver remain open;
removing this workaround does not establish readback support.

## Interactive DSP parity (2026-10-10)

Alpha.7 enables typed native Room EQ/delay, global FX, mapped DSP Control Room,
analog reference and mic phantom/Hi-Z/AutoSet edits using the reviewed restore
mapping. Room EQ coverage, desired values and UI echoes use canonical read
addresses, not overlapping write addresses. Mock USB and synthetic GTK tests
pass; individual physical transitions remain to be qualified. Unsupported
output calibration and non-boolean Room EQ enable flags remain guarded.
No raw writes, clock changes, presets or firmware operations are enabled.

## Fast initialization and driver startup (2026-10-09)

Alpha.4: adjacent native gain / explicit center-pan commands are combined
without relying on cached hardware state. Measured 11,233 send words instead
of 13,442: sends 0.935 s, complete initialization 1.889 s. Signal-path comparison
passed on paired Playback 1/2 -> Analog 1/2, including recentering after a
nonzero pan; full DSP background readback also passed. This is not matrix
readback. Smaller packets, reduced heartbeat traffic and concurrent register
reads did not improve measured throughput and were not retained.

Implemented in alpha.3 development: ACK-driven send batches, 128-word USB
transfers, preserved MIDI frames at full-buffer boundaries, validated saved
DSP application followed by non-blocking readback, and an opt-in graphical
companion service for the audio driver. Measured complete application:
2.086 seconds with 4,512 routes; fresh background DSP verification succeeded.
Sub-second complete initialization remains a performance goal, not a claim.
First-use hardware capture remains slower. Reliable send readback is unchanged.

## Full host-authoritative DSP initialization (requested 2026-10-08)

The requested behavior is the UFX+ manual section 25.7 option **Always init
DSP devices with TotalMix FX settings**: on connection, the application's saved
mixer state wins over standalone device changes, without the mismatch prompt.
This includes channel and FX state, not just sends. It is not an instruction
to restore USB Settings, change sample rate, store a hardware preset or update
firmware.

Status: **implemented for the mapped native UFX+ DSP state**, with a separate
persistent `force-dsp-on-connect` preference. It restores channel/DSP state,
Room EQ/delay, global FX and mapped DSP Control Room registers, followed by
saved sends and final output levels/mutes. It is not a relabeled sends-only
checkbox. See the README for the exact scope and exclusions.

The versioned profile is hardware-seeded, identity/DSP-revision bound,
checksum-protected and atomically saved. Desired state remains separate from
readback. Complete coverage/value validation precedes the first parameter
write. In alpha.3, fresh DSP verification follows application in the background
as explicitly approved by the user; successful application is not labeled as
verified until the real comparison succeeds.
Local restore commands never become USB session commands. In particular,
Room EQ uses different native read and write bases, checked against the
supplied TotalMix 2.03 UFX+ writer/receiver.

Offline tests cover profile roundtrip, incompatible identity/revision,
corrupt/incomplete data, interrupted writes, output restore ordering and the
full GUI -> DSP -> sends -> final output sequence. Hardware send readback,
two-way mismatch resolution, CC automatic DSP initialization and broader
rate/topology qualification remain open. Loopback, USB Settings, DURec,
hardware presets and firmware are not part of this restore.

## English-only UI audit (requested 2026-10-08, low priority)

Audit all OSCmix windows, USB Settings panel and Cinnamon applet for remaining
French strings, tooltips, errors and launcher labels. Development and published
documentation remain English. This is a backlog item, not a claim that every
installed string has already been translated.

## Current: hardware-authoritative sends

2026-10-10 reference result: official macOS TotalMix reads hardware-input
sends, but retains and rewrites cached Playback sends even after Device choice
in the tested configuration. A paired input route was read at -30 dB/R50;
contradictory input cache was replaced with the real -30 dB, whereas
contradictory Playback cache won. See `native-matrix-investigation.md`.
Implemented locally: periodic input-bank readback, sparse reconstruction using
the reference pairing table, stale-query rejection and readback provenance marks.
Live tests read -30/R50, -42/L50 to Analog 1/2 and -36/R25 to Phones 9/10,
then restored the original input sends and output mutes. No audio was generated.
Offline tests cover all four mono/stereo lookup combinations; physical digital
routes and other sample rates remain to be qualified. Output DSP verification
also marks output faders. Playback still requires an explicit host-state policy:
no real Playback send values have been found. Whole-matrix Device import and
the two-way mismatch resolver remain disabled on this partial evidence.

Follow-up completed: two macOS Device-choice tests intercepted every parameter
write while allowing known reads. Input witnesses followed hardware (-33/R50,
-47/L50); both Playback routes followed conflicting host caches. Each capture
returned eight input cells, no Playback cells, and no parity errors. The same
second-case input response was retained and read under Linux before restoration.
Matching TotalMix decompilation and both audited driver families provide no
additional verified Playback read command. Recorded-response regression tests
cover the entire unknown Playback bank. Next protocol work requires new evidence
of a genuine Playback response (for example a qualified CC capture or a vendor
protocol clarification), not another identical Device-upload test. Existing CC
code or OSC feedback alone is not proof that CC readback worked for Playback.

- First resolve the reported Playback 1/2 fader regression without restoring
  unknown send levels or increasing output volume automatically.
  The native paired-send correction is installed and its attenuation has
  been measured on Analog 1/2 (2026-10-07); full matrix readback remains open.
- Recover the UFX+ mixer matrix through the native USB3 control transport.
- Compare the request sequence and conversion with the UFX+ branch of the
  macOS TotalMix reference; do not substitute a different device's protocol.
- Distinguish hardware readback, local cache and unconfirmed edits.
- Validate routing before enabling matrix-dependent Solo/playback mute or
  the hardware-versus-console synchronization choice.

## High priority next: device / OSCmix mismatch dialog

Requested priority update: 2026-10-07. Implement immediately after reliable
hardware send readback and validated send writes, before lower-priority work.

- On connection or reconnection, compare a complete, fresh device snapshot
  with the corresponding OSCmix state, including routing and send levels.
- Do not mistake missing, stale or cached values for a hardware mismatch.
  Incomplete readback must show a synchronization status, not an overwrite
  choice based on guessed values.
- When a real mismatch exists, show an explicit choice: **Use device
  settings** (update the console without writing the device) or **Use OSCmix
  settings** (explicitly confirm before applying the console mix to hardware).
- Allow dismissal without changing hardware; preserve the pending conflict
  and keep automatic restore disabled until the user resolves it.
- Scope comparison and restore to settings supported and verified by the
  active CC or USB3 transport. Never write firmware or hardware presets.
- Verify writes by readback; report partial failures without claiming the
  console and hardware are synchronized.
- Test matching states, real differences, incomplete reads, reconnection,
  both choices, cancellation and write failures.

Status: planned, not implemented. Reliable hardware readback is a hard
prerequisite; the existing local send cache does not meet it.

2026-10-08 initial follow-up: the manual Sync status window was implemented
with both choices disabled. The later host-authoritative implementation now
enables the OSCmix choice when a valid local profile is available; the device
choice remains disabled. There is no automatic incomplete-read popup.
This is not the mismatch resolver above. Empty/partial upload rejection,
duplicate/conflicting cells, end ordering and request isolation now have
dedicated collector tests. Invalid local caches are rejected atomically.
Neither an isolated matrix query nor a full upload with audio stopped
returned send cells. A non-empty ordinary TotalMix device-upload reference
is still required; do not enable replay on the strength of local echoes.

Historical workaround (2026-10-08; removed in alpha.9): an opt-in, persistent
host-authoritative send initialization policy was implemented for native
USB3. After fresh pairing readback it applies the saved send levels/pans,
once per connection. Missing/invalid caches do not trigger default writes.
Local per-route fences confirm USB completion, never hardware readback.
Errors, pairing changes and timeouts stop without automatic retry or rollback.
The policy defaults off and does not affect CC, output faders, clock or DSP.
This explicitly authorized overwrite supersedes the no-replay policy only
when enabled; it does not solve readback or implement mismatch detection.
This standalone policy was removed at the user's request on 2026-10-10.
The verified two-way resolver still requires reliable Playback readback.

Validation: offline engine/model/transport/launcher tests and five synthetic
GUI/backend tests pass (complete plan, missing cache/layout, rejected send,
stale acknowledgement). On 2026-10-08 the installed local build completed
4,512 logical routes in about 48 seconds with USB completion fences; the
independent audio driver remained running at 48 kHz. This is transport-level
validation, not measured routing correctness or a hardware readback round trip.

## Follow-up validation

- Test unified transport selection physically in Class Compliant mode.
- Distinguish measured Peak/RMS from estimated gain reduction.
- Reconcile documentation, build dependencies and releases with tested code.

## Coordinated driver work

The separate USB3 driver still needs long-duration drift and inter-group
timing qualification, real power-off cold-start validation, and verified
streaming with a locked external clock. Managed settings changes should
confirm actual audio progress rather than service activation alone.
The current Clock Source selector and grouped Analog 1–8 playback node are
implemented; remaining RME digital-I/O settings are not all writable.

The driver's PipeWire node-exposure tab and Cinnamon switches are implemented
and hardware-tested in driver alpha 5. See its `docs/desktop-backlog.md`.

## Snapshots (native UFX+, corrected 2026-10-12)

Eight named slots, Store/recall/rename, event-driven modified indication and a
common Undo/Redo journal cover supported mix edits, Store, names and recalls.
Recall sends only changed DSP/routes, orders attenuations before increases and
preserves unknown Playback mute state. Audio editing is locked during transfer;
channel selection, scrolling and metering remain available.

The shared toolbar contains history, recall preferences and file operations;
Monitoring owns Main B/Phones assignments. F1–F8 and the TotalMix OSC snapshot
grid are supported. Store changes memory; session saving commits a bank through
one metadata replacement, preserving the old generation if writing fails.

TotalMix tagged-text import/export covers the supported UFX+ parameters and
banks. Tests exercise the decompiled format and unchanged-value sentinel; no
file produced by an actual TotalMix session has yet qualified interoperability.
Per-slot sentinel retention, external DSP modified indication, confirmed
closing saves and Main B reassignment compensation are covered by regression
tests. Physical UFX+ A/B recall/timing, live Main B Link, complete Playback
state, groups/DURec, factory slot initialization and CC snapshots remain open.
See `snapshots.md` for exact coverage, evidence and limitations.
