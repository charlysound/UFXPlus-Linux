# Native USB3 Solo, PFL and Output Cue

## Reference behavior

The [RME Fireface UFX+ manual](https://rme-audio.de/downloads/fface_ufxplus_e.pdf)
is the behavioral reference (printed pages 62, 66–67 and 77):

- Input and Software Playback have Solo buttons. Solo is post-fader and applies
  to the selected hardware-output submix; both source rows share that selection.
- Solo Master suspends/re-enables the selected Solos without deleting them.
- Hardware Output has Cue. It sends the selected output's audio to the assigned
  monitoring output; clicking Cue is distinct from selecting a submix for editing.
- Live Mode replaces source Solo with PFL, independent of the send fader, on the
  Cue destination. Exclusive mode replaces the previous source selection.

The independent implementation uses the existing native logical-send encoder.
TotalMix FX 2.03 x86_64's mixer renderer at `0x1000ecb60` distinguishes route Solo,
source PFL and Cue destination. Its sender at `0x10015cdb0` emits logical native
send gain/pan commands. The macOS USB 3.39 `UserClientWriteDSP` path bounds each
transfer to 128 words; the Linux transport retains that packet bound.

## Implementation

`monitor.h` owns native monitoring state. Normal desired sends and known-route
coverage remain separate from temporary effective sends. Fader edits made during
Solo update the desired mix; ending Solo restores those current values. Hardware
uploads of temporary muted sends cannot replace the desired faders. Unknown
submixes are rejected until the normal sends are synchronized, including Playback.

GTK shows S on Input/Playback, PFL in Live Mode, and Cue on Output. Solo Master and
Live/Exclusive settings and the legacy physical Cue destination are in the header.
The Control Room occupies the right of the **same** Hardware Outputs row. Its Assign
menu owns Main, Main B, Phones 1–4 and the logical Cue destination (Main/Phones).
No extra mixer bank or output row is created. Both views retain physical indices,
selection, meters, routing, mute and inline settings/EQ/dynamics editors. Explicit role assignment normalizes the output to stereo and prevents unlinking
until the role is removed. Legacy mono assignments stay visible until explicitly
normalized; opening the GUI alone never changes pairing.

Control Room displays Phones, Speaker B, Main, then the command column. Assign,
DIM/Recall/Mono, Speaker B/Ext. Input/Mute FX and Talkback retain their FX 2 grouping.
The column geometry is measured from the official RME `TMFX-2.0.jpg` (80 × 340 pixels
at source scale), normalized to the common strip width. Horizontal overflow keeps
both zones side by side. Exact TotalMix overflow and all Speaker B/multiple-Phones
visual states remain unqualified; this is not a claim of pixel-identical rendering
or full TotalMix parity.

New assignments must be unique, including pending Main writes. The GUI and engine
both reject collisions. Ambiguous imported/legacy roles are highlighted in Assign;
their outputs remain accessible among ordinary outputs. Assignment feedback is
available before the entire mixer becomes snapshot-ready.

Recall is a separate no-argument action: restore the DIM memory if active, then
apply Recall Volume to Main A through the volume/Link transition. DIM itself moves
the software fader and restores its saved value when disabled. It does not change global Mute Enable. It participates
in the existing Undo journal and accepted-write/readback mechanism. The stored
Recall Volume and DIM reduction remain in the Control Room settings page.

Logical Cue follows Main/Phones reassignment. During active listening, both the old
and new destination are validated, then restored/rendered inside the existing USB
completion transaction. Unsynchronized destinations and removal of an active Cue
role are rejected. Physical `/monitor/target` requests switch back to legacy mode.
The logical role is saved with snapshots/session state; old files without it retain
their physical destination. Snapshot exclusions preserve the listening preference
and resolve it against the resulting assignments.

Speaker B, Link, External Input, Mute FX and Talkback/Listenback are implemented
in `control-room-engine.h`, with logical state in `control-room-state.h`. Main A
is independent of the hardware active-main register `0x3050`. Assigning A/B copies
the Main submix and later edits propagate in either direction even with Link off.
Link applies a relative dB delta to the two output faders. An inactive speaker
path is suppressed in the effective matrix without changing its desired sends.

Mute FX and External Input use the native shared Last FX Level memory. Temporary
FX-return suppression for external/communication paths keeps a separate logical
value, including edits while suppression is active. Talk and Listen sources are
mono and use their input-row global fader. Listenback alone is valid. A per-output
Talkback option overrides the Phones default; explicit OFF survives refresh and
reassignment. Ordinary sends remain distinct from temporary communication routes.
Changing the Talk source explicitly clears its ordinary sends; Listen source
pair splitting preserves the other channel's normal coefficients.

Cue uses a **typed local operation** emitting `0x3e00` with source in the high
byte and destination in the low byte, or `0xffff` to stop. Those are zero-based
channel indices, not pairs. Cue to itself is cancelled. This command never enters
the DSP cache: read-side Room EQ can have the same numeric address. Its USB command
is identified from the native UFX+ writer; audible DSP interactions remain to be
compared on hardware.

Monitoring and Control Room use local pipe BEGIN/END 104/103; Cue is typed sub-ID
102. These envelopes never reach USB. Existing matrix-only 115/114 and 125/126
transactions retain their restrictions. Each complete mixed transaction is
validated before writes, preserves operation order and acknowledges successful
transfers only. A short/failed transfer aborts without retry or a success ACK.
The helper exits on such failures; a disconnected console does not establish
that the full transaction was applied. A rapid Talkback release arriving during
a pending Control Room operation is deferred until its completion, not discarded.

The click in the Control Room is a toggle. Explicit OSC 1/0 supports press/release
controllers; losing window focus does not clear a latched state. Native ARC/key
mode selection and ownership semantics across multiple remote clients are not
implemented by this change.

Mono/stereo topology changes reconstruct affected desired routes from the normal
coefficient cache and re-render logical sends. They do not invoke the CC Solo
coefficient writer. Existing CC Solo handling is retained.

## Validation and remaining qualification

`make check` covers shared Input/Playback Solo, output isolation, Master selection
retention/reactivation, exclusive selection, PFL, Cue routing and source edits,
fader restoration, input readback isolation, mono/stereo changes, synchronization
conflicts and shutdown. Model tests cover all three rows and their redraw state.
Mock USB tests cover large restorations, 128-word packets and abort-on-error.
These tests do not open the hardware.

An audible A/B against TotalMix on the UFX+ remains necessary. The hardware Cue
path is implemented, but its combinations with source/destination EQ, dynamics,
FX returns and Talkback have not been certified by audio capture. Link at the
silence/limit boundaries and interactions with arbitrary native fader groups,
front-panel changes and 96/192 kHz remain qualification gaps. These limits are not
claims of complete TotalMix parity.

## Native Playback Mute

Input, Playback and Output retain distinct parameter banks. Playback source Mute
uses `0x2340 + 10 * channel` (zero-based channel 0..93), value 0 or 1. It is not a
matrix coefficient. A mono toggle writes one word; a paired toggle writes the two
independent words, even when addressed through the right channel. Neither toggle
changes desired sends or gain/pan commands. Fader edits while muted still write
the current desired sends. Solo/PFL/Cue rendering does not fold Playback Mute into
the matrix and does not clear its dedicated bit.

Protocol evidence: TotalMix FX 2.03 x86_64 initializes the Playback parameter
mapping in `0x10015edb0`: descriptor 2 (Chan Mute) has register offset 0, scale 1.
Its parameter flusher `0x10015b960` addresses the Playback bank after
`(input_count + output_count) * 0x30`, with a stride of 10. With UFX+ 94/94 this
is `0x2340..0x26e2`. Existing macOS USB 3.39 / TotalMix 2.03 IOKit captures dated
2026-10-10 include successful outgoing writes of zero to all 94 such registers.
The captured files include `input-device-choice.jsonl`, `osc-sends.jsonl`,
`forced-device.jsonl`, `route-cache-disagreement.jsonl`, `device-open.jsonl` and
`cache-disagreement.jsonl` in the private `macos-sends-20261010.bGlYhO` evidence
session. They do not contain a captured Mute=1 experiment or qualified Playback
readback. A direct hardware/audio A/B, including Mute/PFL precedence, remains
pending. The implementation does not claim a complete TotalMix Mute Master.

Only these 94 boolean commands are admitted by the native parameter allowlist.
They require no previous DSP value: the qualified DSP snapshot does not contain
Playback parameters. The existing DSP profile coverage is unchanged. GTK strip
and inspector display accepted per-channel writes, echoed only after a successful
USB transfer; this is USB completion feedback, not device readback. The engine
can republish confirmed values to a reconnecting GUI during the same session.
A fresh backend has no established Playback Mute state until a write succeeds or
an actual parameter observation arrives; Playback Mute is not persisted/restored
as part of the DSP profile. The current GTK default must not be read as hardware
confirmation on startup. Stereo writes are sequential, not atomic; a partial
acceptance leaves the pair visibly muted and allows a subsequent Unmute request.

Regression tests exercise all channels, exact mono/stereo words, no optimistic
state publication, parameter boundaries and holes, synchronization conflicts,
fader changes while muted, and Solo/PFL/Cue with the Playback mute flag set. A GTK
inspector test checks deferred feedback and partial stereo confirmation. These
are synthetic tests, separate from the pending audible hardware qualification.

## Control Room OSC API

| Address | Value / action |
|---|---|
| `/controlroom/state` | No arguments; read-only assignment and observed-control feedback, independent of snapshot readiness |
| `/controlroom/mainout` | Pair index 0–46, existing API; rejects occupied pairs |
| `/controlroom/main-b`, `/controlroom/phones1` … `phones4` | 0 = None, 1–47 = physical pair; rejects occupied pairs |
| `/controlroom/cue-to` | 0 = Main, 1–4 = Phones; feedback -1 = legacy physical destination |
| `/controlroom/recall` | No arguments; uses synchronized Main and Recall Volume |
| `/controlroom/error` | Feedback string for rejected commands |

`gtk4/control-room-test.c` exercises the actual layout, physical channel mapping,
mono pairs, conflicting assignments, command callbacks, inline editor insertion
and horizontal overflow. `tools/monitor-test.c` checks exact Recall register words,
assignment collisions and active Cue migration; `tools/snapshot-test.c` checks
Recall Undo/Redo and logical-Cue persistence/migration. `gtk4/test_host_sync.py`
permits the no-argument discovery query but still rejects unsolicited parameter
writes, including every other Control Room command. All use synthetic devices.

### Added Control Room commands

| Address | Value |
|---|---|
| `/controlroom/speaker-b`, `/controlroom/link-ab`, `/controlroom/mute-fx` | Explicit boolean 0/1 |
| `/controlroom/external-input`, `/controlroom/talkback` | Explicit boolean 0/1 |
| `/controlroom/external-input/source` | 0=None, otherwise 1-based physical stereo source (left member) |
| `/controlroom/talkback/source`, `/controlroom/listenback/source` | 0=None, otherwise 1-based mono input |
| `/controlroom/external-input/gain`, `/controlroom/talkback/dim`, `/controlroom/listenback/dim` | Float dB, −65..0 |
| `/input/N/communication-volume` | Float dB, −65..+6; assigned Talk/Listen source only |
| `/output/N/talkback` | Boolean reception option; paired outputs share UI edits |

The System page groups Talkback, Listenback and Main Out settings. The Link
control is in the Speaker B strip; no additional command row is introduced.
Local snapshot format 4 keeps the logical Control Room fields separately from DSP.
Formats 1–3 migrate Main A from their old `0x3050` meaning. Session metadata stores
current logical state, Cue role/destination and temporary FX restoration values.
A saved active session is rendered once normal routing and DSP coverage are known;
opening an additional GUI does not rerun these transitions. Snapshot exclusions
protect the native global monitoring settings; Undo uses the full logical state.
TotalMix exchange includes software globals, `Talkback Sel.` per output and input
global faders in Mixer row 0. This remains the existing partial TotalMix codec.

### TotalMix skin startup Mute correction (2026-10-15)

The TotalMix renderer used the generic observed-value requirement for Playback
Mute, preventing the first click in a fresh backend session. The dedicated
boolean command is now allowed even when that observation is absent: the first
request explicitly sets Mute=1. No synthetic Off value is stored. The active
colour still waits for transfer completion feedback. Either accepted muted side
of a stereo pair offers Unmute, including the narrow strip.

`/totalmix/playback-mute-startup` tests the initial real X11 click, unchanged
unknown model state before feedback, partial stereo acceptance, mono, lock and
disconnect. On the user's UFX+, a real Playback 1/2 click produced both Mute=1
completion messages and silence (-infinity measured peaks) on outputs 1/2 while
Playback samples continued. Unmute restored output signal. This validates this
route on this device, not all Solo/PFL combinations.
