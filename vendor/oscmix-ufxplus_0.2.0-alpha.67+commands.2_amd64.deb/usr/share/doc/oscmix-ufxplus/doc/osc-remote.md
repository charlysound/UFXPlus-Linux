# Contrôle distant OSC

Dans Options → External Control, **OSC Settings** configure quatre contrôleurs
et **Enable OSC Control** ouvre ou ferme leurs ports UDP. Le serveur est
désactivé par défaut. Son activation et les réglages sont conservés dans
`~/.config/oscmix/osc-remote.ini` ; une activation mémorisée est rétablie au
prochain démarrage. Ce fichier global n’est pas inclus dans les Workspaces.

Chaque contrôleur possède une adresse IPv4 d’écoute, un port entrant, l’adresse
IPv4 du client et son port de retour. Seuls les paquets provenant de cette IP
client sont traités. Par défaut : écoute et client `127.0.0.1`, ports entrants
7001–7004, retours 9001–9004, seul le contrôleur 1 est utilisé, banques de huit
faders. Pour un client sur le réseau, choisir une adresse d’écoute accessible
et son adresse client. OSC utilise ici UDP sans authentification ni chiffrement.

Les ports entrants actifs doivent être distincts. Les ports de retour doivent
être différents des ports entrants, pour éviter une boucle. Un échec de bind,
de validation ou de sauvegarde conserve les réglages et sockets précédents.
Pour échanger les ports de deux contrôleurs déjà ouverts, désactiver d’abord
le serveur. Désactiver ferme les sockets et supprime leurs sources GTK.

## Commandes du premier lot

La référence documentaire est la table RME `OscTableTotalMix_240722.ods`,
distribuée dans [l’archive officielle](https://rme-audio.de/downloads/osc_table_totalmix_new.zip).
La décompilation statique REA de TotalMix FX 2.03 confirme les handlers,
la courbe du fader, la construction des banques et les gardes de liaison.

Toutes les commandes ci-dessous prennent **un float OSC**, même les indices.
Les banques proposent 8, 16, 24 ou 48 faders. Une paire stéréo compte pour un
fader et ses commandes visent sa voie gauche. L’ordre est celui des voies
physiques UFX+, après les exclusions physiques configurées pour ce contrôleur.
Cette configuration adapte les flags natifs « remote enabled » sans reprendre
leur stockage binaire propriétaire.

| Adresse | Valeur |
|---|---|
| `/setSubmix` | Sortie physique à partir de zéro ; une paire est ramenée à sa voie gauche |
| `/setBankStart` | Voie physique à partir de zéro sur le bus courant |
| `/1/busInput`, `/1/busPlayback`, `/1/busOutput` | Pression > 0,5 ; relâchement ignoré |
| `/1/bank+`, `/1/bank-` | Pression > 0,5 : avance/recul d’une banque |
| `/1/track+`, `/1/track-` | Pression > 0,5 : avance/recul d’un fader |
| `/1/volumeN` | Position 0–1, courbe TotalMix, de −65 à +6 dB |
| `/1/panN` | 0–1 converti en −100 à +100 |
| `/1/mute/1/N` | 0–1 : activé si > 0,5 |
| `/1/solo/1/N` | Même règle, Input/Playback seulement |

`N` commence à un dans la banque. Le début de la dernière banque est borné
pour remplir la banque quand il reste assez de voies.

Le serveur retourne les valeurs float de volume, pan, Mute/Solo et le submix
sur ces mêmes adresses, au plus à 10 Hz lors d’un changement. Le retour reflète
le modèle OSCmix et les réponses du moteur, pas une preuve de lecture matérielle.
Une route sans cache chargé, réponse explicite ou édition locale n’émet pas
de volume/pan et ne peut pas recevoir ces éditions. Les changements de volume
et de pan sont envoyés au moteur ; leur envoi ne modifie pas optimistement le
modèle. Les faders de communication Talkback/Listenback sont exclus de cette
première adaptation du volume de routage.

## Labels et niveaux distants

La seconde passe ajoute ces retours, en conservant les types du protocole :

| Adresse | Type et contenu |
|---|---|
| `/1/tracknameN` | String : nom de la voie ou de la paire, incluant les noms locaux |
| `/1/labelSubmix` | String : nom de la sortie du submix |
| `/1/volumeNVal` | String : par exemple `-12.3 dB`, ou `-oo` au minimum |
| `/1/panNVal` | String : `L50`, `0`, `R50` ; extension OSCmix en page 1 |
| `/1/levelNLeft`, `/1/levelNRight` | Float 0–1 : Peak converti par la courbe de fader TotalMix |
| `/1/levelNLeftVal`, `/1/levelNRightVal` | String : niveau en dB ou `-oo` |

La table native réserve PrintPan à la page de canal détaillé ; `panNVal` en
page 1 est donc une extension explicite, pas une nouvelle équivalence native.
Les labels sont réexaminés à chaque cycle, même sans modification des paramètres
audio, pour prendre en compte les renommages locaux. Seules les valeurs
modifiées sont renvoyées, à un maximum de 10 Hz. Les emplacements sans voie
sont vidés pour éviter de conserver le nom ou le niveau d’une ancienne banque.

**Send Peak Level Data** est désactivé par défaut pour chaque contrôleur.
**Peak Hold** sélectionne la valeur maintenue du modèle et son temps Hold.
Ces deux options sont persistantes ; une ancienne configuration sans ces clés
conserve l’envoi des niveaux désactivé. Une paire utilise les deux voies
physiques et une voie mono est reproduite à gauche et à droite, comme dans
la référence. Les données absentes ou âgées de plus d’une seconde reviennent
à zéro et `-oo`. Désactiver les niveaux, le contrôleur ou le serveur efface
les derniers niveaux avant de fermer ses sockets.

Les niveaux utilisent les données Peak déjà reçues par le modèle, sans calcul
RMS supplémentaire ni modification de la correction des vumètres. Leur demande
maintient la réception des mètres si toutes les fenêtres de mix sont masquées.
Cette adaptation réutilise les ballistiques temporelles du modèle. L’option
**OSC decay** ajoute, uniquement au retour distant, un cycle de maintien puis
une décroissance de 0,8 dB par cycle de feedback. Elle est désactivée par défaut
pour préserver les anciennes configurations. La cadence est ici 10 Hz ; ce
choix ne revendique pas la cadence exacte du scheduler natif.

Les quatre liens **Submix linked to OSC Controller** suivent la sélection
du mélangeur. Une sélection `/setSubmix` du contrôleur lié met également à
jour cette sélection locale. Sans lien, chaque contrôleur conserve son submix.
Les contrôleurs liés partagent également le bus et l’index de banque. La sélection
d’un canal local repositionne leurs banques ; les limites de chaque taille et
les exclusions sont réappliquées séparément. Cette adaptation suit la sélection
du modèle, pas la position de défilement d’une fenêtre GTK. Un contrôleur en
page 4 reste sur le bus Output.

**Lock submix** fixe une sortie physique 1–94, ramenée à la gauche d’une paire.
Il prend priorité sur le lien de submix et refuse `/setSubmix`, sans modifier
la sélection locale. Les listes **Exclude Inputs/Playback/Outputs** acceptent
des numéros physiques comme `1,3-6` ; une paire suit l’exclusion de sa voie
gauche. Ces réglages sont propres à chacun des quatre contrôleurs et persistants.
Une configuration invalide conserve les réglages et sockets précédents.

Les éditions audio sont refusées hors connexion, pendant une transaction,
un verrou d’édition ou une opération de monitoring. En USB natif, elles
attendent également `/snapshot/ready=1`. Les paquets malformés, nombres non
finis, valeurs hors bornes et types autres que float sont ignorés. Les bundles
immédiats sont acceptés, avec limites de taille/profondeur et validation de
leur structure avant traitement. Les bundles programmés ne sont pas acceptés.

## Page 2 : gain, EQ et dynamique

`/setOffsetInBank` sélectionne le fader détaillé par son index **à partir de zéro**
dans la banque courante. `/2/track+` et `/2/track-` déplacent cette sélection,
en décalant la banque à ses limites. Les trois commandes `/2/busInput`,
`/2/busPlayback`, `/2/busOutput` sélectionnent le bus et sa première voie.
Une paire stéréo compte toujours comme un seul fader.

Toutes les commandes suivantes prennent un float **0–1**. Les activations
sont des bascules : pression > 0,5 inverse la valeur observée ; relâchement
ignoré. Les autres commandes règlent une valeur absolue normalisée.

| Adresses `/2/…` | Conversion vers le moteur |
|---|---|
| `gain`, `gainRight` | Gain analogique Input selon les bornes matérielles publiées, pas de 1 ou 0,5 dB |
| `lowcutEnable`, `lowcutGrade`, `lowcutFreq` | Activation, pente 6/12/18/24 dB/oct, fréquence logarithmique 20–500 Hz |
| `eqEnable` | Activation de l’EQ |
| `eqType1`, `eqType3` | Peak/Low Shelf ; Peak/High Shelf/Low Pass |
| `eqGain1…3`, `eqFreq1…3`, `eqQ1…3` | −20…20 dB (0,5), 20–20000 Hz logarithmique, Q 0,7–5 (0,1) |
| `compexpEnable`, `compexpGain` | Activation, gain −30…30 dB (0,5) |
| `compexpAttack`, `compexpRelease` | 0–200 ms ; 100–999 ms |
| `compTrsh`, `compRatio` | −60…0 dB (0,5) ; 1–10 (0,1) |
| `expTrsh`, `expRatio` | −99…−30 dB (0,5) ; 1–10 (0,1) |
| `alevEnable`, `alevMaxgain`, `alevHeadroom`, `alevRisetime` | Activation ; 0–18 dB (0,5), 3–12 dB (0,5), 0,1–9,9 s (0,1) |
| `volume`, `pan`, `mute`, `solo` | Mêmes routes et gardes que la page 1 ; Mute/Solo deviennent des bascules |

`/1/micgainN` règle aussi le gain du fader N de la banque. Sur une paire,
`gain` et `micgainN` écrivent les deux gains ; `gainRight` vise uniquement
la voie droite. Les limites des deux voies sont vérifiées avant tout envoi,
et la zone de gain indisponible est sautée comme dans le panneau local.
Les paramètres DSP visent le canal canonique comme le panneau DSP existant.
Ces commandes ne changent pas la composition des paires.

Chaque paramètre retourne un float normalisé et, sauf les activations,
une string `Val` avec sa valeur réelle. `/2/trackname`, `/2/labelSubmix`,
`/2/volumeVal`, `/2/panVal` et les niveaux `/2/levelLeft`, `/2/levelRight`
complètent les retours. Les niveaux restent soumis à Send Peak Level Data.
Une fonction indisponible retourne zéro et `n.a.` pour sa valeur texte.
Les éditions sont refusées si le moteur n’a pas encore publié le paramètre.
Aucune valeur supposée n’est écrite dans le modèle après l’envoi.
Playback n’a pas d’EQ/dynamique matériel ; Solo Output et gain numérique
ne sont pas ajoutés par cette adaptation.

Les noms et les échelles proviennent de la table native à `0x100540260`,
les bornes statiques de `0x10023d0e0` et du getter `0x10010d6c0`, examinés
avec REA sur FX 2.03. Les pas sont arrondis aux valeurs du moteur OSCmix ;
cela ne revendique pas une équivalence bit à bit de l’arrondi natif.
Les bornes de gain sont adaptées aux métadonnées UFX+ en cours, et les
fréquences sont arrondies au hertz accepté par le moteur. Les variations
d’autres appareils et les tables modifiées à l’exécution ne sont pas qualifiées.

Les paramètres de canal et la page 4 ajoutés après ce lot sont détaillés plus bas.

## Page 3 : réverbération, écho, snapshots et groupes

Les adresses ci-dessous sont préfixées par `/3/` et reçoivent un float 0–1.
Les activations sont des bascules sur pression > 0,5 ; relâchement ignoré.
Les valeurs continues sont absolues et normalisées. Les noms et échelles sont
confirmés par la table native FX 2.03 `0x100540dd0`, les bornes globales
`0x10023f090` et le dispatcher `0x10014b420`, examinés statiquement avec REA.

| Adresse sans préfixe | Paramètre réel |
|---|---|
| `reverbEnable`, `reverbType` | Bascule ; 15 algorithmes dans l’ordre du moteur existant |
| `reverbPredelay` | 0–999 ms, pas de 1 |
| `reverbLowcut`, `reverbHighcut` | 20–500 Hz et 2000–20000 Hz, logarithmiques |
| `reverbRoomscale` | 0,5–3, pas de 0,01 ; types classiques |
| `reverbAttack` | 5–400 ms ; Envelope |
| `reverbHold`, `reverbRelease` | 5–400 et 5–500 ms ; Envelope/Gated |
| `reverbTime`, `reverbHighdamp` | 0,1–5 s et 2000–20000 Hz logarithmiques ; Space |
| `reverbSmooth` | 0–100, pas de 1 |
| `reverbWidth`, `echoWidth` | 0–1, pas de 0,01 dans cette interface OSC native |
| `reverbVolume`, `echoVolume` | −65…+6 dB, pas de 0,5 ; échelle linéaire normalisée, distincte de celle du fader de mix |
| `echoEnable`, `echoType` | Bascule ; Stereo Echo / Stereo Cross / Pong Echo |
| `echoDelaytime` | 0,1–2 secondes, pas de 0,01 |
| `echoFeedback` | 0–100, pas de 1 |

Les paramètres FX utilisent les adresses, types et conversions du moteur commun
(`fx-parameters.h`). Les écritures n’altèrent pas optimistement le modèle.
Un réglage inapplicable à l’algorithme observé est refusé. Chaque réglage renvoie
sa position float et une string `Val`, sauf les activations ; le type retourne
son nom. Les valeurs indisponibles sont signalées par `n.a.` et une position
neutre. Les widths négatives du panneau local restent une capacité du moteur ;
l’interface native page 3 exposée ici ne les commande pas. Le filtre High Cut
d’écho n’a pas d’adresse dans la table native page 3 examinée et n’est pas ajouté.

| Adresse | Action sur pression > 0,5 |
|---|---|
| `/3/snapshots/8/1` … `/3/snapshots/1/1` | Rappeler les snapshots 1…8, indices inversés |
| `/3/undo`, `/3/redo` | Historique commun, uniquement si disponible |
| `/3/muteGroups/4/1` … `/3/muteGroups/1/1` | Basculer les quatre groupes Mute |
| `/3/soloGroups/4/1` … `/3/soloGroups/1/1` | Basculer les quatre groupes Solo |
| `/3/faderGroups/4/1` … `/3/faderGroups/1/1` | Basculer les quatre groupes de faders |

Les snapshots passent par le propriétaire de transaction `SnapshotPanel` : même
session, identifiant de requête, verrou et suivi de fin que les actions locales.
Le rappel distant ignore le mode Store du bouton local ; il ne peut jamais
transformer une demande de rappel en écriture de slot. Les slots vides sont
refusés. Undo/Redo respectent les indicateurs publiés par le moteur.

Les groupes utilisent `/routegroup` et `/fadergroup`, avec leurs règles de
propagation, d’historique et de persistance existantes. Leur activation OSC ne
change pas leurs membres. Une édition/effacement de groupe en cours bloque les
bascules distantes. Ces actions nécessitent le backend USB natif synchronisé.
Les retours float sur les adresses de groupes et de snapshots reflètent les
états observés, sans animation de clignotement. Les commandes se fondent sur le
dernier retour reçu ; un bundle n’est pas une transaction audio atomique et ne
doit pas servir à enchaîner plusieurs bascules dépendantes sans attendre le retour.

`/3/globalMute` et `/3/globalSolo` sont désormais raccordés. Le premier utilise
le maître natif Mute Enable UFX+ (`0x3052`, confirmé par la table de correspondance
initialisée dans `10015edb0`) ; le second utilise le Solo Master du monitoring.
Les groupes respectent ces maîtres, sans effacer leurs états ou leurs membres.
Cue reste une sélection indépendante. Le Solo Master et Cue nécessitent un
état de monitoring effectivement reçu ; une valeur par défaut ne suffit pas.
Les commandes DuRec sont raccordées selon le lot ci-dessous.
Les adresses non reconnues ne sont pas transmises au moteur.

## Commandes complémentaires de page 2

| Adresse `/2/…` | Portée et conversion |
|---|---|
| `phase`, `phaseRight` | Inversion mono/gauche ou droite réelle d’une paire ; Input/Playback/Output |
| `phantom`, `instrument`, `autoset` | Bascules uniquement sur les entrées ayant la capacité correspondante |
| `stereo` | Basculer la paire physique ; état des deux côtés requis et gardes du moteur conservées |
| `msProc`, `width` | Sources stéréo ; largeur −1…+1 normalisée, transmise en pourcentage signé |
| `loopback` | Output seulement, contrôleur Loopback existant |
| `refLevel` | Index direct entier à partir de zéro, borné par les niveaux du canal ; pas un float normalisé |
| `cue` | Basculer l’écoute de cette sortie via le monitoring, sans changer son submix |
| `talkbackSel`, `noTrim` | Output seulement ; mêmes chemins que le panneau local |
| `reverbSend`, `reverbReturn` | Input/Playback ou Output respectivement ; −65…0 dB, pas de 0,5 |

Toutes les activations sont des bascules sur pression > 0,5. Les réglages
communs d’une paire vérifient les deux valeurs et capacités avant envoi ; la
phase droite reste indépendante. Les nouvelles commandes ne simulent pas une
réussite : l’affichage distant suit les retours du moteur. Le moteur peut
refuser notamment une modification de stéréo incompatible avec Control Room
ou Mirror.

La vérification statique a aussi confirmé le pourcentage signé du registre de
largeur Input (indice natif 9 → offset 5, facteur 100). La garde interactive du
helper est alignée sur −100…100 et la largeur observée est conservée pour les
éditions ultérieures de routage. Les paramètres numériques sont retournés avec
une string `Val`. `pad` n’a pas de capacité/commande établie pour cette cible,
et le gain numérique ne dispose pas d’un chemin qualifié ; ils restent refusés.
`recordEnable` et `playChannel` sont raccordés au lot DuRec ci-dessous, avec
une garde supplémentaire sur l’état Stopped et le retour du canal.

## Page 4 : Room EQ

Une notification `/4` ou une adresse `/4/…` sélectionne le bus Output. `track+`
et `track-` naviguent parmi ses faders après exclusions. `leftChannel` et
`rightChannel` sont deux bascules indépendantes : gauche seule, droite seule,
les deux ou aucune écriture. La droite exige une vraie paire stéréo ; ces
choix ne modifient pas la composition des paires ni les liens du panneau local.

| Adresses `/4/…` | Valeur réelle, à partir d’un float 0–1 |
|---|---|
| `reqDelay` | 0–42,5 ms, pas de 0,01 |
| `reqVolumeCorr` | −24…+3 dB, pas de 0,1 ; correspondance native vers offset Output 11, facteur 100 |
| `reqEnable` | Bascule, seulement quand le brut d’activation est connu et vaut 0 ou 1 |
| `reqType1`, `reqType8`, `reqType9` | Quatre types établis dans le moteur existant |
| `reqGain1…9` | −20…+20 dB, pas de 0,1 |
| `reqFreq1…9` | 20–20000 Hz, pas de 1 ; normalisation logarithmique native (échelle 9) |
| `reqQ1…9` | 0,4–9,9, pas de 0,1 |

Les retours comprennent `/4/trackname`, les sélections des côtés, les positions
float et les strings `Val`. Quand les deux côtés sont sélectionnés, la gauche
fournit la valeur affichée et la commande écrit les deux côtés. Tous les côtés
ciblés doivent avoir une valeur connue avant le premier envoi.

Le backend publie aussi `/output/N/roomeq/raw` afin de conserver la distinction
entre valeur brute et affichage booléen. **L’encodage non booléen reste inconnu** :
les écritures d’activation sont refusées dans ce cas, et la restauration exacte
existante conserve son brut. Les bases Room EQ de commande (`30a0`) et de retour
(`3426`) restent distinctes. L’écriture de correction de volume est bornée et
requiert une observation préalable comme les autres commandes interactives.
Cette passe n’altère pas la politique de restauration des profils.

## Vérification

La phase de tests a repris le 18 octobre 2026 à la demande de l’utilisateur.
Le test OSC comporte dix scénarios isolés : commandes/UDP à quatre contrôleurs,
paires/liens, configuration/verrous/persistance, DuRec et conversions pages 2–4.
Les conversions testées vérifient les fréquences logarithmiques des pages 2
et 4. Les valeurs absentes et l’encodage Room EQ non booléen
refusent les écritures ; les commandes de canal DuRec exigent Stopped.

Le test DuRec moteur couvre le temps 32 bits et zéro initial, les états inconnus
ou périmés, le mauvais domaine CC/Room EQ, les séquences, ACK, timeout, Stop
armé et les conflits de transactions. Les tests natifs gardent DuRec hors du
rejeu DSP et testent les bornes des canaux. Les suites existantes couvrent les
menus, fenêtres, groupes, snapshots, paires, Peak/RMS et les deux skins.
Le rapport de la livraison conserve les résultats, le commit et les empreintes.
La qualification avec une application TouchOSC et un support DuRec physique
reste distincte des tests isolés.

## État des points 1–5 du plan du chat

1. Maîtres globaux page 3 : raccordés, avec prise en compte par les groupes.
2. Paramètres de canal page 2 : raccordés pour les capacités UFX+ établies ;
   Pad/gain numérique non qualifiés restent refusés ; l’enregistrement est traité au point 6.
3. Cue, Talkback Select, No Trim et sends/returns FX : raccordés aux chemins existants.
4. Room EQ : sélection des côtés, délai, correction, neuf bandes et master conditionnel.
   Encodage du master non booléen toujours ouvert ; aucune garde supprimée.
5. Quatre contrôleurs : exclusions, verrou, liens bus/banque/submix, retours et option
   de décroissance OSC. Il s’agit d’adaptations documentées, pas d’une parité runtime certifiée.

Compilation du moteur, du helper natif et de GTK réussie. Les tests et
l’installation initialement différés ont ensuite été autorisés. La correction du moteur
de vumètres est conservée. Les mises à jour du moteur des points 1–5 sont
limitées aux maîtres des groupes, à la largeur observée, au retour brut Room EQ
et aux gardes interactives de largeur/correction de volume.

## Point 6 : DuRec et enregistrement

Le transport UFX+ natif est raccordé à la page 3 et à la barre latérale TotalMix.
Les commandes `/3/recordRecordStart`, `/3/recordPlayPause`, `/3/recordStop`
acceptent la pression (>0,5) puis attendent le relâchement avant une nouvelle
pression. Les retours `/3/recordTime` et `/3/recordState` sont des strings ; les
boutons reflètent le retour matériel, avec clignotement Play en pause.

| Action | État requis | Chemin moteur | UFX+ |
|---|---|---|---|
| Record | Stopped | `/durec/record` sans argument | `3e9a:8122` |
| Play/Pause | Stopped, Playing ou Paused | `/durec/play` sans argument | `3e9a:8123` |
| Stop lecture | Playing ou Paused | `/durec/stop` sans argument | `3e9a:8121` |
| Stop enregistrement | Recording | deux pressions `/durec/stop` en 2 s, ou `/durec/stoprecord` explicite | `3e9a:8120` |

Le délai de deux secondes est une adaptation Linux. Le natif OSC arme aussi
l’arrêt à la première pression (compteur 100) ; le panneau natif présente une
confirmation. Aucun délai natif équivalent en secondes n’est affirmé.

Le helper reçoit une enveloppe locale typée et bornée, rejette les séquences
répétées et les transactions concurrentes, puis écrit un seul mot. L’acquittement
prouve la fin de l’écriture USB, pas le démarrage du transport. Une autre commande
attend un retour matériel postérieur ; aucun nouvel essai automatique à expiration.
Les données absentes, inconnues, périmées après 5 s ou d’une ancienne session
ne peuvent pas autoriser une commande. Les métadonnées affichées sont effacées
quand l’état expire ou quand le support disparaît.

REA établit le constructeur UFX+ `10015a850` → `1000a2150` (base `3e00`),
les relais `10015c910`/`10015c970` → `1000a21f0`/`1000a2380`, et le retour
`10015cfe0` → `1000a25d0` à partir de `33f4`. Les cas indirects du décodeur
sont désassemblés séparément depuis ses octets REA : le pseudocode Ghidra
tronqué ne suffit pas à les établir. L’ancien décodeur CC `3580` reste distinct
et ne remplace pas le retour natif UFX+ (cette plage est du Room EQ natif).

Temps écoulé : mot bas puis mot haut, 32 bits en secondes. Le moteur publie
`/durec/time` comme int tant que représentable, sinon float, et
`/durec/timetext` exact. Statut, position, charge/erreurs USB, espace,
nombre/fichier courant, mode et métadonnées bornées sont lus, jamais rejoués
par snapshots/profils. Les paramètres de canal `recordEnable` (booléen) et
`playChannel` (entier direct 0–80) utilisent les offsets Input 3/4 et Output 5/6,
confirmés dans la table UFX+ et ses chemins de lecture/écriture. Ils exigent
Stopped et une observation récente du canal côté helper. L’armement d’une
paire vérifie les deux côtés ; l’affectation Play d’une paire reste refusée
jusqu’à qualification de sa politique droite. Aucune modification des paires.

La gestion/suppression des fichiers, le seek, Prev/Next et le mode d’enregistrement
restent désactivés. La page System historique reste désactivée en USB natif ;
le transport qualifié est accessible par la barre TotalMix et OSC. Les tests
isolés passent avant installation ; ils ne constituent pas un essai d’écriture
sur le support DuRec physique. Voir le rapport de validation du lot.

## Travail à venir après le point 6

1. **Compléter DuRec.** Qualifier Play Channel d’une paire, les variantes de
   capacité, les métadonnées de fichier courant et les modes. Suivre ensuite
   sélection/Prev/Next/seek ; traiter suppression avec confirmation dédiée.
2. **Menus restant désactivés.** MIDI/ARC distant, MIDI submix, Operational Mode,
   Offline Device Setup, Store Setup, Stand Alone MIDI et CC Mode : relier chaque
   entrée à ses capacités, à son retour et à sa persistance avant activation.
3. **Parité restante.** Résoudre Room EQ non booléen, Pad/gain numérique,
   variations de tables et arrondis natifs ; distinguer les adaptations Linux.
4. **Qualification OSC réelle.** Vérifier quatre clients, banks/exclusions,
   verrou de submix, gainRight, côtés Room EQ, FX, groupes et snapshots avec
   un client réel, après les scénarios isolés. Un bundle n’est pas atomique.
5. **Qualification matérielle DuRec.** Support de test dédié, absence/erreur,
   Record → Stop confirmé, Play/Pause, temps long, retrait/reconnexion ; comparer
   write ACK et retour indépendant. Ne pas déclencher un enregistrement depuis
   les tests automatiques ni déduire le comportement audio d’un test simulé.


Loopback natif UFX+ : `/output/N/loopback` accepte uniquement0/1. Le moteur
canonise une tranche stéréo et applique chaque sortie physique par la commande
USB dédiée40/16/valeur/(100+sortie), sans registre DSP. La GUI et la page2
remote envoient une seule action au propriétaire de paire. Les suffixes
`/available`, `/known`, `/pending` et `/target` distinguent capacité opérationnelle,
valeur du dernier transfert terminé et intention en attente. `known` ne désigne
pas un readback matériel. Les commandes concurrentes sur la même sortie sont
refusées pendant le transfert. Le profil par UID ne contient que les commandes
terminées ; il est réappliqué une fois après la synchronisation DSP de démarrage,
puis doit recevoir ses propres acquittements. Les snapshots v9 stockent cet état
séparément du DSP ; v1..v8 restent lisibles sans inventer des valeurs Loopback.
Un rappel qui changerait une sortie dont l'état courant est inconnu est refusé.
