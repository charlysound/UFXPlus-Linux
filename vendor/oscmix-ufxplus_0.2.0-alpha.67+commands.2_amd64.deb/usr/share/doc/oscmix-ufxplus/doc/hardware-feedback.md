# Hardware feedback execution record

Scope: implementation developed as local alpha.14–16 on 2026-10-12 and
published in alpha.17. Both approved plans are tracked here. Original sources were
backed up privately before edits. No vendor code or full capture belongs here.

## Work and completion gates

1. Inventory every channel, matrix, DSP, monitoring and hardware-setting field.
2. Diagnose Playback parameter ownership, addressing, writes and read paths.
3. Carry origin, freshness and unknown values through the engine and UI.
4. Qualify channel and matrix acquisition, pairing, missed/stale observations.
5. Implement coherent device adoption with explicit coverage, no cached replay.
6. Preserve coverage in Store, recall, Undo and both snapshot file formats.
7. Replay captures and fault cases; run physical checks, then performance checks.

Completion requires independent hardware evidence for each hardware-backed
field. A successful USB write, TotalMix OSC response or stored host value is
not device readback. Unsupported Playback recovery remains an open requirement.
Rate/layout qualification and audible validation are reported independently.

## Evidence and inventory

Manual: UFX+ sections 25.3, 25.5.2, 25.7, 25.8 and 26. TotalMix 2.03 Intel:
UFX+ receiver 10015cfe0, input reconstruction 10015ea60, descriptors 10015edb0,
channel writer 10015b960, route writer 10015cdb0, host restore 10015ab10.
The earlier macOS experiments are documented in native-matrix-investigation.md.

| Family | Current evidence | Remaining requirement |
|---|---|---|
| Input/output channel DSP, EQ, dynamics, Auto Level | Complete qualified scoped upload; most control mappings exist | Per-field origin/freshness and external-change regression |
| Output levels/mute/pan/reference/crossfeed | Scoped upload; stamped level feedback | Extend stamped delivery to all controls |
| Room EQ/delay | Separate read/write addresses, scoped upload | Retain raw enable bits; qualify transitions |
| Reverb/echo, mapped Control Room | Scoped upload | Same provenance and adoption path |
| Input sends/pan | Explicit gain-and-pan pairs only, four pairing cases; missing routes retained | Partial coverage is reported; broader physical destinations/rates |
| Playback sends/pan | Native logical writes; no cells in tested uploads | Independent device read path remains unresolved |
| Playback mute/FX/stereo/width/M/S/phase | Six native descriptors and outgoing capture words | Complete control/state paths; no qualified bank readback |
| Solo/PFL/Cue, Main B/Phones assignment | Host logic plus temporary hardware routing | Keep desired and audible state separate |
| Groups/names/layout | Workspace or host state | Do not claim hardware recovery |
| Loopback, DURec, output calibration | Outside qualified restore scope | Separate protocol qualification; never infer default values |
| USB clock/status, firmware, stored device setups | Different hardware scope | Status observation only; not mixer restore commands |

## Playback diagnosis

The descriptor table maps parameter IDs 2,11,0,9,8,7 to offsets 0..5 of a
10-word-per-channel bank at 0x2340, with scales 1,10,1,100,1,1. The previous
engine mapped only mute; Playback stereo was changed in software without its
native register write. Width/FX/M/S/phase were absent from the Playback tree.
The archived successful macOS writes include all six offsets. Their startup
values alone do not qualify arbitrary nonzero transitions or readback.

The receiver's below-0x3000 branch dispatches 48-word Input/Output channels;
it does not decode the Playback 10-word bank. Matrix reconstruction traverses
the input count, not Playback. Re-auditing the unguarded archive also found zero
Playback channel-bank reads. Thus guard suppression alone does not explain
the missing Playback bank. No new read command is established by these facts.

## Validation

Baseline and updated full suites passed, including native/mock USB, GTK model,
widgets, snapshot files/history and the 13 synthetic startup-authority cases.
Additional regressions cover all 564 Playback register/control mappings,
source/timestamp persistence, stale observations, unknown imported fields,
no-write workspace reload, and failed/successful coherent adoption.

On the connected device at 48 kHz, an external USB write guard allowed only
heartbeat, 3e04=67cd and 3e05=3481. All parameter writes were forbidden.
The live test observed all 9,287 scoped parameter paths and all 94 output levels;
two consecutive device adoptions completed in about 4.0 and 2.5 seconds,
including console publication. Repeating a completed request did not reacquire
or write. Background reads and meters remained healthy for ten seconds afterward. It produced zero USB
parameter words, zero blocked write attempts, no malformed meter snapshots and
a clean helper exit. Audio and MIDI services remained active. Zero Playback
parameters were observed. Full-device recovery correctly refused the request.

Two real timing faults were discovered and fixed: continuous status traffic
must not reset the upload-drain timer; after staged delivery, the helper must
keep heartbeats running while waiting for the console publication acknowledgement
instead of filling its pipe with meter packets. The first failure timed out
without adoption; the second exposed the need for the completion handshake.

No physical qualification is inferred from mock tests, accepted writes or a
colored UI marker. New arbitrary Playback control transitions, audible effects,
96/192 kHz layouts and all digital destinations remain unqualified. The later
complete macOS handshake captures below qualify two Device-choice acquisitions;
ordinary reconnect/close remains unqualified. Both the official captures and
fresh native reads leave complete Playback recovery unresolved.

## Shipped behavior and remaining gates

Alpha.16 validation: the actual GTK button's click path, disconnected/busy guards
and removal of the duplicate action are tested. Engine regression covers adoption
followed by Store, recall and Undo/Redo with application Playback retained.
The full `make`/`make check` suite passed. Two physical read-only adoptions again
observed 9,287 DSP paths and 94 outputs, with zero parameter writes or blocked
attempts. A separate muted A/B snapshot test passed on the physical device;
see snapshots.md for its scope and evidence limits. The local package and desktop
launcher were updated to alpha.16; GitHub was not changed.

- Every mapped channel/DSP observation carries its source and query timestamp.
  Accepted writes and restored workspace state remain host-sourced. Stale reads
  cannot replace newer edits. Only explicitly observed Input gain-and-pan pairs update known routes;
  omitted values are retained and partial coverage is reported.
- Use device settings stages and validates DSP plus the input matrix,
  blocks conflicting edits, then adopts them without writes. Failure retains the
  previous console. Playback and host monitoring remain explicitly unverified.
- Alpha.16 exposes this supported adoption as the single Use device settings
  button, replacing the disabled full-recovery placeholder and its duplicate.
  Complete recovery of unknown Playback remains an evidence gap, not a blocker
  for this action or snapshots. No missing Playback cell is reset.
- Playback mute/FX/stereo/width/M/S/phase have bounded native control paths,
  snapshot/exchange support and host workspace persistence. Unknown values are
  preserved rather than invented. Snapshot completion reports writes, not full
  hardware verification; imported and historical provenance cannot become live.
- Protocol research still needs an independent Playback observation mechanism.
  Once found, qualify each field and route against deliberate cache/device
  disagreement, then qualify rates, destination banks and audible behavior before
  enabling complete recovery. These requirements are open, not declared complete.

## Next investigation plan: KEXT baseline before DriverKit

Updated 2026-10-12 after checking RME's website and the locally archived package
readmes/install instructions. This plan extends all completion gates above;
it does not replace the snapshot, provenance, adoption or validation work.

Handshake priority, revised at the user's request: establish a complete official
session before interpreting missing feedback. Remove the query-only restriction
and simulated-success interception from the primary macOS reference experiment.
Let the official driver and TotalMix complete their real session handshake,
including session-index and host-accept operations. Handshake suppression is a
possible experimental confound, not a proven explanation of the Playback gap.
Execution result: two complete official 3.39 sessions and a native Linux
reproductions in Isochronous and Bulk mode now confirm successful index/acceptance commands and cleared
mismatch status, but no Playback observations. Details, capture limitations and
unqualified reopen attempts are recorded in native-matrix-investigation.md.
The complete-device recovery gate remains open; acceptance alone is not a fix.

### Driver choice and controlled variables

RME currently offers both drivers for UFX+ and macOS 11 or later:

| Package | Architecture | Website release date | Investigation role |
|---|---|---|---|
| driver_usb_mac_339.zip | USB 2/3 kernel extension, 3.39 | 2026-06-06 | Primary reference: already exercised in our Intel VM |
| driver_usbdk_mac_430.zip | USB 2/3 DriverKit, 4.30 | 2026-06-07 | Optional isolated comparison after the baseline investigation |

These are separate driver families. The larger version number is not evidence
of better Playback feedback. Both package readmes list UFX+ and USB 3/2.0.
Neither current release note advertises a UFX+ Playback recovery fix. Both
packages list TotalMix FX 1.991; preserve the tested TotalMix 2.03 binary and
record its hash so installation cannot silently change the application under
comparison. If 2.03 cannot be retained, record the application change as a
separate experiment, not a driver-only result.

The existing reference is macOS 15.7.7, Intel, KEXT 3.39, TotalMix 2.03 and
native USB 3. Its application binary matches the earlier decompilation and its
input/DSP acquisition provides a working positive control. DriverKit has only
been inspected offline here. Therefore 3.39 is the better baseline for this
investigation; this is a project-specific judgment, not a general claim of
superior audio performance or an RME recommendation for virtual machines.

Sources:

- https://rme-audio.de/fireface-ufx.html (UFX+ downloads)
- https://rme-audio.de/macos-usb-drivers.html (parallel supported driver families)
- https://rme-audio.de/rme-macos.html (installation guidance)
- Readme and installation RTFs in the privately archived 3.39 and 4.30 packages.

### 1. Resolve the evidence gaps offline

- Reuse the existing macOS captures and the alpha.15 native acquisition results.
  Input/DSP observations work; zero Playback observations is established only
  for the tested sequences. Do not repeat the same negative test without a
  specific new hypothesis.
- Trace Device-choice acquisition from TotalMix through the KEXT user client
  to incoming USB data. Separate hardware messages, driver buffers, application
  cache, sparse reconstruction and subsequent host replay. The current IOKit
  traces are not independent USB wire captures.
- Map session opening, ownership/negotiation, session-index and host-accept
  operations, notifications, heartbeat, acquisition and orderly release from
  existing captures and decompilation. Identify which operations were suppressed
  by the earlier guard. Do not require every ordinary official handshake word
  to be decoded before observing the complete official session; resolve unknown
  meanings from that capture. Do not synthesize or probe unknown commands.
- Check separately for Playback routes/pan and the six channel controls:
  mute, FX send, stereo, width, M/S and phase. Search for an alternative receive
  path, session prerequisite or explicit host ownership. Missing receiver code
  in the known branch alone does not prove that the device cannot return state.
- Deliver a hypothesis table with supporting evidence, a discriminating test,
  expected session transitions, positive control and a stopping condition.

### 2. Prepare the existing VM safely

- Back up guest preferences, TotalMix, Linux workspace/snapshots, service state
  and the original VM domain XML. Make a consistent powered-off VM snapshot or
  clone before any driver replacement; verify the rollback path.
- Preflight macOS without the passed-through FL1100 controller. Prevent an
  automatic TotalMix launch from replaying cached state on device attachment.
  Record the actually loaded driver and bound device, not just package receipts.
- Keep the initial baseline at native USB 3, 48 kHz, the current clock and
  firmware. Record pairing, channel layout, driver settings and full channel
  availability. Keep Mic 9 phantom OFF and monitoring levels low.
- Record the device's Bulk/Isochronous input mode independently of USB 3 link
  speed. Returning a 5000-Mbps link to Linux is insufficient: the installed
  Linux audio backend also requires Bulk input. Restore this through RME's
  supported Settings option before the final handoff if the VM used Isochronous.
- Prepare and inspect the guest's saved mixer state before its controlled
  launch: phantom OFF, attenuated monitoring and muted test destinations. The
  official session may replay mixer values, so protect connected monitors with
  physical attenuation/isolation as well; a software mute that the application
  could overwrite is not sufficient protection. Back up and log any replayed
  state. No firmware utility, factory reset or Forced Init is part of this test.
- Transfer exclusive controller ownership deliberately: stop Linux mixer,
  MIDI and audio services, cleanly unmount the disk sharing FL1100, and attach
  the controller with the VM powered off. This interrupts Linux audio.
  Never let two control applications compete for the interface.

### 3. Capture the complete official handshake on KEXT 3.39

- Start with the official driver and TotalMix completing an ordinary session,
  using passive logging. Forward real calls and return their real results:
  no query-only allowlist, no blocked session-index/host-accept commands, no
  fabricated success, and no filtering of normal mixer replay in this reference
  capture. Observe from before connection/open through acquisition to release;
  record command order, values, responses, errors and timing in both directions.
- Verify instrumentation preserves buffers, call order and results. Compare
  session completion with an uninstrumented run where feasible. Treat logging
  overhead or missing capture boundaries as limitations, not device behavior.
- Capture a fresh process/device session and a subsequent reconnect/reopen,
  plus the Device-choice mismatch path. Keep a known input/DSP positive control
  in each qualified acquisition. Avoid surprise removal or forced USB resets.
- Establish whether independent USB capture is feasible without changing the
  experiment. Host usbmon cannot see traffic through a controller owned by
  VFIO. Use a verified guest/controller capture method if available; otherwise
  retain the explicit IOKit-level evidence limitation.
- Compare this complete sequence with the archived restricted experiment and
  the Linux helper's current session. Identify omitted initialization,
  acknowledgement, subscription or ordering steps only where evidence supports
  them. The complete official session is the baseline; selectively suppressing
  a step is an optional later diagnostic, not a prerequisite to observing it.
- Use deliberately different hardware preparation and host-cache values, with
  muted destinations and the input positive control. Reuse the prior Analog
  1/2 and Phones 9/10 cases; vary one Playback field at a time. An accepted
  preparation write is only intended state until independently verified.
- Repeat a candidate read with a fresh application process and different cache
  values. Require raw returned data that follows the independently established
  hardware state. GUI movement, OSC values and cached replay do not qualify.
- Correlate reads and writes in time: label observations before and after
  automatic replay separately. If replay overwrites a marker before observation,
  that run cannot establish recovery of the original device state. Only after
  recording a complete working session, consider a separate experiment that
  suppresses identified mixer replay while preserving the genuine handshake;
  disclose any remaining instrumentation effects.
- Stop and restore on a phantom-on attempt, loss of safe monitoring conditions,
  unintended clock/firmware changes or transport failure. An invalid input
  positive control invalidates the acquisition. Normal session writes are
  expected and recorded, rather than treated as an automatic test failure.

### 4. Compare DriverKit only if it can answer a remaining question

- Use the saved VM clone/snapshot and RME's installation instructions. The
  installers can remove the other driver family, so do not treat installation
  as a side-by-side toggle. Reboot and verify that the intended driver actually
  owns UFX+ before interpreting results.
- Keep OS, TotalMix binary, firmware, native USB 3 topology, sample rate,
  channel count, cache disagreement and capture procedure matched to 3.39.
  Verify DriverKit channel limiting is not reducing the test layout.
- Compare actual queries and returned device data. A different API wrapper or
  UI result without new hardware evidence is insufficient. Keep any VM-specific
  incompatibility distinct from a protocol limitation.
- Do not apply Apple Silicon security instructions to this Intel VM blindly.
  The DriverKit firmware warning for the original UFX and other older devices
  is not a reason to flash this UFX+. Firmware changes are outside this plan.

### 5. Implement only what the evidence supports

- If the native session is incomplete, implement the evidenced handshake as an
  explicit session lifecycle, including real acknowledgements, readiness,
  timeout, disconnect and orderly release. Expand its bounded command coverage
  to include proven required session operations instead of preserving the old
  query-only restriction. Keep exact-device checks and no generic raw-write API.
  Requalify DSP/input feedback even if Playback recovery remains unresolved.
- If a Playback read mechanism is proven, implement bounded acquisition and
  decoding in the local native helper/engine. Extend origin/freshness tracking,
  coherent adoption, stale-response handling and snapshot verification.
- Qualify routes/pan and all six Playback controls independently, including
  mono/stereo pairing, supported destination banks and single/double/quad-speed
  layouts. Separate silent protocol checks from later bounded signal tests;
  accepted writes alone do not prove audible behavior.
- Exercise Store, recall, Undo, imported snapshots and reconnect with deliberate
  cache mismatch. Verify that Use device settings adopts a complete coherent
  observation without writing cached state back. Test timeout, partial upload,
  duplicate requests, disconnect and rate/session changes.
- Use device settings adopts the qualified hardware-backed fields and retains
  application Playback and monitoring. Preserve host/unknown provenance and
  explicitly distinguish this supported action from recovering unknown Playback.
  Incomplete or changed DSP/input acquisition still prevents adoption.
- Run make and make check for implementation changes, capture replay/fault
  regressions, guarded physical checks and a performance comparison. Package
  and install locally only after those checks pass.

### 6. Restore and report after each physical session

Restore guest preferences without an uncontrolled mixer launch, cleanly unmount
guest storage and shut down the VM. Restore the original domain configuration
while it is off. Verify FL1100 returns to xhci_hcd, UFX+ enumerates at 5000 Mbps,
and the shared disk returns to its original read-only mount. Restore Linux
profiles/services in dependency order, then verify 48 kHz, Mic 9 phantom OFF,
saved output mutes and the local application state. Preserve private captures
and a concise result table recording driver/application hashes, allowed writes,
observed coverage, failures and unresolved claims. Keep proprietary binaries,
raw captures and personal configuration outside the repository.
