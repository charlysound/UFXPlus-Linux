# Native send synchronization investigation — 2026-10-07

## Complete official session capture — 2026-10-12

The handshake restriction was removed for two new macOS reference experiments.
The existing Intel macOS 15.7.7 VM used official USB KEXT 3.39 and TotalMix 2.03
(same original binary hash as the earlier investigation). Passive instrumentation
on a private application copy now logged every RME user-client method, including
scalar arguments and actual results. No session or mixer write was intercepted
or given simulated success. The separate existing alert helper selected Device;
it did not alter driver calls. These are IOKit captures, not macOS USB wire traces.

Both cases completed this sequence, with ordinary heartbeats between commands:

1. `3e07=0001`: first ConnectionIndex update from the deliberately zeroed cache.
2. `3e04=67cd`: channel/DSP upload request.
3. `3e07=0002`: next ConnectionIndex update.
4. `3e05=3481`: matrix request, followed by eight input cells and one terminator.
5. `3e03=234a`: host acceptance; observed `3203` mismatch flags cleared.
6. TotalMix replayed channel and matrix settings, including cached Playback.

The same disagreement markers as the guarded experiments were used. The input
returned -33 dB/R50 and then -47 dB/L50, independently matching the preparation.
Playback retained the host's -54/-56 dB and then -53/-55 dB values. Both captures
returned 10,084 distinct channel/status registers, zero Playback channel-bank
registers and zero Playback matrix cells, with no recorded API errors, parity
errors or truncated payloads. All 94 output mutes were observed ON; every
observed or written phantom value was OFF. No test audio was generated.

Timing distinguishes acquisition from replay: in case A the matrix terminated
at 5.203 seconds and the first Playback write followed at approximately 6.343
seconds. Case B also terminated before its first Playback write. Therefore the
absence of Playback in the captured upload is not caused by the later cached
replay erasing an earlier Playback response. Successful session acceptance
does not establish Playback recovery. These replies confirm the existing
input-only regression fixtures under a complete, unfiltered official handshake.

Two additional reopen attempts without automatic Device selection stalled at
the mismatch dialog and produced no OSC state. They are explicitly unqualified
for feedback conclusions. Apple-event quit was canceled; SIGTERM fallback was
used. An ordinary application-close handshake has not been established by those
attempts. GUI rendering remains limited by the VM's unavailable Metal support.

### Native Linux reproduction

A source-only `--session-matrix-probe`, enabled by `OSCMIX_LAB_DIAGNOSTICS`,
reproduced the five acquisition/session commands above without mixer replay.
It requires complete validated scoped DSP coverage before the second index
update, and a valid matrix terminator before acceptance. A release build rejects
the option before opening USB. The ordinary helper's runtime policy is unchanged.

The 45-second physical run received all scoped DSP fields and exactly the eight
case-B input cells plus one terminator; Playback cells and bank registers remained
absent. Both index writes and acceptance succeeded, and mismatch flags cleared.
Linux usbmon independently recorded 1,669 heartbeats, one channel query, one
matrix query, two index writes and one acceptance, with zero unexpected OUT
words or failed OUT completions. Its text IN payload previews are truncated and
are not used to claim full incoming coverage. No mixer parameter was written.
Exit 3 denotes incomplete whole-matrix coverage, not a transport failure.

That first Linux run used Isochronous input mode. After restoring Bulk through
the official RME Settings application, a second 45-second run returned the same
eight case-B input cells, all scoped DSP fields, zero Playback registers/cells
and confirmed acceptance. It recorded 1,682 heartbeats and zero mixer parameter
writes; exit 3 again reports incomplete matrix coverage. The independent usbmon
OUT audit above applies to the first run, not this repeat. This controls for the
input transport mode in the native acquisition comparison.

A subsequent independently guarded acquisition successfully adopted all 9,287
scoped device fields and 94 output observations, twice, with zero parameter
writes. Playback remained unobserved and complete-device adoption was refused.

**Finding:** suppressing the session-index/acceptance handshake does not explain
the missing Playback feedback in these tested 3.39/native paths. The official
application's input-only reconstruction and subsequent Playback replay remain
consistent with the evidence. Do not add automatic acceptance to normal
read-only adoption as a purported Playback fix: it changes the mismatch status
without supplying the missing state. Full Playback recovery remains unresolved.
DriverKit 4.30 remains an optional separate comparison, not a demonstrated fix.

### Hypotheses and remaining tests

| Hypothesis | Discriminating evidence or next test | Status / stopping condition |
| --- | --- | --- |
| The query-only guard prevented Playback upload | Real index and acceptance calls, cleared mismatch status, valid DSP/input positive controls in two official sessions | Not supported in these tested paths; stop repeating this sequence without a new variable |
| Cached replay erased an earlier Playback reply | Correlate complete incoming capture with the first Playback write | Matrix terminates before replay with no Playback cells; no hidden earlier reply in these captures |
| Linux input transport mode caused the missing Playback data | Repeat the same acquisition in Bulk after the Isochronous run | Both give the same input witness and no Playback; mode is still required for Linux audio startup |
| Another receive path or session transition supplies Playback | Establish a concrete receive path from decompilation or a qualified ordinary reconnect/close capture, then test cache disagreement with an input positive control | Open; stalled reopen attempts do not qualify, and unknown command probing is excluded |
| DriverKit changes device-returned coverage | Matched driver-only comparison in a rollback-capable VM, with raw response evidence | Optional and not performed; a different UI value or successful write is insufficient |

### Restoration and validation

The final guest boot visibly selected MacOS_Sequoia and ran macOS 15.7.7.
An earlier mistaken Recovery boot required a VM reset after ignoring virtual
input and normal shutdown requests; it is not represented as a graceful shutdown.
RME Settings restored Bulk while retaining Internal/48 kHz. Guest preferences
were restored byte-for-byte, its RME login agent re-enabled without launching
TotalMix, external storage cleanly unmounted, and the final guest shut down
normally. No domain configuration change was needed.

FL1100 returned to xhci_hcd, UFX+ enumerated at 5000 Mbps, and the shared APFS
disk returned to its original read-only mount. Linux audio, MIDI and OSCmix
are active at 48 kHz. The original DSP and routing profiles were unchanged;
fresh DSP verification passed and all 94 output mutes matched the saved profile,
including the saved phantom-OFF settings in the scoped DSP verification.
Playback restoration remains write-completion evidence, not hardware readback.

`make`, `make check` and `git diff --check` passed. Changes from this experiment
are a source-only diagnostic, regression updates and documentation; the installed
alpha.15 package was not replaced. Private captures and VM screenshots remain
outside the repository.

## macOS reference capture — 2026-10-10

### Follow-up: guarded hardware/cache disagreement

A second investigation isolated reads from TotalMix's automatic restoration.
A private, instrumented TotalMix 2.03 copy used the official USB KEXT 3.39.
Its parameter writes were intercepted and reported as simulated successes;
only the previously observed heartbeat, channel query and matrix query were
forwarded. This is **active instrumentation**, not an unmodified-app capture.
Session-index and host-accept writes were also blocked. The original app and
driver were not patched or replaced.

With TotalMix stopped, a separate bounded preparation program checked pairing
and phantom-off state, muted destination Analog 1/2 and Phones 9/10, and sent
three logical gain/pan markers. USB completion of a Playback preparation is
not independent proof of its hardware value. The host cache was then made
deliberately different, and its ConnectionIndex set to zero to trigger the
existing Device-choice path. No unknown hardware command was introduced.

| Case / route | Preparation command | Host cache | TotalMix after Device choice |
| --- | --- | --- | --- |
| A: Input 1/2 → Analog 1/2 | −33 dB, R50 | −52 dB, center | **−33 dB, R50** |
| A: Playback 1/2 → Analog 1/2 | −27 dB, R25 | −54 dB, center | **−54 dB, center** |
| A: Playback 9/10 → Phones 9/10 | −37 dB, L25 | −56 dB, center | **−56 dB, center** |
| B: Input 1/2 → Analog 1/2 | −47 dB, L50 | −51 dB, center | **−47 dB, L50** |
| B: Playback 1/2 → Analog 1/2 | −41 dB, L25 | −53 dB, center | **−53 dB, center** |
| B: Playback 9/10 → Phones 9/10 | −29 dB, R50 | −55 dB, center | **−55 dB, center** |

Each qualified app capture returned 10,085 distinct channel registers, eight
input matrix cells and one matrix terminator, with zero parity errors and
**zero Playback matrix cells**. All four phantom values remained zero and
the four destination mutes read back as enabled. The guard blocked 8,656
non-query DSP words per case, including 2,209 attempted Playback words;
none of these blocked words is a hardware observation or an executed write.
Every forwarded DSP word was an allowed query/heartbeat. Selector 5 denials
were intentional guard actions, not transport failures.

Comparing the final channel-register maps between A and B found only register
0x3202 changed, not an alternate per-route Playback value. The input witness
was independently present in the response and reconstructed correctly in
TotalMix. An initial run that did not trigger Device upload is retained as
unqualified evidence and excluded from these conclusions.

The decompiled UFX+ reconstruction at 0x10015ea60 traverses hardware inputs
(count at 0x14080), not Playback (count at 0x14084). The audited KEXT ReadDSP
path drains received USB words; WriteMixer is an output path, not a missing
matrix-read selector. The inspected DriverKit 4.30 wrappers did not reveal
an alternative proven Playback query. DriverKit was not tested live here.

**Conclusion:** the tested Device-upload path does not supply Playback sends,
even when cache restoration cannot overwrite the evidence. This strengthens
the earlier finding; it does not prove that every firmware, driver version or
other protocol path lacks readback. There is still no verified command to
implement as genuine Playback readback. Do not infer Playback zeros from a
terminator, import the input bank into Playback, or label host cache/write
completion as device state. The two recorded responses are regression fixtures
that check every Playback cell remains unknown.

After restoring the guest preferences and shutting it down cleanly, a Linux
read-only probe returned the exact case-B -47 dB/L50 input words and terminator,
again without Playback cells and with zero parameter writes. The original
Linux profiles were preserved, the controller returned to xhci_hcd, and audio,
MIDI and OSCmix were restarted at 48 kHz. Only diagnostic tests/documentation
changed in this follow-up; no speculative Playback-read implementation was
installed.

Live reference: macOS 15.7.7, official USB KEXT 3.39, TotalMix 2.03, native
USB3 UFX+. The installed x86_64 TotalMix slice exactly matches the existing
2.03 export identified below. A private instrumented copy records unchanged
IOKit DSP calls; this is application/driver evidence, not USB wire capture.
OSC permits bounded control despite the VM's unavailable Metal renderer.
No vendor binary, decompiled code, serial, private preferences or full capture
is included here.

### Device choice does not read back tested Playback sends

The first cache experiment changed `Slider 00 94/95`, which is not the
destination-specific send. Its unchanged +0.6 dB feedback was inconclusive.
Serializer/index analysis identified `Slider 02 94/95` as Playback Analog
1/2 to output Analog 1/2 (destination index plus two).

With that actual cached route changed to -23 dB, explicit **Device** selection
returned -23 dB through OSC and wrote native word `0x57803f1a` (-230 tenths,
center-pan flag) to hardware. A repeat changed cache to -31 dB while the last
hardware command was -23 dB: Device choice again kept the cache and wrote
`0x57803eca`. Neither upload contained a Playback matrix cell.
An OSC value or even the Device button is therefore not proof of Playback
readback in this tested version/state.

### Actual hardware-input sends are readable

With destination Main fully attenuated, Input Analog 1/2 was set to -30 dB.
TotalMix was closed; a separate bounded program used the official driver's
ordinary channel-state and matrix queries. The response contained:

| Raw word | Source | Output | Parameter | Value |
| --- | --- | --- | --- | --- |
| `40001ed4` | 0 | 0 | gain | -300 |
| `c0401ed4` | 1 | 0 | gain | -300 |
| `c0009ed4` | 0 | 1 | gain | -300 |
| `40409ed4` | 1 | 1 | gain | -300 |
| `c03f8000` | — | — | terminator | — |

After changing only the input route cache to -42 dB, reopening TotalMix with
Device selected read these same four cells and returned **-30 dB** through
OSC. At the same time Playback returned its changed cached **-31 dB**.
This differential test establishes the two distinct sources of displayed data.

Changing the input balance to R50 then closing TotalMix produced four
additional read words: `40002032`, `c0402032`, `c000a032`, `4040a032`.
These decode as read parameter **1**, signed value **50**. Native pan writes
use parameter **2** instead. The center-pan query omitted these cells, so an
absent value is not an explicitly read zero.

Static cross-check: reconstruction `0x10015ea60` iterates hardware input count
at offset `0x14080`, uses the input-bank index path of `0x1000fa0c0`, and does
not traverse Playback count at `0x14084`. The paired input response repeats
gain/pan across four cells; those must not be interpreted as four independent
CC stereo coefficients. Earlier empty uploads with only active Playback are
consistent with this input-only reconstruction, not evidence of a broken
Linux transport or a silent entire matrix.

The standalone official-driver probe must arm DSP input using selector 7
with argument 2 before draining selector 14. A first probe omitted that
trigger and is excluded from the readback conclusions. The valid probes had
zero parameter writes, successful IOKit calls and valid parity.

After clean guest shutdown and returning the controller to Linux, the Linux
`--matrix-probe` returned the exact same eight -30 dB/R50 words and terminator,
with zero unsupported words and **zero parameter writes**. The query completed
its matrix response about 35 ms after the scheduled request. Diagnostic exit
status 3 is intentional: eight explicit input values are not a complete
35,344-value input-plus-Playback matrix. Linux can read these input sends;
there is no need to route this read through a VM.

For context, the instrumented TotalMix startup sent 4,512 matrix words in
73 IOKit calls over about 1.44 seconds. This VM/tracer timing is not a native
performance benchmark or snapshot-recall measurement, and should not be used
to claim TotalMix inherently needs that long.

### Implementation boundaries

The collector now exposes only explicitly received cells from a terminated,
non-corrupt request and reports hardware-input/Playback coverage separately.
Recorded center/R50 input responses have offline regression fixtures. Missing
cells, conflicting duplicates, unterminated uploads and stale requests never
supply a value. Full-matrix completeness/replay gates remain conservative.

### Linux implementation and qualification

The bridge now periodically queries the input matrix using the same known
request. A private pipe message distinguishes observations from CC registers
and accepted-write echoes. The engine updates **inputs only** when both gain
and pan are explicitly present, resolving paired channels to their left member.
The former -65 dB / center fallbacks were removed on 2026-10-12: a later sparse
reply could overwrite known snapshot state. Missing fields now leave the whole
logical send and its provenance unchanged. Partial coverage is reported in the
GUI status instead of manufacturing an orange-marked value.
Readback updates never emit parameter writes. Playback is never reconstructed
from an absent cell. A query crossing a host write or layout change is discarded;
monotonic request timestamps also reject responses older than a GUI edit.

The GUI imports input gain/pan per destination and distinguishes it from cache
with a small green fader marker. Output faders get the marker after full DSP
verification; Playback remains unmarked. It is evidence of the last qualified
observation, not continuous synchronization. Queries run after stable DSP state
and approximately every five seconds at idle; unchanged routes are not flooded
back to the GUI. New connections and local edits invalidate provenance.

The exact TotalMix pairing table was checked against the matching binary. Both
paired selects left input/left output; input-only pairing selects left input;
output-only pairing selects left output; unpaired selects the addressed cells.
All four combinations are covered offline. Physical Linux tests at 48 kHz
read Input Analog 1/2 at -30 dB/R50 and -42 dB/L50 to Analog 1/2, and -36 dB/R25
to Phones 9/10. Baseline routes were read before edits and restored before
restoring destination mutes. No generated audio or phantom/clock writes.
Paired input writes now use logical gain/pan, like the reference; redundant
CC-only MIX bookkeeping writes are omitted on native USB.

Comparing all 10,085 common channel registers from two macOS Playback-level
states found no alternate Playback send value: differences were confined to
known output attenuation and status registers. This does not prove readback is
impossible, but no additional proven read command is available from that audit.
Two-way mismatch resolution and Playback readback remain unresolved. Digital
routes, other sample rates, cold power-on and sound quality are not qualified
by these tests. No firmware or persistent preset writes were made.

## TotalMix FX 2.03 follow-up — 2026-10-08

The user supplied a local Ghidra export of the official macOS Intel TotalMix
FX 2.03 binary (SHA-256
`75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265`).
It is application pseudo-code, not the original source or the USB driver.
No vendor binary or decompiled source is included in this repository.

Evidence in that export:

- Device type 28 (`0x1c`) reaches constructor `0x10015a8e0`, whose vtable is
  `0x1001d7808`. This is the UFX+ family, not the receive path at
  `0x1001521a0` with a different channel stride.
- Receive handler `0x10015cfe0` retains channel-state then matrix-query phases
  (`3e04=67cd`, followed by `3e05=3481`). It separates channel/FX mismatch
  from mixer reconstruction. No newly inferred command was sent to hardware.
- Matrix words retain source bits 22..29, output bits 15..21, parameter bits
  13..14 and a signed 13-bit value. Outputs outside the 94-channel range
  terminate upload in this handler; our collector deliberately accepts only
  the actually observed marker, pending additional evidence.
- Reconstruction at `0x10015ea60` uses a sentinel (`0x5555`) for absent
  values, with -65 dB / center-pan fallbacks and a pairing-dependent lookup
  table at `0x1001c3a60`. This supports investigating sparse/estimated
  reconstruction, not treating an empty response as a complete silent matrix.
- Sender `0x10015cdb0` distinguishes signed 13-bit gain and pan encodings,
  including a special zero-pan flag. Existing gain/pan translation is unchanged.
- The host-choice path marks channel, output and FX/mix state for update
  (`0x10015ab10`); it is broader than sends. A full equivalent needs complete
  saved state and qualified write coverage, not just a new label.

After installed host-send initialization, a new 45-second read-only matrix
probe returned **2 explicit cells and 1 end marker**, versus previous empty
snapshots. Audio remained running. The collector still reports PARTIAL;
missing values are not published as silence. This demonstrates some matrix
data can arrive but does not establish why the count changed or full readback
correctness. The probe now logs up to 32 decoded cells (raw word, zero-based
source/output, parameter, timestamp and request status) for reproducibility.

A second otherwise equivalent probe, with decoded-cell logging enabled,
returned **0 cells and 1 marker** again. The two-cell observation was not
reproduced and must not be described as a solved sparse upload. It could also
include unsolicited updates after the request; a controlled macOS comparison
is still needed. Both probes reported zero parameter writes. The UFX+ family
vtable was also checked directly in the binary: receiver at vtable +0xb8,
sender at +0xe8, agreeing with the functions identified above.

Next: correlate actual words with known sends and physical pairing, then
compare ordinary Device upload in TotalMix with this response. Only after that
qualify sparse defaults and reconstruction. Do not relax completeness checks
solely because TotalMix has fallback values.

## Confirmed scope

The macOS USB driver's `UserClientReadDSP` copies received DSP bytes to the
application. Mixer reconstruction is in TotalMix, not the settings panel or
the PCM driver. In the privately held TotalMix binary from the USB 3.39
package, UFX+ is device type 28, constructed through `0x10009873c`.
Its receive path is `0x10009a460`, not an assumed UCX/802 handler.

The UFX+ device-upload branch requests `3e04=67cd`, then `3e05=3481`.
The second phase decodes a source index, output index, parameter and signed
13-bit value. Reconstruction uses a sentinel for absent cells; a terminating
marker alone is not proof of the actual send levels. TotalMix also contains
a warning that mix settings can only be estimated. Do not assume that all
UI-only state can be recovered unambiguously from DSP state.

## Command encoding discrepancy

The UFX+ native sender at `0x10009a24e` builds source/output addresses with
`source << 22`, `output << 15`, tag bit 30, and a signed 13-bit value.
Volume command bit 13 has separate flag semantics. Pan is a **write**
parameter 2 (bit 14), also signed 13-bit. This is not the readback parameter
numbering (volume 0 / pan 1).

The shared OSCmix engine emits CC V2: signed 14-bit volume and signed 8-bit
pan. Passing this through unchanged incorrectly sets native bit 13 for
negative volume and loses sign extension for negative pan. The native
transport now translates these two payloads; addressing, channel/DSP writes
and the CC transport are unchanged. This encoding correction itself does not
replay a mix on startup. The later, separately opt-in host-authoritative send
initialization policy is documented in the README; it is not hardware readback.

An existing private Windows recording independently contains 29 native send
commands for combined source 102, output 0. One recorded -2.0 dB command is
`0x59801fec`. The old CC passthrough instead produces payload `0x3fec` rather
than `0x1fec`. Tests compare against the independently observed word and
exercise every permitted ordinary level and pan value, including right-side
outputs, mute encoding and denied addresses. Proprietary files and full
captures remain outside the repository.

This verifies wire encoding, **not** a live write/readback round trip. No
send was deliberately changed in this investigation because its initial
hardware value could not be read for an exact restore.

## Physical read-only results

With continuous Linux audio running at 48 kHz, two bounded 45-second probes
were run, with the GUI control owner closed temporarily:

| State request | Matrix request | Unique cells | End markers | Parameter writes |
| --- | --- | --- | --- | --- |
| 2 s | 4 s | 0 | 1 | 0 |
| 2 s | 14 s | 0 | 1 | 0 |

The channel snapshot completed around 11.38 s from probe start. The delayed
matrix marker arrived at 14.034 s. Both returned 10,085 distinct register
addresses (including the marker), with no invalid matrix words. Separating
the two requests therefore does **not** solve the missing matrix payload.
The diagnostic now uses the non-overlapping timing. Audio was not restarted,
and the GUI was relaunched afterwards.

## Playback 1/2 regression follow-up

After a reported send cutoff when lowering Playback 1/2, the running remote
was stopped; the audio driver was left running and no send was restored to
an assumed level. The installed helper still used the old CC passthrough.
The corrected native helper was installed locally with the previous binary
backed up. Subsequent user-authorized hardware testing showed that this
encoding fix alone did **not** resolve the cutoff.

An additional offline regression test exercises the real OSC-to-MIDI engine
path for paired playback faders over the full UI level range. CC retains its
four coefficient writes. Native USB3 paired playback now emits one logical
gain and balance, never the extra cross-route mute commands. Either-half
addressing, source/output pair bounds and nonzero balance are covered.

### Hardware confirmation

The old four-write sequence left Analog 1/2 silent at every tested level,
despite an active Playback 1/2 meter. A private diagnostic forwarding only
the left diagonal gain command restored **both** output channels. This
matches the single-command paired-send behavior of the Windows reference.
Consequently, the four independent-coefficient assumption in the offline
test was wrong for this native paired route: the extra writes interfere
with the logical stereo send.

The integrated engine fix, without the diagnostic filter, gave the following
median pre-output-fader RMS differences relative to hardware Playback 1/2:

| Requested send | Analog 1 | Analog 2 |
| --- | --- | --- |
| -30 dB | -30.008 dB | -30.008 dB |
| -36 dB | -36.012 dB | -36.012 dB |
| -42 dB | -42.023 dB | -42.023 dB |
| -36 dB (return) | -36.011 dB | -36.011 dB |
| -30 dB (return) | -30.004 dB | -30.004 dB |

These are signal-path measurements, **not send-register readback**. Tests
used the existing playback signal and preserved output gain, clock and
firmware. Scope: paired Playback 1/2 to paired Analog 1/2, 48 kHz native USB3;
other physical destinations and mono-input routing remain unqualified.

A follow-up verified the fader minimum (UI -65 / mute), recovery to -30 dB,
and balance at -50 / 0 / +50 / 0. Balance attenuated only the opposite side
by approximately 6.02 dB and returned both sides to -30.01 dB. The session
was left at a known -30 dB send and centered balance, not restored to an
unknown pre-bug value. The output faders were not changed by the test.

## Remaining gate

### Readback recheck after the paired-send fix

Two further 45-second observations were performed with native audio left
running and OSCmix's GUI owner temporarily stopped. The ordinary upload
sequence still returned zero cells and one end marker, despite the known
active playback route from the preceding attenuation tests.

Static analysis identified the UFX+ `3e07` field as the runtime
`ConnectionIndex`: the constructor initializes it to zero, the application's
settings serializer names it explicitly, and the receive/upload countdown
increments and sends it at `0x10009a4cb`. An isolated diagnostic reproduced
the fresh-application value 1, once, before the matrix request. Result:
10,085 unique registers, zero matrix cells, one end marker, zero unsupported
matrix words. This did not solve the readback. No send, clock, preset or
firmware value was written; the session-index write is reported separately.

`--connection-matrix-probe` is a source diagnostic available only when built
with `OSCMIX_LAB_DIAGNOSTICS`. Release builds reject that option before opening
USB. It is not part of normal startup or the bridge's command allowlist.
Do not repeat it as an automatic recovery strategy.

The official macOS 3.39 and DriverKit 4.30 `UserClientWriteDSP` routines
copy their supplied words to USB; no matrix query interception or synthetic
driver-side matrix reconstruction was found in those routines. Their read
counterparts copy the received DSP data. A reference capture must exercise
the explicit **device-to-host** TotalMix upload, not just fader movements
or its normal startup using a saved host workspace. Preserve the working
Linux mix; do not apply a host workspace or store a hardware preset to
manufacture a successful readback.

Hardware-authoritative sends are **not implemented successfully**. The GUI
still labels sends as cached; neither an accepted command nor an empty
upload is promoted to a hardware readback. Need an ordinary TotalMix UFX+
device-upload reference showing a non-empty response and its complete
session sequence. In particular, compare session generation/handshake before
adding any additional command; do not guess register writes or overwrite the
device with a host mix to manufacture a successful readback.

## 2026-10-08: independent query and idle-stream checks

The same local macOS 3.39 TotalMix UFX+ receive branch was reviewed again:
`0x10009a549` submits the matrix query in upload state 2; `0x10009acee`
decodes matrix cells; `0x10009b0b0` reconstructs application state from
the received values. No new proven read request was identified. The
host-accept/store commands remain outside the allowlist.

Two additional bounded Linux tests preserved the existing mix:

| Test | State queries | Matrix queries | Cells | End markers |
| --- | --- | --- | --- | --- |
| Audio running, matrix query without preceding channel upload | 0 | 1 | 0 | 1 |
| Audio stopped, full channel then matrix upload | 1 | 1 | 0 | 1 |

Both ran for 45 seconds with the existing heartbeat and returned diagnostic
status 3. Neither wrote channel/send parameters, clock, presets or firmware.
The first test saw 26 unique register addresses; the second saw 10,085.
Audio was restarted at 48 kHz after the second test, the two existing
Analog 1/2 PipeWire links were restored, and OSCmix was relaunched.
This rules out channel-upload overlap and active PCM as sufficient
explanations for these empty responses; it does not identify their cause.

`--matrix-only-probe` reproduces the first variant without adding a new
command identity. The diagnostic collector now starts only at the explicit
request, rejects inconsistent duplicates and data after the end marker,
and never counts duplicate words as additional coverage. Previously, a
single cell plus an end marker could have produced exit status 0: that
was not sufficient proof of a complete matrix. Complete explicit coverage
is now required conservatively. Real sparse/stereo upload semantics must
still be qualified; even full coverage does not authorize mix replay.

The GUI's manual **Sync** status window explains missing readback and keeps
both device/console choices disabled. It does not announce a mismatch,
automatically restore a mix, or claim that the conflict resolver is complete.
Local cache validation rejects non-finite/out-of-range values before any
model mutation. Offline tests cover empty, partial, conflicting, corrupt,
complete synthetic snapshots, duplicate markers and isolation across queries.
