# Validation OSC et DuRec — v0.2.0-alpha.24

18 octobre 2026. Tests isolés, sans ouverture du matériel par les exécutables de test.

- `make -k -j2 check-native` : réussi, dont le test DuRec ajouté, snapshots,
  groupes, Mute/Solo Master, profils, ACK/readback, valeurs invalides, FX,
  service USB simulé et acquisition des mètres simulée.
- `GSK_RENDERER=cairo xvfb-run -a make -k -C gtk4 -j2 check` : réussi avec
  configuration/état temporaires, notamment menus, fenêtres, Matrix, modèles,
  paires Input/Playback/Output, snapshots, deux skins et rendu Peak/RMS.
- `gtk4/remote-osc-test` : 10 scénarios réussis ; le dixième complète la suite
  GTK avec les conversions pages 2–4 et les paramètres de canal DuRec.
- Tests Python : lancement 7/7, packaging 22/22, synchronisation GTK/backend
  simulé 16/16. Syntaxe du lanceur vérifiée par `bash -n`.
- Cartographie : empreintes et références cohérentes, preuves REA conservées.

Les échecs initiaux de groupes provenaient des fixtures historiques : Mute Enable
n’était pas défini et le scénario Solo supposait que les groupes ignoraient Solo
Master. Les fixtures et assertions vérifient maintenant les deux maîtres, le
bypass et la conservation des membres ; les assertions de routage restent actives.
Le test OSC a été replacé après la vérification des valeurs de configuration par
défaut et sélectionne explicitement Input après le passage Room EQ en Output.

La correction des vumètres est conservée : calibration RMS, état inconnu,
ballistique, géométrie et demande d’acquisition restent couverts par les tests.
Des avertissements GTK de dépréciation et EGL sous Xvfb subsistent ; ils n’ont
pas produit d’échec de test.

Les commandes DuRec sont testées par des sinks simulés. Aucun test automatique
ne crée ou ne supprime d’enregistrement physique. La validation du support DuRec,
les affectations Play d’une paire et les commandes de fichiers restent distinctes.
Le rapport de livraison externe conserve le commit, le paquet, ses empreintes,
les sauvegardes et le résultat de l’installation.

## File navigation and classic-panel access — v25 increment

Native UFX+ `/durec/previous` and `/durec/nextfile` navigate files at register
`0x3e9e`, values `0`/`1`. `/durec/next` remains the observed next-file index.
Navigation requires fresh Stopped state, no conflicting transaction and the
sequenced helper validation used by Record/Play/Stop. After a write, another
command requires a new status observation. ACK does not change file selection.

The TotalMix sidebar previous/next buttons use this controller. The classic
System page now exposes Record, Play/Pause, Stop and navigation outside the
clock/storage restriction, with observed status, filename and elapsed time.
Stop while recording retains the two-press guard. Opening sends no recorder
command. Disconnection clears displayed metadata and disables commands;
click-time guards also apply before the next visual refresh.

Native evidence: TotalMix FX 2.03 x86_64, SHA-256
`75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265`,
REA `0x1000a2380` actions 5/6 and `0x1000c9100` panel tags 0x11/0x12.
Tests are simulated; physical media remain unqualified. File deletion,
arbitrary selection, seek and recording modes are separate developments.
Navigation during playback is not enabled by this increment.

### Observed file catalogue

The classic DuRec panel now includes an expandable Files list. It retains
indexed name/channel/duration observations for each file and shows unknown
fields explicitly while metadata are incomplete. Opening or expanding the
list sends no file command. It does not select, play or delete a file.

The catalogue is cleared after media removal/unavailability, a recorder epoch
change, device session change, disconnect or changed file count. A changed
filename discards the previous channels/duration for that index. Metadata
before a usable recorder status are ignored. Zero seconds is a known duration;
missing duration remains unknown. Numeric bounds follow the current native
receiver fields, with indices bounded by DUREC_MAX_FILES.


## DuRec complet — incrément nocturne du 18 octobre 2026

Les commandes natives paramétrées utilisent le sous-ID local 98 (17 octets,
deux mots de 32 bits encodés séparément : séquence/action, argument). Les
anciens frames de 12 octets restent inchangés. Aucun de ces sous-ID ne rejoint
l’USB ; le helper n’émet que les registres natifs validés.

| OSC | Arguments | Écriture UFX+ | Condition |
|---|---|---|---|
| `/durec` | aucun | aucune | Republie le catalogue observé |
| `/durec/file` | index i | 3e9c, index OR 8000 | Stopped, fichier complet connu |
| `/durec/delete` | index i, nom s | 3e9b, index OR 8000 | Stopped, identité exacte du fichier |
| `/durec/seek` | secondes i | 3e9d, secondes | Fichier courant confirmé, durée connue |
| `/durec/playmode` | mode i 0..5 | 3ea0, mode OR 8000 | Stopped/Recording/Playing/Paused |
| `/durec/next` | index i ou -1 | 3e9f, index OR 8000 | Playing/Paused, -1 efface la suite |
| `/input/N/record`, `/output/N/record` | i 0/1 | canal physique, offset 3/5 | Configuration native déverrouillée, registre observé dans la session |
| `/input/N/playchan`, `/output/N/playchan` | i 0..80 | canal physique, offset 4/6 | Stopped, 0 = Off |

Les affectations absolues utilisent la même séquence et le même ACK que les
commandes de fichier. Les changements rapides gardent la dernière intention
par canal pendant au plus cinq secondes ; les deux côtés d’un Record stéréo
existant sont donc appliqués successivement, chacun après un nouvel état
appareil. Refus, timeout, changement de support ou autre opération annulent
les changements en attente. Il n’y a aucun retry de transport.

Le catalogue contient au maximum 1050 fichiers, indexés 0..1049. Une entrée
est validée sur une séquence complète index + quatre mots de nom + info +
durée ; la table de fréquences du binaire donne 32000..192000 Hz. Un changement
de support ou de nombre de fichiers invalide les entrées. La suppression
invalide immédiatement le catalogue, puis attend le retour matériel.

Le panneau DuRec commun aux deux skins expose sélection, informations,
suppression confirmée avec nom/index, position en secondes, modes, fichier
suivant, stockage, charge/erreurs USB, temps et les 188 canaux physiques
Input/Output. Les deux canaux d’une paire stéréo sont configurables séparément,
sans inventer une politique d’affectation Play droite. Le bouton Record Mode
de la barre TotalMix ouvre ces affectations : REA 1000c8490 lit une bascule
locale et 1000914b0 la transmet à 1000807d0 pour les contrôles des canaux ;
aucun nouvel opcode de « mode d’enregistrement » n’est établi par ce bouton.

Qualification et traces matérielles : voir le rapport de session sous
`outputs/durec-completion-night/` dans le workspace de cartographie. Les
preuves statiques, tests simulés et observations USB y restent distincts.

Le contrôle natif de 1000c84b0 désactive Previous/Next pour statut <5 et
Recording 6, et les laisse actifs en Playing/Paused. L’incrément nocturne
étend donc les actions 5/6 aux états connus 5/10/11 ; l’ancienne restriction
Stopped-only de I50-01 est remplacée, après vérification native ciblée.

### Lecture DSP longue et fermeture du panneau

La réception DuRec périodique est indépendante de l’image DSP : le helper
la publie avec son heure d’arrivée, dans une enveloppe séparée. Les champs
DSP conservent la provenance du début d’upload (notamment le garde A20).
Après chaque commande DuRec, deux cycles de statut sont ignorés avant
d’autoriser un nouvel état ; l’acquittement seul ne lève pas cette barrière.
Cette politique conservative d’OSCmix empêche un upload DSP incomplet de
faire périmer en boucle les nouveaux retours du recorder. Ce n’est pas
une nouvelle commande ni une règle firmware attribuée à TotalMix.

Le panneau garde son hôte vivant lorsqu’il est détaché. La destruction
parent/panneau est testée dans les deux ordres, fenêtre DuRec ouverte ou
fermée, avec les erreurs GTK rendues fatales.

### Complément stéréo et états natifs

REA 1000fa130 (fabd6..fada6) et l’assembleur fad67..fada6 confirment
la copie de la même valeur du paramètre vers le pair stéréo, y compris
Record 15 et Play 16. Le panneau lie ces affectations par défaut ; la
liaison est désactivable pour éditer chaque canal physique. Le port OSC
page 2 applique désormais cette règle aux paires Play, 0..80 et Off 0,
sans inventer une valeur droite +1.

Le slot UFX+ 1001d7808+110 pointe vers 10015c930, relais tail-jump
vers 1000a2320 : configuration refusée pendant Recording 6 ou si le
bit 10 hex du statut est posé. Le receiver 1000a25d0 (2865..286b) conserve
bien ce bit séparément. OSCmix publie /durec/configlocked et respecte
ce verrou pour les affectations en Stopped/Playing/Paused. Les modes
sont modifiables pendant Recording selon le handler natif 1000c9100 ;
Delete exige l’arrêt et une confirmation d’identité.


La recette physique du paquet +durec.4 a révélé qu’une suppression du
fichier en cours de lecture est ignorée par l’UFX+ malgré un ACK d’écriture.
Le paquet suivant garde donc Delete à Stopped dans le moteur/helper et le
contrôleur UI. Le rafraîchissement natif 1000c84b0 désactive lui aussi le
contrôle associé à +0x358 hors des états 3/5 ; l’absence de garde locale
dans le handler 1000c9100 ne permettait pas d’en déduire une disponibilité.
Les tests rejettent Delete en Playing/Paused/Recording avant toute écriture.
