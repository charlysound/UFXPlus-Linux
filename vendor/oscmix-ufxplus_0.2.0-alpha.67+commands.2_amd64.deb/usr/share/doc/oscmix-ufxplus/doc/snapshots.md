# Snapshots — native UFX+

Eight named slots support recall, **Store** then destination, and double-click
rename. F1–F8 perform the same slot action. Names accept up to 28 UTF-8 bytes,
including an empty name. Unstored slots show **Empty** and a dashed border,
including while Store is active. The active slot flashes after a supported mix edit;
Store flashes the destinations. A recall does not ask for confirmation.

The shared header toolbar owns Undo/Redo and Preferences. History includes
supported channel/DSP/send/monitoring edits, recalls, Store and renames. Repeated
edits on one OSC control within 400 ms form a gesture. A new edit after Undo
replaces the redo branch. Ctrl+Z, Ctrl+Y and Ctrl+Shift+Z use this history outside
text entry. Meter observations are not undoable edits.

## Recall preferences

**Load Room EQs with Snapshot** is available for native sessions as well as the
legacy UFX+ session. It is a persisted global recall policy, not an immediate
DSP command: Cancel preserves it and OK waits for the engine's durable save.
When off, snapshot recall preserves the current Room EQ, output delay and
volume calibration. When on, it recalls the supported saved Room parameters;
old snapshots without those fields preserve the current values. Undo/Redo
remain independent of this recall exclusion. Unknown preference feedback keeps
the control disabled; this does not enable unsupported Record/Play controls.

**Recall safe** is one indexed choice, defaulting to Main Volume:

- Nothing: recall supported parameters subject to TotalMix's fixed exclusions.
- Main Volume: preserve levels at the recalled Main and Main B assignments.
- Main/Phones Volumes: additionally preserve the current four Phones destinations.
- Control Room Settings: preserve Main/Main B/Phones assignments, their output
  mutes and levels, and Cue selection.

Mono Main, DIM level, Recall level, PFL mode and Cue/PFL destination are
retained in every mode. DIM enable is retained unless Main changes while
volumes are excluded; TotalMix clears DIM in that case. Global Mute, Solo Master and Exclusive Solo remain
recallable. Exclusions are applied before generating writes.

Main uses the existing Main Output control. Main B and Phones 1–4 are shared
Control Room assignments in the **Assign** menu at the right of Hardware Outputs;
there are no snapshot-only Phones selectors. Their values identify protected
destinations. When an assignment is also the logical Cue destination, active
monitoring moves through the existing completion transaction, preserving normal
sends. The Cue role is serialized as the optional `cue-role` key; older files
without it preserve legacy physical targeting. Recall is journaled as one action
(DIM off plus the two Main output levels), independently of editing Recall Volume.
When recall changes Main B while volumes are excluded, its saved level
difference from Main is applied to the protected Main level, as in TotalMix
`1001043a0`. Live Main B switching and linked fader operation are not implemented.

**Load Room EQ with snapshot** is off initially. It controls Room EQ, output
delay and supported Phones Crossfeed. Room EQ values are captured regardless
of this preference. Output delay uses the UFX+ native scale of 100 units/ms
(0–42.5 ms), established by the TotalMix writer table.

## Files and persistence

Store and rename update memory. **Save session**, normal shutdown or optional
**Save on changes** persist the bank. Automatic saving is disabled by default;
when enabled, OSCmix groups changes into a delayed save rather than writing the
whole bank on every fader event. Explicit Quit waits for confirmation
that the engine saved the session. A failed or unconfirmed save keeps the
window open; acknowledgements are tied to the backend session and request.

The native **Preferences → Operation → Save changes regularly (<1 min)**
checkbox uses this same engine policy. It is staged until OK, waits for durable
preference confirmation and reflects the selected device's observed policy.
The regular-save engine coalesces changes for three seconds; native confirmed
session metadata is also saved immediately by its existing completion owner,
independently of this option. No additional GUI timer or DSP write is introduced
by the preference or the automatic file save.

The private cache is under
`$XDG_STATE_HOME/oscmix/snapshots/<device-identity-hash>/`. Each save writes a new
set of versioned slot files, then replaces `bank.ini` as the commit point. A
failed save keeps the previous committed bank. Version 3 retains per-field historical source/timestamps and known Playback FX,
width, stereo, mute, M/S and phase. Legacy v1/v2 files remain readable; missing
fields are unknown and never imply a reset. Imported TotalMix values carry no
current hardware-observation claim. Preferences have a separate file.
Loading the bank at startup never recalls a slot. Initial slots remain empty
on the fixed UFX+ and tagged-DSP paths until stored; their complete native
factory seed has not been reproduced.

Coefficient-only profiles with complete producer-issued Full metadata initialize
eight independent factory slots before saved-state adoption. These are the
declared Full intentions, not eight copies of the current mix or a claimed
hardware readback. Construction does not select a slot or write the device.
Optional unknown defaults prevent construction rather than becoming zero.

The internal `bank.ini` contains an eight-bit `snapshots/slots` occupancy mask.
Save Session durably writes newly initialized slots too. A valid mask is
authoritative: an empty slot ignores stale files, while an occupied slot with
a missing or invalid file remains unavailable. A legacy bank without a mask
preserves missing slots as empty. Invalid existing metadata, including a broken
bank symlink, never triggers a factory fallback. Only an absent bank permits
factory initialization; a separate preferences file does not prevent it.
The mask is an internal cache extension, not a change to a native TotalMix file
format or the explicit OSCmix `.oscbank` format. Preserve the bank metadata and
slot files together when backing up or evaluating an older application version.

**Load/Save Snapshot** supports the UFX+ subset of TotalMix's single-snapshot
`.tmss` structure: Preset/device, Inputs, Playbacks, Outputs, OutputRoomEqs,
Mixer and General. Room EQ and Crossfeed are read from native OutputRoomEqs;
older OSCmix files that put them in Outputs remain readable. If the native
section is present it is authoritative, including omitted/unchanged fields;
stale Room values from Outputs are not merged into it. Different UFX+ serials
are accepted; values are validated before any writes. Old OSCmix `.ini` files
can still be imported.

**Preload/Save Snapshot Bank** retains OSCmix's historical UFX+ tagged-text
bank, with current state plus eight slot columns and the legacy `.tmss`
extension. The file chooser explicitly calls it an **OSCmix legacy UFX+ bank**.
It is not a native TotalMix workspace: native Preload all Snapshots consumes
`.tmws`, whose window and per-device nested containers are different. Renaming
the historical file does not make it compatible. Full native workspace
import/export is not implemented. Scalar native-profile banks use the distinct versioned
`.oscbank` format described in `session-operations.md`, not a fabricated
TotalMix file. Exporting a bank requires eight stored slots; an empty slot is
never silently replaced with the current mix.

**Native UFX+ Preload from `.tmws`** reads the snapshot bank of one exactly
matching device block, ignoring the Windows and other-device blocks. It does
not load window layouts or MIDI/OSC settings. The expected tag comes from the
current engine identity; it must match both native device containers exactly.
Some historical Linux UIDs use hash-padding rather than the native serial
format, so a mismatch is refused instead of selecting a device by substring
or extracting digits. This is a conservative matching limit, not a claim that
every Linux UID equals a native TotalMix instance name.

All eight destination snapshots must already exist. The native cold factory
seed is not fully represented yet; partial/sentinel fields must preserve a
real stored destination, never eight invented copies of the live mix. An
empty slot causes a clear refusal before mutation. All eight conversions and
names are validated before replacing anything; a bad last column leaves the
entire bank, names, active/dirty markers and Undo history unchanged.

The current column is ignored. Missing/sentinel slot columns preserve each
destination. A missing Mixer section preserves routes; a present Mixer
resets omitted output-route keys to defaults while omitted communication-bus
keys stay unchanged. As in native Preload, Room EQ/Crossfeed and presentation
fields are not preloaded. Success is one bank Undo/Redo operation, with no
Recall, mix write or audio restart. Native `.tmws` export remains unavailable;
the chooser distinguishes native preload from legacy OSCmix bank export.

The parser has explicit Linux-side file/line/depth/duplicate guards, not new
native format laws. Tests use handwritten structural fixtures and inert engine
sinks; no authentic TotalMix export or hardware interoperability is implied.

Missing named fields retain their existing values. During bank import this
means each destination slot retains its own value, not the current live mix.
Present Mixer fields with the unchanged sentinel or a missing slot column
also retain that slot’s value. A present Mixer section
uses TotalMix's defaults for omitted routes. Unknown Playback mute uses the
unchanged-value sentinel accepted by the decompiled loader, never an invented
unmute. Unknown Playback FX/M/S/phase also use the unchanged-value sentinel.
Unsupported hardware and DURec fields are omitted on export.
Loading an entire bank is one undoable operation, clears the active slot
indicator and does not recall it.

This is an implementation of the statically established file subset, not
qualified interoperability with a running TotalMix application or the original
TotalMix source. The native reference is TotalMix FX2.03 x86_64
SHA25675fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265,
writer1000fe200 and snapshot loader1000f4c10. Native parameter52 (Crossfeed)
and53–84 (Room EQ) belong to OutputRoomEqs. The separate RoomEQPreset selector
and native workspace envelopes are not represented. No artificial Version1200
maximum is inferred from the writer: older native versions have migrations
that this subset does not claim to reproduce completely.
No file exported by an actual TotalMix session was available for that test.
Channel names/layouts, fader groups, DURec, output gain
calibration and Main B Link are outside the implemented exchange coverage.

## Transport and validation

Capture drains previous writes through the existing native helper. Recall
validates the target, applies exclusions and compares exact DSP values and
logical routes. It sends changed routes, including those affected by pairing,
width, Solo or Cue. Level decreases precede increases. This ordering implements
the purpose of ReduceUpwind; it does not reproduce TotalMix's exact cycle timing.
A no-op recall uses two local fences and sends zero USB parameter words.

A bounded transaction is validated before its first write; the helper sends
at most 128 words per USB transfer. Completion is reported only after the USB
transfers succeed; recalls that change Record/Play also await subsequent channel
and recorder-state observations. Background DSP readback verifies the mix without replay.
Audio editing is blocked while the transaction is outstanding; navigation,
scrolling and metering continue. A delayed acknowledgement stays pending,
without permanently latching a GUI failure. Reconnection invalidates the old
session. A real USB failure stops the existing supervised control session;
there is no automatic rollback/replay of a partially applied mix.

Playback sends remain OSCmix logical state. Use device settings adopts fresh
inputs, outputs, DSP and explicitly reported input routes while preserving
unreported input sends and Playback state. Missing gain or pan never creates
silence or center-pan defaults, including after an acknowledged recall;
Store then captures the resulting console. Missing Playback hardware readback
does not block Store, recall or Undo/Redo. Unknown Playback mute remains unknown and is not written during
recall or Undo. USB/clock settings, firmware and hardware setup storage are
excluded. Class Compliant snapshots are not implemented.

With **Always init DSP devices with OSCmix settings** disabled, startup loads
the saved Input and Playback routes into engine memory once the device channel layout is
known. This uses the validated `ufxplus-native-matrix.ini` cache already used by
the GUI; it emits no parameter writes and never recalls a snapshot. Existing
session edits, explicit device observations or routes restored by an explicit host initialization take
precedence. Input/output channel settings and DSP still come from device observations.
Snapshot availability does not require automatic initialization. Missing DSP,
input routing or a missing/invalid Playback cache is reported in the snapshot
status instead of a generic synchronization wait. Unknown values remain unknown.

Tests cover common history/redo branching, Store versus disk persistence,
confirmed GUI save, full bank reload, external DSP dirty indication,
Main B reassignment, DIM handling, Crossfeed exchange,
failed bank saves, recall exclusions, unknown mute, no-op transactions, TotalMix
numeric records and sparse fields, OSC grid mapping, GUI locking, reconnect,
malformed data, bounded USB batches and failed/short transfers. Fixtures use
synthetic state and mocked USB. A bounded physical A/B recall was subsequently
checked as described below; audible timing and broader layouts remain unqualified.

### Alpha.16 physical check — 2026-10-12

An isolated copy of the user's workspace/bank used the real native helper,
engine and GTK application at 48 kHz. Analog 1/2 was muted and freshly read
back before changing Input 1/2 and Playback 1/2 sends to that destination.
Snapshots A and B stored -60 dB and -55 dB, both centered. A/B recall, Undo
and Redo each produced the expected current-state export. A subsequent device
adoption independently read the input route at -55 dB and retained application
Playback at -55 dB. Session saving succeeded in the private bank.

After normal startup restoration, an external guard allowed only the two
destination mute-ON commands and those bounded test-route values/center pan,
plus the established read queries and heartbeat. The qualified run had zero
blocked writes and successful USB completions. All observed test destination
mutes stayed ON; no test sound was generated. Playback export and USB completion
are application/write evidence, not independent Playback hardware readback.

The original user state files and snapshot bank were byte-identical after the
test. Normal startup restored the original mix; fresh DSP verification passed
and all 94 output mute states matched the saved profile, with phantom OFF.
The first harness attempts (unsupported OSC getter assumptions and a stale
temporary GUI) are excluded from this qualification and retained privately.

## Local evidence: TotalMix FX 2.03 x86_64

- UFX+ manual §25.5.2 and §25.7: eight slots, Store, names and common history.
- `100023a00`, `100023900`: slot actions and modified/Store indication.
- `100104020`, `1001043a0`: storage, recall and exact exclusion groups.
- `1000f96d0`, `10010b760`: parameter dirty state and common undo journal.
- `1001017a0`: 28-byte names and undoable renaming.
- `10001b330`, `10001d470`: default preferences and delayed optional saving.
- `10015b960`, `1000ecb60`: deferred volume increases (ReduceUpwind).
- `100069b80`, `1000fe200`, `1000ffce0`: tagged-text writer and nine columns.
- `100102150`, `100102c90`, `100102f80`: per-slot bank import and Mixer defaults.
- `1000f23b0`, `1000f2b30`: factory initialization before copying eight slots;
  the complete device-specific defaults are not yet reproduced.
- `1000f4c10`, `100100510`, `100100f00`: model matching, absent fields,
  unchanged sentinel and omitted Mixer values.
- `10015edb0`, tables `100549d80`–`10054a318`: UFX+ names/register scales.
- `10014b420`, table at `100541250`: OSC `/snapshots/8/1` = slot 1 through
  `/snapshots/1/1` = slot 8; release messages do not recall.

## FX state in local format v5

Version 5 retains the unclipped logical Input/Playback FX sends, their known masks,
and Output No Trim. Versions 1–4 still load; missing logical send values remain
unknown until supported state is available. The 21 global effect values remain
in the existing DSP state. FX recalls, Reset, imports and On/Off edits use the
common journal. A multi-parameter operation follows TotalMix's internal order,
including High Cut before Attack and Room Scale. Effect banks remain separate
from the eight full mixer snapshots, in `fx-presets.ini` beside `bank.ini`.


## Group state in local format v7

Version 7 stores the persistent Fader, Mute and Solo memberships and their active masks. Load Groups with Snapshot defaults off, preserving earlier OSCmix recall behavior. Missing group state in versions 1–6 preserves current groups. Undo/Redo restores the transaction's groups regardless of the current preference. Temporary fader membership is excluded from files and preserved during recall. Malformed lengths, noncanonical base64, invalid masks and Solo membership on physical output faders are rejected before application. Save Session reports group persistence failure and can retry.

TotalMix tagged-text import/export maps Fader bits 1–4, Mute bits 7–10 and Solo bits 12–15 from Group Flags, plus the named General group buttons. A present inherited bank sentinel retains group flags; absent Mixer fields follow the existing native descriptor defaults. When exporting old slots without group metadata, the native format materializes current groups, matching their recall inheritance; it cannot represent a separately unknown membership inside Group Flags. Group-only state is software metadata and does not add registers to the generic USB whitelist. Record/Play assignments use the separate v8 contract below.


## Record/Play assignments in local format v8 (+menus.5)

Load Record/Play with Snapshot defaults off. Store always retains the known RecordEnable and PlayChannel assignments for physical Input/Output channels. Software Playback channels have no such fields. Version 8 adds explicit known masks; versions 1–7 remain readable and preserve current assignments. Unknown values never become zero writes. Tagged-text TotalMix exchange uses the existing RecordEnable/PlayChannel descriptors and the native unchanged sentinel for unknown fields. The new fields remain outside dsp_scope and the generic DSP write whitelist.

Preferences and the snapshot panel share one control. Its state follows engine feedback; an old backend without the capability leaves it disabled. Persistence failure retains the previous preference. Workspaces carry the preference, use it for their prepared recall and publish it only on success. Old Workspaces without the key preserve the current policy. Undo/Redo restores the transaction's assignments independently of the current preference.

The entire mix and assignment batch is prepared before USB. A typed local envelope is validated separately: only observed channel fields, RecordEnable 0/1 and PlayChannel 0–80. Fresh recorder status and writable configuration are required for changes; recording, unknown/stale status, pending recorder commands and locked configuration refuse the recall. A helper refusal before USB restores local staging through the same mixer algorithm with both writers suppressed. It adds no history entry and does not select the requested slot.

A correlated USB completion timestamp starts the observation phase. Subsequent matching channel values and writable recorder state are required before successful completion and history commit. Cached data, a legacy one-word ACK, old stamps or a matching value from before completion cannot confirm a recall. Post-write verification observations retain their query provenance; recorder status retains its actual receipt time. No recording is started by snapshot recall.

Readback has a bounded 35-second wait after USB completion. A timeout after known USB completion reports a partial change, clears the requested slot selection and retains a common history entry. Unconfirmed assignments become unknown; Undo waits for fresh channel observations before writing them. A missing transport ACK leaves physical completion unknown: mutating commands are blocked until a complete validated Use device settings acquisition or reconnection. An incomplete device acquisition does not clear that fault; the existing Solo/PFL/Cue acquisition preconditions still apply. No uncertain write is automatically retried or replayed.

The software tests cover old/corrupt files, native exchange, whole-batch refusal at the actual USB boundary, timestamp correlation, topology/group rollback, defaults, persistence, partial completion, recovery and Undo/Redo. Hardware validation and the exact installed package are recorded separately in the increment report. F18, Class Compliant snapshots, is explicitly outside this work.
