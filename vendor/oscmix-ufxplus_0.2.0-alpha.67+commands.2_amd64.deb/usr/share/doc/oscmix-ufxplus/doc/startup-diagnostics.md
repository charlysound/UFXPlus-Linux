# Premier démarrage après installation — alpha.25

Le diagnostic est actif sans option à chaque démarrage normal, y compris le
premier après installation. Le journal du lanceur se trouve sous
`$XDG_RUNTIME_DIR/oscmix-ufxplus-native-usb3-<uid>-<port>.log`.
Il contient la version et les SHA-256 des trois exécutables, le PID du moteur,
sa disponibilité, la frontière exacte d’un échec, les erreurs USB/du tube,
les compteurs de la file de contrôle et le statut de sortie du moteur enfant.
Aucun reset ni nouvel essai automatique n’est ajouté.

## Reproduction et cause

Les anciennes traces du premier démarrage v24 montraient un arrêt après 723
états sans écriture de paramètres. Elles ne contenaient pas son point de sortie.
Le scénario contrôlé reprend le vrai pont et le vrai moteur, avec une copie
privée des états et la restauration DSP désactivée. Un wrapper retarde le moteur
d’une seconde, sans modifier USB ni les exécutables testés.

Avec le comportement précédent, le pont démarrait sa production alors que le
moteur ne lisait pas encore. Le tube se remplissait et le délai de 100 ms d’un
paquet de contrôle expirait. La seule attente du moteur prêt n’a pas suffi :
une autre reproduction échouait après 727 états. Le service des vumètres pouvait
reprendre l’espace disponible avant le paquet de contrôle, et un moteur en
initialisation pouvait rester occupé plus de 100 ms. Un test sur un vrai tube
reproduit l’espace repris par les mètres ; il échoue avec l’ancien code.

Ces causes sont démontrées par les reproductions contrôlées. Le point de sortie
du premier incident historique n’ayant pas été enregistré, l’identité exacte
de tous les incidents antérieurs n’est pas affirmée.

## Correction

- Le moteur signale sa disponibilité après chargement initial et ouverture OSC.
  Le pont vérifie le PID et attend ce signal avant acquisition/production. Il
  maintient le heartbeat ; l’absence du moteur expire après 10 s.
- Les observations et acquittements partagent une file FIFO bornée de 512 trames
  atomiques, au plus 1 287 octets par trame. Une indisponibilité temporaire du
  tube conserve la trame ; aucune écriture USB n’est répétée.
- Les données de contrôle passent avant la livraison de nouvelles trames de
  vumètres. Le worker EP84 reste indépendant, à échéances 20 ms. Les paramètres
  sont temporairement moins lus au seuil de 128 trames de contrôle en attente.
- La saturation de la file, une trame trop ancienne (10 s), une fermeture ou
  une écriture partielle du tube produisent un échec explicite. Aucun défaut
  de données n’est remplacé par un succès supposé.

La correction concerne le transport Linux entre processus. Elle ne modifie ni
la conversion Peak/RMS, ni les paires, ni le format des profils ou leur autorité.
Un ACK garde son sens : écriture USB terminée, pas retour matériel indépendant.

## Vérification

Le test de réservation reproduit le défaut avec l’ancien service (`poll=0`,
huit remplissages concurrents) et réussit avec la correction (`poll=1`, aucun
remplissage concurrent). Le test FIFO vérifie un lecteur bloqué 250 ms, l’ordre
exact des observations/ACK, le bouclage, la saturation et l’expiration bornées.
Le plus grand retour cohérent d’acquisition tient derrière le seuil haut
(490 trames sur 512), sans lecteur disponible pendant sa sérialisation.
Les gardes de disponibilité refusent mauvais PID, répétition et commandes
prématurées. Le test du lanceur vérifie le diagnostic dès son premier lancement.

Le scénario matériel retardé avec la correction complète a reçu 10 084 états,
avec acquisition à 50 Hz, aucune écriture de paramètres et arrêt propre. La file
s’est vidée sans perte de contrôle, avec un âge maximal observé d’environ 135 ms.
La version candidate a ensuite démarré avec le profil habituel et obtenu le
readback DSP vérifié. Les résultats finaux, le commit, les empreintes et la
vérification de l’installation sont conservés dans le rapport de livraison.
