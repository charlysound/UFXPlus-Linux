# Vumètres TotalMix : rendu et acquisition vérifiés

Revue du 17 octobre 2026. Référence exclusive : TotalMix FX 2.03 Intel x86_64,
SHA-256 `75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265`.
Les preuves REA sont conservées dans `cartography/evidence/rea-meter-*.json`
du workspace DRIVER+ OSCmix. Ce document décrit les sources corrigées et les
tests isolés ; il ne certifie ni un processus déjà ouvert ni un essai matériel.

## Dessin et coordonnées

`10007c580`, la table `1001c2d50`, `100144de0` et `100142920` établissent :

| Tranche | Barre gauche | Barre droite |
|---|---|---|
| normale stéréo | x 11–17 | x 19–25 |
| normale mono | x 13–23 | — |
| étroite stéréo | x 9–15 | x 17–23 |
| étroite mono | x 11–21 | — |

Ce sont les unités natives d'une tranche haute de 352, pas des pixels de la
fenêtre à tout zoom. Les barres étaient auparavant placées sur la région du
fader. Le type 18 représente le RMS, le type 19 le Peak Hold et le voyant OVR
(`100083750`). Les trois bandes continues sont 178–305, 164–178 et 132–164 ;
le voyant séparé occupe 121–131. Une crête trop haute est signalée par le voyant,
sans inventer une quatrième bande continue.

Les palettes RGBA, y compris leurs alpha, sont extraites de `10013ad50`.
Le contour de 0,6 pixel et les huit sommets de `10013d150` sont adaptés en
patches Cairo. Les sorties non sélectionnées utilisent leur seconde palette.
La hauteur de la crête suit également la correction native aux petits zooms.
La courbe dB→position est recalculée au zoom courant : arrondi de `161*zoom`,
puis arrondi de son segment supérieur (`10008cd50`, `100092d40`).

Les graduations sont les chemins vectoriels originaux : `10026b880`,
`10026deb0`, `100268fb0`, avec les tables de décalage `1001445b0` et les
translations vérifiées dans l'assembleur de `1001446d0`. Elles ne sont plus
redessinées avec des chiffres et traits approximatifs. Le rendu Cairo recalcule
chaque décalage de glyphes au zoom courant. Les atlas de fond n'intègrent pas
ces chemins pour éviter un double dessin ou une graduation figée au zoom 1.
Le résultat statique est mis en cache au zoom et à la densité courants dans
le cache borné du renderer ; les barres restent actualisées séparément.

FX : descripteurs `100238e50`, x=107,5/116,5/139,5/148,5 et translation y=21.
Le même dessin de barres est employé. Les préférences Hold/RMS+3 sont partagées
avec les tranches. Les enveloppes FX n'absorbent chaque mesure horodatée qu'une
fois, indépendamment du nombre de rendus GTK.

## Mesures, chiffres et préférences

L'acquisition UFX+ USB est reliée statiquement au slot +0x58 de la vtable
`1001d7370`, soit `100139c60`, par `1000f8440` et `100139120`.
La branche PCIe est distincte (`10010f270`, `1001d64a0`, `10010f890`).
Ces relations ne prouvent pas l'exécution d'un chemin particulier.

La conversion RMS native utilise `0x1.00000400000c0p-55`, soit
`1/(512*(2^23-1)^2)`, avant la préférence RMS+3. OSCmix utilisait `2^-54`,
introduisant environ +3,010299 dB. La correction est limitée au transport
natif UFX+. Le compteur de surcharge post-DSP conserve tout son nibble ;
il n'est plus masqué par un AND avec le compteur pré-DSP.

`10001b330` donne HoldTime=20 dixièmes et Plus3db=1 par défaut.
`10010e660` borne HoldTime à 1–100 dixièmes. `1000ec5a0` ajoute exactement
3,01 dB après l'intégration de puissance. Le menu « Level meters… » expose
ces réglages et le choix des chiffres Peak/RMS ; ils sont persistés dans
`oscmix/meters.ini`. Le bouton RMS de la sidebar utilise le même état.

Les chiffres Peak **et RMS**, disponibilité RMS et OVR sont échantillonnés
à 5 Hz. OVR remplace les chiffres Peak seulement ; UFL s'applique sous −144 dB
et le format passe à zéro décimale à −99,8 dB inclus (`100083750`).
Les barres gardent leur cadence propre. Les paquets antérieurs à la dernière
mesure sont rejetés avant de modifier le niveau courant.

## Vérification et limites

Les tests couvrent les conversions de paquets USB simulés, les compteurs pairs,
le silence, la conservation du transport historique, les enveloppes, les
préférences persistantes, la cadence numérique et des positions/colorations
de pixels indépendantes des fonctions d'implémentation.
Les planches de rendu synthétiques couvrent mono/stéréo et normal/étroit.
Les chemins de graduation au zoom 1 donnent la même image que leur
rasterisation de référence ; six zooms ont été exercés.

Le comparatif pixel à pixel avec TotalMix exécuté sur un hôte macOS compatible
reste à réaliser. Cairo et le moteur GPU natif peuvent différer aux bords et
dans la composition des patches ; les coins du fond sont rendus par Cairo.
Les enveloppes restent l'adaptation continue au temps écoulé, pas une preuve
de timing matériel. Le contexte d'activation du timer alternatif de 40,33 ms
reste inconnu : le timer de référence 20 ms n'a pas été remplacé.

La variante `Preferences/OperationMode != 0` déplace les barres d'entrée et
Playback (x 27/35 en stéréo, 29 en mono) ; OSCmix reste ici dans sa disposition
ordinaire. La sélection pré/post-FX et toutes les variantes gestuelles de
remise à zéro ne sont pas qualifiées par cette passe. Aucun essai audio ou
redémarrage du transport USB n'a été effectué.

## Reproduction

Les scripts `tools/extract-totalmix-meters.py` et
`tools/extract-totalmix-graphics.py` vérifient l'empreinte de la référence.
Les en-têtes générés restent reproductibles depuis le binaire identifié.

Depuis la racine des sources :

```sh
make -C gtk4 all totalmix-render-bench
xvfb-run -a env GDK_BACKEND=x11 GSK_RENDERER=cairo make -C gtk4 check
make tools/fx-reference-test
./tools/fx-reference-test
```

Les tests n'ouvrent pas le matériel. Le benchmark logiciel ne mesure ni la
latence audio ni une cadence physique de l'application installée.

## Résultat du contrôle final

Compilation GTK et bridge réussie. `make -C gtk4 check` complet et
`make check-native` réussis ; tests de transport exclusivement simulés.
Le contrôle documentaire passe : 2 819 empreintes et 294 références.

Benchmark logiciel, trois rangées en 1280×840 avec vumètres actifs :
9,64 ms de moyenne (maximum 10,30 ms), ou 12,04 ms avec panneaux ouverts
(maximum 12,86 ms). Ce résultat est propre à ce poste et au renderer Cairo
sous Xvfb ; il ne mesure pas la cadence USB ni une latence audio.

Les journaux, la planche de rendu et l’audit d’acquisition sont conservés sous
`/home/adrien/Documents/ChatGPT/DRIVER+ OSCmix/outputs/meters-exact/`.
Le binaire GTK compilé est `gtk4/oscmix-gtk4` dans la copie de travail.
Le processus système déjà lancé n’a pas été remplacé ou redémarré.


## OVR sample threshold — v25 +menus.3

The existing native channel OSC packet already carries the post-DSP four-bit full-scale sample count (0..15), independent of the pre-DSP count. The shared meter model now compares it with the selected 1..10 threshold. Legacy boolean overload flags remain boolean. The default stays 1 for backward compatibility with OSCmix; TotalMix finishLaunching uses 3. REA 10010e660 clamps the preference, 1000ec5a0 compares the count, and 100139c60 establishes the UFX+ acquisition/conversion. Raw evidence is retained in cartography/evidence/rea-ovr-threshold-20261018.json.

FX adds an atomic `/fx/meter/{input,output}/{0,1}/frame/level` message with `ffii` Peak dB, RMS dB, sample count and modulo-31-bit millisecond stamp. The prior Peak/RMS/time paths remain. The model stores a complete observation with a local receive date; duplicate/backward stamps, old receive dates and malformed fields cannot refresh it. Clock wrap and session invalidation are covered. The FX display prefers this observation in both skins; no threshold above 1 is inferred from an older stream lacking sample counts.

The OVR hold continues to use the existing time-based envelope. Repainting a frame cannot extend its hold. Saving preferences is durable and atomic; save errors preserve the model and do not close the dialog. No USB request, gain, routing or recorder change is introduced by these preferences.
