# RME device selection

Open the device name at the top of the TotalMix sidebar. In Skin 1 use the
header's device button. Window → Device Selection is also available in the
bound mixer/matrix view. Each entry includes its USB serial number. Choose a
device explicitly; disappearance never selects another device automatically.

The existing UFX+ control session remains alive when another card is selected.
Returning to that same UFX+ connection restores its mixer/matrix presentation,
model, settings and history. A different card gets a separate device page;
UFX+ faders, snapshots and settings are not reused for it. The original Babyface
has its own input, playback and output faders, pans and live peak/RMS meters,
using the existing mixer calculations and the driver's native command owner.
Other models require their corresponding native runtime capabilities; catalogue
recognition alone does not enable their mixer.
Selection is not aggregation, clock synchronization or a new audio stream.

The selected serial UID is retained across removal and reconnection. Its old
control owner is retired before a new incarnation can open. Duplicate identities,
a missing device or discovery errors
suspend control. Switching is refused while a mixer transaction
is active, or if saving the current session fails. Audio and recording are not
stopped by selecting another device. Existing UFX+ state files
remain in place; an unavailable card creates no editable mixer state to confuse
with that UFX+ session.

## Reference and Linux adaptation

Driver first: RMEFirefaceUSB 3.39 x86_64, SHA-256
`19c8b7d292a8d1588e4a777d351d0489523bf2da3fab655269ea63fe6e07c2cb`.
The identity catalogue is generated from `ufxplusctl rme-catalog` of producer
`3a627cef2b29850b487cc9ebb62ca198905917b8`; 33 personalities, 47 VID/PID
identities including aliases. Only the emitted identity/model metadata is used
by the selection adapter. Regenerate with `python3 gtk4/export_device_catalogue.py /path/to/ufxplusctl --commit COMMIT > gtk4/rme-usb-catalogue.json`.
No per-model transport or USB-write permission is
inferred from catalogue recognition. The Python adapter reads kernel-cached
sysfs metadata, with the same stable UID contract as `rme_device`. The packaged snapshot is
SHA-256 `f5241e00c65e3852ce3ceb2bf2288e23675019f37fe3e3ca179f8b3689464ad8`.

TotalMix FX 2.03 x86_64 SHA-256
`75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265`:

- Sidebar descriptor 5: type 5, x=5/y=6/w=112/h=20, flags `0x08100001`.
  Descriptor 6 is its device-name label.
- `0x100089400`, case 5 dispatches the selected device name to `0x1001369d0`;
  Evidence ID `ev_7bf00c9356a09ae90a8a8a0855958c05cce70b39acfdb5e7b63c596377473680`.
- `0x1001369d0` calls `ChangeToDevice:SubType:fNewWindow:` with new-window false;
  `ev_829b1de6537e685694f2bd45c03a1f19c449a3a67eeea80e0db95d2e7303f756`.
- `0x10012f420` changes the cached function, preserves/restores its size and
  invalidates the view on success;
  `ev_67dfa150d7f534b7ad9eaaefe0bc03f618a9163c3ccfc676a7365c15db31f31d`.
- `0x1000ad1f0` saves per-device caches and `DeviceSelected` separately;
  `ev_4d8259e7120a0d253cb42d53c0778394267bd2638e205353b483f4d41206e656`.

These are static REA findings, not original source or native runtime execution.
GTK popover rendering, the Window menu access, USB UID/incarnation tokens and
the unavailable-control page are explicit Linux adaptations. Full native GUI
parity for every card, per-card native geometry and controls are not claimed.

## Selection and command boundaries

A selection key contains UID plus the current cached connection fingerprint:
USB path/bus/address/revision, sysfs object birth identity and descriptor hash. A menu target from an older
connection is rejected. The legacy UFX+ owner is enabled only for the one
unambiguous original bound identity/fingerprint. Other devices are displayed
without assigning that owner's OSC endpoint to them.

Every outbound OSC datagram shares the selection mutex, including ordinary
parameters, DSP initialization, host/batch plans, snapshots, device-read and
text commands. Deselecting the owner closes that gate, discards queued host
plans and suspends/clears ARC input events. Late replies continue into the
original UFX+ model only; they cannot populate the selected Babyface page.
Held MIDI/ARC gestures are ended on their original owner before deselection;
partial controller input is discarded. MIDI/OSC input and feedback pause while
the owner is deselected, without changing its saved controller configuration.
Detached settings windows are hidden/disabled and restored to that same owner.
The existing ARC preference is retained for returning to the bound session.
The native owner rechecks the bound UID/incarnation before opening and after
claiming its control interface, before any command. Launcher reconnect also
refuses a changed binding.
The backend can continue its own UFX+ observations/keepalive; no new USB owner,
mode switch, reset, detach, audio restart or parameter command is introduced by
the selection adapter.

Tests cover identity ambiguity, stale connection/menu targets, removal without
fallback, every send surface, and real GTK selection/return in both skins.
Physical selection tests and installation have their own delivery report;
unit tests and metadata recognition are not hardware mixer qualification.


### Device-owned files

The launcher fixes one editable owner UID per process. GUI preferences, history,
engine snapshots and native DSP files use the same UID-scoped config/state roots
under `oscmix/devices/SHA256(uid)/`. Desktop XDG paths remain unchanged for other
applications. Selecting a metadata-only device cannot edit that owner's files.
A subsequent launch with a different UFX+ serial starts a separate empty profile.
The old global files are copied once only when their saved DSP device identity
matches the bound UFX+ serial; those original files are retained. A mismatched or
unidentified profile fails closed. Class Compliant launches retain their current
transport and storage policy. These paths are a Linux adaptation of per-device
state ownership, not evidence of native AppKit source identity.

The GUI test activates the actual popover model button, including action lookup
after the popup closes; directly calling the action alone is insufficient.

GTK closes a model-button popup before dispatching its tracked action. Keep
the popup attached until replacement/window unrealize/disposal, so the selected
command retains its action context. This was reproduced via the real menu item
and checked against [GTK 4.14 source](https://raw.githubusercontent.com/GNOME/gtk/4.14.5/gtk/gtkmodelbutton.c).

Native scalar session (introduced in devices.3): selecting the original Babyface
starts a private, per-incarnation controller and the existing OSCmix engine.
The engine uses the shared volume/pan/stereo calculations; its typed coefficients
are passed to the driver's guarded mixer API. Virtual MIDI registers are local
host feedback only. UFX+ late replies retain their original model. Returning to
UFX+ resumes its existing transport and view. Per-UID route caches are host intent,
not device readback; startup never restores them to hardware automatically.
The native producer must be bundled by the packager with an explicit SHA-256.
Other dialects remain unavailable until their native coordinates are attributed.

The producer is the authority for dialect admission. The GUI does not duplicate
its list of supported product IDs. Native models also own their presentation,
meter and interaction files; no selected-card edit writes the UFX+ namespace.
The engine's explicit ready record gates the first user command.
# Automatic native connection — devices.4

The same serial UID retains its selected view across removal and a new USB
incarnation. A unique initial device is selected automatically; another UID is
never substituted after removal. The old scalar owner is stopped and reaped
before the replacement starts. A failed unchanged attachment is not retried
until an explicit selection or a new incarnation.

The optional verified native runtime bundle runs audio/MIDI in the independent
`rme-native-devices.service` user service, also started at desktop login. It
preserves existing external owners. OSCmix keeps the levels/control owner and
waits for audio readiness of the exact sysfs incarnation before opening it.
Closing the GUI does not stop that independent audio/MIDI service. No scene or
cached mixer values are replayed as part of connection recovery.

The versioned bundle records both supervisor source and reused binary provenance.
Other command dialects, initial hardware state and full GUI parity remain in
RME-06AB/RME-07D; this connection change does not claim their completion.


# Babyface mixer state and meters — devices.6

The producer supplies the established TotalMix Full-mode initial host template.
GTK builds it before loading the saved UID profile; only established saved
values override the template. The merged host state is saved before the existing
engine starts, so both use the same gain and pan from the first gesture. This
does not read the hardware matrix or reset the attached interface. Template,
saved host intent, accepted USB commands and hardware observations remain distinct.
Legacy profiles without initial metadata retain their unknown-state handling.

This follows TotalMix 2.03 `0x1000f23b0` → `0x1000f2b30` → `last.<Device>.xml`
→ native open. REA evidence: `ev_276610a8b7d5fa6edc197d66dbc10c84ad1179c6e051c4fa59208bf157045cba`,
`ev_3001f6b565688241c7b57307ea91b697606d3945ac097642985e6bb72b6c4275`.
The existing UFX+ reset calculations already represent native -300 dB silence
as -65 dB on the wire. Output defaults are separate from route defaults and
come from the producer's attributed native model roles.

The meter producer decodes the existing Babyface native frames into 10 input,
12 playback and 12 output peak/RMS/overload values at single speed. Only active
ports of the selected owner reach the existing OSC meter endpoints. Missing,
stale, partial, foreign or non-finite frames cannot replace a valid observation.

# Shared native channel labels and Linux host services — devices.7

The driver's active port contract now supplies the display name separately from
the USB stream group name. OSCmix uses that display name before applying the
user's saved aliases. For the original Babyface, the TotalMix 2.03 wide labels
are AN 1/2, PH 3/4 for output/playback, AS 1/2 and the remaining ADAT channels.
The producer records the native reference digest with attributed names. Other
models retain the existing fallback until their native naming table is assigned;
the GUI does not add a second model or product-ID table.

The bundled runtime registers a true ALSA card and PipeWire Device for each
admitted native attachment, using that same active-channel contract. Its ready
state waits for the kernel card and actual bound PipeWire objects. Native node
selection is per UID in the existing driver settings panel. Applying a native
selection disconnects or reconnects only its PipeWire nodes; the native USB owner
and ALSA card remain active. The separate rme-native-host package supplies the
common kernel module and panel without replacing the running UFX+ service.

These are Linux host adaptations, separate from the RME reference behavior.
They reuse native capabilities without claiming that the original reference
driver implements ALSA or PipeWire, or that every untested model is qualified.
