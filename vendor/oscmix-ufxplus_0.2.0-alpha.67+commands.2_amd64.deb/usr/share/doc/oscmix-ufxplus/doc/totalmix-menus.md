# Menus TotalMix dans OSCmix

Implémentation du 17 octobre 2026 dans les sources GTK4 et le moteur UFX+.
La référence statique est TotalMix FX 2.03 Intel x86_64, SHA-256
`75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265`.
Il s’agit d’une adaptation Linux. Les tests utilisent des transports simulés,
un récepteur UDP local isolé et Xvfb ; aucune nouvelle qualification matérielle
ou exécution de TotalMix n’est revendiquée.

## Fonctions livrées

| Partie | Comportement |
|---|---|
| Actions communes | `menu_actions.[ch]` définit actions typées, coches et raccourcis. `menu_integration.inc` raccorde les contrôleurs existants. Les actions de fichiers sont bloquées hors synchronisation, pendant une transaction ou une édition du mix. |
| Barre | File, Function, Options, Window, Help ; snapshots, banque, Undo/Redo, préférences, Channel Layout, aide et informations de l’appareil. F1–F8 rappellent les snapshots par une seule voie. |
| Présentation | Options partagées avec la sidebar, rangées, Trim, noms originaux, panneau FX, deux skins, échelle de sidebar et masquage Control Room. Fenêtres supplémentaires partageant le modèle ; les mètres restent actifs tant qu’une vue est visible. |
| Reset Mix | Douze variantes avec confirmation de portée ; onze plans moteur et un effacement local des noms. Les variantes sans Room EQ préservent ses paramètres. Le résultat attend la barrière finale du transport. |
| Workspaces | Format OSCmix versionné `.oscworkspace`, huit sélections rapides, dix récents et effacement des récents. Sauvegarde et chargement du mix courant, slots éventuellement vides, groupes, préférences snapshot, noms et présentation. |
| Matrix et réglages | Routage Input/Playback vers Output, gain/pan, sélection, navigation clavier et repli des paires stéréo. Réglages Control Room effectivement rapportés, raccourcis persistants avec contrôle des conflits, informations de connexion et du périphérique. |

Les menus contextuels existants Copy/Paste Mix, Paste FX, Mirror et les banques
Reverb/Echo restent raccordés à leurs contrôleurs. Cette livraison n’ajoute pas
de banques natives EQ/Dynamics non qualifiées.

File / Function / Options / Window / Help reste accessible dans les deux skins.
Window → Toggle Old-New Design alterne les deux apparences OSCmix existantes ;
Appearance permet toujours leur sélection explicite. La bascule conserve le
modèle de mixage, la sélection et l’échelle, s’applique aux fenêtres de mixage
ouvertes et reste disponible avec Lock User Interface. Elle ne constitue pas
une reproduction des deux designs natifs. Le choix est mémorisé au démarrage
ou restauré par un Workspace. Skin 1 conserve aussi sa barre supérieure OSCmix.
En TotalMix, Options conserve l’accès aux réglages des vumètres,
à la synchronisation, au Monitoring et à Solo Master. Les préférences et le
Monitoring s’ouvrent dans une fenêtre lorsque leur bouton OSCmix est masqué ;
ils retrouvent leur popover avec Skin 1. Les corrections des vumètres sont conservées.

## Fichiers et transactions

Les snapshots et banques `.tmss` passent par le moteur existant. Le chargement
simple accepte aussi un ancien `.ini`. **Preload refuse `.ini` avant toute
écriture**, car ce format contient un mix unique à rappeler et non une banque.
L’export de banque `.tmss` conserve la restriction aux huit slots remplis.

Le Workspace n’est pas un fichier natif `.tmws`. Il inclut un état moteur
versionné, les huit slots et leurs noms, groupes de faders et Mute/Solo,
préférences snapshot, ainsi que `appearance.ini`, `totalmix-view.ini` et
`totalmix-sidebar.ini`. La disposition courante comprend largeur des tranches,
panneaux ouverts, défilement, vue Mixer/Matrix et visibilité FX/Control Room.
Les préférences globales des vumètres et les raccourcis ne sont pas remplacés.
Les fenêtres supplémentaires et leurs géométries ne sont pas sérialisées.

Le chargement valide identité, version, checksum, snapshots et groupes avant
application. Il demande confirmation et annonce l’effacement de l’historique
Undo. Un échec du transport ne devient pas un succès après expiration d’un
délai : l’opération reste en attente. Un changement de session invalide son
callback. Les confirmations `/snapshot/saved` sont signées et liées à la requête ;
un simple `/snapshot/request` ne vaut pas confirmation.

Les écritures de fichiers sont remplacées atomiquement. Le chemin accepté par
le sélecteur est conservé exactement, sans suffixe ajouté après sa confirmation.
La restauration du moteur et des fichiers de présentation n’est pas une
transaction atomique commune : une erreur disque après application moteur est
signalée comme restauration partielle. Les métadonnées moteur non persistées
peuvent être réessayées par Save Session.

## Portée des resets

Les tags 1–3 remplacent le routage ; 4 réinitialise les volumes de sortie ;
5 et 11 les effets avec/sans Room EQ ; 6 les noms locaux ; 7–9 les paires
mono/stéréo éligibles ; 10 et 12 effectuent Total Reset avec/sans Room EQ.
Total Reset inclut les gains d’entrée et l’alimentation fantôme : la confirmation
le précise. Les affectations Control Room participent aux règles de conversion.

Undo couvre l’état audio géré par le moteur. L’effacement des noms locaux n’est
pas restauré par cet historique. Les GroupFlags natifs et la préférence native
« disable pan » ne sont pas représentés par les conversions. Une suite de
registres envoyée au périphérique n’est pas une transaction matérielle atomique.

## Différences et fonctions indisponibles

- Always on Top est activé seulement si le gestionnaire X11 annonce
  `_NET_WM_STATE_ABOVE`. Prevent Sleep reflète le résultat de l’inhibition GTK.
- Set Scale devient explicitement **Sidebar Scale**. Appearance sélectionne les
  skins OSCmix ; ce n’est pas une reproduction des deux designs natifs.
- Fermer la fenêtre principale conserve le comportement OSCmix de minimisation ;
  une vue supplémentaire se masque et peut être réutilisée. Quit passe par la
  sauvegarde acquittée existante. Function → Toggle Mixer Window et Toggle Matrix Window ouvrent ou masquent
  des fenêtres indépendantes, avec coches et réutilisation après fermeture.
  Ces fenêtres partagent le modèle et le transport du mix courant. Mixer View / Matrix View
  conservent la sélection de vue de la fenêtre principale. La Matrix continue
  de recevoir les mises à jour quand la fenêtre principale est masquée ; les
  mètres restent actifs tant qu’une fenêtre de mix est visible. La géométrie
  et l’ouverture de ces fenêtres ne sont pas sauvegardées dans le Workspace.
- Mixer Settings expose les paramètres Control Room observés. Preferences
  conserve les exclusions snapshot/autosave. OSC Connection décrit les endpoints
  OSCmix courants ; ce panneau n’implémente pas TotalMix Network Remote.
- Le serveur OSC et ses quatre liens de submix sont décrits dans
  [osc-remote.md](osc-remote.md). La page 1 est adaptée aux commandes prises en
  charge ; labels, Peak et les pages détaillées gain/EQ/dynamique, FX et Room EQ
  conditionnel sont raccordés, avec maîtres globaux, verrou de submix et exclusions
  des quatre contrôleurs. La v24 ajoute le transport DuRec qualifié et ses retours
  dans la barre TotalMix et la page 3 OSC. Les fichiers, modes et capacités encore
  non qualifiés restent indisponibles. Tests isolés repris avant installation ;
  leur réussite ne constitue pas une qualification d’enregistrement matériel.
- Les commandes MIDI CC / Mackie et ARC USB via UFX+ ou côté PC sont décrites dans
  [midi-arc.md](midi-arc.md), avec les fonctions développées et les limites de
  qualification sur contrôleur réel. MIDI / ARC Settings est accessible depuis
  External Control ou le menu principal du skin OSCmix.
- Operational Mode, Offline Device Setup, stockage Setup 1–6, Stand Alone MIDI et CC au
  débranchement restent indisponibles. Les entrées exposées sont désactivées ;
  le panneau Supported Features explique cette limite. La présence de six
  entrées dans le NIB ne prouve pas six slots matériels UFX+.
- Services et Hide Others de macOS ne sont pas transposés à GTK/Linux.

## Vérification

La suite moteur `make check-native` et la suite GTK `make -C gtk4 check` passent
avec état utilisateur isolé et Xvfb. Des tests ciblés supplémentaires couvrent :

- chaque plan de reset, Undo, variantes Room EQ, refus, erreur et acquittement
  tardif ; refus non audible de Preload `.ini` ;
- aller-retour Workspace avec slots vides, groupes, préférences et Room EQ,
  données invalides, échec de persistance et reprise ;
- sélection exacte du chemin de sauvegarde, récents et sélections rapides ;
- commandes typées, indisponibilité, coches et unicité des raccourcis ;
- barrière finale, ancien acquittement, délai dépassé et changement de session ;
- Matrix, réglages observés, conflits de raccourcis, deux skins, fenêtres
  supplémentaires et restitution de la disposition courante ;
- rendu de la fenêtre, du menu File, de Matrix et des réglages.

Les nouvelles cibles sont `check-menu-reset`, `check-menu-reset-engine`,
`check-workspaces` au niveau moteur et `check-menus` dans `gtk4`.
La compilation utilise GTK4 et, pour la fonction X11, les bibliothèques X11.
Les avertissements de dépréciation des boîtes de dialogue GTK existantes
restent présents ; ils ne sont pas des échecs de test.


## Complément global des menus — alpha.25 +menus.1

Preferences ouvre une fenêtre à catégories. Snapshots & Workspaces réutilise les widgets et transactions du contrôleur existant ; les options suivent le retour moteur. Level Meters emploie le même formulaire que le dialogue autonome (maintien Peak/OVR, RMS +3 dB, chiffres Peak/RMS) ; les modifications restent en brouillon jusqu’à Apply. Mixer View expose les options existantes et l’échelle globale. Control mène aux vrais contrôleurs MIDI/ARC, OSC et synchronisation.

Window → Set Scale applique 75, 100, 135, 180 ou 200 % à toute la zone Mixer/Matrix et aux fenêtres supplémentaires. La transformation GTK couvre le rendu et le pointage ; le menu système et les dialogues gardent leur taille GTK. Le réglage persiste dans appearance.ini et suit le Workspace. Un défilement vertical garde les rangées inférieures accessibles quand le contenu agrandi dépasse l’écran ; à 100 %, la disposition élastique existante est conservée. L’ancien zoom propre à la barre latérale est conservé séparément.

Mixer Settings ajoute External Input (source et gain), Link Main A/B, PFL et Solo Exclusive. Chaque Apply exige une valeur rapportée et un mixeur disponible. Un envoi ne crée pas d’acquittement local. L’entrée externe est une paire stéréo résolue par le moteur. Les accès MIDI/ARC et OSC utilisent leurs contrôleurs existants. Global Mute dans la barre latérale suit /controlroom/muteenable et respecte les opérations en cours ; il ne remplace pas Main Mute.

Network Remote Settings est visible mais désactivé. Son protocole natif ne se confond pas avec la connexion OSC interne ni les quatre contrôleurs OSC.

### Écarts encore ouverts

Le mode DAW, Offline Device Setup, Network Remote natif, Store current State into Device, MIDI autonome et CC à la déconnexion n’ont pas encore de parcours complet qualifié. Le nombre de six entrées Setup du menu générique ne prouve pas six emplacements UFX+. Le changement de mode DAW natif avertit d’une remise à zéro du routage et d’un redémarrage : une simple bascule d’affichage ne reproduit pas ce mode.

Preferences reste partiel face à TotalMix : recentrage pan lors du changement Mono/Stereo, verrouillage global, choix des mètres de dynamique, réduction des pointes de rappel, options AUX/MADI et corrections de luminosité. Les anciens/nouveaux graphismes TotalMix ne sont pas identiques aux deux présentations OSCmix. Ces écarts restent dans le registre ; cette livraison ne revendique pas une parité globale.


## Complément Preferences et groupes — alpha.25 +menus.2

Mixer View raccorde FX Send follows highest/Main au contrôleur `/fx/follow` existant. Les deux choix sont exclusifs ; tous deux décochés sélectionnent les envois indépendants. L’affichage conserve l’état observé après la demande, jusqu’au retour moteur. Une valeur absente ou un mix verrouillé ne permet pas de commande.

Operation ajoute Disable mouse wheel operation et Disable double click fader actions, appliqués par Apply et persistés atomiquement dans `interaction.ini`. La molette des contrôles modifiables est interceptée dans les deux skins, les panneaux DSP/FX et les fenêtres détachées, y compris les contrôles DuRec déplacés. Le défilement des listes et la navigation du mixeur restent disponibles. Le double-clic des faders de canal/FX Send est désactivable ; les éditeurs numériques, Ctrl-clic, pan et clavier restent disponibles. Les valeurs par défaut conservent le comportement antérieur. Un échec de sauvegarde ne change pas le modèle en mémoire.

Load Groups with Snapshot est relié au propriétaire de transaction snapshot. Store mémorise les appartenances et les quatre boutons actifs Fader/Mute/Solo ; Recall les rappelle si l’option est activée. Undo/Redo restaure les groupes de l’opération même si l’option a changé depuis. L’ancien format sans groupes conserve les groupes courants. Le groupe temporaire reste local à la session et ne s’enregistre pas. L’import/export TotalMix conserve les champs Group Flags et les boutons de groupes ; le conteneur Workspace OSCmix conserve aussi la nouvelle préférence, tout en acceptant les anciens fichiers.

Cette livraison ne termine pas la parité globale. Le rappel Record/Play, encore absent de +menus.2, est développé dans +menus.5 avec une transaction DuRec distincte, des observations fraîches et une confirmation finale. Le mode DAW, Offline Device Setup, le protocole Network Remote et le stockage dans l’appareil restent ouverts ; un protocole OSC existant ne remplace pas Network Remote.


## Full Scale Samples for OVR — alpha.25 +menus.3

Level Meters, dans Preferences et dans son dialogue autonome, propose Full scale samples for OVR, de 1 à 10. Le compteur UFX+ transmis avec chaque mesure est comparé au seuil ; les rafraîchissements GTK ne sont pas additionnés. Inputs, Playback et Outputs partagent la préférence, avec le maintien OVR existant. Les transports qui ne fournissent qu’un drapeau conservent leur sémantique booléenne. Le défaut reste 1 pour conserver le comportement OSCmix antérieur ; le défaut natif TotalMix documenté est 3.

Les quatre mètres FX reçoivent Peak/RMS/compteur/date dans un seul message, en conservant les anciennes adresses. Le modèle refuse trames malformées, anciennes ou répétées, et invalide l’observation au changement de session. Les deux présentations FX utilisent le seuil. Un ancien flux sans compteur conserve son comportement au seuil 1 ; il ne fabrique pas un compteur pour un seuil supérieur.

Apply enregistre atomiquement meters.ini, conserve les clés inconnues et ne change le modèle qu’après succès. Un échec laisse le formulaire ouvert avec l’erreur. Cancel et la fermeture conservent le réglage courant. Modifier le seuil ne remet pas à zéro les enveloppes Peak/RMS ou un maintien OVR déjà actif.


## Rappel Record/Play dans les snapshots (+menus.5)

Load Record/Play with Snapshot rejoint le formulaire partagé de Preferences et du panneau snapshots. L’option est désactivée par défaut, suit le retour du moteur et se conserve dans la session et les Workspaces OSCmix. Les affectations connues sont stockées même quand leur rappel est désactivé. Les anciens fichiers sans ces champs conservent le réglage courant. Le codec v8 et l’échange TotalMix gardent les valeurs inconnues distinctes de zéro.

Les canaux physiques Input/Output sont pris en charge, avec les gardes DuRec et un lot validé avant USB. L’interface reste verrouillée jusqu’à la confirmation des valeurs matérielles postérieures à l’achèvement USB. Refus, ACK absent, délai de relecture et Undo/Redo suivent le propriétaire transactionnel commun ; voir doc/snapshots.md. Les fonctions M01 à F17 restantes ne sont pas clôturées par cette livraison. F18 (snapshots CC) est exclu à la demande de l’utilisateur.


## Sélection de sous-mix et exclusions MIDI (+menus.6)

Le menu MIDI / ARC Settings propose trois listes d’exclusion par profil MIDI, avec brouillon, Apply/Cancel, validation et persistance. Une moitié exclue bloque la paire stéréo entière ; les profils restent indépendants, sans changement des affectations ARC. Les anciennes préférences sans listes gardent toutes les voies incluses.

Les commandes CC MIDI13–16 sélectionnent le sous-mix, les boutons REC Mackie de la rangée Output sélectionnent leur destination. Le lien local est respecté ; une sélection privée ne déplace pas la sélection GTK. La numérotation CC est corrigée selon sa table physique native, distincte des banques Mackie repliées en stéréo. La courbe, les gardes et les propriétaires des commandes de niveau restent inchangés. Les options Trim/LCD et REC depuis les rangées sources restent séparées ; aucune parité globale n’est revendiquée.


## Lock User Interface — +menus.7

Preferences → Operation → Lock User Interface protège les commandes locales du mixeur, de la matrice, du DSP, de Control Room, de DuRec et des snapshots. La valeur est désactivée par défaut ; Apply la mémorise dans `interaction.ini`. Fermer les préférences sans Apply abandonne le brouillon ; une erreur de sauvegarde conserve l’état courant. Les deux présentations et les fenêtres détachées partagent cette préférence.

Les contrôleurs MIDI, ARC USB via UFX+ et OSC restent actifs avec leurs gardes habituelles. Les observations matérielles, les mètres, les transactions déjà acceptées et Read Device continuent. La sélection du sous-mix, le défilement, le zoom et les préférences restent disponibles. Les boutons de la sidebar respectent les exceptions bit20 des descripteurs TotalMix2.03 : repli des panneaux et Show FX, mais rappel/Store/noms de snapshots et layouts protégés. Les confirmations et éditeurs ouverts avant le verrouillage revérifient la garde avant une modification.

Référence native : garde1001462a0 et tables de contrôles vérifiées sur SHA75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265 ; contrat et preuves dans la cartographie UI-lock-20261018. Ce verrou n’est pas un mécanisme d’authentification et ne change pas le verrou interne des transactions. Aucun nouveau protocole USB.
