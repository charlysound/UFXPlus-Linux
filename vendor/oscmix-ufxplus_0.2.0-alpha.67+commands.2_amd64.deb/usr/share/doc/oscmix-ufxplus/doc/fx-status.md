# FX — implémentation locale alpha.21

## Base et périmètre

L’implémentation part du dossier source réel et des modifications alpha.19 déjà
présentes. Les 119 fichiers de la sauvegarde créée avant l’interruption étaient
identiques au dépôt avant cette reprise : aucune ancienne implémentation FX
n’était à annuler. La Control Room et les snapshots alpha.19 ont été conservés.

Référence statique : TotalMix FX 2.03 Intel, SHA-256
`75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265`.
Les pilotes KEXT 3.39 / DriverKit 4.30 transportent les mots DSP (1–128 mots) ;
le traitement audio reste dans l’UFX+. Aucun changement du pilote PCM.
Les faits numériques nécessaires aux tests sont dans `tools/fixtures/fx/` ;
ni le binaire, ni les bitmaps RME ne sont distribués.

## Implémenté et contrôlé hors matériel

| Fonction | Preuve de référence | Vérification |
|---|---|---|
| 21 paramètres, encodage signé, enums, arrondi | `10054a1e0`, `10015b960` | Limites exhaustives côté pont, arrondis et commandes réelles OSC |
| Ordre des opérations multiples | parcours 44–64 de `10015b960` | Reset, snapshots et restauration DSP ; High Cut avant Attack/Room Scale |
| Reset + 10 Reverb + 3 Echo | `1001e5810`, `1001e5b90`, `1000140f0` | 167 mots comparés au JSON extrait indépendamment ; On/Off et autre effet préservés |
| 225 transitions de type | setter du type, sans réinitialisation des autres paramètres | Valeurs cachées conservées ; quatre dispositions GTK |
| Deux banques de 16 emplacements | `1000132c0`, `1000139c0` | Save/Recall/Rename, sauvegarde atomique, rechargement des 32 emplacements, Undo/Redo des banques |
| Presets `.tmrv` / `.tmeo` | `1000ffec0`, `10006acc0`, `100103760` | Structure `Preset/effet/Params/val e,v`, 2 décimales, première colonne, sentinelle et import partiel |
| Historique commun | architecture existante + `1000f96d0` | On/Off exacts, une action par import/Reset/Recall, Undo/Redo, aucun journal parallèle |
| Highest / Main / indépendant | `100101090`, `100109370`, `1001094c0` | Seuil 0,1 dB, exclusion No Trim, stéréo, non-dominant, valeur logique non écrêtée, silence −300 |
| Persistance des départs | modèle flottant natif puis écrêtage dans le writer | Format v5, migration v4, échange de snapshot TotalMix avec No Trim et silence |
| Mètres FX In/Out | `100107e10`, `1000924f0`, `1000cabf0` | In = Output pre-FX 94/95 ; Out = Input pre-FX 94/95 ; Peak/RMS synthétiques, aucune écriture |
| Fader FX non linéaire | `10008cd50`, `100092ca0`, `100092d40` | Courbe avec arrondi des coordonnées à l’échelle, inversion et points −65/0/+6 |
| Panneau GTK | tables `100237a10`, `100238e50`, `100238590` | Géométrie proportionnelle, captures des quatre dispositions, BPM 999 à délai nul, saisie/molette/clavier |
| Verrouillages | état/provenance existants du projet | Ouverture/synchronisation sans édition ; édition bloquée pendant transaction ou déconnexion |

Le panneau global remplace la page FX générique. Width/M/S/Phase restent dans
les réglages des tranches Playback. Les retours Output continuent de passer
par le moteur Control Room. Les tests existants couvrent les interactions
Mute FX, External Input, Talkback, Main A/B et les échecs de transfert simulés.

Les paramètres restent dans les caches DSP observés/en attente existants.
Seuls les départs logiques non écrêtés, No Trim et les banques ont un état
supplémentaire. Le suivi ne transforme pas une route inconnue en silence.
Un transfert accepté ne certifie pas la relecture ni le résultat audio.

## Compléments alpha.21 — 14 octobre 2026

Les sept points FX de l'audit ci-dessous ont maintenant une implémentation :
petits faders Send/Return, indicateur DSP/LIM, bouton FX indépendant, sous-menus
Recall/Save to/Factory et sélection, préférences des mètres FX persistantes,
et gestes/saisie numérique. Les tranches conservent leur hauteur minimale de
180 pixels, avec une colonne FX supplémentaire (largeur totale 120 pixels).
La description détaillée et le périmètre des tests sont dans les
[notes alpha.21](releases/v0.2.0-alpha.21.md).

Les faders et les potentiomètres utilisent `gtk4/channel_fx.h`, les mêmes
paramètres du modèle et les commandes `/input/N/fx`, `/playback/N/fx`,
`/output/N/fx`. Les retours continuent de passer par la Control Room. Un test
supplémentaire a révélé puis corrigé la perte d'une édition du retour Main à la
sortie d'External Input : sa mémoire `last_fx` est maintenant actualisée avec
la mémoire par sortie. Les tests contrôlent également que le retour effectif
reste coupé pendant External Input et Talkback.

Le test `gtk4/fx-strip-test` couvre les vraies fonctions d'interaction et un
mouvement de souris X11, sans ouvrir l'interface audio. Les captures incluent
les trois rangées et la Control Room, pas seulement le panneau global. Les
tests du panneau et de l'en-tête couvrent la persistance des préférences, la
sélection de preset, l'expiration du Peak Hold et l'invalidation de la charge
DSP à une nouvelle session.

Le Trim complet reste le chantier voisin identifié séparément. La présence des
contrôles et leur fonctionnement testé ne constituent pas une certification
pixel par pixel ni une qualification audio.

## Audit initial des éléments visibles manquants — 14 octobre 2026

**État constaté en alpha.20, conservé pour traçabilité ; corrections alpha.21 ci-dessus.**

Le signalement des petits faders révèle une omission du plan et de la livraison :
le contrôle FX dans Channel Settings ne remplace pas le contrôle permanent dans
la tranche. L'alpha.20 installée ne reproduit donc pas encore l'ensemble de
l'interface FX. Les tests réussis du panneau global ne couvrent pas cette absence.

Constats issus du code actuel, rapprochés du [manuel UFX+, §§25.3.1,
25.5–25.7](https://rme-audio.de/downloads/fface_ufxplus_e.pdf) et des références
TotalMix 2.03 du plan :

| Priorité | Élément | Constat vérifié et correction à prévoir |
|---|---|---|
| 1 | Petits faders FX Send, Inputs et Playback | `gtk4/mixer_row.c` ne dessine aucun contrôle FX et ne gère que les glissements Volume/Pan. `gtk4/channel_settings.c` expose uniquement un potentiomètre `fx`. Ajouter les faders permanents, synchronisés avec ce potentiomètre et les retours du moteur. |
| 1 | Petits faders FX Return, Outputs et Control Room | Même absence dans le composant de tranche partagé. Ajouter les retours visibles en réutilisant `/output/N/fx` et les mémoires logiques Control Room ; ne pas contourner Mute FX, Talkback ou External Input. |
| 2 | Indicateur de charge DSP | Le moteur possède `newdspload()` et publie `/hardware/dspload`, mais aucun affichage GTK ne consomme cette valeur. Ajouter le compteur avec état inconnu/déconnecté ; vérifier la disponibilité du feedback natif avant de présenter une mesure. |
| 2 | Affichage indépendant du panneau FX | `gtk4/main.c` insère le panneau dans l'inspecteur général. Le bouton de l'inspecteur masque tout cet ensemble ; aucune commande dédiée Show FX n'existe. |
| 2 | Menu des presets conforme à la référence | `fx_panel.c` présente 16 lignes avec Save, puis les commandes et presets usine à plat. Les opérations existent, mais la hiérarchie Recall / Save to / Factory n'est pas reproduite. La sélection est reçue dans `p->selected`, sans repère de sélection sur les entrées de rappel. |
| 2 | Préférences des mètres | Les mètres FX In/Out existent. Le Peak Hold est un maximum local réinitialisé au clic ou à l'expiration des données ; aucune durée configurable ni option RMS +3 dB n'est raccordée au panneau. Leur comportement exact dans TotalMix 2.03 reste à comparer. |
| 3 | Gestes des faders et édition précise | La molette de `mixer_row.c` fait défiler la rangée ; le double-clic du fader principal impose 0 dB. Le potentiomètre Send/Return n'offre pas de saisie numérique. Le contrat des gestes doit être comparé puis partagé avec les nouveaux petits faders, sans recopier ces raccourcis incomplets. |

Écart voisin, distinct des départs FX : le bouton Trim par tranche et les
repères des autres routages ne sont pas présents. Le No Trim des sorties et le
suivi FX Highest/Main existent, mais ne constituent pas un mode Trim complet.

Les algorithmes Reverb/Echo, On/Off, paramètres, banques utilisateur, import/export,
suivi Highest/Main/indépendant et Mute FX sont déjà présents ; ils ne doivent pas
être comptés comme fonctions absentes. Les fonctions natives `100109370` et
`1001094c0` décrivent le suivi des départs, pas la présence d'un fader GTK.

La prochaine correction doit commencer par les deux premières lignes. Sa recette
doit inclure les tranches Input, Playback, Output et Control Room, mono/stéréo,
la synchronisation fader/potentiomètre dans les deux sens, les changements de
sous-mix, Recall/Undo, les valeurs inconnues, les verrouillages et les coupures
temporaires des retours. Les captures du seul panneau global sont insuffisantes.
Cet audit ne constitue pas une nouvelle qualification audio ni une comparaison
exhaustive de toutes les fonctions de TotalMix.

## Limites de fidélité encore ouvertes

- Width négatif est pris en charge par le widget, le setter sans clamp et le
  writer signé de la référence statique ; son effet audio sur cette UFX+ reste
  à qualifier. Release atteint 500 ms (492 dans les presets usine), High Cut /
  High Damp démarrent à 2 kHz. Time accepte 5 s dans le modèle et 4,9 s dans l’UI.
- La géométrie et les courbes sont portées, mais les couleurs, les gestes fins,
  la disposition responsive et le rendu exact FX 2 ne sont pas certifiés pixel
  par pixel. Le Peak Hold GTK est maintenant temporisé et réinitialisable par clic ;
  sa temporisation exacte reste à comparer à celle de TotalMix exécuté.
- Le codec reproduit la structure et la précision retrouvées statiquement.
  La relecture des exports dans TotalMix exécuté n’a pas été effectuée. Les
  valeurs hors des plages explicites sont rejetées : le setter natif non borné
  peut accepter des valeurs supplémentaires selon leur origine.
- Le journal regroupe toujours les gestes voisins à 400 ms, comme le moteur
  existant. L’équivalence exacte de ce regroupement et de la sélection du menu
  de presets reste à comparer. Save/Rename des banques FX rejoignent le même journal avec restauration
  persistante de leur emplacement/nom.
- Le suivi fonctionne sur les 94 sorties du modèle actuel. L’exclusion des ports
  inactifs en Double/Quad Speed et les réaffectations Main complexes demandent
  encore une comparaison native ; les tests hors matériel ne qualifient pas
  96/192 kHz.
- Ni écoute comparative, ni charge DSP, ni changement de fréquence, ni essai de
  routage sur le matériel n’ont été effectués pour cette livraison. Définir les
  raccordements et niveaux avant ces essais. La relecture Playback matérielle
  complète reste distincte de la conservation de son état hôte connu.

## Validation et livraison

Les tests dédiés sont `tools/fx-reference-test`, `tools/test_fx_factories.py`,
`gtk4/fx-panel-test` et `gtk4/fx-strip-test`. La recette complète est `xvfb-run -a make -j4 check`.
Le constructeur Debian effectue une reconstruction propre et cette recette
avec des répertoires de configuration/état temporaires ; il ne produit le
paquet que si ces vérifications réussissent.

Le paquet vise `/usr/lib/oscmix-ufxplus/AppRun`, utilisé par le lanceur système.
Il ne modifie pas les chemins de configuration ni les identifiants techniques
historiques. Cette livraison locale ne déclenche ni installation, ni lancement
sur l’interface, ni publication.
