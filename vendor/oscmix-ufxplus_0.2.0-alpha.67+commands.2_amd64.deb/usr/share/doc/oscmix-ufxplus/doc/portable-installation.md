# Installation Linux portable

L'archive OSCmix dépose le même programme et les mêmes services que le paquet
Debian, aux mêmes chemins. Elle utilise l'installateur commun du projet pilote,
identifié par son empreinte lors de la construction. Le fonctionnement par carte
et les fichiers XDG ne dépendent pas du gestionnaire de paquets.

Après extraction, `python3 install.py --check` vérifie intégralement le manifeste
et les conflits. `sudo python3 install.py --install` installe ; `--remove` retire
seulement les fichiers encore conformes appartenant à cette installation.
`--root /chemin` permet une préparation sans toucher au système courant. Une
installation gérée par les paquets doit être mise à jour avec son gestionnaire :
l'archive refuse d'écraser des fichiers étrangers ou modifiés.

Le contrôle avant installation ne valide pas les bibliothèques graphiques,
l'audio ni le noyau de la machine cible. Le programme AMD64 demande notamment
GTK4, GLib, ALSA, libusb et PipeWire compatibles avec les versions de compilation.
Installer aussi le composant hôte RME de la même livraison pour les réglages et
le frontend ALSA. Les adaptations de services et de module noyau sont décrites
dans son archive ; la copie de fichiers ne démarre aucun service et ne charge
aucun module automatiquement.

Les sources se compilent avec les outils habituels du projet. Pour exporter
l'application déjà construite, utiliser `packaging/build-portable.py` avec le
paquet source identifié, le fichier `portable_install.py` du dépôt pilote à un
commit fixé et son SHA256. `dpkg-deb` sert uniquement à extraire le paquet sur la
machine de construction ; il n'est pas requis par l'installateur portable.

Debian/Ubuntu, Fedora, Arch et openSUSE utilisent ce même contenu. La présence
de cette archive ne constitue pas une qualification sur ces quatre familles.
La validation des bibliothèques, de la session et du noyau reste à effectuer
sur chaque distribution disponible. Les données de mixage restent conservées
dans les répertoires XDG propres à l'utilisateur et à chaque carte.
