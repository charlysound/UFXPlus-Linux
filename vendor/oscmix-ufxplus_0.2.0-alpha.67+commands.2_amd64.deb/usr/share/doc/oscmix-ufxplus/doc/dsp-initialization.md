# Native DSP initialization

The UFX+ manual section 25.7 describes **Always init DSP devices with TotalMix
FX settings** as a host-authoritative policy that suppresses the mismatch
question: standalone device changes are overwritten. OSCmix now provides
the corresponding **Always init DSP devices with OSCmix settings** preference
for its mapped native USB3 DSP state. It is not just a sends checkbox and it
does not import TotalMix workspace files.

Since alpha.9 this is the only automatic initialization preference. The former
temporary sends-only option is removed; `force-sends-on-connect` is ignored
and deleted on the next preference save. `force-dsp-on-connect` is preserved,
defaults to off, and is never enabled by migrating a sends-only preference.
The synthetic GUI/backend suite now tests the removal as well as full-DSP
ordering, missing data, stale acknowledgements and rejected writes.

Startup authority and readback provenance are separate. With this preference
enabled, saved OSCmix settings win once per connection/reconnection (or an
explicit Apply). Afterwards a device observation updates the console; a user
edit in OSCmix writes that edit to the device. Background observations and
mismatch reports must never initiate another restore. Disabling the preference
does not manufacture missing Playback send readback. The UI now describes
input readback as a live source rather than a competing initialization choice.

## Do not confuse startup initialization with snapshot recall

Section 25.7 spans pages 75-76 of the
[UFX+ manual](https://rme-audio.de/downloads/fface_ufxplus_e.pdf). On page 76,
the **Snapshots** heading describes selectable **Recall safe** exclusions for
Main Volume, Main/Phones Volumes and Control Room Settings. When selected,
these preserve the corresponding current settings during snapshot recall;
they are not mandatory omissions from every restore.

The following, separate **Device Handling** heading describes **Always init
DSP devices with TotalMix FX settings**. This paragraph does not say that the
snapshot recall exclusions apply to startup initialization. Accordingly,
OSCmix's startup restore continues to restore its supported output levels and
DSP Control Room fields, with output levels/mutes applied last for safety.
Named snapshots have their own recall-exclusion policy; see `snapshots.md`.
Main/Phones roles must be resolved from channel assignments, not assumed to
mean the first output pair or fixed headphone channel numbers.

Distinguish three categories when reporting parity: a user-selected snapshot
exclusion, a setting outside this DSP restore (such as USB clock), and an
unimplemented native feature (such as Loopback). The last category is an OSCmix
limitation, not an exclusion justified by section 25.7.

## Transport boundary

### Reapplying a full profile in the same session (development)

Playback pairing is software state, not part of a hardware DSP upload. Each
accepted DSP-begin request now republishes all 94 Playback pairing flags from
the engine before starting the restore. Hardware input/output pairing must
still arrive from the restored profile; stale pre-restore layout coverage is
cleared. Previously the GUI cleared all three rows but only received two from
the DSP publication, so a second application could time out with outputs muted.
The old synthetic backend incorrectly supplied all three rows, masking the
missing production publication. Engine tests now assert every Playback flag
on both first and repeated begin requests without a refresh or reconnection;
a GUI regression runs two complete DSP/send/output cycles in one session.
Overlapping reapplication during the layout-wait phase is blocked. Following
an incomplete initialization, restart the mixer rather than attempting another
begin against a backend still inside its restore transaction.

### Output monitoring after verification (development)

A verification mismatch or timeout no longer permanently gates incoming DSP
state. Read-side observation and saved host intent are separate: a mismatch
remains visible and protects the saved profile, but fresh output volume
observations can continue reaching the console without any parameter rewrite.

Output volumes use a dedicated local-pipe/OSC observation message with the
backend session and a monotonic timestamp. Full-query replies carry the query
start time; old-drain data and restore-time data remain suppressed. The GUI
rejects observations predating a local fader edit or a newer accepted read.
Accepted USB writes and cached profile publication do not acquire a readback
indicator. A global DSP success does not mark every output as freshly read.

Offline coverage exercises all 94 output addresses, pending/success/mismatch/
timeout states, restore/drain blocking, mono and paired channel identities,
right-before-left delivery, stale sessions/timestamps and malformed values.
The bridge-to-pipe, pipe-to-OSC and GTK-model paths are tested without USB.
Physical front-panel event delivery and latency remain to be qualified; these
tests do not establish that the device emits an unsolicited event for every
front-panel change.

Follow-up: a read-only watchdog now recovers from missing unsolicited output
events using the existing DSP upload (`3e04=67cd`), two seconds after the
previous upload completes. It does not introduce a new protocol command.
Uploads never overlap an active restore, verification or matrix request;
incomplete reads back off for ten seconds after a 25-second deadline. This is
bounded recovery, not a promise of sub-second knob tracking. Unsolicited
updates continue to be forwarded immediately when safe. Unchanged DSP controls
are filtered before OSC publication; unchanged output observations refresh
their timestamps without rebuilding GTK controls.

Requested uploads retain their start timestamp. An edit invalidates the old
upload, with stale timestamps retained until the receive stream drains. The
GUI also fences observations predating a full restore, so a late pre-restore
packet cannot undo the restored output value after initialization finishes.

The official TotalMix 2.03 UFX+ USB capture has 5,005 native heartbeats with a
median interval of **20.034 ms**. Its device-settings upload spans about
**1.779 s** from request to the last Room EQ register. The custom 100 ms probes
are not representative of this official cadence. The bridge and diagnostics
now service the existing `3dff` heartbeat every 20 ms, with 10 ms register-read
timeouts. This adds no session command, parameter write, reset or new USB
owner. A Linux read-only complete coverage check took **1.85 s**, with zero
parameter writes; the audio driver remained running. This explains the
previous ~9 s upload delay, not the physical-control-to-display latency.
The macOS 3.39 and DriverKit 4.30 reference read methods copy completed USB
data into the caller's buffer; they do not reconstruct faders themselves.
DriverKit's corresponding trigger arms a 1,024-byte asynchronous read with
a 10 ms timeout. Its error recovery is not copied into this safe transport.

Once verification has drained stale replies and issued its fresh query, all
decoded settings are published as they arrive, not held until the global
comparison ends. Restore and stale-drain phases still suppress observations.
Cancelled watchdog uploads are now prevented from replacing generic DSP
state too, rather than protecting only output faders. Regression tests feed
all mapped DSP registers through incomplete verification and check gain,
phantom/Hi-Z, output pan/mute/pairing, EQ, Dynamics, Room EQ, global FX and
Control Room through the OSC engine without hardware writes. Phantom tests
are synthetic only.

The signal chain is hardware REG_IN -> native bridge -> OSC engine -> GTK
model. OSC feedback is already part of that chain; it does not bypass the
hardware read. Output observations use `/readback/output/N` with session and
query timestamps; accepted writes and profile publication cannot use that
provenance. Generic parameters retain their existing OSC addresses. Optional
bounded traces include USB receive and model-application monotonic times;
these measure software delivery, not the time before an event reaches USB.

The installed development test compared all **94** output observations to
the GTK model: no missing values and no value mismatches. Eight complete
recovery uploads took **1.836–1.855 s**. For the first 94 output observations,
USB-arrival-to-model latency was 0.027 ms median, 0.052 ms p95 and 0.090 ms
maximum. These are local software-path measurements, **not** physical-knob
or display/compositor latency. The audio driver stayed on the same invocation
at 48 kHz / 94 channels / 128 frames, without missing frames or underruns.

Coverage counting is incremental, so each short USB reply no longer causes
a scan of the entire DSP snapshot. Duplicate/invalid values cannot underflow
the missing-register count or falsely complete a snapshot. Repeated unchanged
single-value parameters/status also no longer invalidate the GTK settings
panel. Raw OSC delivery is preserved, including repeated relative ARC events;
multi-argument updates keep their previous behavior.

The supplied UFX+ receiver handles ARC delta/button notifications (`3203` /
`3204`) separately from absolute register updates. This supports investigating
the user's notification hypothesis, but does not establish that a front-panel
knob uses ARC events. No speculative ARC-to-volume write, `3e03` acceptance
command, or automatic state replay was added. Further qualification must
distinguish a new-value event from a change notification, missing session
setup, or no event. Full uploads remain the current fallback until this is
demonstrated; Playback readback is still unresolved.

The supplied TotalMix 2.03 UFX+ receiver at `10015cfe0` decodes output channel
registers with stride 48 and signed tenths of a decibel at offset zero. Its
normal live path skips the odd channel's volume update when stereo-linked;
the upload path is distinct. This supports retaining individual channel
observations and the left-channel stereo fader, not taking an average/maximum
or rewriting the right channel to conceal a discrepancy. Control Room and
physical knob behavior still need a real front-panel witness.

For bounded diagnostics, start the mixer with `OSCMIX_TRACE_OUTPUT=1`.
The native log records at most 256 changed output observations and 16 upload
outcomes; the GUI records at most 256 accepted changed output values. This
traces register/channel/value, requested versus unsolicited origin and the
model observation timestamp without writing parameters or saving raw USB
captures. It is off by default. Recorded-response/unit tests and synthetic
GUI tests must not be reported as a physical knob test.

Live check (2026-10-10): 94/94 decoded hardware output values matched the
GTK model that supplies the faders, with no missing channel. Analog 1/2 was
-26.5 dB, Analog 3/4 -3.7 dB and Phones 9/10 and 11/12 -20.0 dB. This is a
present-state comparison, not a physical knob-response test. Initialization
was disabled in the user's current preference, which was preserved. The
monitoring session ended with zero parameter writes and zero rejected meter
snapshots; the independent audio driver was not restarted.

A complete read-only upload took about 9.3 seconds. Thus the two-second idle
interval is **not** a two-second guaranteed update latency. A bounded receive
burst experiment did not improve this (about 9.3-9.4 seconds) and was removed.
Fast unsolicited front-panel event delivery remains a priority investigation;
do not label the fallback as immediate synchronization. Offline coverage now
includes 13 GUI/backend scenarios, including policy-on and policy-off device
changes that must not cause reinitialization.

Only the existing IF1 bulk control transport is used. No audio IF0 setup,
USB reset, control transfer, firmware interface, hardware preset, USB Settings,
sample-rate or clock-source command is part of initialization.

The channel read/write map and global DSP ranges were checked against the
supplied TotalMix FX 2.03 Intel UFX+ sender `10015b960` and receiver
`10015cfe0`. Room EQ is important: the read base is `3426`, while the write
base is `30a0`, with 32 words per output. Read-side addresses overlapping
`3eXX` must never be submitted as session/setup writes. Tests check every
translated destination. Since alpha.7 the interactive native setter uses the
same reviewed address mapping with a stricter typed-value allowlist.

### Interactive controls (alpha.7)

Room EQ commands `30a0..3c5f` are checked against canonical readback addresses
`3426..3fe5`. Coverage, cached desired state, accepted-write echoes and later
readback verification all use the read-side address; USB uses the write-side
address. This matters because the two address ranges overlap. Every output is
tested, including missing coverage and signed gain values. Accepted-write UI
echoes are not treated as proof of hardware verification.

Analog input reference/48V, mic 9–12 Hi-Z/AutoSet, output reference and phones
crossfeed now have channel-specific interactive guards. Room EQ master accepts
only boolean values and refuses to overwrite an observed non-boolean encoding;
full-profile restoration still preserves such observed values exactly. Per-band
on/off remains the existing software gain-zero/restore mechanism, not a newly
decoded hardware bypass bitmap. Output volume calibration is still excluded.

All mapped reverb/echo and six DSP Control Room registers have bounded setters.
FX ranges follow the [UFX+ manual, Reverb and Echo](https://archiv.rme-audio.de/download/fface_ufxplus_e.pdf),
with wire scaling from the existing UFX+ engine. The GTK FX panel exposes the
previously missing reverb parameters, echo high-cut/width and Main Output
selection. Clock/hardware/storage widgets stay disabled in native mode without
disabling their Control Room sibling. No raw register API was added.

Validation: native allowlist/boundary tests, mock USB writes, model/transport
tests and a synthetic GTK panel test (including actual ancestor sensitivity
under Xvfb). The 176.4-kHz addition belongs to the separate audio driver.
Listening at 176.4 kHz remains unqualified.

### Bounded hardware control check (2026-10-10, 48 kHz)

Using the installed alpha.7 native transport's descriptor guard, typed register
policy and fresh DSP reader, a controlled test changed all 12 analog input
gains and the Analog 1 output pan. All outputs were first muted and the mutes
verified by a fresh hardware upload. All 13 requested control values were then
returned correctly by another hardware upload. Only the touched controls and
previous mutes were restored; the final complete scoped DSP comparison had
zero differences from the baseline. No audio stimulus was played.

Phantom testing was deliberately OFF-only: all four microphone inputs were
first observed OFF, received only OFF writes, and a fresh complete DSP
comparison remained unchanged. No phantom ON command was sent to hardware.
This qualifies command delivery/readback, not the 48 V voltage or switching
transient. Activation needs a separately confirmed safe connection.

The hardware harness exercised the native USB mapping, not mouse interaction.
Separate offline tests exercise OSC-to-register encoding for line/mic gain,
the microphone gain gap, phantom ON/OFF channel restrictions, output pan
-100..100, and stereo send pan in both CC and native modes. These results do
not establish send readback, audible pan law or all-rate physical I/O behavior.

Scope is explicitly enumerated in `tools/dsp-state.h`: channel state and DSP,
output state, nine-band Room EQ/delay, reverb/echo and mapped DSP Control Room
registers. Unsupported output calibration fields are excluded because the
current hardware does not return them. Loopback, DURec and TotalMix software
workspace/ARC assignments are not claimed. Single-speed layout qualification
still applies.

## State and failure handling

### Current-session Apply

Startup authority and explicit reapplication are separate operations. On a
new backend connection, **Always init DSP devices with OSCmix settings** uses
the validated device-bound disk profile. With the policy off, normal device
observations do not trigger a restore. **Apply OSCmix settings now** freezes
the current session's complete DSP state, never reloads that startup file and
never fills unknown fields from defaults. Manual Apply is available with
**Always init** either on or off and leaves that saved preference unchanged.
It requires a connected native device and valid sends; it is unavailable during
another operation or after incomplete initialization. The button updates while
Sync stays open, and its tooltip explains why it is unavailable.
The existing setting scope and
manual section 25.7 distinctions are unchanged.

The current DSP state receives the same fresh hardware observations published
to the console, including incremental verification replies and observations
after a mismatch. Accepted local edits update it too. The restore/verification
target is a separate copy: later observations cannot mutate an in-flight
transaction. Invalid, stale, pre-edit, wrong-session and incomplete data must
not become a new restore target. No new USB command or register is introduced.

Input and Playback sends already come from the current model rather than a
fresh disk reload. Their frozen plan remains protected until the final output
stage completes. Playback values are still host intent, not device readback.

Changed DSP state is checkpointed atomically after 500 ms of inactivity, or
after five seconds of continuous changes when safe. No checkpoint runs during
a restoration or pending verification, after a mismatch/incomplete verification,
or before forced startup has completed. Thus verification can delay persistence;
these intervals are not a durability deadline. A failed save retains the
previous file and is retried at most once per five seconds. Current sends use
an independent coalesced, atomic checkpoint after completed initialization.
The two files are not a cross-file atomic transaction; abrupt process/power
loss before a checkpoint can still lose recent edits.

Offline regression coverage includes all 9,287 scoped DSP fields and all 94
output volumes (disk -51 dB, current -39.5 dB), repeated Apply, immutable targets,
fresh verification observations, stale packets, incomplete/wrong-revision
state, failed USB writes, automatic disk-profile startup, checkpoint cadence,
and current input/Playback send plans for every mono/stereo destination.
Phantom changes in these tests are synthetic only, never physical 48 V tests.

### Profile format and restore ordering

The private version-1 DSP file contains a physical-device identity, reported
DSP revision, complete allowlisted raw values and a canonical SHA-256 checksum.
This checksum detects accidental corruption; it is not an authentication
mechanism. Files are atomically replaced with durable writes and mode 0600.
The separate native matrix cache supplies desired send levels and pans.

1. Require a valid saved matrix and a live backend session.
2. For startup, check the live DSP revision and validate the complete,
   device-bound saved profile before any parameter write. Explicit Apply uses
   the complete current session state and its known device revision instead.
   First use still captures a full real
   hardware snapshot; it never manufactures a default profile.
3. Write all output mutes first and require successful USB completion.
4. Apply allowlisted non-final DSP fields, including pairing, in bounded
   128-word transfers. Publish accepted host intent, explicitly not readback.
5. Rebuild the send plan from that restored pairing, then apply bounded batches
   with matching completion fences on the I/O thread.
6. Restore output levels, then saved output mutes, requiring USB completion.
   Unlock the console and display verification pending.
7. Drain the previous upload before issuing a fresh read-only query. Compare
   complete DSP coverage in the background. Distinguish verified, mismatch and
   incomplete states. No failed comparison causes an automatic rewrite.

The console and detached editors are locked during initialization. A failure
stops the operation without retry or rollback and can leave outputs muted.
Partial initialization does not overwrite the previous desired DSP or send
file. A full-policy session that never reached initialization, for example
because the saved matrix was missing, must not replace the saved DSP profile
with the un-restored hardware startup state either.

On normal exit after successful application, complete current session state
and the GUI's sends are saved for the next connection, even if verification
is still pending. A detected mismatch preserves the previous DSP profile.
Incomplete writes never replace the previous profile. While readback is in
flight, its stale/intermediate data cannot overwrite the GUI or saved intent;
application edits restart verification after draining the previous query.
Persistent termination handlers allow service/launcher
shutdown to save rather than dying on a second SIGTERM. Abrupt SIGKILL/power
loss cannot be guaranteed to save the most recent edits.

## Verification on 2026-10-08

- `make check`: native codec, engine/fence, DSP profile/restore, GTK model,
  transport and launcher tests.
- `python3 gtk4/test_host_sync.py -v`: existing send-only tests plus full
  DSP-before-sends/output-after-sends sequencing and DSP rejection without
  send writes; simulated backend, no USB hardware.
- Read-only `ufxplus-native --dsp-check`: complete scoped hardware coverage,
  zero parameter writes.
- Physical UFX+ at 48 kHz: seeded the current hardware DSP profile, confirmed
  output mutes, wrote 4,512 logical routes, restored original output state and
  verified DSP by fresh readback.
- Changed band-1 EQ gain temporarily from 0 to -1 dB on linked Input 1/2.
  Restart restored two changed DSP fields to 0 dB from the saved profile;
  final readback succeeded and original output levels/mutes were preserved.
- Service stop persisted the complete profile after the termination fix.
  The audio driver was not restarted and its Analog 1/2 PipeWire links remained.

This does not physically qualify every possible phantom, Hi-Z, reference,
Room EQ or global FX transition; those paths have map/range and mock tests.
Most importantly, **DSP readback is verified, but send writes are still only
USB-completed**. Reliable matrix readback and the two-way mismatch resolver
remain separate unfinished work.

## Send restoration performance (development, 2026-10-09)

The previous GUI advanced one route per 10 ms timer tick and USB-completion
round trip. A 4,512-route matrix therefore had a 45.12-second software floor,
before USB latency and rendering. The new implementation:

- validates up to 256 logical routes atomically before emitting any command;
- drives the next batch from the matching ACK on the I/O thread, independent
  of GTK rendering, with one outstanding batch and a five-second deadline;
- validates/stages the bounded pipe transaction before its first USB write;
- groups the unchanged register words into at most 128 words / 512 bytes per
  transfer, as in macOS 3.39 `UserClientWriteDSP` (range check at `4fd0`,
  word-count-to-byte conversion at `4fff`, USB call at `5031`);
- rejects bad, stale or duplicate sequences, stops on short/failed transfers,
  and never retries or treats an accepted write as hardware readback.

Measured on the physical UFX+, using a private copy of the existing saved
matrix: **4,512 routes / 13,442 words completed in 1.120 seconds**. No DSP,
clock, preset, firmware or audio-interface setup was written by that test;
the existing audio driver was left running. This confirms transfer completion,
not a fresh readback of all send values or an audible qualification of every
route. Tests with a bounded asynchronous USB queue were also about 1.119 s,
so that extra complexity was not retained.

**The requested sub-second complete initialization is not achieved.** One
fresh, complete DSP snapshot separately took 9.526 s (45,428 bytes / 7,445
read completions, no timeouts). Sixteen asynchronous receive requests still
took 8.666 s. The live revision arrives early, but that is not full state
coverage. Repeating complete reads synchronously remains the dominant full
initialization delay in alpha.2.

The user subsequently approved application before readback. The alpha.3
development implementation above applied the complete saved DSP/send/output
setup in **2.086 s**, followed by successful background verification. The
audio driver remained running. Tests exercise stale-upload draining, a fresh
query boundary, mismatches, timeouts, edits invalidating an in-flight read,
profile rejection, output ordering and failures without retry.

A separate engine parser bug was found during burst testing: when a read
filled the 8 KiB buffer, a valid trailing partial SysEx frame was discarded
even after earlier complete frames had freed space. It is now compacted and
preserved; a real pipe-parser regression test covers this boundary. The GUI
requests a larger receive buffer within system limits, and bulk state
publishing is paced to avoid flooding its UDP queue. No global sysctl is used.

Remaining performance work must preserve actual route semantics and the
firmware boundary. Do not skip unknown sends, change stereo encoding, or
introduce unqualified device commands merely to claim a sub-second result.

## TotalMix-guided command compaction (alpha.4, 2026-10-09)

The supplied TotalMix FX 2.03 UFX+ send function at `10015cdb0` encodes
gain plus a centered pan with bit 13 (`0x2000`), avoiding a separate pan
word. It maintains gain/pan caches, but `10015ab10` invalidates both caches
for a full host restore. Cache suppression alone therefore does not explain
fast forced initialization. The USB branch for product `3fc1` selects the
transport with writer `10013ab60` (63 queued words), distinct from the
Thunderbolt transport. The driver's 128-word limit is an accepted maximum,
not proof of the application's chosen batch size.

OSCmix now compacts only adjacent validated native left-gain / center-pan
writes for the exact same route, within a completed host batch. It recomputes
odd parity and preserves every other word and its order. Nonzero pans,
right-side gain words, DSP/session commands and CC traffic are unchanged.
There is no cache-based omission of unknown hardware state or cross-batch
coalescing. USB failure still stops without ACK or automatic retry.

Measured on the same saved 4,512-route setup:

| Experiment | Send application | Complete application | Result |
| --- | ---: | ---: | --- |
| Alpha.3 installed baseline | 1.122 s | 2.073 s | Reference |
| 63-word packets, no compaction | 1.132 s | 2.091 s | Not retained |
| Heartbeats every 100 ms during DSP restore | 1.118 s | 2.079 s | Not retained |
| Gain/center-pan compaction | 0.935 s | 1.889 s | Retained |
| Compaction plus concurrent REG_IN draining | 0.935 s | 1.886 s | Extra concurrency not retained |

Compaction removes 2,209 explicit redundant words: 13,442 -> 11,233 send
words; complete parameter writes 22,823 -> 20,614. All 4,512 logical routes
are still applied. Background DSP readback succeeded after each complete
test. It does not establish send-register readback or an all-topology guarantee.

A bounded signal test compared the old two-command send with the combined
command on paired Playback 1/2 -> Analog 1/2. At -24 dB and -18 dB, measured
attenuation differed by less than 0.01 dB; recentering from -50 and a nonzero
+50 balance also passed. The existing output settings were preserved and
the saved send was restored afterwards. Offline tests exhaust gain encodings,
parity, unchanged cases and mixed batches. No audio driver restart, firmware,
USB reset, clock change or speculative `3e03=234a` command was used.

Complete initialization is still above one second. Further gains need fewer
proven-equivalent commands or a better-understood native startup sequence,
not omission of silent routes or labeling pending writes as complete.
