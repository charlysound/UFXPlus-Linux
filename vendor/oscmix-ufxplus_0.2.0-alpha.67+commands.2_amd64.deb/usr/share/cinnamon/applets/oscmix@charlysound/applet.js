const Applet = imports.ui.applet;
const PopupMenu = imports.ui.popupMenu;
const Util = imports.misc.util;
const Gio = imports.gi.Gio;
const Main = imports.ui.main;

class OscmixApplet extends Applet.TextIconApplet {
    constructor(orientation, panelHeight, instanceId) {
        super(orientation, panelHeight, instanceId);
        this.set_applet_icon_name('io.github.charlysound.OscmixUfxplusUsb3');
        this.set_applet_label('OSCmix');
        this.set_applet_tooltip('Show OSCmix · right-click for Minimize and Quit');
        this._alive = true;
        this._busy = false;
        for (const [label, action] of [['Show OSCmix', '--show'],
                                     ['Minimize OSCmix', '--minimize'],
                                     ['Quit OSCmix', '--quit']]) {
            const item = new PopupMenu.PopupMenuItem(label);
            item.connect('activate', () => this._run(action));
            this._applet_context_menu.addMenuItem(item);
        }
    }

    on_applet_clicked() {
        this._run('--show');
    }

    _run(action) {
        if (!this._alive || this._busy)
            return;
        // Show can start the long-lived launcher; never wait for it to exit.
        if (action === '--show') {
            Util.spawn(['oscmix-ufxplus', '--show']);
            return;
        }
        this._busy = true;
        try {
            const process = Gio.Subprocess.new(['oscmix-ufxplus', action],
                Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE);
            process.communicate_utf8_async(null, null, (child, result) => {
                this._busy = false;
                try {
                    const [, , stderr] = child.communicate_utf8_finish(result);
                    if (this._alive && !child.get_successful() && child.get_exit_status() !== 1)
                        Main.notifyError('OSCmix', stderr.trim() || 'Window action failed');
                } catch (error) {
                    if (this._alive)
                        Main.notifyError('OSCmix', String(error));
                }
            });
        } catch (error) {
            this._busy = false;
            Main.notifyError('OSCmix', String(error));
        }
    }

    on_applet_removed_from_panel() {
        this._alive = false;
    }
}

function main(metadata, orientation, panelHeight, instanceId) {
    return new OscmixApplet(orientation, panelHeight, instanceId);
}
