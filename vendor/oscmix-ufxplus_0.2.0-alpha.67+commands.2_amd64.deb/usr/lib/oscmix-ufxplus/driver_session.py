#!/usr/bin/env python3
"""Read-only reconnect gate for the optional supervised native audio driver.

No USB access, audio restart or mixer writes. Trust only a live supervisor and
its direct worker, never a stale status file or a recycled PID.
"""
import json
import os
from pathlib import Path
import sys
import time
import subprocess
import select
import signal
import stat


def wake_key(path, uid):
    """Private tmpfs change hint only; never an authority for stopping a child."""
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'r') as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600):
            raise ValueError('Invalid native status ownership')
        payload = stream.read(2_000_001)
    if len(payload) > 2_000_000:raise ValueError('Native status too large')
    value = json.loads(payload)
    if value.get('schema') != 1 or value.get('closing') or value.get('inventory_error'):
        return None
    rows = [row for row in value.get('devices', []) if row.get('uid') == uid]
    if len(rows) != 1:return None
    row = rows[0]
    return (value.get('manager_nonce'), row.get('generation'), row.get('status'),
            *(tuple((row.get(name) or {}).get(k) for k in ('request_id','phase'))
              for name in ('rate_change','hardware_change')))


def control_transition(value, baseline):
    from native_runtime import rate_transition
    if baseline is None:return False
    if baseline.get('native') is False and value.get('native') is True:
        handoff = value.get('owner_change') or {}
        old, marker = baseline.get('marker') or {}, value.get('marker') or {}
        if (handoff.get('phase') == 'applied' and handoff.get('owner') == 'native'
                and handoff.get('from_generation') == old.get('generation')
                and type(handoff.get('to_generation')) is int
                and handoff['to_generation'] > old.get('generation',0)
                and handoff['to_generation'] == marker.get('generation')
                and value.get('uid') == baseline.get('uid')
                and all(marker.get(k) == old.get(k) for k in
                        ('manager_pid','manager_process_start','manager_nonce','attachment'))):
            # Audio/MIDI ownership can migrate while this same IF1 stays open.
            # The committed handoff ACK bridges a missed ready publication.
            baseline = dict(baseline,native=True,marker=dict(old,generation=handoff['to_generation']))
    return rate_transition(value, baseline) is not None


def admission(uid, ui_pid):
    """Capture authority before IF1 opens; only status reads may wait/retry."""
    from linux_settings_status import status, available, SettingsStatusError
    if not available():return None
    while True:
        os.kill(ui_pid,0)
        try:
            value=status(uid)
            if admitted_services(value):
                return {key:value[key] for key in ('uid','native','marker')}
            if value.get('state') in ('error','failed','migration_blocked'):
                raise RuntimeError(value.get('error') or 'Audio owner cannot admit a mixer')
        except SettingsStatusError as error:
            if error.code not in ('unavailable','busy'):raise
        except (OSError,ValueError,subprocess.SubprocessError):pass
        time.sleep(1)


def admitted_services(value):
    if value.get('state') not in ('running','recovering'):return False
    if value.get('native') is True:return value['alsa']['ready']
    backend=(value.get('applied') or {}).get('backend')
    if backend == 'pipewire':return value['pipewire']['ready']
    if backend == 'alsa':return value['alsa']['ready']
    return backend == 'pipewire+alsa' and value['alsa']['ready'] and value['pipewire']['ready']


def watch(uid, backend_pid, ui_pid, baseline):
    """Release our own IF1 child for an exact common-owner transaction.

    The manager drains audio itself. This watcher cannot stop a service or
    target an unrelated process; a pidfd pins the sibling backend identity.
    """
    from linux_settings_status import status, available
    if not available() or not hasattr(os, 'pidfd_open'):return 0
    parent = os.getppid()
    expected = (Path(__file__).resolve().parent / 'bin/ufxplus-native').resolve()
    child = Path('/proc') / str(backend_pid)
    def identity(require_executable=True):
        fields = (child / 'stat').read_text().rsplit(')',1)[1].split()
        if fields[1] != str(parent) or (require_executable and (child/'exe').resolve() != expected):
            raise ValueError('Backend is not this launcher child')
        return fields[19]
    try:
        started = identity(False)
        descriptor = os.pidfd_open(backend_pid)
    except (OSError,ValueError):return 0
    try:
        poll = select.poll();poll.register(descriptor, select.POLLIN)
        # A shell background PID can be published before its exec. Pin that
        # exact child first, then wait for its expected executable to appear.
        deadline=time.monotonic()+5
        while True:
            if poll.poll(20):return 0
            if identity(False) != started:return 0
            if (child/'exe').resolve() == expected:break
            if time.monotonic() >= deadline:
                signal.pidfd_send_signal(descriptor,signal.SIGTERM)
                return 1
        path = Path(os.environ.get('OSCMIX_RME_RUNTIME_STATUS') or
                    (Path(os.environ['XDG_RUNTIME_DIR']) / 'rme-native/devices.json'))
        previous = object()
        while not poll.poll(500):
            try:
                os.kill(ui_pid, 0)
                current = wake_key(path, uid)
                if current == previous:continue
                value = status(uid)
                previous = current
                if value.get('native') is not True:continue
                if control_transition(value, baseline):
                    signal.pidfd_send_signal(descriptor, signal.SIGTERM)
                    return 0
                if admitted_services(value):
                    baseline = value
            except ProcessLookupError:return 0
            except (OSError,ValueError,KeyError,RuntimeError,subprocess.SubprocessError):
                # A failed read is not permission to kill or replay a command.
                continue
    finally:
        os.close(descriptor)
    return 0


def common_snapshot():
    """Reuse the Linux authority after the historical owner has delegated.

    The UFX+ mixer still owns its existing IF1 helper. This only changes the
    read-only audio readiness gate; it cannot start or recover an audio owner.
    """
    try:
        from device_inventory import enumerate_cached, records
        from native_runtime import current_attachment
        from linux_settings_status import available, status
        if not available():return None
        devices = enumerate_cached()
        bindings = [row for row in records(devices) if row[6] == '1']
        selected = os.environ.get('OSCMIX_BOUND_DEVICE_UID')
        if selected:bindings = [row for row in bindings if row[0] == selected]
        if len(bindings) != 1:return None
        uid = bindings[0][0]
        device = next(item for item in devices if item['uid'] == uid)
        value = status(uid)
        if value.get('native') is not True:return None
        marker = value.get('marker') or {}
        attachment = marker.get('attachment') or {}
        if any(attachment.get(key) != val for key,val in current_attachment(device).items()):
            return None
        required = ('manager_pid','manager_process_start','owner_pid','owner_process_start',
                    'worker_pid','worker_process_start','generation')
        if any(isinstance(marker.get(key),bool) or not str(marker.get(key)).isdigit()
               or int(marker[key]) <= 0 for key in required):return None
        if not isinstance(marker.get('manager_nonce'), str) or not marker['manager_nonce']:return None
        ready = (value['state'] in ('running','recovering') and value['alsa']['ready']
                 and (value['pipewire']['ready'] or value['state'] == 'recovering'
                      or (value.get('applied') or {}).get('backend') == 'alsa'))
        return dict(schema=1,common_owner=True,uid=uid,
                    state='running' if ready else 'preparing',
                    pid=marker['manager_pid'],process_start=marker['manager_process_start'],
                    worker_pid=marker['worker_pid'],worker_process_start=marker['worker_process_start'],
                    session=f"{marker['manager_nonce']}:{marker['generation']}:{marker.get('audio_format_generation',0)}",
                    attachment=attachment)
    except (ImportError,OSError,ValueError,KeyError,IndexError,TypeError,RuntimeError,subprocess.SubprocessError):
        return None


def snapshot(runtime=None, proc=Path("/proc")):
    try:
        runtime = Path(runtime or os.environ["XDG_RUNTIME_DIR"])
        data = json.loads((runtime / "ufxplus-session.json").read_text())
        if not isinstance(data, dict):
            return None
        pid = data["pid"]
        if data.get("schema") != 1 or type(pid) is not int or pid <= 0:
            return None
        fields = (proc / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
        if fields[19] != data["process_start"]:
            return None
        if data.get('state') in ('delegated','delegation-error'):
            # An old session key cannot authorize the new audio generation.
            return common_snapshot() or dict(data,state='worker-unavailable')
        if data.get("state") == "running":
            worker = data["worker_pid"]
            try:
                child = proc / str(worker)
                valid = (type(worker) is int and worker > 0
                    and (child / "stat").read_text().rsplit(")", 1)[1].split()[1] == str(pid)
                    and os.readlink(child / "exe").removesuffix(" (deleted)") == "/usr/bin/ufxplus-live-capture")
            except OSError:
                valid = False
            if not valid:
                # The worker may exit just before the supervisor publishes the
                # disconnect. Keep waiting, but NEVER authorize a new backend.
                data = dict(data, state="worker-unavailable")
        return data
    except (OSError, ValueError, KeyError, IndexError, TypeError):
        return None


def key(data):
    prefix = f"{data['uid']}:native:" if data.get('common_owner') else ''
    return prefix + f'{data["pid"]}:{data["process_start"]}:{data["session"]}'


def wait(previous, ui_pid):
    # Runs only while disconnected. One small tmpfs read per second; no shell,
    # systemctl, USB scans or growing threads while the mixer is connected.
    while True:
        try:
            os.kill(ui_pid, 0)
        except ProcessLookupError:
            return 3
        data = snapshot()
        if data is None or data.get("state") == "stopped":
            return 2
        if data.get("state") == "running" and key(data) != previous:
            print(key(data), flush=True)
            return 0
        time.sleep(1)


def main():
    if len(sys.argv) == 4 and sys.argv[1] == 'admit':
        print(json.dumps(admission(sys.argv[2],int(sys.argv[3]))),flush=True)
        return 0
    if len(sys.argv) == 6 and sys.argv[1] == 'watch':
        return watch(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), json.loads(sys.argv[5]))
    if sys.argv[1:] == ["current"]:
        data = snapshot()
        if data is None:
            return 2
        print(key(data))
        return 0
    if len(sys.argv) == 4 and sys.argv[1] == "wait":
        return wait(sys.argv[2], int(sys.argv[3]))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
