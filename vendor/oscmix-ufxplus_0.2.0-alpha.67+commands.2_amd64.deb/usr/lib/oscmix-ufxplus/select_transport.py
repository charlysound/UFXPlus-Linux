"""Read-only launcher discovery; never switch hardware modes or claim USB.

The native helper still enforces the full descriptor fingerprint. CC discovery
accepts only a kernel Fireface UFX+ sequencer client with the established three
ports (two physical MIDI ports, followed by the control port). A userspace
native MIDI bridge is not a Class Compliant control device.
"""
import argparse
from pathlib import Path
import re
import subprocess
import sys


def cc_ports(listing):
    clients = []
    current = None
    for line in listing.splitlines():
        match = re.match(r"client (\d+): '(.*)' \[(.*)\]", line)
        if match:
            number, name, attrs = match.groups()
            current = None
            if name.startswith('Fireface UFX+') and re.search(r'\btype=kernel\b', attrs):
                current = (number, [])
                clients.append(current)
        elif current is not None:
            match = re.match(r"\s+(\d+)\s+'", line)
            if match:
                current[1].append(int(match.group(1)))
    return [f'{client}:2' for client, ports in clients if sorted(ports) == [0, 1, 2]]


def native_count(root=Path('/sys/bus/usb/devices')):
    count = 0
    for device in root.iterdir():
        try:
            if ((device / 'idVendor').read_text().strip() == '2a39'
                    and (device / 'idProduct').read_text().strip() == '3fc1'):
                count += 1
        except OSError:
            continue
    return count


def select(native, ports, requested='auto', port=None):
    if port is not None:
        if requested == 'native-usb3' or port not in ports:
            raise ValueError('The requested port is not a detected UFX+ CC control port.')
        return 'class-compliant', port
    if requested == 'auto':
        if not native and not ports:
            raise ValueError('No UFX+ detected in native USB3 or Class Compliant mode. Check power, USB connection and Linux device visibility. No device mode was changed.')
        if native and ports:
            raise ValueError('Both modes are present. Select --native-usb3 or --class-compliant explicitly.')
        requested = 'native-usb3' if native else 'class-compliant'
    if requested == 'native-usb3':
        if not native:
            raise ValueError('No native USB3 UFX+ detected.' +
                             (' A CC control port is present; use the automatic launcher or --class-compliant.' if ports else ' Check power, USB connection and Linux device visibility.') +
                             ' No device mode was changed.')
        if native != 1:
            raise ValueError('Exactly one native USB3 UFX+ is required; no hardware mode was changed.')
        return requested, '-'
    if not ports:
        raise ValueError('No UFX+ CC control port detected.' +
                         (' A native USB3 device is present; use the automatic launcher or --native-usb3.' if native else ' Check power, USB connection, device mode and ALSA MIDI availability.') +
                         ' No device mode was changed.')
    if len(ports) != 1:
        raise ValueError('Exactly one UFX+ CC control port is required. For multiple devices use --cc-port CLIENT:PORT. No device mode was changed.')
    return requested, ports[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--native-usb3', action='store_true')
    mode.add_argument('--class-compliant', action='store_true')
    parser.add_argument('--cc-port')
    parser.add_argument('--list-devices', action='store_true')
    args = parser.parse_args()
    try:
        listing = subprocess.run(['aconnect', '-l'], capture_output=True, text=True,
                                 timeout=3, env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'})
        ports = cc_ports(listing.stdout)
    except (OSError, subprocess.TimeoutExpired):
        ports = []
    native = native_count()
    if args.list_devices:
        print(f'Native USB3 candidates: {native}')
        print('CC control ports: ' + (', '.join(ports) or 'none'))
        return 0
    requested = 'native-usb3' if args.native_usb3 else 'class-compliant' if args.class_compliant else 'auto'
    try:
        print(*select(native, ports, requested, args.cc_port))
    except ValueError as error:
        print(error, file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
