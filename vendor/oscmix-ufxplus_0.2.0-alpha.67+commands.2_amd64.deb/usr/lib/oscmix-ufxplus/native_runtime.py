"""Read the native per-device supervisor; never owns or writes USB."""
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time


def current_attachment(device, sysfs=Path('/sys/bus/usb/devices')):
    node = sysfs / device['usb_path']
    info = node.stat()
    return dict(sysfs_inode=info.st_ino, sysfs_ctime_ns=info.st_ctime_ns,
                bus=int((node/'busnum').read_text()), address=int((node/'devnum').read_text()),
                descriptor_sha256=hashlib.sha256((node/'descriptors').read_bytes()).hexdigest())


def ready(path, uid, attachment):
    """Only a private snapshot of this exact attachment can admit a mixer."""
    path = Path(path)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'r') as stream:
        info = os.fstat(stream.fileno())
        if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o600 or not stat.S_ISREG(info.st_mode):
            raise ValueError('Invalid native runtime status ownership')
        payload = stream.read(2_000_001)
    if len(payload) > 2_000_000:
        raise ValueError('Native runtime status too large')
    data = json.loads(payload)
    if data.get('schema') != 1 or data.get('closing') or data.get('inventory_error'):
        return False
    pid = data.get('manager_pid')
    if type(pid) is not int or pid <= 0:
        return False
    os.kill(pid, 0)
    matches = [row for row in data.get('devices', []) if row.get('uid') == uid]
    if len(matches) != 1:
        return False
    row = matches[0]
    if any(row.get('attachment', {}).get(key) != value for key, value in attachment.items()):
        return False
    if row.get('status') == 'error':
        raise RuntimeError('Native audio session failed: ' + str(row.get('error', 'see runtime status')))
    return row.get('status') in ('running', 'external_owner')


def rate_transition(value, baseline):
    """A published transition from this exact admitted session, not a retry."""
    if value.get('state') == 'hardware_changing':
        change, marker = value.get('hardware_change'), value.get('marker') or {}
        previous = baseline.get('marker') or {}
        if (not isinstance(change, dict) or not isinstance(change.get('request_id'), str)
                or not change['request_id'] or len(change['request_id']) > 128
                or any(ord(c) < 32 or ord(c) == 127 for c in change['request_id'])
                or type(change.get('from_generation')) is not int
                or change['from_generation'] != previous.get('generation')
                or change.get('phase') not in ('stopping','waiting_control','applying','starting')
                or value.get('uid') != baseline.get('uid')
                or any(marker.get(k) != previous.get(k) for k in
                       ('manager_pid','manager_process_start','manager_nonce','attachment'))):
            raise RuntimeError('Hardware transition belongs to another session')
        return dict(change, _kind='hardware', _marker=dict(previous))
    if value.get('state') != 'rate_changing':
        return None
    change, marker = value.get('rate_change'), value.get('marker') or {}
    previous = baseline.get('marker') or {}
    if (not isinstance(change, dict) or not isinstance(change.get('request_id'), str)
            or not change['request_id'] or len(change['request_id']) > 128
            or any(ord(c) < 32 or ord(c) == 127 for c in change['request_id'])
            or type(change.get('from_generation')) is not int
            or change['from_generation'] != previous.get('generation')
            or not isinstance(change.get('phase'), str) or not change['phase']
            or change['phase'] in ('applied', 'error')
            or type(change.get('requested_rate_hz')) is not int
            or change['requested_rate_hz'] <= 0
            or value.get('uid') != baseline.get('uid')
            or any(marker.get(k) != previous.get(k) for k in
                   ('manager_pid', 'manager_process_start', 'manager_nonce', 'attachment'))):
        raise RuntimeError('Sample-rate transition belongs to another session')
    return dict(change)


def rate_transition_applied(value, change):
    if change.get('_kind') == 'hardware':
        current, marker = value.get('hardware_change') or {}, value.get('marker') or {}
        previous = change['_marker']
        if any(marker.get(k) != previous.get(k) for k in
               ('manager_pid','manager_process_start','manager_nonce','attachment')):
            raise RuntimeError('Hardware transition authority changed')
        # An explicit return from external clock may have a new request ID.
        # It must still acknowledge a newer generation of this same attachment.
        if current.get('phase') == 'error':
            raise RuntimeError(current.get('error') or 'Hardware settings change failed')
        return (current.get('phase') == 'applied' and current.get('audio_resumed') is True
                and type(current.get('to_generation')) is int
                and current['to_generation'] > change['from_generation']
                and marker.get('generation') == current['to_generation']
                and type(marker.get('audio_format_generation')) is int
                and marker['audio_format_generation'] > 0
                and type(current.get('observed_rate_hz')) is int
                and current['observed_rate_hz'] > 0
                and value.get('rate') == current['observed_rate_hz']
                and all(type(current.get(k)) is int and current[k] > 0
                        and current[k] == value.get(k) for k in
                        ('capture_channels','playback_channels')))
    current = value.get('rate_change') or {}
    if current.get('request_id') != change['request_id']:
        raise RuntimeError('Sample-rate transition was replaced')
    if current.get('phase') == 'error':
        raise RuntimeError(current.get('error') or 'Sample-rate change failed')
    marker = value.get('marker') or {}
    return (current.get('phase') == 'applied'
            and current.get('from_generation') == change['from_generation']
            and type(current.get('to_generation')) is int
            and current['to_generation'] > change['from_generation']
            and marker.get('generation') == current['to_generation']
            and type(marker.get('audio_format_generation')) is int
            and marker['audio_format_generation'] > 0
            and current.get('observed_rate_hz') == change['requested_rate_hz']
            and value.get('rate') == change['requested_rate_hz'])


def wait_audio(uid, incarnation, cancelled=lambda: False, timeout=30, transition=None):
    from device_inventory import enumerate_cached, records
    from linux_settings_status import available, status, SettingsStatusError
    common = available()
    configured = os.environ.get('OSCMIX_RME_RUNTIME_STATUS')
    if transition and not common:
        raise RuntimeError('Sample-rate authority is unavailable')
    if not configured and not common:
        return  # Older installations retain their independently owned session.
    deadline = time.monotonic() + timeout
    while not cancelled():
        devices = enumerate_cached()
        rows = records(devices)
        if not any(row[0] == uid and row[5] == incarnation for row in rows):
            raise RuntimeError('Selected native device connection changed')
        device = next(d for d in devices if d['uid'] == uid)
        try:
            if common:
                value = status(uid)
                marker = value.get('marker') or {}
                if transition and transition.get('_kind') == 'hardware' and value['state'] == 'clock_idle':
                    # Explicit external-clock idle is an intentional stopped state.
                    # Keep cancellation live while waiting for a user Internal request.
                    deadline = time.monotonic() + timeout
                applied = not transition or rate_transition_applied(value, transition)
                if (value['state'] in ('running', 'recovering') and value['alsa']['ready'] and
                        applied and
                        all(marker.get('attachment', {}).get(key) == expected
                            for key, expected in current_attachment(device).items())):
                    return value
                if value['state'] in ('error', 'failed'):
                    raise RuntimeError(value.get('error') or 'Native audio session failed')
            elif ready(configured, uid, current_attachment(device)):
                return
        except SettingsStatusError as error:
            if error.code not in ('unavailable', 'busy'):
                raise
        except FileNotFoundError:
            pass
        if time.monotonic() >= deadline:
            raise RuntimeError('Native audio owner did not become available')
        time.sleep(.25 if common else .1)
    raise RuntimeError('Native session cancelled')


def wait_binding(helper, uid, previous, ui_pid):
    """New attachment of the same UID only; absence never selects another card."""
    while True:
        try:
            os.kill(ui_pid, 0)
        except ProcessLookupError:
            return 3
        try:
            result = subprocess.run([sys.executable, helper, '--bind-legacy'],
                                    capture_output=True, text=True, timeout=4, check=True)
            fields = result.stdout.strip().split('\t')
            if len(fields) == 2 and (not uid or fields[0] == uid) and fields[1] != previous:
                print('\t'.join(fields), flush=True)
                return 0
        except (OSError, subprocess.SubprocessError):
            pass
        time.sleep(.5)


if __name__ == '__main__':
    if len(sys.argv) == 6 and sys.argv[1] == 'wait-binding':
        raise SystemExit(wait_binding(sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5])))
    raise SystemExit(2)
