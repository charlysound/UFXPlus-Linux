"""Native Full FX intentions, applied by the bound Linux audio owner only.

No USB command or effect store. Availability is static; completion/admission
belongs to the actual audio worker and its revision-bound named endpoint.
"""
import importlib.util
import sys

REFERENCE='75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'
NAMES=('reverb_enabled','reverb_type','reverb_predelay','reverb_lowcut','reverb_highcut','reverb_attack','reverb_hold','reverb_release','reverb_roomscale','reverb_time','reverb_highdamp','reverb_smoothness','reverb_volume','reverb_width','echo_enabled','echo_type','echo_delay','echo_feedback','echo_highcut','echo_volume','echo_width')

def capability(description):
    cap=description.get('capabilities',{}).get('software_effects')
    if cap is None or isinstance(cap,dict) and cap.get('available') is False:return None
    if (not isinstance(cap,dict) or type(cap.get('schema')) is not int or cap['schema']!=1
            or cap.get('available') is not True or cap.get('admitted') is not False
            or cap.get('implementation')!='host_cpu' or cap.get('admission_authority')!='audio_owner'
            or cap.get('value_unit')!='native_scaled_i16' or cap.get('parameter_count')!=21
            or cap.get('reference_sha256')!=REFERENCE
            or cap.get('value_maps')!={'reverb_type':list(range(15))}):raise RuntimeError('Invalid native software effects authority')
    descriptors=cap.get('parameters');fields={}
    if not isinstance(descriptors,list) or len(descriptors)!=21:raise RuntimeError('Incomplete native software effects descriptors')
    for d in descriptors:
        if (not isinstance(d,dict) or d.get('parameter') not in NAMES or d['parameter'] in fields
                or any(type(d.get(k)) is not int for k in ('native_parameter','min','max','step','scale','initial'))
                or d['native_parameter']!=44+NAMES.index(d['parameter'])
                or not -32768<=d['min']<=d['initial']<=d['max']<=32767 or d['step']<=0 or d['scale']<=0
                or (d['initial']-d['min'])%d['step']):raise RuntimeError('Invalid native software effects descriptor')
        fields[d['parameter']]=dict(d)
    defaults=description.get('host_mixer_defaults',{}).get('software_effects')
    if (not isinstance(defaults,dict) or defaults.get('provenance')!='native_full_global_descriptors_1000f2b30_100240060'
            or defaults.get('hardware_confirmed') is not False or defaults.get('values')!={name:fields[name]['initial'] for name in NAMES}
            or any(type(v) is not int for v in defaults['values'].values())):raise RuntimeError('Invalid native software effects Full intentions')
    return fields

def profile_lines(description):
    fields=capability(description)
    return [] if fields is None else ['software-effects\t1']+[f"software-effect-parameter\t{name}\t{d['native_parameter']}\t{d['min']}\t{d['max']}\t{d['step']}\t{d['scale']}\t{d['initial']}\t-1" for name,d in fields.items()]

def client_for(uid,marker):
    path='/usr/lib/rme-native-host/settings'
    if path not in sys.path:sys.path.insert(0,path)
    import software_effects_control
    return software_effects_control.Client.from_uid(uid,marker)

class Records:
    def __init__(self,description,factory=None):
        self.fields=capability(description);self.values={};self.ready=False;self.client=None;self.revision=None;self.identity=None;self.factory=factory;self.error='Software effects are unavailable for this audio connection'
    def accept(self,coordinate,value):
        p=coordinate>>8&255;name=NAMES[p-44] if 44<=p<=64 else None
        if self.fields is None or coordinate&255 or name is None or type(value) is not int:raise RuntimeError('Invalid software effects coordinate')
        d=self.fields[name]
        if not d['min']<=value<=d['max'] or (value-d['min'])%d['step']:raise RuntimeError('Invalid software effects value')
        if name in self.values:raise RuntimeError('Duplicate software effects intention')
        self.values[name]=value
    def validate_initial(self):
        if self.fields is not None and set(self.values)!=set(NAMES):raise RuntimeError('Incomplete native software effects opening intention')
    def status_valid(self,value,expected=None):
        if (not isinstance(value,dict) or value.get('identity')!=self.identity or value.get('state') not in ('ready','active')
                or type(value.get('revision')) is not int or value.get('hardware_confirmed') is not False
                or value.get('host_intentions') is not True or value.get('parameters')!=expected and expected is not None):raise RuntimeError('Software effects completion is not confirmed')
        params=value.get('parameters')
        if not isinstance(params,dict) or set(params)!=set(NAMES):raise RuntimeError('Invalid software effects state')
        for name,v in params.items():
            d=self.fields[name]
            if type(v) is not int or not d['min']<=v<=d['max'] or (v-d['min'])%d['step']:raise RuntimeError('Software effects state is outside native UI domains')
        return value
    def commit(self,initial=False):
        if self.fields is None:return True
        if initial:self.validate_initial()
        if not self.values:return self.ready
        try:
            if self.client is None:
                if self.factory is None:raise RuntimeError(self.error)
                self.client=self.factory();status=self.client.status();self.identity=status.get('identity');self.status_valid(status);self.revision=status['revision']
            if not initial and not self.ready:raise RuntimeError(self.error)
            expected=dict(self.client.status()['parameters']) if initial else dict(self.last)
            expected.update(self.values)
            reply=self.client.set(self.revision,dict(self.values));self.status_valid(reply,expected)
            if reply['revision']!=self.revision+1:raise RuntimeError('Software effects revision was not completed')
            self.revision=reply['revision'];self.last=expected;self.values.clear();self.ready=True;self.error='';return True
        except (RuntimeError,OSError,ValueError,KeyError,TypeError,ImportError,AttributeError) as error:
            self.ready=False;self.error=str(error);self.values.clear();return False
