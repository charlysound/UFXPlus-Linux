"""Common sparse matrix opening, live coefficients and completion fences.

Model adapters validate producer metadata; only the native owner encodes and
allocates the sparse pool or sends USB. No GUI-side per-device transport.
"""
import native_scalar_session as shared

REFERENCE = '75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'


def bank_contract(description, model):
    """Three producer-owned banks, including output-only or PB Phones slots."""
    geometry=description.get('mixer_geometry')
    if (not isinstance(geometry,dict) or type(geometry.get('schema')) is not int or geometry['schema']!=1
            or not isinstance(model.get('ports'),dict) or not isinstance(model.get('active'),dict)
            or not isinstance(model.get('storage'),dict)):
        raise RuntimeError('Invalid native sparse bank metadata')
    banks={}
    for bank,key,slot in (('input','inputs','input_slots'),('playback','playbacks','playback_slots'),('output','outputs','output_slots')):
        storage,ports,active=geometry.get(slot),model['ports'].get(key),model['active'].get(bank)
        if (type(storage) is not int or not 1<=storage<=256 or model['storage'].get(bank)!=storage
                or model.get(slot)!=storage or not isinstance(ports,list) or not ports
                or any(not isinstance(port,dict) for port in ports) or not isinstance(active,list)):
            raise RuntimeError('Invalid native sparse bank metadata')
        channels=[port.get('native_channel') for port in ports]
        if (any(type(ch) is not int or not 1<=ch<=storage for ch in channels)
                or channels!=sorted(set(channels)) or active!=[ch-1 for ch in channels]
                or any(type(ch) is not int for ch in active) or model.get('active_'+key)!=active):
            raise RuntimeError('Invalid native sparse active coordinates')
        banks['outputs' if bank=='output' else bank]=tuple(active)
    if description.get('inputs')!=model['ports']['inputs'] or description.get('outputs_and_playbacks')!=model['ports']['outputs']:
        raise RuntimeError('Inconsistent native sparse compatibility ports')
    return model,banks


def profile_lines(description,name,contract):
    """Existing model/profile/renderer; no frontend slot or naming table."""
    from native_legacy_session import append_host_defaults
    model,_=contract(description)
    lines=['#oscmix-native-profile-v1','name\t'+name.replace('\t',' ').replace('\n',' '),
           'geometry\t'+'\t'.join(str(description['mixer_geometry'][k]) for k in ('input_slots','playback_slots','output_slots'))]
    for kind,key in (('input','inputs'),('playback','playbacks'),('output','outputs')):
        for port in model['ports'][key]:
            label=port.get('display_name')
            if (not isinstance(label,str) or not label.strip() or len(label.encode('utf-8'))>=32
                    or any(ord(ch)<32 or ord(ch)==127 for ch in label)
                    or port.get('display_name_reference_sha256')!=REFERENCE):
                raise RuntimeError('Invalid native sparse display name')
            lines.append(f"{kind}\t{port['native_channel']-1}\t{label}")
    if description.get('host_mixer_defaults',{}).get('channel_defaults',{}).get('mute') is not False:
        raise RuntimeError('Invalid native sparse initial mute intention')
    append_host_defaults(lines,description)
    lines.extend(shared.matrix_monitor_profile(description))
    lines.append(f"native-renderer-flags\t{model['renderer_flags']}")
    return lines


def meter_messages(decoded,description):
    ports=description['native_model']['ports']
    return shared.meter_messages(decoded,description,dict(input=ports['inputs'],playback=ports['playbacks'],output=ports['outputs']))


class UnavailablePhysicalControls(shared.PhysicalControls):
    """An unavailable observation never becomes a gain or an adoption."""
    def __init__(self,description):
        super().__init__(description)
        initial=description.get('physical_controls')
        self.reason=initial.get('reason') if isinstance(initial,dict) else None
        if not isinstance(self.reason,str) or not self.reason:
            raise RuntimeError('Missing native physical-control unavailability')
        self.accept(initial)

    def accept(self,value,now=None):
        if (not isinstance(value,dict) or type(value.get('schema')) is not int or value['schema']!=1
                or value.get('identity')!=self.identity or value.get('source')!='unavailable'
                or value.get('state')!='unavailable' or value.get('hardware_observed') is not False
                or value.get('hardware_matrix_readback') is not False or value.get('adoption_admitted') is not False
                or value.get('values')!=[] or type(value.get('sequence')) is not int or value['sequence']!=0
                or value.get('age_ms') is not None or value.get('reason')!=self.reason):
            raise RuntimeError('Invalid native sparse physical-control availability')
        return []


class TypedSparsePipe(shared.TypedMixerPipe):
    """Collect the whole opening matrix before the owner's first clear/OUT."""
    def __init__(self, *args, **kwargs):
        description = kwargs['equalizer_description']
        model, self.banks = self.model_contract(description)
        self.capacity = model['slot_capacity']
        self.maintenance_packets = model['initial_maintenance_usb_packets']
        self.initial = {}
        self.initial_records = 0
        self.matrix_restored = False
        super().__init__(*args, **kwargs)
        self.expected = (len(self.banks['input']) + len(self.banks['playback'])) * len(self.banks['outputs']) + len(self.banks['outputs'])

    def coordinate(self, command):
        kind = command.get('kind')
        if kind not in ('input', 'playback', 'output_gain'):
            raise RuntimeError('Unadmitted native sparse parameter')
        output, units = command.get('output'), command.get('units')
        if (type(output) is not int or output not in self.banks['outputs']
                or type(units) is not int or not -131072 <= units <= 131071):
            raise RuntimeError('Invalid native sparse coefficient or output')
        source = None if kind == 'output_gain' else command.get('source')
        if source is not None and (type(source) is not int or source not in self.banks[kind]):
            raise RuntimeError('Invalid native sparse source')
        if kind != 'output_gain' and source is None:
            raise RuntimeError('Missing native sparse source')
        return kind, source, output

    def completed(self, answer, count, restoring=False, equalizer_maintenance=0):
        if (not isinstance(answer, dict) or answer.get('error')
                or answer.get('identity', self.identity) != self.identity
                or type(answer.get('sequence')) is not int or answer['sequence'] != self.sequence
                or answer.get('accepted_by_host') is not True
                or answer.get('hardware_confirmed') is not False
                or answer.get('session_retired') is not False
                or answer.get('state_complete') is not True
                or type(answer.get('commands_completed')) is not int or answer['commands_completed'] != count
                or any(type(answer.get(key)) is not int or answer[key] < 0
                       for key in ('usb_completed', 'host_noops', 'maintenance_usb_completed'))
                or answer['host_noops'] > count
                or answer['usb_completed'] > 2 * count
                or answer['maintenance_usb_completed'] != (self.maintenance_packets+(2 if self.private_fx.cap else 0)+equalizer_maintenance if restoring else 0)):
            raise RuntimeError('Native sparse completion incomplete; session retired')

    def _flush_commands(self):
        if not self.commands:
            return
        for command in self.commands:
            if command.get('kind')=='equalizer':
                if not self.matrix_restored or self.equalizer is None:raise RuntimeError('Uninitialized native sparse EQ')
                continue
            key=self.coordinate(command)
            if not self.matrix_restored:self.initial[key]=command['units']
        if not self.matrix_restored:
            self.initial_records += len(self.commands)
            if self.initial_records > 4 * self.expected:
                raise RuntimeError('Native sparse opening intention exceeds its geometry')
        else:
            if self.equalizer is not None:self.equalizer.validate_commands(self.commands)
            if self.sequence == 2**64 - 1:
                raise RuntimeError('Native mixer sequence exhausted')
            self.sequence += 1
            answer = self.send(dict(op='set', identity=self.identity, sequence=self.sequence, commands=self.commands))
            self.completed(answer,len(self.commands))
            if self.equalizer is not None:
                self.equalizer.completed(self.commands)
                feedback=[word for command in self.commands if command.get('kind')=='equalizer' for word in self.equalizer.feedback(command)]
                for start in range(0,len(feedback),128):self.acknowledge(shared.local_sysex(0,feedback[start:start+128]))
        self.commands.clear()

    def restore_equalizers(self):
        # One opening transaction prevalidates all physical/private/EQ data
        # before the owner's first clear. Completion precedes ACK99/READY.
        if self.matrix_restored or len(self.initial) != self.expected:
            raise RuntimeError('Incomplete or duplicate native sparse opening intention')
        outputs = self.banks['outputs']
        payload = {bank: [self.initial[(bank, source, output)] for output in outputs for source in self.banks[bank]]
                   for bank in ('input', 'playback')}
        payload['outputs'] = [self.initial[('output_gain', None, output)] for output in outputs]
        if self.private_fx.cap:payload['fx_bus']=self.private_fx.matrix()
        equalizers=[];sweep=0
        if self.equalizer is not None and self.equalizer.cap is not None:
            if self.equalizer.cap.get('restore_transport')!='restore_matrix':raise RuntimeError('Unsupported sparse EQ restore transport')
            equalizers=self.equalizer.initial_commands()
            payload['equalizers']=equalizers
            allocated=sum(c['settings']['enabled'] or c['settings']['lowcut_enabled'] for c in equalizers)
            sweep=self.equalizer.cap['initial_clear_entries']-allocated
        if sum(value != 0 for bank in ('input', 'playback') for value in payload[bank]) > self.capacity:
            raise RuntimeError('Native sparse opening intention exceeds the sparse pool')
        if self.sequence == 2**64 - 1:
            raise RuntimeError('Native mixer sequence exhausted')
        self.sequence += 1
        answer = self.send(dict(op='restore_matrix', identity=self.identity, sequence=self.sequence, **payload))
        self.completed(answer,self.expected+self.private_fx.count+len(equalizers),restoring=True,equalizer_maintenance=sweep)
        current=self.send(dict(op='describe')) if self.private_fx.cap or equalizers else None
        if equalizers:
            self.equalizer.confirm(current,self.identity,equalizers)
            for command in equalizers:self.acknowledge(shared.local_sysex(0,self.equalizer.feedback(command)))
        if self.private_fx.cap:self.private_fx.confirm(current,self.identity)
        self.matrix_restored = True
        self.initial.clear()

