"""MADI sparse adapter using the common scalar engine and per-UID session.

Only the native owner allocates slots, encodes words, clears the hardware and
advances its opening cycles. This bridge submits a complete host intention and
waits for completion; its feedback never represents hardware matrix readback.
"""
import math
import native_scalar_session as shared
from native_sparse_session import TypedSparsePipe

def model_contract(description):
    model, cap = description.get('native_model'), description.get('capabilities')
    geometry = description.get('mixer_geometry')
    if (not isinstance(model, dict) or model.get('codec') != 'madi_sparse'
            or model.get('native_class') != 29 or model.get('controller_family') != 12
            or model.get('renderer_flags') != 134217792
            or model.get('slot_capacity') not in (2048, 1024, 512)
            or model.get('matrix_queue_words') != 128
            or not isinstance(cap, dict) or cap.get('route_protocol') != 'MadiSparse'
            or cap.get('restore_transport') != 'restore_matrix' or cap.get('max_commands') != 128
            or cap.get('coefficient_commands') != ['input', 'playback', 'output_gain']
            or cap.get('matrix_readback') is not False or cap.get('set') is not False
            or cap.get('parameters') != [] or cap.get('fx_parameters') is not False
            or type(description.get('native_units_at_unity')) is not int
            or description['native_units_at_unity'] != 32768
            or type(description.get('coordinate_base')) is not int or description['coordinate_base'] != 0
            or not isinstance(geometry, dict) or geometry.get('schema') != 1
            or any(type(geometry.get(key)) is not int or not 1 <= geometry[key] <= 256
                   for key in ('input_slots', 'playback_slots', 'output_slots'))):
        raise RuntimeError('Invalid native MADI sparse model contract')
    banks = {}
    for bank, key, slot in (('input', 'inputs', 'input_slots'),
                            ('playback', 'outputs_and_playbacks', 'playback_slots'),
                            ('outputs', 'outputs_and_playbacks', 'output_slots')):
        ports = description.get(key)
        if not isinstance(ports, list) or not ports or any(not isinstance(port, dict) for port in ports):
            raise RuntimeError('Invalid native MADI active ports')
        channels = [port.get('native_channel') for port in ports]
        if (any(type(channel) is not int or not 1 <= channel <= geometry[slot] for channel in channels)
                or len(channels) != len(set(channels))):
            raise RuntimeError('Invalid native MADI coordinates')
        banks[bank] = tuple(channel - 1 for channel in channels)
    equalizer=shared.native_scalar_equalizer.capability(description)
    if equalizer is None:
        if cap.get('equalizer')!={'available':False,'admitted':False}:
            raise RuntimeError('Invalid native MADI unavailable EQ contract')
    elif (equalizer.get('restore_transport')!='restore_matrix'
            or equalizer.get('initial_clear_entries')!=22
            or equalizer['inputs']!=frozenset(banks['input'])
            or equalizer['outputs']!=frozenset(banks['outputs'])):
        raise RuntimeError('Invalid native MADI EQ restoration or eligible ports')
    # Producers before the shared sparse metadata expose the same fixed MADI
    # opening: 2048 clear slots in sixteen 128-word packets.
    packets = model.get('initial_maintenance_usb_packets', 16)
    if type(packets) is not int or packets != 16:
        raise RuntimeError('Invalid native MADI clear metadata')
    return dict(model, initial_maintenance_usb_packets=packets), banks


def madi_profile(description, name):
    model, _ = model_contract(description)
    # The producer supplies the native Full template and active coordinates.
    # The common profile keeps mouse, mix math, cache and Control Room paths.
    lines = shared.profile_lines(description, name)
    defaults = description['host_mixer_defaults'].get('channel_defaults')
    if not isinstance(defaults, dict) or defaults.get('mute') is not False:
        raise RuntimeError('Invalid native MADI Full channel defaults')
    lines.append(f"native-renderer-flags\t{model['renderer_flags']}")
    return lines


class MadiPhysicalControls(shared.PhysicalControls):
    SOURCE = 'native_madi_status_usb'

    def accept(self, value, now=None):
        # Validate owner observations and their real provenance. Physical
        # controls remain unadmitted for projection until their scopes and
        # HAL semantics are ported; never turn them into DSP master feedback.
        super().accept(value, now)
        return []


class TypedMadiPipe(TypedSparsePipe):
    model_contract = staticmethod(model_contract)


def pcm_matches(description, admitted):
    geometry = description.get('pcm_geometry')
    return isinstance(geometry, dict) and all(type(geometry.get(key)) is int and geometry[key] == admitted.get(key)
        for key in ('capture_channels', 'playback_channels'))


def run(args, transition=None):
    return shared.run(args, transition, profile_builder=madi_profile,
                      pipe_type=TypedMadiPipe, admission_check=pcm_matches,
                      physical_type=MadiPhysicalControls)
