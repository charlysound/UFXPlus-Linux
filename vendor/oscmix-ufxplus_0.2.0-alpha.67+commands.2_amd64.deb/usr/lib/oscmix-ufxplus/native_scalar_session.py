"""Own one native scalar mixer and reuse OSCmix's existing mixing engine.

Only the typed controller writes hardware. MIDI echo is local host feedback.
A failed batch retires the entire session; there is no automatic replay.
"""
import argparse
import fcntl
import json
import math
import os
from pathlib import Path
import native_scalar_equalizer
import native_private_fx
import native_software_effects
import selectors
import select
import shutil
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import time
import threading

from device_inventory import enumerate_cached, records
from device_session import prepare


def request(path, value):
    with socket.socket(socket.AF_UNIX) as client:
        client.settimeout(7)
        client.connect(str(path))
        client.sendall(json.dumps(value).encode() + b'\n')
        response = bytearray()
        while b'\n' not in response:
            part = client.recv(65536)
            if not part or len(response) > 262144:
                raise RuntimeError('Incomplete mixer acknowledgement')
            response.extend(part)
        result = json.loads(response)
        if result.get('error'):
            raise RuntimeError(result['error'])
        return result


def osc_text(address, value):
    def string(value):
        raw = value.encode() + b'\0'
        return raw + bytes((-len(raw)) % 4)
    return string(address) + string(',s') + string(value)


def local_sysex(subid, words):
    payload = bytes((word >> shift) & 127 for word in words for shift in range(0, 35, 7))
    return b'\xf0\x00\x20\x0d\x10' + bytes((subid,)) + payload + b'\xf7'


def parameter_capabilities(description):
    """Use the native producer's attributed parameter bounds, never a PID table."""
    capabilities = description.get('capabilities', {})
    if not isinstance(capabilities, dict):
        raise RuntimeError('Invalid native mixer capabilities')
    parameters = capabilities.get('parameters', [])
    if not isinstance(parameters, list):
        raise RuntimeError('Invalid native parameter capabilities')
    result = {}
    for parameter in parameters:
        if not isinstance(parameter, dict):
            raise RuntimeError('Invalid native parameter capability')
        kind = parameter.get('kind')
        if kind not in ('input_phantom', 'input_gain', 'input_gain_tenths', 'input_high_z', 'output_loopback'):
            continue
        direction = 'outputs' if kind == 'output_loopback' else 'inputs'
        active = {port['native_channel'] - 1 for port in description['outputs_and_playbacks' if direction == 'outputs' else 'inputs']}
        channels = parameter.get(direction)
        value_type = {'input_gain':'integer_db','input_gain_tenths':'db_tenths'}.get(kind,'bool')
        if (parameter.get('value_type') != value_type
                or type(parameter.get('hardware_readback')) is not bool
                or not isinstance(channels, list) or not channels
                or any(type(channel) is not int or channel not in active or
                       not 0 <= channel <= 255 for channel in channels)
                or len(set(channels)) != len(channels) or kind in result):
            raise RuntimeError('Invalid native parameter capability')
        value_key = 'values_db_tenths' if kind == 'input_gain_tenths' else 'values_db'
        values = parameter.get(value_key) if kind in ('input_gain', 'input_gain_tenths') else None
        limit = 32760 if kind == 'input_gain_tenths' else 3276
        if kind in ('input_gain', 'input_gain_tenths') and (not isinstance(values, list) or not 1 <= len(values) <= 256
                or any(type(db) is not int or not -limit <= db <= limit for db in values)
                or sorted(set(values)) != values):
            raise RuntimeError('Invalid native gain capability')
        result[kind] = {direction:frozenset(channels), value_key:tuple(values) if values else ()}
    if (result.get('input_gain', {}).get('inputs', frozenset()) &
            result.get('input_gain_tenths', {}).get('inputs', frozenset())):
        raise RuntimeError('Ambiguous native gain unit capabilities')
    return result


def phantom_inputs(description):
    return parameter_capabilities(description).get('input_phantom', {}).get('inputs', frozenset())


def gain_inputs(description):
    cap = parameter_capabilities(description).get('input_gain', {})
    return {channel: cap['values_db'] for channel in cap.get('inputs', ())}


def gain_tenths_inputs(description):
    cap = parameter_capabilities(description).get('input_gain_tenths', {})
    return {channel: cap['values_db_tenths'] for channel in cap.get('inputs', ())}


def physical_output_ranges(description):
    active = {port['native_channel']-1 for port in description['outputs_and_playbacks']}
    result = {}
    for cap in description.get('capabilities', {}).get('parameters', []):
        if cap.get('kind') != 'output_physical_level':continue
        channels, lo, hi, step = (cap.get(key) for key in ('outputs','min','max','step'))
        if (cap.get('value_type') != 'db_tenths' or type(cap.get('hardware_readback')) is not bool
                or type(cap.get('native_renderer_complete')) is not bool
                or not isinstance(channels,list) or not channels
                or any(type(ch) is not int or ch not in active for ch in channels)
                or len(set(channels)) != len(channels) or result
                or any(type(n) is not int for n in (lo,hi,step))
                or not -32768 <= lo <= hi <= 32767 or not 1 <= step <= hi-lo+1
                or (hi-lo) % step):
            raise RuntimeError('Invalid native physical-output capability')
        result = {ch:(lo,hi,step) for ch in channels}
    return result


class PhysicalControls:
    """Project attributed encoder observations, without issuing USB writes.

    Per-control sequences prevent an unrelated new packet from replaying an old
    value. A completed local command also fences observations made before it.
    Output observations have a separate private event: they are physical levels,
    not the engine's digital output coefficient or its logical stereo fader.
    """
    REFERENCE = '19c8b7d292a8d1588e4a777d351d0489523bf2da3fab655269ea63fe6e07c2cb'
    SOURCE = 'native_encoder_usb'

    def __init__(self, description):
        self.identity = description['identity']
        self.inputs = {port['native_channel']-1 for port in description['inputs']}
        self.outputs = {port['native_channel']-1 for port in description['outputs_and_playbacks']}
        self.gains = gain_inputs(description)
        self.half_gains = gain_tenths_inputs(description)
        self.packets = 0
        self.sequences = {}
        self.local_after = {}

    def completed(self, commands):
        now = time.monotonic()
        for command in commands:
            if command['kind'] in ('input_gain', 'input_gain_tenths'):
                self.local_after[('input_gain_control', command['input'])] = now
            elif command['kind'] == 'output_physical_level':
                self.local_after[('output_level_control', command['output'])] = now

    def accept(self, value, now=None):
        if value is None:return []  # Earlier producer: keep observations unknown.
        now = time.monotonic() if now is None else now
        if (not isinstance(value, dict) or type(value.get('schema')) is not int or value['schema'] != 1
                or value.get('identity') != self.identity
                or value.get('source') != self.SOURCE
                or value.get('reference_sha256') != self.REFERENCE
                or value.get('matrix_readback') is not False
                or value.get('phantom_readback') is not False
                or value.get('implicit_writeback') is not False
                or value.get('value_unit') != 'native_ioaudio_level_control'
                or value.get('state') not in ('unknown', 'observed', 'unavailable')
                or value.get('hardware_observed') is not (value['state'] == 'observed')
                or type(value.get('packets')) is not int or not self.packets <= value['packets'] < 2**64
                or not isinstance(value.get('values'), list) or len(value['values']) > 260):
            raise RuntimeError('Invalid native physical-control observation')
        observations = []
        seen = set()
        for item in value['values']:
            if not isinstance(item, dict):raise RuntimeError('Invalid native physical control')
            kind, channel, db = item.get('kind'), item.get('channel'), item.get('db_tenths')
            key = (kind, channel) if type(channel) is int else None
            sequence, age = item.get('observation_sequence'), item.get('age_ms')
            allowed = self.inputs if kind == 'input_gain_control' else self.outputs
            if (kind not in ('input_gain_control', 'output_level_control') or key is None
                    or channel not in allowed or key in seen
                    or type(item.get('native_control_value')) is not int
                    or type(sequence) is not int or not 1 <= sequence <= value['packets']
                    or sequence < self.sequences.get(key, 0)
                    or type(age) is not int or not 0 <= age < 2**64
                    or (db is not None and (type(db) is not int or not -32768 <= db <= 32767))):
                raise RuntimeError('Invalid native physical-control coordinate or sequence')
            seen.add(key)
            if value['state'] != 'observed':raise RuntimeError('Unobserved native control has values')
            if sequence == self.sequences.get(key, 0):continue
            if db is None or now-age/1000 <= self.local_after.get(key, float('-inf')):continue
            if kind == 'input_gain_control':
                if not (db % 10 == 0 and db//10 in self.gains.get(channel, ())
                        or db in self.half_gains.get(channel, ())):
                    continue  # An attributed HAL value may be outside the command domain.
            observations.append((kind, channel, db))
        # A BF/Pro packet observes a complete physical output pair. Preserve
        # that fact for the logical stereo gain/balance callback; a recent side
        # cannot borrow its peer from an older encoder packet.
        values = {(item['kind'],item['channel']):item for item in value['values']}
        projected = {(kind,channel) for kind,channel,_ in observations}
        observations = [(kind,channel,db) for kind,channel,db in observations
            if kind != 'output_level_control' or
            (('output_level_control',channel^1) in projected
             and values[(kind,channel^1)]['db_tenths'] is not None
             and values[(kind,channel^1)]['observation_sequence'] == values[(kind,channel)]['observation_sequence'])]
        # Validate the entire snapshot before advancing any per-control cursor.
        self.packets = value['packets']
        for item in value['values']:
            self.sequences[(item['kind'], item['channel'])] = item['observation_sequence']
        return observations

    @staticmethod
    def profile(observations):
        return [f"physical-{'input-gain' if kind == 'input_gain_control' else 'output-level'}\t{channel}\t{db}"
                for kind, channel, db in observations]

    @staticmethod
    def feedback(observations):
        inputs = []
        outputs = []
        for kind, channel, db in observations:
            if kind == 'input_gain_control':
                word = ((0x1900+channel) << 16) | (db & 65535)
                inputs.append(word | ((1-word.bit_count()%2) << 31))
            else:
                outputs.append((channel << 16) | (db & 65535))
        return ([local_sysex(0, inputs)] if inputs else []) + ([local_sysex(98, outputs)] if outputs else [])


class TypedMixerPipe:
    """Serialize coefficients and local completion fences on one owner.

    A fence acknowledges completed writes, never hardware readback. Its reply
    stays on the private engine pipe and cannot become a device MIDI command.
    """
    FENCE_SUBIDS = frozenset((96, 99, 111, 113, 114, 103, 126))

    def __init__(self, identity, sequence, send, acknowledge, ready, phantom_channels=(), gain_channels=None,
                 high_z_channels=(), loopback_channels=(), gain_tenths_channels=None,
                 equalizer_description=None, defer_ready=False, physical_controls=None,
                 physical_output_channels=None, software_effects_factory=None):
        if type(sequence) is not int or not 0 <= sequence < 2**64:
            raise RuntimeError('Invalid native mixer sequence')
        self.identity, self.sequence = identity, sequence
        self.send, self.acknowledge, self.ready = send, acknowledge, ready
        self.pending = bytearray()
        self.commands = []
        self.announced_ready = False
        self.retired = False
        self.phantom_channels = frozenset(phantom_channels)
        self.gain_channels = dict(gain_channels or {})
        self.high_z_channels = frozenset(high_z_channels)
        self.loopback_channels = frozenset(loopback_channels)
        self.gain_tenths_channels = dict(gain_tenths_channels or {})
        self.equalizer = native_scalar_equalizer.Records(equalizer_description) if equalizer_description else None
        self.private_fx = native_private_fx.Records(equalizer_description or {})
        self.software_effects=native_software_effects.Records(equalizer_description or {},software_effects_factory)
        self.defer_ready = defer_ready
        self.open_completed = False
        self.physical_controls = physical_controls
        self.physical_output_channels = dict(physical_output_channels or {})

    def restore_fx_bus(self):
        fx=self.private_fx
        if fx.cap is None or fx.cap['restore_op']!='restore_fx_bus':return
        matrix=fx.matrix()
        if self.sequence==2**64-1:raise RuntimeError('Native mixer sequence exhausted')
        self.sequence+=1
        answer=self.send(dict(op='restore_fx_bus',identity=self.identity,sequence=self.sequence,fx_bus=matrix))
        fx.completed(answer,self.identity,self.sequence,fx.count,restoring=True)
        fx.confirm(self.send(dict(op='describe')),self.identity)

    def flush_private_fx(self):
        fx=self.private_fx
        if not fx.commands:return
        while fx.commands:
            commands=fx.commands[:128]
            if self.sequence==2**64-1:raise RuntimeError('Native mixer sequence exhausted')
            self.sequence+=1
            answer=self.send(dict(op='set_fx_bus',identity=self.identity,sequence=self.sequence,commands=commands))
            fx.completed(answer,self.identity,self.sequence,len(commands))
            del fx.commands[:len(commands)]

    def flush(self):
        self._flush_commands()
        self.flush_private_fx()

    def restore_equalizers(self):
        if self.equalizer is None or self.equalizer.cap is None:
            return
        commands = self.equalizer.initial_commands()
        if self.sequence == 2**64-1:raise RuntimeError('Native mixer sequence exhausted')
        self.sequence += 1
        answer = self.send(dict(op='restore_equalizers',identity=self.identity,sequence=self.sequence,commands=commands))
        noops = answer.get('host_noops') if isinstance(answer,dict) else None
        inactive = sum(not item['settings']['enabled'] and not item['settings']['lowcut_enabled'] for item in commands)
        if (not isinstance(answer,dict) or answer.get('error')
                or type(answer.get('sequence')) is not int or answer['sequence'] != self.sequence
                or answer.get('identity',self.identity) != self.identity
                or answer.get('accepted_by_host') is not True or answer.get('session_retired') is not False
                or type(answer.get('commands_completed')) is not int or answer['commands_completed'] != len(commands)
                or type(noops) is not int or not 0 <= noops <= inactive
                or type(answer.get('usb_completed')) is not int or answer['usb_completed'] != len(commands)-noops
                or type(answer.get('maintenance_usb_completed')) is not int
                or answer['maintenance_usb_completed'] != 22-(len(commands)-inactive)):
            raise RuntimeError('Native equalizer restoration incomplete; session retired')
        current = self.send(dict(op='describe'))
        self.equalizer.confirm(current,self.identity,commands)
        for item in commands:
            self.acknowledge(local_sysex(0,self.equalizer.feedback(item)))

    def _flush_commands(self):
        if not self.commands:
            return
        if self.sequence == 2**64 - 1:
            raise RuntimeError('Native mixer sequence exhausted')
        if self.equalizer is not None:self.equalizer.validate_commands(self.commands)
        self.sequence += 1
        count = len(self.commands)
        answer = self.send(dict(op='set', identity=self.identity,
                                sequence=self.sequence, commands=self.commands))
        noops = answer.get('host_noops', 0) if isinstance(answer, dict) else None
        inactive_eq = sum(command['kind'] == 'equalizer' and
                          command.get('settings', {}).get('enabled') is False and
                          command.get('settings', {}).get('lowcut_enabled') is False
                          for command in self.commands)
        if (not isinstance(answer, dict) or answer.get('error')
                or type(answer.get('sequence')) is not int
                or answer.get('sequence') != self.sequence
                or answer.get('identity', self.identity) != self.identity
                or answer.get('session_retired') is not False
                or answer.get('accepted_by_host') is not True
                or type(answer.get('usb_completed')) is not int
                or type(noops) is not int or not 0 <= noops <= inactive_eq
                or answer['usb_completed'] != count-noops
                or ('commands_completed' in answer and
                    (type(answer['commands_completed']) is not int or answer['commands_completed'] != count))
                or (noops and 'commands_completed' not in answer)):
            raise RuntimeError('Mixer write incomplete; session retired')
        if self.equalizer is not None:self.equalizer.completed(self.commands)
        feedback = []
        physical_feedback = []
        for command in self.commands:
            kind = command['kind']
            if kind == 'output_physical_level':
                physical_feedback.append((command['output'] << 16) | (command['db_tenths'] & 65535))
                continue
            if kind == 'equalizer':
                feedback.extend(self.equalizer.feedback(command))
                continue
            if kind not in ('input_phantom', 'input_gain', 'input_gain_tenths', 'input_high_z'):
                continue
            control = {'input_phantom':11, 'input_gain':9, 'input_gain_tenths':9, 'input_high_z':13}[kind]
            value = (command['db'] * 10 if kind == 'input_gain' else command['db_tenths']
                     if kind == 'input_gain_tenths' else int(command['enabled']))
            word = ((0x1000 + control * 256 + command['input']) << 16) | (value & 65535)
            word |= (1 - word.bit_count() % 2) << 31
            feedback.append(word)
        if feedback:
            # This private virtual-register feedback represents completed
            # parameter writes. It is neither USB data nor a hardware readback.
            for start in range(0,len(feedback),128):self.acknowledge(local_sysex(0,feedback[start:start+128]))
        if physical_feedback:
            # Completion of an explicit renderer command, distinct from an
            # actual encoder observation (98) and a logical output fader.
            self.acknowledge(local_sysex(97, physical_feedback))
        if self.physical_controls is not None:self.physical_controls.completed(self.commands)
        self.commands = []

    def feed(self, data):
        if self.retired:
            raise RuntimeError('Native mixer pipe retired')
        try:
            self.pending.extend(data)
            while len(self.pending) >= 8:
                coordinate, units = struct.unpack('<Ii', self.pending[:8])
                del self.pending[:8]
                kind = coordinate >> 16
                if kind == 0:
                    if coordinate or units or self.announced_ready or self.commands:
                        raise RuntimeError('Invalid or duplicate native engine readiness')
                    self.announced_ready = True
                    if not self.defer_ready:self.ready()
                    continue
                if not self.announced_ready:
                    raise RuntimeError('Native engine command before readiness')
                if kind == 45:
                    if coordinate & 65535 or units not in (1, 2) or (self.defer_ready and not self.open_completed) or (self.equalizer is not None and self.equalizer.pending):
                        raise RuntimeError('Invalid snapshot coefficient phase')
                    self.flush()
                    continue
                if self.defer_ready and not self.open_completed and kind in (5,6,7,8,10):
                    raise RuntimeError('Physical input and loopback parameters are excluded from native open')
                if kind == 4:
                    subid = coordinate & 65535
                    if subid not in self.FENCE_SUBIDS or units <= 0:
                        raise RuntimeError('Invalid local mixer completion fence')
                    if self.equalizer is not None and self.equalizer.pending:
                        raise RuntimeError('Incomplete equalizer at native completion fence')
                    if subid == 99 and (not self.defer_ready or self.open_completed):
                        raise RuntimeError('Duplicate or unexpected native open completion')
                    if subid==99:self.software_effects.validate_initial()
                    self.flush()
                    if subid == 99:
                        self.restore_fx_bus()
                        self.restore_equalizers()
                        if self.equalizer is not None and self.equalizer.cap is not None and self.equalizer.initializing:
                            raise RuntimeError('Native equalizer opening incomplete')
                        if self.private_fx.cap is not None:
                            if not self.private_fx.initialized:raise RuntimeError('Private FX opening incomplete')
                            self.acknowledge(local_sysex(90,(units,1)))
                    if self.software_effects.fields is not None:
                        if subid==99:
                            if self.private_fx.cap is None or not self.private_fx.initialized:raise RuntimeError("Software effects require completed private FX matrix")
                            admitted=self.software_effects.commit(initial=True);self.acknowledge(local_sysex(84,(units,int(admitted))))
                        elif self.software_effects.values and not self.software_effects.commit():
                            self.acknowledge(local_sysex(85,(units,1)));continue
                    self.acknowledge(local_sysex(subid, (units,)))
                    if subid == 99:
                        self.open_completed = True
                        self.ready()
                    continue
                if kind==44:
                    self.software_effects.accept(coordinate,units);continue
                if kind in (40,41,42):
                    self.private_fx.accept(kind,coordinate,units)
                    if len(self.private_fx.commands)>=128:self.flush()
                    continue
                if kind == 5:
                    source = coordinate & 255
                    if (coordinate & 65280 or source not in self.phantom_channels
                            or units not in (0, 1)):
                        raise RuntimeError('Unsupported native phantom command')
                    self.commands.append(dict(kind='input_phantom', input=source, enabled=bool(units)))
                elif kind == 6:
                    source = coordinate & 255
                    if coordinate & 65280 or units not in self.gain_channels.get(source, ()):
                        raise RuntimeError('Unsupported native input gain command')
                    self.commands.append(dict(kind='input_gain', input=source, db=units))
                elif kind in (7, 8):
                    channel = coordinate & 255
                    allowed = self.loopback_channels if kind == 7 else self.high_z_channels
                    if coordinate & 65280 or channel not in allowed or units not in (0, 1):
                        raise RuntimeError('Unsupported native boolean parameter command')
                    self.commands.append({'kind':'output_loopback' if kind == 7 else 'input_high_z',
                                          'output' if kind == 7 else 'input':channel, 'enabled':bool(units)})
                elif kind == 10:
                    source = coordinate & 255
                    if coordinate & 65280 or units not in self.gain_tenths_channels.get(source, ()):
                        raise RuntimeError('Unsupported native fractional input gain command')
                    self.commands.append(dict(kind='input_gain_tenths', input=source, db_tenths=units))
                elif kind == 9:
                    output = coordinate & 255
                    limits = self.physical_output_channels.get(output)
                    if (coordinate & 65280 or limits is None or not limits[0] <= units <= limits[1]
                            or (units-limits[0]) % limits[2]):
                        raise RuntimeError('Unsupported native physical-output command')
                    self.commands.append(dict(kind='output_physical_level',output=output,db_tenths=units))
                elif kind in (11,12,13):
                    if self.equalizer is None:raise RuntimeError('Unsupported native equalizer command')
                    command = self.equalizer.feed(kind,coordinate,units)
                    if command is not None:self.commands.append(command)
                elif kind not in (1, 2, 3) or (kind == 3 and coordinate & 255):
                    raise RuntimeError('Invalid typed native mixer command')
                else:
                    item = dict(kind={1: 'input', 2: 'playback', 3: 'output_gain'}[kind],
                                output=(coordinate >> 8) & 255, units=units)
                    if kind != 3:
                        item['source'] = coordinate & 255
                    self.commands.append(item)
                if len(self.commands) == 128:
                    self.flush()
            self.flush()
        except Exception:
            # No partial restore, failed fence or ambiguous transaction may be
            # replayed automatically, even if the caller retains this object.
            self.retired = True
            self.pending.clear()
            self.commands.clear()
            self.private_fx.commands.clear()
            self.private_fx.initial.clear()
            raise


def accept_levels(observation, frame, uid):
    """Validate one complete owner observation before exposing it to the view."""
    if not isinstance(frame, dict) or type(frame.get('schema')) is not int or frame['schema'] != 1:
        raise RuntimeError('Invalid native level schema')
    if frame.get('event') == 'stopped':
        raise RuntimeError(frame.get('error') or 'Native level owner stopped')
    identity = frame.get('identity')
    if not isinstance(identity, dict) or identity.get('uid') != uid:
        raise RuntimeError('Foreign native level identity')
    previous = observation['identity']
    if frame.get('event') == 'ready':
        if previous is not None:raise RuntimeError('Duplicate native level readiness')
        if (type(identity.get('page_count')) is not int or not 1 <= identity['page_count'] <= 15 or
                type(identity.get('page_bytes')) is not int or not 4 <= identity['page_bytes'] <= 1024):
            raise RuntimeError('Invalid native level geometry')
        observation.update(time=time.monotonic(), identity=identity, sequence=0, elapsed_ms=0)
        return
    sequence, elapsed = frame.get('sequence'), frame.get('elapsed_ms')
    if (frame.get('event') != 'snapshot' or previous != identity or
            type(sequence) is not int or not observation['sequence'] < sequence < 2**64 or
            type(elapsed) is not int or not observation['elapsed_ms'] <= elapsed < 2**64):
        raise RuntimeError('Stale or foreign native level snapshot')
    pages = frame.get('pages_hex')
    if (not isinstance(pages, list) or len(pages) != identity.get('page_count') or
            any(not isinstance(v, str) or len(v) != identity.get('page_bytes', 0)*2 or
                any(c not in '0123456789abcdefABCDEF' for c in v) for v in pages)):
        raise RuntimeError('Incomplete native level snapshot')
    decoded = frame.get('decoded_levels')
    counts = observation.get('meter_channels')
    if decoded is not None:
        if not isinstance(decoded, dict):raise RuntimeError('Invalid decoded levels')
        declared = frame.get('decoded_level_channels', dict(input=10, playback=12, output=12))
        if (not isinstance(declared, dict) or set(declared) != {'input','playback','output'}
                or any(type(value) is not int or not 1 <= value <= 256 for value in declared.values())
                or (counts is not None and counts != declared)):
            raise RuntimeError('Invalid or changed decoded meter geometry')
        counts = dict(declared)
        for bank, count in counts.items():
            values = decoded.get(bank)
            if not isinstance(values, list) or len(values) != count:raise RuntimeError('Invalid decoded level bank')
            for value in values:
                if (not isinstance(value, dict) or any(type(value.get(key)) not in (int,float) or
                        not math.isfinite(value[key]) for key in ('peak_db','rms_db')) or
                        type(value.get('overload')) is not int or not 0 <= value['overload'] <= 15):
                    raise RuntimeError('Invalid decoded native meter')
    observation.update(time=time.monotonic(), identity=identity, sequence=sequence,
                       elapsed_ms=elapsed, meters=(sequence,decoded) if decoded is not None else None,
                       meter_channels=counts)


def meter_messages(decoded, description, bank_ports=None):
    """Existing OSC model endpoints, using producer-native active coordinates."""
    def string(value):
        raw=value.encode()+b'\0'
        return raw+bytes((-len(raw))%4)
    for bank, key in [('input','inputs'),('playback','outputs_and_playbacks'),('output','outputs_and_playbacks')]:
        for port in (bank_ports[bank] if bank_ports is not None else description[key]):
            channel = port['native_channel']
            if type(channel) is not int or not 1 <= channel <= len(decoded[bank]):
                raise RuntimeError('Native meter coordinate outside decoded bank')
            value = decoded[bank][channel-1]
            yield string(f'/{bank}/{channel}/level')+string(',ffi')+struct.pack('>ffi',value['peak_db'],value['rms_db'],value['overload'])


def stop(child):
    if child is not None and child.poll() is None:
        child.send_signal(signal.SIGINT)
        try:
            child.wait(timeout=8)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait()


def engine_child(argv):
    # Popen closes everything except these high descriptors before this exec.
    for source, target in zip(map(int, argv[:3]), (6, 7, 9)):
        os.dup2(source, target, inheritable=True)
    for fd in map(int,argv[:3]):
        os.close(fd)
    os.execvpe(argv[3], argv[3:], os.environ)


def matrix_monitor_profile(description):
    lines = []
    monitor = description.get('capabilities', {}).get('matrix_monitor')
    if monitor is not None:
        if (not isinstance(monitor, dict) or type(monitor.get('mono')) is not bool
                or type(monitor.get('cue')) is not bool
                or (monitor['cue'] and (monitor.get('cue_gain') != 'destination_master'
                    or monitor.get('cue_source_balance') is not True))):
            raise RuntimeError('Unsupported native matrix monitor capability')
        lines.append('matrix-monitor\t' + ('mean-columns' if monitor['mono'] else 'none')
                     + '\t' + ('matrix-cue' if monitor['cue'] else 'none'))
        cue_eq = monitor.get('cue_eq_redirect', False)
        if type(cue_eq) is not bool:
            raise RuntimeError('Invalid native Cue equalizer capability')
        if cue_eq:
            equalizer = native_scalar_equalizer.capability(description)
            if not monitor['cue'] or equalizer is None or not equalizer['outputs']:
                raise RuntimeError('Native Cue equalizer requires output equalizers and Cue')
            lines.append('matrix-monitor-cue-eq\t1')
    return lines


def host_control_room_profile(description):
    """Project native host intentions; these controls have no USB registers."""
    capabilities = description.get('capabilities', {})
    defaults = description.get('host_mixer_defaults')
    if defaults is None:
        defaults = {}
    if not isinstance(capabilities, dict) or not isinstance(defaults, dict):
        raise RuntimeError('Invalid native host Control Room metadata')
    present = 'control_room' in capabilities or 'control_room' in defaults
    if not present:
        return []
    cap, initial = capabilities.get('control_room'), defaults.get('control_room')
    if (not isinstance(cap, dict) or type(cap.get('schema')) is not int or cap['schema'] != 1
            or cap.get('dim') is not True or cap.get('recall') is not True
            or cap.get('implementation') != 'host_output_master'
            or cap.get('reference_sha256') != native_scalar_equalizer.REFERENCE
            or not isinstance(initial, dict)):
        raise RuntimeError('Invalid native host Control Room capability')
    limits = cap.get('level_range_db')
    numeric = lambda value: type(value) in (int, float) and math.isfinite(value)
    if (not isinstance(limits, dict)
            or any(not numeric(limits.get(key)) or limits[key] != expected
                   for key, expected in (('min', -65), ('max', 0)))
            or any(not numeric(cap.get(key)) or cap[key] != expected
                   for key, expected in (('dim_step_db', 0.1), ('recall_step_db', 1)))):
        raise RuntimeError('Invalid native host Control Room domain')
    values = []
    for key, step in (('dim_reduction_db', 1), ('dim_previous_db', 1), ('recall_volume_db', 10)):
        value = initial.get(key)
        if not numeric(value) or not -65 <= value <= 0:
            raise RuntimeError('Invalid native host Control Room initial level')
        raw = round(value * 10)
        if abs(raw - value * 10) > 1e-8 or (raw + 650) % step:
            raise RuntimeError('Invalid native host Control Room initial step')
        values.append(raw)
    lines = ['host-control-room\t1\t-650\t0\t1\t10\t' + '\t'.join(map(str, values))]
    capability_keys = ('external_input', 'talkback', 'listenback', 'talk_receive',
                       'communication_step_db', 'fx_return')
    initial_keys = ('external_source', 'external_gain_db', 'talk_source', 'listen_source',
                    'talk_dim_db', 'listen_dim_db', 'last_fx_db')
    if not any(key in cap for key in capability_keys) and not any(key in initial for key in initial_keys):
        return lines
    flags = [cap.get(key) for key in capability_keys[:4]]
    fx = cap.get('fx_return')
    if (any(type(flag) is not bool for flag in flags) or flags[1:] != [flags[1]] * 3
            or fx not in ('absent', 'admitted', 'unported', 'unknown')
            or fx in ('unported', 'unknown') and any(flags)
            or not numeric(cap.get('communication_step_db')) or cap['communication_step_db'] != 0.5):
        raise RuntimeError('Invalid native host communication capability')
    ports = description.get('native_model', {}).get('ports', {}).get('inputs', description.get('inputs', []))
    if not isinstance(ports, list) or any(not isinstance(port, dict) for port in ports):
        raise RuntimeError('Invalid native host communication sources')
    active = {port.get('native_channel') - 1 for port in ports
              if type(port.get('native_channel')) is int and 1 <= port['native_channel'] <= 256}
    raw_initial = []
    for key in initial_keys:
        value = initial.get(key)
        if key in ('external_source', 'talk_source', 'listen_source'):
            if type(value) is not int or value != -1 and value not in active:
                raise RuntimeError('Invalid native host communication source')
            if key == 'external_source' and value >= 0 and (value % 2 or value + 1 not in active):
                raise RuntimeError('Invalid native host External Input pair')
            raw_initial.append(value)
        else:
            if not numeric(value) or not -65 <= value <= 0:
                raise RuntimeError('Invalid native host communication initial level')
            raw = round(value * 10)
            if abs(raw - value * 10) > 1e-8 or (raw + 650) % (10 if key == 'last_fx_db' else 5):
                raise RuntimeError('Invalid native host communication initial step')
            raw_initial.append(raw)
    columns = [1, int(flags[0]), int(flags[1]), int(flags[3]), fx, -650, 0, 5, *raw_initial]
    lines.append('host-communication\t' + '\t'.join(map(str, columns)))
    return lines


def channel_defaults_profile(description):
    """Project Full intentions and optional storage-scoped pairing exceptions.

    Absence of mono_channels is compatibility, not proof of an empty native
    exception list. No product IDs or observed physical values belong here.
    """
    initial = description.get('host_mixer_defaults')
    if initial is None:
        return []
    if not isinstance(initial, dict):
        raise RuntimeError('Invalid native Full defaults')
    channel = initial.get('channel_defaults')
    if channel is None:
        return []
    if (not isinstance(channel, dict) or type(channel.get('stereo')) is not bool
            or type(channel.get('ms_processing')) is not bool
            or channel.get('mute', False) is not False
            or type(channel.get('width')) not in (int, float)
            or not math.isfinite(channel['width']) or not -1 <= channel['width'] <= 1):
        raise RuntimeError('Invalid native Full channel defaults')
    lines = [f"channel-defaults\t{int(channel['stereo'])}\t{round(channel['width'] * 100)}\t{int(channel['ms_processing'])}"]
    if 'mono_channels' not in channel:
        return lines
    mono, geometry = channel['mono_channels'], description.get('mixer_geometry')
    banks = ('input', 'playback', 'output')
    if (not isinstance(mono, dict) or set(mono) != set(banks)
            or not isinstance(geometry, dict)):
        raise RuntimeError('Invalid native Full mono exceptions')
    lines.append('channel-mono-defaults\t1')
    for bank in banks:
        count, values = geometry.get(bank + '_slots'), mono[bank]
        if (type(count) is not int or not 1 <= count <= 256 or not isinstance(values, list)
                or any(type(ch) is not int or not 0 <= ch < count for ch in values)
                or len(set(values)) != len(values)
                or any((ch ^ 1) not in values for ch in values)):
            raise RuntimeError('Invalid native Full mono exception coordinates')
        lines.extend(f'channel-mono-default\t{bank}\t{ch}' for ch in sorted(values))
    return lines


def append_native_menu_profile(lines, description):
    """Carry producer presentation identity, not a consumer product table."""
    context = description.get('native_menu_context')
    reference = native_scalar_equalizer.REFERENCE
    if context is not None:
        if (not isinstance(context, dict) or type(context.get('schema')) is not int
                or context['schema'] != 1 or context.get('reference_sha256') != reference
                or context.get('validation_function') != '100130080'):
            raise RuntimeError('Invalid native menu presentation context')
        native_class = context.get('model_class')
    else:
        # Earlier attributed family producers already supplied the same class.
        # Missing metadata remains unknown, not a guess from a model/PID name.
        model = description.get('native_model') or {}
        if not isinstance(model, dict):raise RuntimeError('Invalid native menu model')
        native_class = model.get('native_model_class', model.get('native_class'))
        if native_class is not None and model.get('reference_sha256', description.get('reference_sha256')) != reference:
            raise RuntimeError('Foreign native menu model reference')
    if native_class is None:return
    if type(native_class) is not int or not 0 <= native_class < 44:
        raise RuntimeError('Invalid native menu model class')
    value = f'native-menu-class\t{native_class}'
    previous = [line for line in lines if line.startswith('native-menu-class\t')]
    if previous and previous != [value]:raise RuntimeError('Conflicting native menu profile')
    if not previous:lines.append(value)
    # Family Describe already carries the native engine's status revision.
    # Never substitute device.version, USB bcdDevice, or a guessed default.
    model = description.get('native_model') or {}
    if not isinstance(model, dict):raise RuntimeError('Invalid native menu model')
    firmware = model.get('firmware_revision')
    if firmware is None:return
    if type(firmware) is not int or not 0 <= firmware <= 65535:
        raise RuntimeError('Invalid native menu firmware revision')
    model_class = model.get('native_model_class', model.get('native_class'))
    model_reference = model.get('reference_sha256', description.get('reference_sha256',
        context.get('reference_sha256') if context is not None else None))
    if model_class != native_class or model_reference != reference:
        raise RuntimeError('Unattributed native menu firmware revision')
    value = f'native-menu-firmware\t{firmware}'
    previous = [line for line in lines if line.startswith('native-menu-firmware\t')]
    if previous and previous != [value]:raise RuntimeError('Conflicting native menu firmware profile')
    if not previous:lines.append(value)


def profile_lines(description, name):
    """Describe owns ports and native initial host intent; never device readback."""
    lines = ['#oscmix-native-profile-v1', 'name\t' + name.replace('\t', ' ').replace('\n', ' ')]
    append_native_menu_profile(lines, description)
    geometry = description.get('mixer_geometry')
    if geometry is not None:
        keys = ('input_slots', 'playback_slots', 'output_slots')
        if (not isinstance(geometry, dict) or type(geometry.get('schema')) is not int
                or geometry['schema'] != 1 or any(type(geometry.get(key)) is not int
                    or not 1 <= geometry[key] <= 256 for key in keys)):
            raise RuntimeError('Invalid native mixer geometry')
        for key, banks in (('inputs', ('input_slots',)),
                           ('outputs_and_playbacks', ('playback_slots','output_slots'))):
            channels = [port.get('native_channel') for port in description[key]]
            if (any(type(channel) is not int or not 1 <= channel <= min(geometry[b] for b in banks)
                    for channel in channels) or len(channels) != len(set(channels))):
                raise RuntimeError('Active port outside native mixer geometry')
        lines.append('geometry\t' + '\t'.join(str(geometry[key]) for key in keys))
    for kind, key in [('input', 'inputs'), ('output', 'outputs_and_playbacks')]:
        for port in description[key]:
            label = port.get('display_name')
            if label is None:  # Compatibility with earlier native producers.
                label = f"{port['stream_name']} {port['stream_channel']}".replace('\t', ' ').replace('\n', ' ')
            elif (not isinstance(label, str) or not label.strip()
                  or len(label.encode('utf-8')) >= 32
                  or any(ord(char) < 32 or ord(char) == 127 for char in label)):
                raise RuntimeError('Invalid native channel display name')
            lines.append(f"{kind}\t{port['native_channel'] - 1}\t{label}")
    lines.extend(f'input-phantom\t{channel}' for channel in sorted(phantom_inputs(description)))
    lines.extend(f"input-gain\t{channel}\t{','.join(map(str, values))}"
                 for channel, values in sorted(gain_inputs(description).items()))
    lines.extend(f"input-gain-tenths\t{channel}\t{','.join(map(str, values))}"
                 for channel, values in sorted(gain_tenths_inputs(description).items()))
    params = parameter_capabilities(description)
    lines.extend(f'input-high-z\t{channel}' for channel in sorted(params.get('input_high_z', {}).get('inputs', ())))
    lines.extend(f'output-loopback\t{channel}' for channel in sorted(params.get('output_loopback', {}).get('outputs', ())))
    lines.extend(native_scalar_equalizer.profile_lines(description))
    lines.extend(native_private_fx.profile_lines(description))
    lines.extend(native_software_effects.profile_lines(description))
    lines.extend(matrix_monitor_profile(description))
    initial = description.get('host_mixer_defaults')
    if initial is not None:
        if (not isinstance(initial, dict)
                or initial.get('provenance') != 'host_template'
                or initial.get('hardware_confirmed') is not False
                or initial.get('reference_sha256') != '75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'
                or initial.get('operation_mode') != 'full'
                or initial.get('route_silence_db') != -300
                or initial.get('route_pan') != 0
                or initial.get('playback_straight') is not True):
            raise RuntimeError('Unsupported native initial mixer template')
        gains = initial.get('output_gains_db')
        mix_outputs = initial.get('playback_mix_outputs')
        ports = description['outputs_and_playbacks']
        active_outputs = {port['native_channel'] - 1 for port in ports}
        if (not isinstance(gains, list) or len(gains) != len(ports)
                or any(type(db) not in (int, float) or not math.isfinite(db) or not -65 <= db <= 6 for db in gains)):
            raise RuntimeError('Invalid native initial output gains')
        if (not isinstance(mix_outputs, list)
                or any(type(index) is not int or index % 2 or index not in active_outputs
                       or index + 1 not in active_outputs for index in mix_outputs)
                or len(set(mix_outputs)) != len(mix_outputs)):
            raise RuntimeError('Invalid native initial playback mix outputs')
        lines.append('startup\tfull')
        lines.extend(channel_defaults_profile(description))
        roles = initial.get('control_room_roles')
        if roles is not None:
            if (not isinstance(roles, dict) or not isinstance(roles.get('phones'), list)
                    or len(roles['phones']) != 4):
                raise RuntimeError('Invalid native Control Room roles')
            assignments = [roles.get('main'), roles.get('main_b'), *roles['phones']]
            active = {port['native_channel'] - 1 for port in ports}
            if (any(type(channel) is not int or (channel != -1 and
                    (channel % 2 or channel not in active or channel + 1 not in active))
                    for channel in assignments)
                    or len({channel for channel in assignments if channel >= 0}) !=
                       sum(channel >= 0 for channel in assignments)):
                raise RuntimeError('Invalid native Control Room assignment')
            lines.append(f"control-room-roles\t{roles['main']}\t{roles['main_b']}\t{','.join(map(str, roles['phones']))}")
        lines.extend(f"output-gain\t{port['native_channel'] - 1}\t{db:g}" for port, db in zip(ports, gains))
        lines.extend(f'playback-mix\t{index}' for index in mix_outputs)
    lines.extend(host_control_room_profile(description))
    return lines


def run(args, transition=None, *, profile_builder=profile_lines, pipe_type=TypedMixerPipe,
        admission_check=None, physical_type=PhysicalControls, meter_builder=meter_messages):
    rows = records(enumerate_cached())
    if not any(row[0] == args.uid and row[5] == args.incarnation for row in rows):
        raise RuntimeError('Selected device connection changed; choose it again')
    app = Path(args.app).resolve()
    controller = app / 'bin/rme-live-levels'
    engine = app / 'bin/oscmix'
    if not controller.is_file() or not engine.is_file():
        raise RuntimeError('Native mixer component missing from this installation')
    config, state = prepare(args.uid)
    runtime = Path(tempfile.mkdtemp(prefix='rme-mix-', dir='/tmp'))
    os.chmod(runtime, 0o700)
    control = runtime / 'control.sock'
    owner = backend = None
    incoming = outgoing = typed = None
    heartbeat = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    destination = None
    cancelled = False
    monitor_stop = threading.Event()
    monitor = None
    reader = selector = None
    rate_notice = {'change': None, 'error': None}

    def cancel(_sig, _frame):
        nonlocal cancelled
        cancelled = True
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, cancel)
    try:
        from native_runtime import wait_audio, rate_transition
        from linux_settings_status import status, SettingsStatusError
        closed = select.poll()
        closed.register(sys.stdin.fileno(), select.POLLHUP | select.POLLERR)
        admitted = wait_audio(args.uid, args.incarnation,
                              lambda: cancelled or bool(closed.poll(0)), transition=transition)
        if admitted is not None:
            def watch_format():
                while not monitor_stop.is_set():
                    try:
                        value = status(args.uid)
                        if monitor_stop.is_set():return
                        change = rate_transition(value, admitted)
                        if change:
                            rate_notice['change'] = change
                            return
                    except SettingsStatusError as error:
                        if error.code not in ('unavailable', 'busy'):
                            rate_notice['error'] = str(error)
                            return
                    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
                        rate_notice['error'] = str(error)
                        return
                    monitor_stop.wait(1)
            monitor = threading.Thread(target=watch_format, daemon=True)
            monitor.start()
        owner = subprocess.Popen([str(controller), args.uid, '--mixer-socket', str(control)],
                                 stdout=subprocess.PIPE, stderr=sys.stderr)
        observation = {'time': time.monotonic(), 'identity': None, 'error': None, 'sequence':0, 'elapsed_ms':0, 'meters':None}
        def consume_levels():
            try:
                for line in iter(lambda: owner.stdout.readline(65537), b''):
                    if len(line) > 65536:raise RuntimeError('Native level frame too long')
                    frame = json.loads(line)
                    accept_levels(observation, frame, args.uid)
            except (OSError, ValueError, RuntimeError) as error:
                observation['error'] = str(error)
        reader = threading.Thread(target=consume_levels, daemon=True)
        reader.start()
        deadline = time.monotonic() + 5
        while not control.exists():
            if cancelled or owner.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError('Native device session could not start')
            time.sleep(.02)
        description = request(control, {'op': 'describe'})
        identity = description['identity']
        if identity['uid'] != args.uid or description.get('retired'):
            raise RuntimeError('Native device identity mismatch')
        if admitted is not None:
            compatible = admission_check(description, admitted) if admission_check is not None else (
                len(description['inputs']) == admitted.get('capture_channels') and
                len(description['outputs_and_playbacks']) == admitted.get('playback_channels'))
            if not compatible:
                raise RuntimeError('Native mixer geometry differs from the confirmed audio format')
        lines = profile_builder(description, args.name)
        lines.extend(f'output-physical-range\t{ch}\t{lo}\t{hi}\t{step}'
                     for ch,(lo,hi,step) in physical_output_ranges(description).items())
        physical = physical_type(description)
        lines.extend(physical.profile(physical.accept(description.get('physical_controls'))))
        profile = runtime / 'profile.tsv'
        profile.write_text('\n'.join(lines) + '\n')
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as reservation:
            reservation.bind(('127.0.0.1', 0))
            port = reservation.getsockname()[1]
        print(f'PROFILE\t{profile}\t{port}\t{state}\t{config}', flush=True)
        # No engine command can be sent until GTK has its immutable device model.
        selector = selectors.DefaultSelector()
        selector.register(sys.stdin, selectors.EVENT_READ)
        events = selector.select(5)
        if not events or cancelled:
            raise RuntimeError('Mixer view did not complete its session handshake')
        command = sys.stdin.readline().strip().split()
        if len(command) != 2 or command[0] != 'UI_PORT' or not 0 < int(command[1]) < 65536:
            raise RuntimeError('Invalid mixer view handshake')
        destination = ('127.0.0.1', int(command[1]))
        selector.unregister(sys.stdin)
        mi_read, incoming = os.pipe()
        outgoing, mi_write = os.pipe()
        typed, route_write = os.pipe()
        high = [fcntl.fcntl(fd, fcntl.F_DUPFD_CLOEXEC, 32) for fd in (mi_read, mi_write, route_write)]
        env = os.environ.copy()
        env.pop('OSCMIX_NATIVE_USB', None)
        env.pop('OSCMIX_PROFILE_CONFIG_HOME', None)
        env.pop('OSCMIX_PROFILE_STATE_HOME', None)
        env.update(OSCMIX_SCALAR_UID=args.uid, OSCMIX_SCALAR_CACHE=str(state / "oscmix/native-routes.ini"), OSCMIX_DEVICE_PROFILE=str(profile), XDG_CONFIG_HOME=str(config), XDG_STATE_HOME=str(state), OSCMIX_SCALAR_OPEN='1')
        backend = subprocess.Popen([sys.executable, __file__, '--engine-child', *map(str, high),
                    str(engine), '-p', 'rme-scalar', '-l', '-r', f'udp!127.0.0.1!{port}',
                    '-s', f'udp!127.0.0.1!{destination[1]}'], pass_fds=high, env=env,
                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=sys.stderr)
        for fd in [mi_read, mi_write, route_write, *high]:
            os.close(fd)
        for fd in (outgoing, typed, sys.stdin.fileno()):
            os.set_blocking(fd, False)
            selector.register(fd, selectors.EVENT_READ)
        last_beat = 0
        last_meter_sequence = 0
        announced_ready = False
        def engine_ready():
            nonlocal announced_ready
            announced_ready = True
            print('READY', flush=True)
        typed_pipe = pipe_type(identity, description.get('last_sequence', 0),
                                    lambda value: request(control, value),
                                    lambda packet: os.write(incoming, packet), engine_ready,
                                    phantom_channels=phantom_inputs(description),
                                    gain_channels=gain_inputs(description),
                                    high_z_channels=parameter_capabilities(description).get('input_high_z', {}).get('inputs', ()),
                                    loopback_channels=parameter_capabilities(description).get('output_loopback', {}).get('outputs', ()),
                                    gain_tenths_channels=gain_tenths_inputs(description),
                                    equalizer_description=description, defer_ready=True,
                                    physical_controls=physical,
                                    physical_output_channels=physical_output_ranges(description),
                                    software_effects_factory=(lambda:native_software_effects.client_for(args.uid,admitted["marker"])) if admitted else None)
        next_physical = time.monotonic()
        engine_deadline = time.monotonic() + 5
        while not cancelled:
            if rate_notice['error']:
                raise RuntimeError(rate_notice['error'])
            if rate_notice['change']:
                notice = 'HARDWARE_CHANGING' if rate_notice['change'].get('_kind') == 'hardware' else 'RATE_CHANGING'
                print(notice + '\t' + rate_notice['change']['request_id'], flush=True)
                return rate_notice['change']
            if owner.poll() is not None or backend.poll() is not None:
                raise RuntimeError('Native mixer session stopped')
            for key, _ in selector.select(.05):
                fd = key.fd
                data = os.read(fd, 65536)
                if fd == sys.stdin.fileno():
                    if not data:
                        cancelled = True
                    continue
                if not data:
                    raise RuntimeError('Native mixer session closed')
                if fd == outgoing:
                    # These are virtual registers from our own engine, never a
                    # USB payload. This echo never claims hardware readback.
                    os.write(incoming, data)
                elif fd == typed:
                    typed_pipe.feed(data)
                    # Large native matrices restore in many completed batches.
                    # Bound an idle engine, not the total time spent making
                    # acknowledged progress on a model's actual geometry.
                    engine_deadline = time.monotonic() + 5
            now = time.monotonic()
            if announced_ready and now >= next_physical:
                snapshot = request(control, dict(op='physical_controls', identity=identity))
                for packet in physical.feedback(physical.accept(snapshot)):
                    os.write(incoming, packet)
                next_physical = now + .25
            if not announced_ready and now > engine_deadline:
                raise RuntimeError('Native mixer engine did not become ready')
            if observation['error'] or (observation['identity'] is not None and observation['identity'] != identity):
                raise RuntimeError(observation['error'] or 'Native session changed identity')
            if now - observation['time'] > 3:
                raise RuntimeError('Native device is no longer responding')
            meters = observation['meters']
            if announced_ready and meters is not None and meters[0] > last_meter_sequence:
                for packet in meter_builder(meters[1], description):heartbeat.sendto(packet, destination)
                last_meter_sequence = meters[0]
            if announced_ready and now - last_beat > .25:
                heartbeat.sendto(osc_text('/device/id', 'rme-scalar'), destination)
                last_beat = now
    finally:
        monitor_stop.set()
        if destination:
            heartbeat.sendto(osc_text('/device/id', ''), destination)
        stop(backend)
        stop(owner)
        if reader is not None:
            reader.join(timeout=1)
        if monitor is not None:
            monitor.join(timeout=4.5)
        if selector is not None:
            selector.close()
        for fd in (incoming, outgoing, typed):
            if fd is not None:
                os.close(fd)
        heartbeat.close()
        shutil.rmtree(runtime)


def session_runner(args):
    from device_inventory import enumerate_cached, records, mixer_route_protocol
    devices=enumerate_cached()
    if not any(row[0] == args.uid and row[5] == args.incarnation for row in records(devices)):
        raise RuntimeError('Selected device connection changed; choose it again')
    device=next(row for row in devices if row['uid'] == args.uid)
    protocol = mixer_route_protocol(device)
    if protocol == 'MatrixSparse':
        from native_matrix_session import run as matrix_run
        return matrix_run
    if protocol == 'DigifaceSparse':
        from native_dante_session import run as dante_run
        return dante_run
    if protocol == 'MadiSparse':
        from native_madi_session import run as madi_run
        return madi_run
    if protocol == 'UfxPairedDbPan':
        from native_ufx_session import run as ufx_run
        return ufx_run
    if protocol == 'LegacyFxTagged':
        from native_legacy_session import run as legacy_run
        return legacy_run
    from native_modern_session import PROTOCOLS
    if protocol in PROTOCOLS:
        from native_modern_session import run as modern_run
        return modern_run
    return run


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--engine-child':
        engine_child(sys.argv[2:])
    parser = argparse.ArgumentParser()
    for key in ('uid', 'incarnation', 'name', 'app'):
        parser.add_argument('--' + key, required=True)
    try:
        args = parser.parse_args()
        runner = session_runner(args)
        transition = None
        while True:
            transition = runner(args, transition)
            if transition is None:
                break
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        print('ERROR\t' + str(error).replace('\n', ' '), flush=True)
        raise SystemExit(1)
