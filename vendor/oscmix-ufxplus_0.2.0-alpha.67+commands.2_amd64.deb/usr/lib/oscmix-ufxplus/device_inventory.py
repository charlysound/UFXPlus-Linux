"""OSCmixer inventory adapter for the driver's passive list-devices schema.

No USB nodes, control requests, ALSA changes, or device fallback. The bundled
catalogue is emitted by the reviewed driver commit recorded in device-selection.md.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

UID = re.compile(r'rme:[0-9a-f]{4}:[0-9a-f]{4}:(?:serial|port):[0-9a-f]+\Z')
PATH = re.compile(r'[0-9]+-[0-9]+(?:\.[0-9]+)*\Z')


def field(value, limit):
    if not isinstance(value, str) or not value or len(value.encode()) > limit:
        raise ValueError('Invalid inventory field')
    if any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('Invalid inventory text')
    return value


def records(devices, sysfs=Path('/sys/bus/usb/devices')):
    if not isinstance(devices, list) or len(devices) > 128:
        raise ValueError('Invalid inventory size')
    rows, seen = [], set()
    for device in devices:
        if not isinstance(device, dict):
            raise ValueError('Invalid inventory record')
        if device.get('model') is None:
            continue
        uid = field(device.get('uid'), 512)
        if not UID.fullmatch(uid) or uid in seen:
            raise ValueError('Invalid or ambiguous device UID')
        seen.add(uid)
        path = field(device.get('usb_path'), 64)
        if not PATH.fullmatch(path):
            raise ValueError('Invalid USB locator')
        node = sysfs / path
        # Bind the list entry to the same cached physical incarnation. A
        # concurrent unplug/replug invalidates this snapshot instead of guessing.
        birth = (node.stat().st_ino, node.stat().st_ctime_ns)
        identity = {name: (node / name).read_text().strip() for name in
                    ('idVendor', 'idProduct', 'bcdDevice', 'busnum', 'devnum')}
        for key, name, base in [('vendor_id', 'idVendor', 16), ('product_id', 'idProduct', 16),
                               ('revision', 'bcdDevice', 16), ('bus', 'busnum', 10), ('address', 'devnum', 10)]:
            if type(device.get(key)) is not int or int(identity[name], base) != device[key]:
                raise ValueError('USB inventory changed during discovery')
        serial = device.get('serial')
        suffix = 'serial:' + serial.encode().hex() if serial else 'port:' + path.encode().hex()
        expected = f"rme:{device['vendor_id']:04x}:{device['product_id']:04x}:{suffix}"
        if uid != expected:
            raise ValueError('Inconsistent UID')
        if serial and (node / 'serial').read_text().strip() != serial:
            raise ValueError('USB serial changed during discovery')
        descriptors = (node / 'descriptors').read_bytes()
        if birth != (node.stat().st_ino, node.stat().st_ctime_ns) or any((node / name).read_text().strip() != value for name, value in identity.items()):
            raise ValueError('USB device reconnected during discovery')
        token = hashlib.sha256(json.dumps([uid, path, identity, birth], sort_keys=True).encode() + descriptors).hexdigest()
        # The pre-existing native control owner accepts this exact fingerprint
        # only. This does not grant control to the other reference personalities.
        legacy = int(device['vendor_id'] == 0x2a39 and device['product_id'] == 0x3fc1
                     and device['model'] == 'fireface_ufx_plus')
        rows.append((uid, field(device.get('product'), 128), field(serial or '—', 128),
                     field(device['model'], 64), path, token, str(legacy)))
    return sorted(rows)


def enumerate_cached(sysfs=Path('/sys/bus/usb/devices'), catalogue=None):
    if catalogue is None:
        catalogue = json.loads(Path(__file__).with_name('rme-usb-catalogue.json').read_text())
    if catalogue.get('schema') != 1 or catalogue.get('reference_sha256') != '19c8b7d292a8d1588e4a777d351d0489523bf2da3fab655269ea63fe6e07c2cb':
        raise ValueError('RME inventory schema/reference mismatch')
    models = {(item['vendor_id'], item['product_id']): item['model'] for item in catalogue['usb_identities']}
    if len(models) != 47:
        raise ValueError('Incomplete or ambiguous RME inventory catalogue')
    devices = []
    for node in sysfs.iterdir():
        try:
            vendor = int((node / 'idVendor').read_text().strip(), 16)
            product = int((node / 'idProduct').read_text().strip(), 16)
        except (OSError, ValueError):
            continue
        model = models.get((vendor, product))
        if model is None:
            continue
        path = node.name
        if not PATH.fullmatch(path):
            raise ValueError('Invalid cached device path')
        serial_path = node / 'serial'
        serial = serial_path.read_text().strip() or None if serial_path.exists() else None
        suffix = 'serial:' + serial.encode().hex() if serial else 'port:' + path.encode().hex()
        devices.append(dict(uid=f'rme:{vendor:04x}:{product:04x}:{suffix}', stable_identity=serial is not None,
                            model=model, vendor_id=vendor, product_id=product,
                            revision=int((node / 'bcdDevice').read_text().strip(), 16),
                            product=(node / 'product').read_text().strip(), serial=serial,
                            usb_path=path, bus=int((node / 'busnum').read_text().strip()),
                            address=int((node / 'devnum').read_text().strip()),
                            speed_mbps=(node / 'speed').read_text().strip()))
    return sorted(devices, key=lambda device: (device['uid'], device['usb_path']))


def mixer_route_protocol(device, catalogue=None):
    """Read the existing native profile dialect; this never admits a writer.

    Linux dispatch uses the producer's central profile table, including its
    USB aliases. No frontend list of model names or product IDs is maintained.
    """
    if catalogue is None:
        path=Path(__file__).with_name('rme-runtime')/'catalogue.json'
        if not path.exists():return None  # Older scalar-only installations.
        catalogue=json.loads(path.read_text())
    if (catalogue.get('schema') != 1 or catalogue.get('reference_sha256') !=
            '19c8b7d292a8d1588e4a777d351d0489523bf2da3fab655269ea63fe6e07c2cb'):
        raise ValueError('Native profile catalogue identity differs')
    if not any(row.get('vendor_id') == device['vendor_id'] and row.get('product_id') == device['product_id']
               for row in catalogue.get('usb_identities',[])):
        raise ValueError('Native profile USB identity is unavailable')
    profiles=[row for row in catalogue.get('profiles',[]) if row.get('product_id') == device['product_id']]
    if len(profiles) != 1:raise ValueError('Native profile is missing or ambiguous')
    protocol=(profiles[0].get('control_capabilities') or {}).get('route_protocol')
    return field(protocol,64)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--bind-legacy', action='store_true')
    modes.add_argument('--has-devices', action='store_true')
    args = parser.parse_args(argv)
    tool = os.environ.get('OSCMIX_RME_CATALOG_TOOL')
    if tool:
        result = subprocess.run([tool, 'list-devices'], check=True, capture_output=True, text=True, timeout=3)
        if len(result.stdout) > 2_000_000:
            raise ValueError('Inventory too large')
        devices = json.loads(result.stdout)
    else:
        devices = enumerate_cached()
    rows = records(devices)
    if args.has_devices:
        return 0 if rows else 1
    if args.bind_legacy:
        candidates = [row for row in rows if row[-1] == '1']
        if len(candidates) != 1:
            raise ValueError('Exactly one native UFX+ control session is required')
        print(candidates[0][0] + '\t' + candidates[0][5])
    else:
        print('#oscmix-rme-inventory-v1')
        for row in rows:
            print('\t'.join(row))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print(f'Device discovery unavailable: {error}', file=sys.stderr)
        raise SystemExit(2)
