"""Digiface Dante metadata adapter on the common scalar/sparse mixer session.

The producer owns active native coordinates, firmware pool and USB personality.
Output-only Phones never become playback/PCM ports through a frontend guess.
"""
import native_scalar_session as shared
from native_madi_session import pcm_matches
from native_sparse_session import TypedSparsePipe
import native_sparse_session as sparse


REFERENCE = '75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'


def model_contract(description):
    model, cap = description.get('native_model'), description.get('capabilities')
    geometry = description.get('mixer_geometry')
    if (not isinstance(model, dict) or model.get('codec') != 'digiface_sparse'
            or model.get('native_class') != 33 or model.get('controller_family') != 15
            or model.get('renderer_flags') != 4194304
            or description.get('reference_sha256') != REFERENCE
            or type(model.get('slot_capacity')) is not int or model['slot_capacity'] not in (512, 1024, 2048, 4096)
            or type(model.get('matrix_queue_words')) is not int or model['matrix_queue_words'] not in (128, 256)
            or type(model.get('initial_clear_slots')) is not int or model['initial_clear_slots'] != 4096
            or type(model.get('initial_maintenance_usb_packets')) is not int
            or model['initial_maintenance_usb_packets'] * model['matrix_queue_words'] != model['initial_clear_slots']
            or not isinstance(cap, dict) or cap.get('route_protocol') != 'DigifaceSparse'
            or cap.get('restore_transport') != 'restore_matrix' or cap.get('max_commands') != 128
            or cap.get('max_restore_bytes') != 524288
            or cap.get('coefficient_commands') != ['input', 'playback', 'output_gain']
            or cap.get('matrix_readback') is not False or cap.get('set') is not False
            or cap.get('parameters') != [] or cap.get('fx_parameters') is not False
            or cap.get('equalizer') != {'available': False, 'admitted': False}
            or cap.get('matrix_monitor') != {'cue': True, 'mono': True,
                'cue_gain': 'destination_master', 'cue_source_balance': True}
            or cap.get('physical_adoption') is not False
            or type(description.get('native_units_at_unity')) is not int or description['native_units_at_unity'] != 32768
            or type(description.get('coordinate_base')) is not int or description['coordinate_base'] != 0
            or not isinstance(geometry, dict) or type(geometry.get('schema')) is not int or geometry['schema'] != 1
            or not isinstance(model.get('ports'), dict) or not isinstance(model.get('active'), dict)
            or not isinstance(model.get('storage'), dict)):
        raise RuntimeError('Invalid native Digiface sparse model contract')
    return sparse.bank_contract(description,model)


def dante_profile(description, name):
    return sparse.profile_lines(description,name,model_contract)


class DantePhysicalControls(shared.PhysicalControls):
    def accept(self, value, now=None):
        # This model has no attributed encoder observation; an unavailable
        # envelope cannot be projected as a gain or used as matrix readback.
        if (not isinstance(value, dict) or type(value.get('schema')) is not int or value['schema'] != 1
                or value.get('identity') != self.identity or value.get('source') != 'unavailable'
                or value.get('state') != 'unavailable' or value.get('hardware_observed') is not False
                or value.get('hardware_matrix_readback') is not False
                or value.get('adoption_admitted') is not False or value.get('values') != []
                or type(value.get('sequence')) is not int or value['sequence'] != 0
                or value.get('age_ms') is not None
                or value.get('reason') != 'native_dante_has_no_physical_encoder_readback'):
            raise RuntimeError('Invalid native Digiface physical-control availability')
        return []


class TypedDantePipe(TypedSparsePipe):
    model_contract = staticmethod(model_contract)


def meter_messages(decoded, description):
    return sparse.meter_messages(decoded,description)


def run(args, transition=None):
    return shared.run(args, transition, profile_builder=dante_profile,
                      pipe_type=TypedDantePipe, admission_check=pcm_matches,
                      physical_type=DantePhysicalControls, meter_builder=meter_messages)
