"""UFXFX paired logical mixer on the shared per-UID owner lifecycle.

No DSP registers, polling counters, firmware/PID dispatch or coefficient math
live here. The native owner supplies semantic domains and both cycle fences.
"""
import json
import socket
import os
import tempfile
from pathlib import Path
import struct
import time
import native_legacy_session as shared
import native_room_equalizer
from native_scalar_session import local_sysex
from native_modern_session import pcm_matches

BANKS = ('input', 'output', 'playback')
DECISIONS = shared.DECISIONS


class Parameters:
    def __init__(self, description):
        model = description['native_model']
        self.room = native_room_equalizer.Parameters(description)
        self.channel, self.global_fx = {}, {}
        for field, target in (('channel_parameters', self.channel), ('global_fx_parameters', self.global_fx)):
            entries = model.get(field)
            if not isinstance(entries, list) or len(entries) > 256:raise RuntimeError('Invalid UFX parameter list')
            for d in entries:
                if (not isinstance(d, dict) or not isinstance(d.get('parameter'), str)
                        or not d['parameter'].isascii() or not d['parameter'].replace('_', '').isalnum()
                        or not 1 <= len(d['parameter']) <= 64 or not shared.uint(d.get('native_parameter'), 8)
                        or d['native_parameter'] >= 85
                        or any(type(d.get(k)) is not int or not -(1 << 31) <= d[k] < 1 << 31
                               for k in ('min', 'max', 'step', 'scale', 'initial'))
                        or d['step'] <= 0 or d['scale'] <= 0 or not d['min'] <= d['initial'] <= d['max']
                        or (d['initial'] - d['min']) % d['step']
                        or d.get('observed_register') is not None and not shared.uint(d['observed_register'], 15)
                        or type(d.get('startup_restore', True)) is not bool):
                    raise RuntimeError('Invalid UFX semantic descriptor')
                low, high = d.get('ui_min', d['min']), d.get('ui_max', d['max'])
                if type(low) is not int or type(high) is not int or not d['min'] <= low <= high <= d['max']:
                    raise RuntimeError('Invalid UFX UI domain')
                if field == 'global_fx_parameters':
                    if d['native_parameter'] in target:raise RuntimeError('Duplicate UFX global semantic ID')
                    target[d['native_parameter']] = d.copy()
                else:
                    banks, scope = d.get('banks'), d.get('channels')
                    if (not isinstance(banks, list) or not banks or len(set(banks)) != len(banks)
                            or any(bank not in BANKS for bank in banks)
                            or scope is not None and (not isinstance(scope, list) or not scope
                                or len(set(scope)) != len(scope) or any(not shared.uint(ch, 8) for ch in scope))):
                        raise RuntimeError('Invalid UFX parameter banks/scope')
                    for bank in banks:
                        if scope is not None and any(ch not in model['active_' + bank + 's'] for ch in scope):
                            raise RuntimeError('Inactive UFX physical parameter scope')
                        key = (BANKS.index(bank), d['native_parameter'])
                        if key in target:raise RuntimeError('Duplicate UFX bank semantic ID')
                        target[key] = d.copy()
        self.reference_levels = {}
        levels = model.get('reference_levels', {})
        if not isinstance(levels, dict):raise RuntimeError('Invalid UFX reference-level metadata')
        for bank, entries in levels.items():
            if bank not in BANKS or not isinstance(entries, list):raise RuntimeError('Invalid UFX reference-level bank')
            for entry in entries:
                if not isinstance(entry, dict) or type(entry.get('channel')) is not int or entry['channel'] not in model['active_' + bank + 's']:
                    raise RuntimeError('Invalid UFX reference-level channel')
                names = entry.get('values')
                if (not isinstance(names, list) or not names or any(not isinstance(n, str) or not n or len(n.encode()) > 64
                        or any(ord(c) < 32 or c == '|' for c in n) for n in names)):
                    raise RuntimeError('Invalid UFX reference-level names')
                key = (BANKS.index(bank), entry['channel'])
                d = self.channel.get((key[0], 4))
                if key in self.reference_levels or not d or len(names) > (d['max'] - d['min']) // d['step'] + 1:
                    raise RuntimeError('Ambiguous UFX reference levels')
                self.reference_levels[key] = names
        self.physical_domains = model.get('physical_domains', {})
        self.required = model.get('required_channel_parameters')
        self.required_global = model.get('required_global_parameters', [])
        if (not isinstance(self.required, list) or any(not isinstance(pair, list) or len(pair) != 2
                or any(type(k) is not int for k in pair) or tuple(pair) not in self.channel
                or self.channel[tuple(pair)].get('startup_restore', True) is not True for pair in self.required)
                or len({tuple(pair) for pair in self.required}) != len(self.required)
                or not isinstance(self.required_global, list)
                or any(type(k) is not int or k not in self.global_fx for k in self.required_global)
                or len(set(self.required_global)) != len(self.required_global)):
            raise RuntimeError('Invalid UFX required restoration coverage')

    def valid(self, bank, ch, parameter, value, restoring=False, raw_room=False):
        if bank==1 and parameter in self.room.descriptors:
            return self.room.valid(ch,parameter,value,restoring or raw_room)
        d = self.global_fx.get(parameter) if bank < 0 else self.channel.get((bank, parameter))
        return (d is not None and type(value) is int and d['min'] <= value <= d['max']
                and (value - d['min']) % d['step'] == 0
                and (not restoring or d.get('startup_restore', True))
                and (bank < 0 or 'channels' not in d or ch in d['channels'])
                and (parameter != 4 or (bank, ch) not in self.reference_levels
                     or (value - d['min']) // d['step'] < len(self.reference_levels[bank, ch])))

    def profile(self):
        def fields(d):
            return '\t'.join(str(d[k]) for k in ('parameter', 'native_parameter', 'min', 'max', 'step', 'scale', 'initial')) + '\t' + str(d.get('observed_register') if d.get('observed_register') is not None else -1)
        for (bank, _), d in self.channel.items():
            scope = ','.join(map(str, d['channels'])) if 'channels' in d else '*'
            yield '\t'.join(('ufx-channel-parameter', BANKS[bank], fields(d), str(d.get('ui_min', d['min'])), str(d.get('ui_max', d['max'])), scope, str(int(d.get('startup_restore', True)))))
        for d in self.global_fx.values():yield 'ufx-global-parameter\t' + fields(d)
        for (bank, parameter), d in self.channel.items():
            if 'value_names' in d:
                names = d['value_names']
                if (not isinstance(names, list) or len(names) != (d['max'] - d['min']) // d['step'] + 1
                        or any(not isinstance(n, str) or not n or len(n.encode()) > 64 or any(ord(c) < 32 or c == '|' for c in n) for n in names)):
                    raise RuntimeError('Invalid UFX value names')
                yield '\t'.join(('ufx-value-names', BANKS[bank], '*', str(parameter), '|'.join(names)))
        for (bank, ch), names in self.reference_levels.items():yield '\t'.join(('ufx-value-names', BANKS[bank], str(ch), '4', '|'.join(names)))
        gain = self.physical_domains.get('input_gain', {})
        if gain.get('requires_known_hi_z') is True:
            values, channels = gain.get('instrument_values'), gain.get('instrument_channels')
            if (not isinstance(values, list) or not values or len(values) > 256 or any(type(v) is not int for v in values)
                    or sorted(set(values)) != values or not isinstance(channels, list) or not channels
                    or any(type(ch) is not int for ch in channels) or len(set(channels)) != len(channels)):
                raise RuntimeError('Invalid UFX instrument gain mode')
            for ch in channels:
                if not self.valid(0, ch, 14, 0) or not self.valid(0, ch, 14, 1) or any(not self.valid(0, ch, 5, v) for v in values):
                    raise RuntimeError('Invalid UFX instrument gain scope')
                yield 'ufx-gain-instrument-values\t' + str(ch) + '\t' + ','.join(map(str, values))
        for bank, parameter in self.required:yield f'ufx-required\t{bank}\t{parameter}'


def ufx_profile(description, name):
    model = description.get('native_model')
    if (not isinstance(model, dict) or type(model.get('schema')) is not int or model['schema'] != 1
            or model.get('codec') != 'ufx_fx' or model.get('route_protocol') != 'UfxPairedDbPan'
            or model.get('reference_sha256') != shared.REFERENCE
            or not shared.uint(model.get('renderer_flags'), 32)):
        raise RuntimeError('Invalid native UFXFX producer authority')
    dims = [model.get(bank + '_slots') for bank in ('input', 'playback', 'output')]
    if any(type(n) is not int or not 1 <= n <= 94 for n in dims):raise RuntimeError('Invalid UFX mixer dimensions')
    compact = model.get('compact_model', {})
    if any(compact.get(key) != value for key, value in (('schema', 1), ('max_request_bytes', 1048576),
            ('route_record_words', 4), ('master_record_words', 4), ('channel_record_words', 4),
            ('global_record_words', 2), ('playback_source_base', 256))):
        raise RuntimeError('Invalid UFX compact ABI')
    lines = ['#oscmix-native-profile-v1', 'name\t' + name.replace('\t', ' ').replace('\n', ' '),
             'geometry\t' + '\t'.join(map(str, dims)), 'native-dialect\tufx-fx\tufx_fx',
             f"native-renderer-flags\t{model['renderer_flags']}"]
    for bank, count in zip(('input', 'playback', 'output'), dims):
        active, ports = model.get('active_' + bank + 's'), model.get('ports', {}).get(bank + 's')
        if (not isinstance(active, list) or not active or len(set(active)) != len(active)
                or any(type(ch) is not int or not 0 <= ch < count for ch in active)
                or not isinstance(ports, list) or [p.get('native_channel') for p in ports] != [ch + 1 for ch in active]):
            raise RuntimeError('Invalid UFX native mixer ports')
        for port in ports:
            label = port.get('display_name')
            if (not isinstance(label, str) or not label.strip() or len(label.encode()) >= 32
                    or any(ord(c) < 32 or ord(c) == 127 for c in label)):
                raise RuntimeError('Invalid UFX channel label')
            lines.append(f"{bank}\t{port['native_channel'] - 1}\t{label}")
    if (compact.get('exact_routes') != (len(model['active_inputs']) + len(model['active_playbacks'])) * len(model['active_outputs'])
            or compact.get('exact_masters') != len(model['active_outputs'])):
        raise RuntimeError('Invalid UFX compact coverage geometry')
    shared.append_host_defaults(lines, description)
    if description['host_mixer_defaults'].get('parameter_defaults_from_descriptors') is not True:
        raise RuntimeError('UFX Full parameter template lacks native provenance')
    lines.append('ufx-parameter-defaults\tfull')
    lines.extend(Parameters(description).profile())
    lines.extend(Parameters(description).room.profile())
    return lines


class UfxJournal:
    multiple_boundaries = True
    def __init__(self, identity, packets):
        self.identity, self.packets = identity, packets
        self.cursor = self.latest = 0
        self.prefix = None
        self.phase = 'initial'
        self.remaining = None
        self.boundary = False
        self.progress = time.monotonic()
        self.error = None
        self.decision_prefix = None
        self.final_prefix = None

    @staticmethod
    def event(item):
        kind, event, ch, output, value = item.get('kind'), 0, 0, 0, 0
        if kind == 'input_route_parameter':
            ch, output, value = item.get('source'), item.get('output'), item.get('value')
            p = item.get('parameter')
            if p not in ('gain_db_tenths', 'pan_hundredths'):raise RuntimeError('Invalid UFX route observation')
            event = 1 if p == 'gain_db_tenths' else 2
        elif kind == 'output_master_parameter':
            output, value = item.get('output'), item.get('value')
            event = {'gain_db_tenths': 7, 'pan_hundredths': 8, 'mute': 9}.get(item.get('parameter'))
            if event is None:raise RuntimeError('Invalid UFX master observation')
        elif kind == 'channel_parameter':
            if item.get('bank') not in BANKS:raise RuntimeError('Invalid UFX channel bank')
            event = (10, 11, 13)[BANKS.index(item['bank'])]
            ch, output, value = item.get('channel'), item.get('native_parameter'), item.get('value')
        elif kind in ('channel_stereo', 'input_mute', 'input_ms_proc'):
            bank = item.get('bank', 'input')
            if bank not in BANKS or type(item.get('enabled')) is not bool:raise RuntimeError('Invalid UFX boolean observation')
            event = (10, 11, 13)[BANKS.index(bank)]
            ch, output, value = item.get('channel'), {'channel_stereo': 0, 'input_mute': 2, 'input_ms_proc': 8}[kind], int(item['enabled'])
        elif kind == 'global_fx_parameter':
            event, output, value = 12, item.get('native_parameter'), item.get('value')
        elif kind not in ('connection_request', 'connection_status', 'native_decision_boundary', 'native_cycle', 'native_invalid_word', 'native_matrix_end', 'native_matrix_outside_model', 'native_matrix_non_input', 'native_parameter_guarded', 'native_inactive_channel', 'native_channel_setting', 'native_setting', 'native_global_setting', 'native_room_equalizer_setting', 'firmware_status'):
            raise RuntimeError('Unknown normalized UFX observation')
        if (not shared.uint(ch, 8) or not shared.uint(output, 8)
                or type(value) is not int or not -2**31 <= value < 2**31):raise RuntimeError('Invalid UFX journal coordinates')
        return event << 16 | output << 8 | ch, value & 0xffffffff

    def accept(self, answer):
        if (not isinstance(answer, dict) or answer.get('identity') != self.identity
                or answer.get('after_sequence') != self.cursor
                or not shared.uint(answer.get('next_sequence')) or not shared.uint(answer.get('latest_sequence'))
                or not self.cursor <= answer['next_sequence'] <= answer['latest_sequence']
                or answer['latest_sequence'] < self.latest):raise RuntimeError('Stale UFX journal authority')
        cycle = answer.get('cycle')
        if (not isinstance(cycle, dict) or cycle.get('phase') not in ('initial', 'awaiting_decision', 'host_transfer', 'device_request', 'device_transfer', 'accepted')
                or type(cycle.get('decision_required')) is not bool or type(cycle.get('can_restore')) is not bool):
            raise RuntimeError('Invalid native UFX cycle authority')
        stage = 1 if cycle['decision_required'] else 2 if cycle['can_restore'] else 0
        prefix = cycle.get('reconstruction_prefix')
        if cycle.get('connection_source') is not None and (type(cycle['connection_source']) is not int or not 0 <= cycle['connection_source'] <= 3):raise RuntimeError('Invalid UFX connection source')
        if stage and (not shared.uint(prefix) or prefix > answer['latest_sequence']):raise RuntimeError('Invalid UFX cycle prefix')
        if stage == 1 and self.decision_prefix is not None and prefix != self.decision_prefix:raise RuntimeError('Changed UFX decision prefix')
        if stage == 2 and self.final_prefix is not None and prefix != self.final_prefix:raise RuntimeError('Changed UFX final prefix')
        seen = self.decision_prefix is not None if stage == 1 else self.final_prefix is not None
        observations = answer.get('observations')
        if not isinstance(observations, list) or len(observations) > 256:raise RuntimeError('Invalid UFX journal window')
        sequence, pending, words = self.cursor, [], []
        def flush():
            if words:pending.append((local_sysex(86, words), sequence));words.clear()
        def mark():
            nonlocal seen
            flush();pending.append((local_sysex(87, (prefix & 0xffffffff, prefix >> 32, stage, cycle.get('connection_source') if cycle.get('connection_source') is not None else 0xffffffff)), None));seen = True
        for record in observations:
            if not isinstance(record, dict) or record.get('sequence') != sequence + 1 or not shared.uint(record.get('age_ms'), 32):
                raise RuntimeError('Lost UFX observation prefix')
            if stage and not seen and record['sequence'] > prefix:mark()
            sequence += 1
            item = record.get('value', record)
            if not isinstance(item, dict):raise RuntimeError('Invalid UFX normalized journal value')
            coordinate, value = self.event(item)
            words.extend((sequence & 0xffffffff, sequence >> 32, coordinate, value, record['age_ms']))
            if len(words) == 160:flush()
        if sequence != answer['next_sequence']:raise RuntimeError('UFX journal cursor mismatch')
        flush()
        if stage and not seen and sequence == prefix:mark()
        if stage and not seen and sequence > prefix:raise RuntimeError('Missed UFX native boundary')
        for packet, through in pending:self.packets.put(packet, through)
        if sequence > self.cursor or cycle['phase'] != self.phase or cycle.get('remaining') != self.remaining:self.progress = time.monotonic()
        self.cursor, self.latest, self.phase, self.remaining = sequence, answer['latest_sequence'], cycle['phase'], cycle.get('remaining')
        if stage and seen:
            self.prefix, self.boundary = prefix, True
            if stage == 1:self.decision_prefix = prefix
            else:self.final_prefix = prefix


class TypedUfxPipe:
    """Compact tuples are staged and fully validated before a Restore OUT."""
    def __init__(self, description, journal, send, acknowledge, ready, mismatch, completed=lambda: None):
        ufx_profile(description, 'Native UFX')
        self.identity, self.sequence = description['identity'], description['last_sequence']
        self.parameters = Parameters(description)
        self.active = [set(description['native_model']['active_' + bank + 's']) for bank in BANKS]
        self.journal, self.send, self.acknowledge, self.ready = journal, send, acknowledge, ready
        self.mismatch, self.completed = mismatch, completed
        self.pending = bytearray()
        self.model = {k: {} for k in ('routes', 'masters', 'channels', 'globals')}
        self.partial_routes, self.partial_masters = {}, {}
        self.bound = self.initialized = self.retired = self.paused = self.waiting_choice = self.host_only = False
        self.cursor_low = self.observed_through = self.decision = None
        self.restoring = False
        self.room_raw = False
        self.revision = 0

    def request(self, operation, **extra):
        if not shared.uint(self.sequence) or self.sequence == 2**64 - 1:raise RuntimeError('Invalid UFX command sequence')
        self.sequence += 1
        payload = dict(op=operation, identity=self.identity, sequence=self.sequence, **extra)
        if len(json.dumps(payload, separators=(',', ':')).encode()) + 1 > 1048576:raise RuntimeError('UFX compact IPC limit exceeded')
        result = self.send(payload)
        if (not isinstance(result, dict) or result.get('error') or result.get('identity', self.identity) != self.identity
                or result.get('sequence') != self.sequence or result.get('accepted_by_host') is not True
                or result.get('session_retired') is not False or result.get('hardware_confirmed') is not False
                or not shared.uint(result.get('usb_completed'))):raise RuntimeError('UFX transaction incomplete; no retry')
        return result

    def cursor_valid(self, final):
        prefix = self.journal.final_prefix if final else self.journal.decision_prefix
        if prefix is None or self.observed_through is None or not prefix <= self.observed_through <= self.journal.packets.forwarded:
            raise RuntimeError('UFX engine did not consume its native cycle prefix')
        return prefix

    def compact(self, restoring):
        if self.partial_routes or self.partial_masters:raise RuntimeError('Partial UFX logical tuple at completion')
        value = {k: list(v.values()) for k, v in self.model.items()}
        if restoring:
            expected = {(s + (256 if b == 2 else 0), o) for b in (0, 2) for s in self.active[b] for o in self.active[1]}
            if set(self.model['routes']) != expected or set(self.model['masters']) != self.active[1]:raise RuntimeError('Incomplete UFX routes/masters')
            required = {(b, ch, p) for b, p in self.parameters.required for ch in self.active[b]
                        if 'channels' not in self.parameters.channel[b, p] or ch in self.parameters.channel[b, p]['channels']}
            if not required <= self.model['channels'].keys() or not set(self.parameters.required_global) <= self.model['globals'].keys():raise RuntimeError('Incomplete UFX parameter restoration')
        return value

    def send_model(self,model,restoring=False):
        extra = dict(model=model)
        if restoring:extra.update(reconstruction_prefix=self.cursor_valid(True), observed_through=self.observed_through)
        answer = self.request('restore' if restoring else 'set', **extra)
        count = sum(len(model[k]) for k in ('routes','masters','channels','globals'))
        if (answer.get('state_complete') is not True or type(answer.get('commands_completed')) is not int or answer['commands_completed'] != count
                or not shared.uint(answer.get('state_revision')) or answer['state_revision'] <= self.revision):
            raise RuntimeError('UFX semantic completion mismatch')
        self.revision = answer['state_revision']

    def flush(self, restoring=False):
        model = self.compact(restoring)
        if not restoring and not any(model.values()) and not self.room_raw:return
        if restoring and self.parameters.room.cap is not None:
            self.parameters.room.validate_full([(c[1],c[2],c[3]) for c in model['channels'] if c[0]==1 and c[2] in self.parameters.room.descriptors],all_outputs=True)
        if self.room_raw:
            room=[c for c in model['channels'] if c[0]==1 and c[2] in self.parameters.room.descriptors]
            self.parameters.room.validate_full([(c[1],c[2],c[3]) for c in room])
            ordinary=dict(model,channels=[c for c in model['channels'] if not (c[0]==1 and c[2] in self.parameters.room.descriptors)])
            raw=dict(routes=[],masters=[],channels=room,globals=[],room_raw_restore=True)
            batches=[raw]+([ordinary] if any(ordinary.values()) else [])
            if len(batches)>2**64-1-self.sequence:raise RuntimeError('UFX RoomEQ completion sequence exhausted')
            for value in batches:
                if len(json.dumps(dict(op='set',identity=self.identity,sequence=self.sequence+1,model=value),separators=(',',':')).encode())+1>1048576:raise RuntimeError('UFX RoomEQ compact IPC limit exceeded')
            for value in batches:self.send_model(value)
            self.room_raw=False
        else:self.send_model(model,restoring)
        if restoring and self.parameters.room.cap is not None:self.parameters.room.confirm(self.send(dict(op='describe')),self.identity)
        for v in self.model.values():v.clear()
        if restoring:self.initialized = True

    def feed(self, data):
        if self.retired:raise RuntimeError('UFX consumer retired')
        try:
            self.pending.extend(data)
            while len(self.pending) >= 8:
                coord, value = struct.unpack('<Ii', self.pending[:8]);del self.pending[:8]
                kind, ch, field = coord >> 16, coord & 255, coord >> 8 & 255
                if kind == 0:
                    if coord or value or self.bound:raise RuntimeError('Invalid UFX engine bind')
                    self.bound = True;continue
                if not self.bound:raise RuntimeError('UFX command before bind')
                if kind==43:
                    if coord&65535 or value!=1 or not self.initialized or self.room_raw or self.parameters.room.cap is None or any(self.model.values()) or self.partial_routes or self.partial_masters:raise RuntimeError('Invalid UFX RoomEQ raw-intention marker')
                    self.room_raw=True;continue
                if self.cursor_low is not None and self.observed_through is None and kind != 25:raise RuntimeError('Noncontiguous UFX consumed cursor')
                if self.observed_through is not None and not self.restoring and kind not in (40, 41):raise RuntimeError('UFX cursor must immediately precede native decision/staging')
                if kind == 23:
                    if value != 1 or self.initialized or self.waiting_choice:raise RuntimeError('Invalid UFX mismatch question')
                    self.waiting_choice = True;self.mismatch();continue
                if kind in (24, 25, 40, 41):
                    if coord & 65535 or self.initialized:raise RuntimeError('Invalid UFX initialization control')
                    if kind == 24:
                        if self.cursor_low is not None:raise RuntimeError('Duplicate UFX cursor')
                        self.cursor_low = value & 0xffffffff;self.observed_through = None;self.paused = True
                    elif kind == 25:
                        if self.cursor_low is None or self.observed_through is not None:raise RuntimeError('Invalid UFX cursor high word')
                        self.observed_through = self.cursor_low | (value & 0xffffffff) << 32
                    elif kind == 40:
                        if not 0 <= value < 4 or self.decision is not None:raise RuntimeError('Invalid native UFX decision')
                        self.request('decide', reconstruction_prefix=self.cursor_valid(False), observed_through=self.observed_through, decision=DECISIONS[value])
                        self.decision = value;self.waiting_choice = False;self.paused = False;self.cursor_low = self.observed_through = None
                    else:
                        if value or self.decision is None or self.restoring:raise RuntimeError('Invalid final UFX restore stage')
                        self.cursor_valid(True);self.restoring = True
                    continue
                if kind == 4:
                    if field or ch not in shared.TypedMixerPipe.FENCE_SUBIDS or value <= 0 or (ch == 99) == self.initialized:
                        raise RuntimeError('Invalid UFX completion fence')
                    self.flush(ch == 99)
                    self.completed();self.acknowledge(local_sysex(ch, (value,)), self.ready if ch == 99 else None)
                    if ch == 99:self.paused = False
                    continue
                if not self.initialized and not self.restoring:raise RuntimeError('UFX write before final native cycle')
                if kind == 45:
                    if coord & 65535 or value not in (1, 2) or not self.initialized or self.waiting_choice or self.partial_routes or self.partial_masters:
                        raise RuntimeError('Invalid UFX snapshot coefficient phase')
                    self.flush()
                    self.completed()
                    continue
                if kind in (29, 30, 31, 32):
                    bank = 0 if kind < 31 else 2
                    if ch not in self.active[bank] or field not in self.active[1] or (kind in (29, 31) and not -4096 <= value <= 4095) or (kind in (30, 32) and not -100 <= value <= 100):raise RuntimeError('Invalid UFX route tuple')
                    key = (ch + (256 if bank == 2 else 0), field)
                    pair = self.partial_routes.setdefault(key, {})
                    part = 0 if kind in (29, 31) else 1
                    if part in pair:raise RuntimeError('Duplicate UFX route tuple field')
                    pair[part] = value
                    if len(pair) == 2:self.model['routes'][key] = [*key, pair[0], pair[1]];del self.partial_routes[key]
                elif kind in (33, 34, 35):
                    if ch or field not in self.active[1] or (kind == 33 and not -4096 <= value <= 4095) or (kind == 34 and not -100 <= value <= 100) or (kind == 35 and not 0 <= value <= 2):raise RuntimeError('Invalid UFX master tuple')
                    pair = self.partial_masters.setdefault(field, {})
                    if kind in pair:raise RuntimeError('Duplicate UFX master tuple field')
                    pair[kind] = value
                    if len(pair) == 3:self.model['masters'][field] = [field, pair[33], pair[34], pair[35]];del self.partial_masters[field]
                elif kind in (36, 37, 38, 39):
                    bank = -1 if kind == 39 else kind - 36
                    if (bank < 0 and ch or bank >= 0 and ch not in self.active[bank]
                            or not self.parameters.valid(bank, ch, field, value, not self.initialized,raw_room=self.room_raw)):
                        raise RuntimeError('Invalid/scoped/explicit-only UFX parameter')
                    if bank < 0:self.model['globals'][field] = [field, value]
                    else:
                        key=(bank,ch,field)
                        if self.room_raw and bank==1 and field in self.parameters.room.descriptors and key in self.model['channels']:raise RuntimeError('Duplicate raw RoomEQ field')
                        self.model['channels'][key] = [bank, ch, field, value]
                else:raise RuntimeError('Unsupported UFX typed command')
        except BaseException:
            self.retired = True
            raise


def request(path, payload):
    # The complete94-channel HostSync contains almost18k routes. A single
    # atomic Restore may wait for hundreds of real USB completions; no retry.
    with socket.socket(socket.AF_UNIX) as client:
        client.settimeout(30)
        client.connect(str(path))
        data = json.dumps(payload, separators=(',', ':')).encode() + b'\n'
        if len(data) > 1048576:raise RuntimeError('UFX request exceeds native IPC bound')
        client.sendall(data)
        result = bytearray()
        while b'\n' not in result:
            part = client.recv(65536)
            if not part or len(result) + len(part) > 1048576:raise RuntimeError('Incomplete UFX owner response')
            result.extend(part)
        answer = json.loads(result)
        if answer.get('error'):raise RuntimeError(answer['error'])
        return answer


def _was_running(path, value=None):
    if value is None:
        if not path.exists():return False
        data = path.read_text()
        if data not in ('0\n', '1\n'):raise RuntimeError('Invalid previous UFX session marker')
        return data == '1\n'
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(prefix='.ufx-running-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as file:
            file.write('1\n' if value else '0\n');file.flush();os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)


def run(args, transition=None):
    # Linux adaptation of Preferences/WasRunning: a crash leaves1; a confirmed
    # close clears it. Cache existence and unknown readback are never dirty.
    _, state = shared.prepare(args.uid)
    marker = state / 'oscmix' / 'ufx-was-running'
    previous = _was_running(marker)
    old = os.environ.get('OSCMIX_UFX_WAS_RUNNING')
    os.environ['OSCMIX_UFX_WAS_RUNNING'] = str(int(previous))
    _was_running(marker, True)
    try:
        result = shared.run(args, transition, profile_builder=ufx_profile, journal_type=UfxJournal,
                            pipe_type=TypedUfxPipe, admission_check=pcm_matches, rpc=request)
        _was_running(marker, False)
        return result
    finally:
        if old is None:os.environ.pop('OSCMIX_UFX_WAS_RUNNING', None)
        else:os.environ['OSCMIX_UFX_WAS_RUNNING'] = old
