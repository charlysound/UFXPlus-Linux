#!/usr/bin/env python3
"""Desktop-session handoff. Never starts/restarts the audio driver itself."""
import os
import subprocess
import sys

UNIT = "oscmix-with-driver.service"

def systemctl(*args):
    return subprocess.run(["systemctl", "--user", *args], check=False,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0

def main():
    graphical = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    active = systemctl("is-active", "--quiet", "ufxplus-driver.service")
    if sys.argv[1:] == ["--check"]:
        return 0 if graphical and active else 1
    if sys.argv[1:]:
        return 2
    # A desktop login can happen AFTER the enabled driver has already started
    # without DISPLAY. Complete that deferred launch only when opted in.
    if not graphical or not systemctl("is-enabled", "--quiet", UNIT):
        return 0
    names = [name for name in ("DISPLAY", "WAYLAND_DISPLAY", "XAUTHORITY",
             "XDG_CURRENT_DESKTOP", "DBUS_SESSION_BUS_ADDRESS") if os.environ.get(name)]
    if names and not systemctl("import-environment", *names):
        return 1
    if active and not systemctl("start", UNIT):
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
