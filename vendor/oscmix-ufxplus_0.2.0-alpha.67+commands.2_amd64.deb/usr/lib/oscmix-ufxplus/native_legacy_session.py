"""LegacyFX journal and semantic transactions on the existing native owner.

The C model owns reconstruction and mismatch policy. This bridge preserves its
ordered input and typed intentions; it never decodes DSP fragments, selects a
model by PID, or retries an uncertain write.
"""
from collections import deque
import fcntl
import json
import math
import os
from pathlib import Path
import select
import selectors
import shutil
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import native_room_equalizer

from native_scalar_session import (TypedMixerPipe, accept_levels, engine_child,
    local_sysex, osc_text, profile_lines, request, stop, host_control_room_profile,
    channel_defaults_profile)
from device_inventory import enumerate_cached, records
from device_session import prepare

REFERENCE = '75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'
QUEUE_LIMIT = 4 * 1024 * 1024
DECISIONS = ('no_mismatch', 'always_use_host', 'use_host', 'use_device')


def uint(value, bits=64):
    return type(value) is int and 0 <= value < 1 << bits


class Parameters:
    """Producer-issued semantic domains, without a frontend register writer."""
    def __init__(self, description):
        model = description['native_model']
        self.room = native_room_equalizer.Parameters(description)
        self.channel, self.global_fx, self.channel_by_bank = {}, {}, {}
        for field, target in (('channel_parameters', self.channel), ('global_fx_parameters', self.global_fx)):
            values = model.get(field, [])
            if not isinstance(values, list) or len(values) > 256:
                raise RuntimeError('Invalid native LegacyFX parameter descriptors')
            names = set()
            for value in values:
                if not isinstance(value, dict):raise RuntimeError('Invalid native parameter descriptor')
                name, index = value.get('parameter'), value.get('native_parameter')
                if (not isinstance(name, str) or not 1 <= len(name) <= 64 or not name.isascii()
                        or not name.replace('_', '').isalnum() or name != name.lower() or name[0].isdigit()
                        or name in names or not uint(index, 8) or field == 'global_fx_parameters' and index in target
                        or any(type(value.get(key)) is not int or not -2**31 <= value[key] < 2**31
                               for key in ('min', 'max', 'step', 'scale', 'initial'))
                        or not value['min'] <= value['initial'] <= value['max']
                        or value['step'] <= 0 or value['scale'] <= 0
                        or (value['initial'] - value['min']) % value['step']
                        or (value['max'] - value['min']) % value['step']
                        or value.get('observed_register') is not None and not uint(value['observed_register'], 15)):
                    raise RuntimeError('Invalid native LegacyFX parameter domain')
                if field == 'channel_parameters':
                    banks = value.get('banks')
                    if (not isinstance(banks, list) or not banks
                            or any(bank not in ('input', 'output') for bank in banks) or len(set(banks)) != len(banks)):
                        raise RuntimeError('Missing native LegacyFX parameter bank authority')
                    channels = value.get('channels')
                    if (type(value.get('startup_restore', True)) is not bool
                            or 'channels' in value and (not isinstance(channels, list) or not channels
                                or any(not uint(ch, 8) for ch in channels) or len(set(channels)) != len(channels)
                                or any(ch not in model.get('active_' + bank + 's', []) for ch in channels for bank in banks))):
                        raise RuntimeError('Invalid native parameter channel scope or startup policy')
                    low, high = value.get('ui_min', value['min']), value.get('ui_max', value['max'])
                    if (type(low) is not int or type(high) is not int or not value['min'] <= low <= high <= value['max']
                            or (low - value['min']) % value['step'] or (high - value['min']) % value['step']):
                        raise RuntimeError('Invalid native LegacyFX parameter UI domain')
                    for bank in banks:
                        if (bank, index) in self.channel_by_bank:
                            raise RuntimeError('Ambiguous native parameter index on one bank')
                        self.channel_by_bank[bank, index] = dict(value)
                elif 'channels' in value or value.get('startup_restore', True) is not True:
                    raise RuntimeError('Unsupported global native parameter policy')
                target[name if field == 'channel_parameters' else index] = dict(value);names.add(name)
        maps = model.get('global_fx_value_maps', {})
        if not isinstance(maps, dict):raise RuntimeError('Invalid native global FX value maps')
        self.maps = {}
        for name, values in maps.items():
            descriptor = next((p for p in self.global_fx.values() if p['parameter'] == name), None)
            if (descriptor is None or not isinstance(values, list)
                    or len(values) != (descriptor['max'] - descriptor['min']) // descriptor['step'] + 1
                    or any(not uint(value, 16) for value in values) or len(set(values)) != len(values)):
                raise RuntimeError('Invalid native global FX wire-value map')
            self.maps[name] = tuple(values)

    def profile(self, prefix='legacy'):
        def fields(value):
            return '\t'.join(str(value[key]) for key in ('parameter', 'native_parameter', 'min', 'max', 'step', 'scale', 'initial')) + '\t' + str(
                value['observed_register'] if value.get('observed_register') is not None else -1)
        for bank in ('input', 'output'):
            for value in self.channel.values():
                if bank in value['banks']:
                    scope = ('\t' + ','.join(map(str, value['channels'])) + '\t' + str(int(value.get('startup_restore', True)))
                             if 'channels' in value else '\t*\t0' if not value.get('startup_restore', True) else '')
                    yield prefix + '-channel-parameter\t' + bank + '\t' + fields(value) + '\t' + str(
                        value.get('ui_min', value['min'])) + '\t' + str(value.get('ui_max', value['max'])) + scope
        for value in self.global_fx.values():yield prefix + '-global-parameter\t' + fields(value)
        for name, values in self.maps.items():yield prefix + '-global-value-map\t' + name + '\t' + ','.join(map(str, values))

    def command(self, kind, channel, index, units, inputs, outputs, *, restoring=False, raw_room=False):
        bank = 'input' if kind == 26 else 'output'
        descriptor = self.global_fx.get(index) if kind == 28 else self.channel_by_bank.get((bank, index))
        if descriptor is not None and descriptor.get('command_kind')=='room_equalizer_parameter':
            if kind!=27 or channel not in outputs:raise RuntimeError('RoomEQ is output only')
            return self.room.command(channel,index,units,raw=raw_room or restoring) if raw_room else dict(self.room.command(channel,index,units,raw=restoring),raw_restore=False)
        if (descriptor is None or not descriptor['min'] <= units <= descriptor['max']
                or (units - descriptor['min']) % descriptor['step']):
            raise RuntimeError('Unsupported or out-of-domain native LegacyFX parameter')
        if kind == 28:
            if channel:raise RuntimeError('Global LegacyFX parameter has a channel coordinate')
            return dict(kind='global_fx_parameter', parameter=descriptor['parameter'], value=units)
        if channel not in (inputs if kind == 26 else outputs):raise RuntimeError('Inactive LegacyFX FX channel')
        if 'channels' in descriptor and channel not in descriptor['channels']:
            raise RuntimeError('Native parameter is unavailable on this physical port')
        if restoring and not descriptor.get('startup_restore', True):
            raise RuntimeError('Native physical parameter requires an explicit live command')
        bank = 'input' if kind == 26 else 'output'
        if bank not in descriptor['banks']:raise RuntimeError('Native LegacyFX parameter is not available on this bank')
        return dict(kind='channel_parameter', bank=bank,
                    channel=channel, parameter=descriptor['parameter'], value=units)


def tagged_profile_lines(description, name):
    """Shared geometry only; each native dialect validates its own contract."""
    model, cap = description['native_model'], description['capabilities']
    for bank, key, slot in (('inputs', 'inputs', 'input_slots'),
                            ('playbacks', 'outputs_and_playbacks', 'playback_slots'),
                            ('outputs', 'outputs_and_playbacks', 'output_slots')):
        ports = description.get(key)
        active = model.get('active_' + bank)
        if (not isinstance(ports, list) or not isinstance(active, list)
                or not active or any(not uint(ch, 8) for ch in active)
                or len(set(active)) != len(active)
                or [p.get('native_channel') for p in ports] != [ch + 1 for ch in active]
                or model.get('ports', {}).get(bank) != ports
                or model.get(slot) != description.get('mixer_geometry', {}).get(slot)):
            raise RuntimeError('Native LegacyFX active ports differ from its model')
    common = dict(description, host_mixer_defaults=None,
                  capabilities=dict({key:value for key,value in cap.items() if key != 'control_room'}, parameters=[]))
    lines = profile_lines(common, name)
    return lines


def append_host_defaults(lines, description):
    from native_scalar_session import append_native_menu_profile
    append_native_menu_profile(lines, description)
    model = description['native_model']
    defaults = description.get('host_mixer_defaults')
    if (not isinstance(defaults, dict) or defaults.get('reference_sha256') != REFERENCE
            or defaults.get('provenance') != 'host_template' or defaults.get('hardware_confirmed') is not False
            or defaults.get('operation_mode') != 'full' or defaults.get('route_silence_db') != -300
            or defaults.get('route_pan') != 0 or defaults.get('playback_straight') is not True):
        raise RuntimeError('Invalid native LegacyFX host template')
    channel = defaults.get('channel_defaults')
    if (not isinstance(channel, dict) or type(channel.get('stereo')) is not bool
            or type(channel.get('ms_processing')) is not bool
            or type(channel.get('width')) not in (int, float) or not math.isfinite(channel['width'])
            or not -1 <= channel['width'] <= 1):
        raise RuntimeError('Invalid native LegacyFX channel defaults')
    outputs = model['active_outputs']
    gains = defaults.get('output_gains_db')
    mixes = defaults.get('playback_mix_outputs')
    roles = defaults.get('control_room_roles')
    if (not isinstance(gains, list) or len(gains) != len(outputs)
            or any(type(db) not in (int, float) or not math.isfinite(db) or not -65 <= db <= 6 for db in gains)
            or not isinstance(mixes, list) or len(set(mixes)) != len(mixes)
            or any(type(ch) is not int or ch % 2 or ch not in outputs or ch + 1 not in outputs for ch in mixes)
            or not isinstance(roles, dict) or not isinstance(roles.get('phones'), list) or len(roles['phones']) != 4):
        raise RuntimeError('Invalid native LegacyFX output defaults')
    assignments = [roles.get('main'), roles.get('main_b'), *roles['phones']]
    if (any(type(ch) is not int or (ch != -1 and (ch % 2 or ch not in outputs or ch + 1 not in outputs))
            for ch in assignments) or len({ch for ch in assignments if ch >= 0}) != sum(ch >= 0 for ch in assignments)):
        raise RuntimeError('Invalid native LegacyFX Control Room assignment')
    control_room = host_control_room_profile(description)
    lines.append('startup\tfull')
    lines.extend(channel_defaults_profile(description))
    lines.append(f"control-room-roles\t{roles['main']}\t{roles['main_b']}\t{','.join(map(str, roles['phones']))}")
    lines.extend(f'output-gain\t{ch}\t{db:g}' for ch, db in zip(outputs, gains))
    lines.extend(f'playback-mix\t{ch}' for ch in mixes)
    lines.extend(control_room)
    return lines


def legacy_profile(description, name):
    """Extend the shared port profile using the producer's model metadata."""
    model = description.get('native_model')
    cap = description.get('capabilities')
    if (not isinstance(model, dict) or model.get('schema') != 1
            or type(model['schema']) is not int or model.get('route_protocol') != 'LegacyFxTagged'
            or model.get('reference_sha256') != REFERENCE
            or model.get('codec') not in ('ffufx', 'ffucx', 'ff802')
            or not isinstance(cap, dict) or cap.get('observations') is not True or cap.get('set') is not False
            or description.get('native_frontend_admitted') is not False
            or cap.get('route_protocol') != 'LegacyFxTagged'
            or cap.get('max_commands') != 128 or cap.get('max_restore_commands') != 2048
            or cap.get('max_restore_bytes') != 512 * 1024):
        raise RuntimeError('Invalid native LegacyFX model contract')
    lines = tagged_profile_lines(description, name)
    offsets = model.get('matrix_group_offsets')
    params = model.get('observed_parameters')
    if (not isinstance(offsets, list) or len(offsets) != 3 or offsets[0] != 0
            or any(not uint(n, 8) for n in offsets) or sorted(set(offsets)) != offsets
            or not isinstance(params, dict)):
        raise RuntimeError('Invalid native LegacyFX fragment metadata')
    registers = []
    for key in ('input_stereo', 'input_msproc', 'output_stereo',
                'output_master_gain', 'output_master_pan', 'output_master_mute', 'input_mute'):
        item = params.get(key)
        if not isinstance(item, dict):raise RuntimeError('Missing native LegacyFX parameter metadata')
        value = item.get('register')
        if value is None and key == 'output_stereo':value = -1
        if type(value) is not int or not (-1 if key == 'output_stereo' else 0) <= value <= 255:
            raise RuntimeError('Invalid native LegacyFX register metadata')
        registers.append(value)
    lines.extend(('native-dialect\tlegacy-fx\t' + model['codec'],
                  'legacy-fragment-offsets\t' + '\t'.join(map(str, offsets)),
                  'legacy-registers\t' + '\t'.join(map(str, registers[:6])),
                  'legacy-input-mute-register\t' + str(registers[6])))
    append_host_defaults(lines, description)
    lines.extend(Parameters(description).profile())
    return lines


class Packets:
    """Bounded atomic SysEx packets; a partial pipe write never interleaves."""
    def __init__(self):
        self.items = deque()
        self.size = 0
        self.lock = threading.Lock()
        self.forwarded = 0

    def put(self, data, through=None, completed=None):
        with self.lock:
            if self.size + len(data) > QUEUE_LIMIT:
                raise RuntimeError('LegacyFX engine input backlog exceeded; no journal loss is allowed')
            self.items.append((bytes(data), through, completed))
            self.size += len(data)

    def write(self, fd):
        budget = 65536
        while budget > 0:
            done = None
            with self.lock:
                if not self.items:return
                data, through, done = self.items[0]
                try:count = os.write(fd, data[:budget])
                except BlockingIOError:return
                if count <= 0:raise RuntimeError('LegacyFX engine input closed')
                self.size -= count;budget -= count
                if count == len(data):
                    self.items.popleft()
                    if through is not None:self.forwarded = max(self.forwarded, through)
                else:
                    self.items[0] = (data[count:], through, done)
                    done = None
            if done is not None:done()


class Journal:
    """Validate complete windows before advancing the contiguous RX cursor."""
    def __init__(self, identity, packets):
        self.identity, self.packets = identity, packets
        self.cursor = self.latest = self.batches = self.ignored = self.maintenance = 0
        self.counter = 80
        self.prefix = None
        self.boundary = False
        self.progress = time.monotonic()
        self.error = None

    def accept(self, value):
        if (not isinstance(value, dict) or type(value.get('schema')) is not int or value['schema'] != 1
                or value.get('identity') != self.identity or value.get('source') != 'native_dsp_usb'
                or value.get('reference_sha256') != REFERENCE or value.get('after_sequence') != self.cursor
                or not uint(value.get('after_sequence')) or not uint(value.get('next_sequence'))
                or not uint(value.get('latest_sequence')) or value['latest_sequence'] < self.latest
                or not self.cursor <= value['next_sequence'] <= value['latest_sequence']
                or not uint(value.get('batches')) or value['batches'] < self.batches
                or not uint(value.get('ignored_words')) or value['ignored_words'] < self.ignored
                or not uint(value.get('maintenance_usb_completed')) or value['maintenance_usb_completed'] < self.maintenance
                or type(value.get('initial_counter')) is not int or not 0 <= value['initial_counter'] <= self.counter
                or value.get('hardware_observed') is not (value['latest_sequence'] != 0)
                or value.get('host_matrix_reconstruction_required') is not True
                or value.get('matrix_projection_complete') is not False
                or value.get('native_frontend_admitted') is not False):
            raise RuntimeError('Invalid or stale native LegacyFX journal window')
        prefix = value.get('reconstruct_through_sequence')
        if (prefix is not None and (not uint(prefix) or prefix > value['latest_sequence']
                or value['initial_counter'] != 0 or (self.prefix is None and prefix < self.cursor))
                or self.prefix is not None and prefix != self.prefix
                or value['initial_counter'] == 0 and prefix is None):
            raise RuntimeError('Native LegacyFX reconstruction boundary changed or was missed')
        observations = value.get('observations')
        if not isinstance(observations, list) or len(observations) > 256:
            raise RuntimeError('Invalid LegacyFX journal length')
        sequence = self.cursor
        for item in observations:
            sequence += 1
            if (not isinstance(item, dict) or not uint(item.get('sequence')) or item['sequence'] != sequence
                    or not uint(item.get('word'), 32) or item['word'] == 0
                    or item['word'] & 0x40000000 or item['word'].bit_count() % 2 != 1
                    or not uint(item.get('age_ms'), 32)):
                raise RuntimeError('Invalid, noncontiguous native LegacyFX observation')
        if sequence != value['next_sequence']:
            raise RuntimeError('Native LegacyFX journal cursor does not match its window')
        pending = []
        words = []
        end = self.cursor
        boundary = self.boundary
        def flush():
            if words:
                pending.append((local_sysex(93, words), end))
                words.clear()
        for item in observations:
            if prefix is not None and not boundary and item['sequence'] > prefix:
                flush();pending.append((local_sysex(92, (prefix & 0xffffffff, prefix >> 32)), None));boundary = True
            end = item['sequence']
            words.extend((end & 0xffffffff, end >> 32, item['word'], item['age_ms']))
            if len(words) == 32 * 4:flush()
        flush()
        if prefix is not None and not boundary and sequence == prefix:
            pending.append((local_sysex(92, (prefix & 0xffffffff, prefix >> 32)), None));boundary = True
        for packet, through in pending:self.packets.put(packet, through)
        if (sequence > self.cursor or value['batches'] > self.batches or value['initial_counter'] < self.counter):
            self.progress = time.monotonic()
        self.cursor, self.latest, self.prefix, self.boundary = sequence, value['latest_sequence'], prefix, boundary
        self.batches, self.ignored, self.maintenance = value['batches'], value['ignored_words'], value['maintenance_usb_completed']
        self.counter = value['initial_counter']


class TypedLegacyPipe:
    RESTORE_LIMIT = 2048
    REQUEST_BYTE_LIMIT = 512 * 1024
    STARTUP_FX_LIMIT = 2048
    USB_PACKETS_PER_COMMAND = 1
    ALLOW_HOST_ONLY = False
    """One startup Restore and subsequent Sets, fenced by actual completions."""
    def __init__(self, description, journal, send, acknowledge, ready, mismatch, completed=lambda: None):
        self.identity = description['identity']
        self.sequence = description['last_sequence']
        if not uint(self.sequence):raise RuntimeError('Invalid LegacyFX command sequence')
        model = description['native_model']
        self.inputs = frozenset(model['active_inputs'])
        self.playbacks = frozenset(model['active_playbacks'])
        self.outputs = frozenset(model['active_outputs'])
        self.output_stereo_noop = model['observed_parameters']['output_stereo']['register'] is None
        self.restore_limit = self.RESTORE_LIMIT
        self.startup_fx_limit = self.STARTUP_FX_LIMIT
        self.host_only = False
        self.parameters = Parameters(description)
        self.room_raw = False
        self.journal, self.send, self.acknowledge, self.ready = journal, send, acknowledge, ready
        self.mismatch, self.completed = mismatch, completed
        self.pending = bytearray()
        self.commands = []
        self.startup_fx = []
        self.stage = None
        self.cursor_low = self.observed_through = self.decision = None
        self.bound = self.initialized = self.retired = self.paused = self.waiting_choice = False
        self.revision = 0

    def maintenance_valid(self, answer):
        return type(answer.get('maintenance_usb_completed')) is int and answer['maintenance_usb_completed'] == 0

    def flush(self, restoring=False, force_room=False):
        if self.room_raw:
            if not force_room:return
            room=[dict(c,raw_restore=True) for c in self.commands if native_room_equalizer.is_command(c)]
            ordinary=[c for c in self.commands if not native_room_equalizer.is_command(c)]
            self.parameters.room.validate_full(native_room_equalizer.tuples(room))
            batches=[room]+[ordinary[n:n+128] for n in range(0,len(ordinary),128)]
            if len(batches)>2**64-1-self.sequence:raise RuntimeError('RoomEQ completion sequence exhausted')
            for commands in batches:
                if len(json.dumps(dict(op='set',identity=self.identity,sequence=self.sequence+1,commands=commands)).encode())+1>self.REQUEST_BYTE_LIMIT:raise RuntimeError('RoomEQ batch exceeds native IPC bound')
            self.room_raw=False
            for commands in batches:self.commands=commands;self.flush()
            return
        if restoring and self.parameters.room.cap is not None:
            room=[c for c in self.startup_fx if native_room_equalizer.is_command(c)]
            self.parameters.room.validate_full(native_room_equalizer.tuples(room),all_outputs=True)
            self.commands.extend(room)
            self.startup_fx=[c for c in self.startup_fx if not native_room_equalizer.is_command(c)]
        if not self.commands and not restoring:return
        if self.stage is not None:raise RuntimeError('Incomplete LegacyFX semantic command at completion')
        if not self.initialized and not restoring:return
        if self.sequence == 2**64 - 1:raise RuntimeError('Native LegacyFX command sequence exhausted')
        self.sequence += 1
        commands = self.commands
        payload = dict(op='restore' if restoring else 'set', identity=self.identity,
                       sequence=self.sequence, commands=commands)
        if restoring:
            prefix = self.journal.prefix
            if (prefix is None or not self.journal.boundary or self.decision is None
                    or self.observed_through is None or not prefix <= self.observed_through <= self.journal.packets.forwarded):
                raise RuntimeError('LegacyFX engine did not reconcile the delivered native prefix')
            payload.update(reconstruction_prefix=prefix, observed_through=self.observed_through, decision=self.decision)
        if len(json.dumps(payload).encode()) + 1 > self.REQUEST_BYTE_LIMIT:
            raise RuntimeError('LegacyFX restoration exceeds native IPC bound')
        answer = self.send(payload)
        noops = sum(c['kind'] == 'channel_stereo' and c['bank'] == 'output' and self.output_stereo_noop for c in commands)
        if (not isinstance(answer, dict) or answer.get('error') or answer.get('identity', self.identity) != self.identity
                or type(answer.get('sequence')) is not int or answer['sequence'] != self.sequence
                or answer.get('accepted_by_host') is not True or answer.get('session_retired') is not False
                or answer.get('hardware_confirmed') is not False or answer.get('state_complete') is not True
                or type(answer.get('commands_completed')) is not int or answer['commands_completed'] != len(commands)
                or type(answer.get('host_noops')) is not int or answer['host_noops'] != noops
                or not uint(answer.get('usb_completed')) or answer['usb_completed'] > (len(commands) - noops) * self.USB_PACKETS_PER_COMMAND
                or (bool(answer['usb_completed']) != (len(commands) > noops))
                or not self.maintenance_valid(answer)
                or not uint(answer.get('state_revision')) or answer['state_revision'] <= self.revision):
            raise RuntimeError('Native LegacyFX transaction incomplete; no retry')
        self.revision = answer['state_revision']
        if restoring and self.parameters.room.cap is not None:self.parameters.room.confirm(self.send(dict(op='describe')),self.identity)
        self.commands = []
        if restoring:self.initialized = True

    def add(self, command):
        if not self.initialized and self.decision is None:
            raise RuntimeError('Native LegacyFX restore intention before model decision')
        self.commands.append(command)
        if self.room_raw:
            if len(self.commands)>4*(self.restore_limit+self.startup_fx_limit):raise RuntimeError('RoomEQ Recall staging exceeds model bound')
            return
        if len(self.commands) > (128 if self.initialized else self.restore_limit):
            raise RuntimeError('Native LegacyFX command bound exceeded')
        if self.initialized and len(self.commands) == 128:self.flush()

    def feed(self, data):
        if self.retired:raise RuntimeError('Native LegacyFX pipe retired')
        try:
            self.pending.extend(data)
            while len(self.pending) >= 8:
                coordinate, units = struct.unpack('<Ii', self.pending[:8]);del self.pending[:8]
                kind, source, output = coordinate >> 16, coordinate & 255, coordinate >> 8 & 255
                if kind == 0:
                    if coordinate or units or self.bound:raise RuntimeError('Invalid LegacyFX engine bind')
                    self.bound = True
                    continue
                if not self.bound:raise RuntimeError('LegacyFX command before engine bind')
                if kind == 45:
                    if coordinate & 65535 or units not in (1, 2) or not self.initialized or self.stage is not None or self.waiting_choice:
                        raise RuntimeError('Invalid snapshot coefficient phase')
                    self.flush(force_room=True)
                    self.completed()
                    continue
                if kind==43:
                    if coordinate&65535 or units!=1 or not self.initialized or self.parameters.room.cap is None or self.room_raw or self.commands or self.stage is not None:raise RuntimeError('Invalid native RoomEQ raw-intention marker')
                    self.room_raw=True;continue
                if self.cursor_low is not None and self.observed_through is None and kind != 25:
                    raise RuntimeError('Incomplete LegacyFX consumed cursor')
                if self.observed_through is not None and self.decision is None and kind != 22:
                    raise RuntimeError('LegacyFX cursor must immediately precede its decision')
                if kind in (24, 25, 22, 23):
                    if coordinate & 65535 or self.initialized or self.stage or self.commands:
                        raise RuntimeError('Invalid LegacyFX reconstruction control')
                    if kind == 23:
                        if (units != 1 and not (units == 2 and self.ALLOW_HOST_ONLY)) or self.waiting_choice or self.cursor_low is not None:
                            raise RuntimeError('Invalid LegacyFX mismatch question')
                        self.host_only = units == 2
                        self.waiting_choice = True;self.mismatch()
                    elif kind == 24:
                        if self.cursor_low is not None:raise RuntimeError('Duplicate LegacyFX consumed cursor')
                        self.cursor_low = units & 0xffffffff;self.paused = True
                    elif kind == 25:
                        if self.cursor_low is None or self.observed_through is not None:
                            raise RuntimeError('Invalid LegacyFX consumed cursor high word')
                        self.observed_through = self.cursor_low | ((units & 0xffffffff) << 32)
                    else:
                        if not 0 <= units < len(DECISIONS) or self.observed_through is None or self.decision is not None:
                            raise RuntimeError('Invalid LegacyFX native model decision')
                        if units in (0, 3) and (self.host_only or getattr(self.journal, 'counts_complete', True) is False):
                            raise RuntimeError('Incomplete native device model requires an explicit host choice')
                        self.decision = DECISIONS[units];self.waiting_choice = False
                    continue
                if kind == 4:
                    subid = coordinate & 65535
                    if subid not in TypedMixerPipe.FENCE_SUBIDS or units <= 0 or self.stage is not None:
                        raise RuntimeError('Invalid LegacyFX completion fence')
                    if (subid == 99) == self.initialized:
                        raise RuntimeError('Duplicate or missing LegacyFX startup completion')
                    self.flush(restoring=subid == 99,force_room=True)
                    if subid == 99:
                        # All cache intentions were checked before the base
                        # Restore. The native owner admits these Sets only
                        # after that complete model, never through defaults.
                        for offset in range(0, len(self.startup_fx), 128):
                            self.commands = self.startup_fx[offset:offset + 128]
                            self.flush()
                        self.startup_fx.clear()
                    self.completed()  # Drain fd7 only after all preceding IPC completions.
                    self.acknowledge(local_sysex(subid, (units,)), self.ready if subid == 99 else None)
                    if subid == 99:self.paused = False
                    continue
                if self.stage is not None:
                    expected = self.stage['coordinates']
                    if (source, output) != expected:raise RuntimeError('LegacyFX semantic stage coordinates changed')
                if kind in (17, 14, 15, 16):
                    if source not in self.inputs or output not in self.outputs:
                        raise RuntimeError('Inactive LegacyFX input route')
                    if kind == 17:
                        if self.stage is not None or units not in (0, 1):raise RuntimeError('Invalid LegacyFX route header')
                        self.stage = dict(coordinates=(source, output), kind='input', output_stereo=bool(units))
                    elif self.stage is None or self.stage['kind'] != 'input':
                        raise RuntimeError('LegacyFX route sideband without header')
                    elif kind == 14:
                        if 'db_tenths' in self.stage or 'pan_hundredths' in self.stage or not -3000 <= units <= 60:
                            raise RuntimeError('Invalid LegacyFX input gain sideband')
                        self.stage['db_tenths'] = units
                    elif kind == 15:
                        if 'db_tenths' not in self.stage or 'pan_hundredths' in self.stage or not -100 <= units <= 100:
                            raise RuntimeError('Invalid LegacyFX input pan sideband')
                        self.stage['pan_hundredths'] = units
                    else:
                        if not -131072 <= units <= 131071:raise RuntimeError('Invalid native18bit coefficient')
                        stage = self.stage;self.stage = None
                        command = dict(kind='input_coefficient', source=source, output=output, units=units)
                        if 'db_tenths' in stage:
                            command.update(kind='input_route_gain', db_tenths=stage['db_tenths'], output_stereo=stage['output_stereo'])
                            if 'pan_hundredths' in stage:command.update(kind='input_route', pan_hundredths=stage['pan_hundredths'])
                        self.add(command)
                elif kind in (18, 19, 20):
                    if source or output not in self.outputs:raise RuntimeError('Inactive LegacyFX master')
                    if kind == 18:
                        if self.stage is not None or not -3000 <= units <= 60:raise RuntimeError('Invalid LegacyFX master gain')
                        self.stage = dict(coordinates=(source, output), kind='output', db_tenths=units)
                    elif self.stage is None or self.stage['kind'] != 'output':
                        raise RuntimeError('LegacyFX master without gain')
                    elif kind == 19:
                        if 'pan_hundredths' in self.stage or not -100 <= units <= 100:raise RuntimeError('Invalid LegacyFX master pan')
                        self.stage['pan_hundredths'] = units
                    else:
                        if 'pan_hundredths' not in self.stage or units not in (0, 1, 2):raise RuntimeError('Invalid LegacyFX master mute')
                        command = dict(kind='output_master', output=output, db_tenths=self.stage['db_tenths'],
                            pan_hundredths=self.stage['pan_hundredths'], mute=('unmuted', 'channel_muted', 'monitor_muted')[units])
                        self.stage = None;self.add(command)
                elif kind in (26, 27, 28):
                    if self.stage is not None:raise RuntimeError('LegacyFX parameter interrupts a semantic stage')
                    command = self.parameters.command(kind, source, output, units, self.inputs, self.outputs,
                                                      restoring=not self.initialized,raw_room=self.room_raw)
                    if self.initialized:self.add(command)
                    else:
                        if self.decision is None:raise RuntimeError('LegacyFX cache parameter before native model decision')
                        self.startup_fx.append(command)
                        if len(self.startup_fx) > self.startup_fx_limit:raise RuntimeError('LegacyFX cached parameter bound exceeded')
                elif kind == 2:
                    if self.stage is not None or source not in self.playbacks or output not in self.outputs or not -131072 <= units <= 131071:
                        raise RuntimeError('Invalid LegacyFX playback coefficient')
                    self.add(dict(kind='playback_coefficient', source=source, output=output, units=units))
                elif kind == 21:
                    if self.stage is not None or units not in (0, 1) or output not in (0, 1, 2, 3):
                        raise RuntimeError('Invalid LegacyFX channel control')
                    if source not in (self.outputs if output == 1 else self.inputs):raise RuntimeError('Inactive LegacyFX channel control')
                    if output in (0, 1):
                        if source % 2:raise RuntimeError('Native LegacyFX stereo command needs an even pair')
                        self.add(dict(kind='channel_stereo', bank='input' if output == 0 else 'output', channel=source, enabled=bool(units)))
                    else:self.add(dict(kind='input_ms_proc' if output == 2 else 'input_mute', input=source, enabled=bool(units)))
                else:raise RuntimeError('Unsupported typed LegacyFX command')
            if self.initialized and self.stage is None:self.flush()
        except Exception:
            self.retired = True;self.pending.clear();self.commands.clear();self.startup_fx.clear();self.stage = None
            raise


class Echo:
    """Virtual engine feedback stays held until its typed fence completes."""
    def __init__(self):
        self.pending = bytearray()
        self.packets = []
        self.size = 0

    def feed(self, data):
        self.pending.extend(data);self.size += len(data)
        if self.size > QUEUE_LIMIT:raise RuntimeError('LegacyFX virtual feedback backlog exceeded')
        while self.pending:
            if self.pending[0] != 0xf0:raise RuntimeError('Invalid private LegacyFX engine feedback')
            end = self.pending.find(b'\xf7')
            if end < 0:break
            self.packets.append(bytes(self.pending[:end + 1]));del self.pending[:end + 1]

    def release(self, destination):
        if self.pending:raise RuntimeError('Incomplete LegacyFX feedback at completed fence')
        for packet in self.packets:destination.put(packet)
        self.packets.clear();self.size = 0


def legacy_meter_messages(decoded, description):
    """Existing OSC order is POST Peak/RMS, PRE Peak/RMS, POST overload."""
    def string(value):
        raw = value.encode() + b'\0'
        return raw + bytes((-len(raw)) % 4)
    for bank in ('input', 'playback', 'output'):
        for value in decoded[bank]:
            pre = ('pre_fx_peak_db', 'pre_fx_rms_db', 'pre_fx_overload')
            if any(field in value for field in pre) and (bank == 'playback'
                    or any(field not in value for field in pre)
                    or any(type(value[field]) not in (int, float) or not math.isfinite(value[field]) for field in pre[:2])
                    or type(value[pre[2]]) is not int or not 0 <= value[pre[2]] <= 15):
                raise RuntimeError('Invalid native LegacyFX pre-DSP meter observation')
    for bank, key in (('input', 'inputs'), ('playback', 'playbacks'), ('output', 'outputs')):
        for port in description['native_model']['ports'][key]:
            channel = port['native_channel']
            if type(channel) is not int or not 1 <= channel <= len(decoded[bank]):
                raise RuntimeError('Native LegacyFX meter coordinate outside decoded bank')
            value = decoded[bank][channel - 1]
            pre = ('pre_fx_peak_db', 'pre_fx_rms_db', 'pre_fx_overload')
            if any(field in value for field in pre):
                yield string(f'/{bank}/{channel}/level') + string(',ffffi') + struct.pack('>ffffi',
                    value['peak_db'], value['rms_db'], value[pre[0]], value[pre[1]], value['overload'])
            else:
                yield string(f'/{bank}/{channel}/level') + string(',ffi') + struct.pack('>ffi',value['peak_db'],value['rms_db'],value['overload'])


def run(args, transition=None, *, profile_builder=legacy_profile, journal_type=Journal, pipe_type=TypedLegacyPipe, admission_check=None, rpc=request):
    """Run one incarnation; the existing dispatcher handles explicit transitions."""
    if not any(row[0] == args.uid and row[5] == args.incarnation for row in records(enumerate_cached())):
        raise RuntimeError('Selected device connection changed; choose it again')
    app = Path(args.app).resolve()
    controller, engine = app / 'bin/rme-live-levels', app / 'bin/oscmix'
    if not controller.is_file() or not engine.is_file():raise RuntimeError('Native mixer component missing from this installation')
    config, state = prepare(args.uid)
    runtime = Path(tempfile.mkdtemp(prefix='rme-legacy-mix-', dir='/tmp'));os.chmod(runtime, 0o700)
    control = runtime / 'control.sock'
    owner = backend = selector = reader = monitor = journal_reader = None
    incoming = outgoing = typed = None
    owned_fds = set()
    def pipe_pair():
        pair = os.pipe();owned_fds.update(pair);return pair
    heartbeat = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    destination = None
    cancelled = False
    threads_stop = threading.Event()
    notice = {'change':None, 'error':None}
    old_signals = {}
    def cancel(*_):
        nonlocal cancelled
        cancelled = True
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):old_signals[sig] = signal.signal(sig, cancel)
    try:
        from native_runtime import wait_audio, rate_transition
        from linux_settings_status import status, SettingsStatusError
        closed = select.poll();closed.register(sys.stdin.fileno(), select.POLLHUP | select.POLLERR)
        admitted = wait_audio(args.uid, args.incarnation, lambda: cancelled or bool(closed.poll(0)), transition=transition)
        if admitted is not None:
            def watch_format():
                while not threads_stop.is_set():
                    try:
                        change = rate_transition(status(args.uid), admitted)
                        if change:notice['change'] = change;return
                    except SettingsStatusError as error:
                        if error.code not in ('unavailable', 'busy'):notice['error'] = str(error);return
                    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
                        notice['error'] = str(error);return
                    threads_stop.wait(1)
            monitor = threading.Thread(target=watch_format, daemon=True);monitor.start()
        owner = subprocess.Popen([str(controller), args.uid, '--mixer-socket', str(control)], stdout=subprocess.PIPE, stderr=sys.stderr)
        observation = dict(time=time.monotonic(), identity=None, error=None, sequence=0, elapsed_ms=0, meters=None)
        def levels():
            try:
                for line in iter(lambda: owner.stdout.readline(65537), b''):
                    if len(line) > 65536:raise RuntimeError('Native level frame too long')
                    accept_levels(observation, json.loads(line), args.uid)
            except (OSError, ValueError, RuntimeError) as error:observation['error'] = str(error)
        reader = threading.Thread(target=levels, daemon=True);reader.start()
        deadline = time.monotonic() + 5
        while not control.exists():
            if cancelled or notice['change'] or notice['error'] or owner.poll() is not None or time.monotonic() >= deadline:
                if notice['change']:return notice['change']
                raise RuntimeError(notice['error'] or 'Native LegacyFX control owner could not start')
            threads_stop.wait(.02)
        description = rpc(control, dict(op='describe'))
        identity = description['identity']
        if identity.get('uid') != args.uid or description.get('retired'):
            raise RuntimeError('Foreign native LegacyFX owner')
        if admitted is not None:
            compatible = admission_check(description, admitted) if admission_check is not None else (
                len(description['inputs']) == admitted.get('capture_channels') and
                len(description['outputs_and_playbacks']) == admitted.get('playback_channels'))
            if not compatible:raise RuntimeError('Native mixer/audio PCM geometry differs from the confirmed audio format')
        lines = profile_builder(description, args.name)
        packets = Packets();journal = journal_type(identity, packets)
        def collect():
            try:
                while not threads_stop.is_set():
                    journal.accept(rpc(control, dict(op='observations', identity=identity, after_sequence=journal.cursor, limit=256)))
                    if journal.cursor == journal.latest:threads_stop.wait(.02)
            except (OSError, ValueError, KeyError, TypeError, RuntimeError) as error:journal.error = str(error)
        journal_reader = threading.Thread(target=collect, daemon=True);journal_reader.start()
        profile = runtime / 'profile.tsv';profile.write_text('\n'.join(lines) + '\n')
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as reservation:
            reservation.bind(('127.0.0.1', 0));port = reservation.getsockname()[1]
        print(f'PROFILE\t{profile}\t{port}\t{state}\t{config}', flush=True)
        selector = selectors.DefaultSelector();selector.register(sys.stdin, selectors.EVENT_READ)
        if not selector.select(5) or cancelled:raise RuntimeError('Mixer view did not complete its session handshake')
        handshake = sys.stdin.readline().strip().split()
        if len(handshake) != 2 or handshake[0] != 'UI_PORT' or not 0 < int(handshake[1]) < 65536:
            raise RuntimeError('Invalid mixer view handshake')
        destination = ('127.0.0.1', int(handshake[1]));selector.unregister(sys.stdin)
        mi_read, incoming = pipe_pair();outgoing, mi_write = pipe_pair();typed, route_write = pipe_pair()
        high = []
        for fd in (mi_read, mi_write, route_write):
            duplicate = fcntl.fcntl(fd, fcntl.F_DUPFD_CLOEXEC, 32);owned_fds.add(duplicate);high.append(duplicate)
        env = os.environ.copy()
        for key in ('OSCMIX_NATIVE_USB', 'OSCMIX_PROFILE_CONFIG_HOME', 'OSCMIX_PROFILE_STATE_HOME'):env.pop(key, None)
        env.update(OSCMIX_SCALAR_UID=args.uid, OSCMIX_SCALAR_CACHE=str(state / 'oscmix/native-routes.ini'),
                   OSCMIX_DEVICE_PROFILE=str(profile), XDG_CONFIG_HOME=str(config), XDG_STATE_HOME=str(state), OSCMIX_SCALAR_OPEN='1')
        backend = subprocess.Popen([sys.executable, str(Path(sys.modules[engine_child.__module__].__file__).resolve()), '--engine-child',
            *map(str, high), str(engine), '-p', 'rme-scalar', '-l', '-r', f'udp!127.0.0.1!{port}', '-s', f'udp!127.0.0.1!{destination[1]}'],
            pass_fds=high, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=sys.stderr)
        for fd in (mi_read, mi_write, route_write, *high):os.close(fd);owned_fds.remove(fd)
        for fd in (incoming, outgoing, typed, sys.stdin.fileno()):os.set_blocking(fd, False)
        for fd in (outgoing, typed, sys.stdin.fileno()):selector.register(fd, selectors.EVENT_READ)
        echo = Echo()
        def drain_feedback():
            while True:
                try:data = os.read(outgoing, 65536)
                except BlockingIOError:break
                if not data:raise RuntimeError('Native LegacyFX engine feedback closed')
                echo.feed(data)
        def completed():
            drain_feedback();echo.release(packets)
        announced_ready = False
        def ready():
            nonlocal announced_ready
            announced_ready = True;print('READY', flush=True)
        pipe = pipe_type(description, journal, lambda payload:rpc(control, payload), lambda packet, done:packets.put(packet, completed=done), ready,
            lambda:print('MISMATCH\t' + args.uid + ('\tHOST_ONLY' if pipe.host_only else ''), flush=True), completed)
        stdin = bytearray();last_beat = last_meter = 0
        engine_progress = time.monotonic();boundary_seen = journal.prefix is not None
        while not cancelled:
            if notice['error']:raise RuntimeError(notice['error'])
            if notice['change']:
                change = notice['change'];kind = 'HARDWARE_CHANGING' if change.get('_kind') == 'hardware' else 'RATE_CHANGING'
                print(kind + '\t' + change['request_id'], flush=True);return change
            if journal.error:raise RuntimeError(journal.error)
            if owner.poll() is not None or backend.poll() is not None:raise RuntimeError('Native LegacyFX session stopped')
            for key, _ in selector.select(.02):
                data = os.read(key.fd, 65536)
                if not data:
                    if key.fd == sys.stdin.fileno():cancelled = True;continue
                    raise RuntimeError('Native LegacyFX engine pipe closed')
                if key.fd == typed:pipe.feed(data);engine_progress = time.monotonic()
                elif key.fd == outgoing:echo.feed(data)
                else:
                    stdin.extend(data)
                    if len(stdin) > 4096:raise RuntimeError('Invalid LegacyFX view input')
                    while b'\n' in stdin:
                        line, _, tail = stdin.partition(b'\n');stdin[:] = tail
                        if not pipe.waiting_choice or line not in (b'LEGACY_CHOICE 0', b'LEGACY_CHOICE 1'):
                            raise RuntimeError('Unexpected LegacyFX mismatch decision')
                        if pipe.host_only and line == b'LEGACY_CHOICE 0':
                            raise RuntimeError('Device choice is unavailable for an incomplete native model')
                        packets.put(local_sysex(91, (int(line[-1:]),)))
                        pipe.waiting_choice = False;engine_progress = time.monotonic()
            if not pipe.paused:packets.write(incoming)
            now = time.monotonic()
            if journal.prefix is not None and not boundary_seen:engine_progress = now;boundary_seen = True
            # The native80counter advances on successful nonempty DSP batches.
            # Progress extends the idle bound; a real mismatch choice may wait.
            progress = max(engine_progress, journal.progress if journal.prefix is None or getattr(journal, 'multiple_boundaries', False) else engine_progress)
            if not announced_ready and not pipe.waiting_choice and now - progress > 10:
                raise RuntimeError('Native LegacyFX initialization stopped making progress')
            if observation['error'] or observation['identity'] is not None and observation['identity'] != identity:
                raise RuntimeError(observation['error'] or 'Native LegacyFX identity changed')
            if now - observation['time'] > 3:raise RuntimeError('Native LegacyFX levels owner stopped responding')
            meters = observation['meters']
            if announced_ready and meters is not None and meters[0] > last_meter:
                for packet in legacy_meter_messages(meters[1], description):heartbeat.sendto(packet, destination)
                last_meter = meters[0]
            if announced_ready and now - last_beat > .25:
                heartbeat.sendto(osc_text('/device/id', description['native_model']['codec']), destination);last_beat = now
    finally:
        threads_stop.set()
        if destination:heartbeat.sendto(osc_text('/device/id', ''), destination)
        stop(backend);stop(owner)
        for thread in (reader, journal_reader, monitor):
            if thread is not None:thread.join(timeout=1)
        if selector is not None:selector.close()
        for fd in owned_fds:os.close(fd)
        if owner is not None and owner.stdout is not None:owner.stdout.close()
        heartbeat.close()
        for sig, old in old_signals.items():signal.signal(sig, old)
        shutil.rmtree(runtime)
