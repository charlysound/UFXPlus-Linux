#!/usr/bin/env python3
"""Read-only startup gate; never open USB, start audio or retry mixer writes.

Type=simple activation is not readiness: service_start.py can wait for USB.
Wait for the supervised worker to receive its first valid input frames AND
own the opened USB audio interface. Legacy drivers retain the direct-PID gate.
This is startup ordering, not proof of audible audio/clock accuracy.
"""
import os
from pathlib import Path
import subprocess
import sys
import time
from driver_session import snapshot

UNIT = "ufxplus-driver.service"


def service():
    result = subprocess.run(
        ["systemctl", "--user", "show", UNIT, "-p", "ActiveState",
         "-p", "MainPID", "-p", "InvocationID"],
        capture_output=True, text=True, check=True, timeout=3)
    state = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
    session = snapshot()
    if session and session.get('common_owner'):
        state['CommonOwner'] = session
        return state
    if (session and str(session.get("pid")) == state.get("MainPID")
            and session.get("invocation") == state.get("InvocationID")):
        state["WorkerPID"] = str(session.get("worker_pid") or 0) if session.get("state") == "running" else "0"
        state["Session"] = str(session.get("session"))
    return state


def audio_open(state, usb=Path("/sys/bus/usb/devices"), proc=Path("/proc"),
               dev=Path("/dev/bus/usb")):
    if state.get('CommonOwner'):
        # This snapshot comes from the shared authority, which validates the
        # real worker, current attachment, ALSA and PipeWire acknowledgements.
        # main() rechecks the complete stable snapshot immediately before exec.
        return state['CommonOwner'].get('state') == 'running'
    pid = state.get("WorkerPID", state.get("MainPID", "0"))
    if not pid.isdecimal() or int(pid) <= 0 or not state.get("InvocationID"):
        return False
    candidates = []
    for path in usb.iterdir():
        try:
            if ((path / "idVendor").read_text().strip() == "2a39"
                    and (path / "idProduct").read_text().strip() == "3fc1"):
                candidates.append(path)
        except OSError:
            continue
    if len(candidates) > 1:
        raise ValueError("Multiple native USB3 UFX+ devices; automatic mixer startup refused.")
    if not candidates:
        return None  # Back off while hardware is unplugged; no busy retry loop.
    try:
        worker = proc / pid
        # Permit a running package binary after an on-disk package upgrade.
        executable = os.readlink(worker / "exe").removesuffix(" (deleted)")
        if executable != "/usr/bin/ufxplus-live-capture":
            return False
        path = candidates[0]
        interface = path / (path.name + ":1.0")
        if ((interface / "bAlternateSetting").read_text().strip() != "1"
                or (interface / "driver").resolve().name != "usbfs"):
            return False
        node = dev / f"{int((path / 'busnum').read_text()):03d}" / f"{int((path / 'devnum').read_text()):03d}"
        if not os.access(node, os.R_OK | os.W_OK):
            return False
        # A stale sysfs state or another owner's open interface is insufficient.
        return any(os.readlink(fd) == str(node) for fd in (worker / "fd").iterdir())
    except (OSError, ValueError):
        return False


def main():
    if sys.argv[1:]:
        return 2
    print("Waiting for the driver to open the UFX+ audio interface (read-only; no USB requests).", flush=True)
    invocation = None
    try:
        while True:
            state = service()
            if state.get("ActiveState") != "active":
                print("Driver is no longer active; mixer was not started.", flush=True)
                return 0
            current = state.get("InvocationID")
            if not current or (invocation is not None and current != invocation):
                raise ValueError("Driver invocation changed; this mixer startup was cancelled.")
            invocation = current
            ready = audio_open(state)
            if ready and service() == state:
                print("Driver audio interface is open; starting OSCmix native USB3 once.", flush=True)
                launcher = str(Path(__file__).resolve().with_name("AppRun"))
                os.execv(launcher, [launcher, "--native-usb3"])
            time.sleep(1 if ready is None else 0.25)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(f"Mixer startup stopped: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
