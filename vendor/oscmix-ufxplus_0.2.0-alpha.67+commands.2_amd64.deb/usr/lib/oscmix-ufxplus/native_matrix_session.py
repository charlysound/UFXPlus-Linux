"""The native14f matrix policy on the common sparse controller.

The owner chooses its initial cycles and native transfers. The frontend uses
producer bank coordinates and Full intentions, without a USB model table.
"""
import native_scalar_session as shared
import native_sparse_session as sparse
from native_madi_session import pcm_matches


def model_contract(description):
    model,cap=description.get('native_model'),description.get('capabilities')
    if (type(description.get('schema')) is not int or description['schema']!=1
            or not isinstance(model,dict) or model.get('codec')!='matrix_sparse'
            or type(model.get('native_class')) is not int or model['native_class']!=32
            or type(model.get('controller_family')) is not int or model['controller_family']!=13
            or type(model.get('renderer_flags')) is not int or model['renderer_flags']!=0x00400020
            or description.get('reference_sha256')!=sparse.REFERENCE
            or type(model.get('slot_capacity')) is not int or model['slot_capacity'] not in (512,1024,2048)
            or type(model.get('matrix_queue_words')) is not int or model['matrix_queue_words']!=128
            or type(model.get('initial_clear_slots')) is not int or model['initial_clear_slots']!=2048
            or type(model.get('initial_maintenance_usb_packets')) is not int or model['initial_maintenance_usb_packets']!=16
            or type(model.get('initial_guard_cycles')) is not int or model['initial_guard_cycles']!=0
            or not isinstance(cap,dict) or cap.get('route_protocol')!='MatrixSparse'
            or cap.get('restore_transport')!='restore_matrix' or cap.get('max_commands')!=128
            or cap.get('max_restore_bytes')!=524288
            or cap.get('coefficient_commands')!=['input','playback','output_gain']
            or cap.get('matrix_readback') is not False or cap.get('set') is not False
            or cap.get('parameters')!=[] or cap.get('fx_parameters') is not False
            or cap.get('equalizer')!={'available':False,'admitted':False}
            or shared.native_private_fx.capability(description) is not None
            or cap.get('matrix_monitor')!={'cue':True,'mono':True,'cue_gain':'destination_master','cue_source_balance':True}
            or cap.get('physical_adoption') is not False
            or type(description.get('native_units_at_unity')) is not int or description['native_units_at_unity']!=32768
            or type(description.get('coordinate_base')) is not int or description['coordinate_base']!=0):
        raise RuntimeError('Invalid native14f matrix model contract')
    return sparse.bank_contract(description,model)


def matrix_profile(description,name):return sparse.profile_lines(description,name,model_contract)


class TypedMatrixPipe(sparse.TypedSparsePipe):
    model_contract=staticmethod(model_contract)


def run(args,transition=None):
    return shared.run(args,transition,profile_builder=matrix_profile,pipe_type=TypedMatrixPipe,
                      admission_check=pcm_matches,physical_type=sparse.UnavailablePhysicalControls,
                      meter_builder=sparse.meter_messages)
