"""ModernFX adapter on the existing per-UID native session plumbing.

The owner normalizes its protocol. This module forwards semantic observations;
it neither decodes native words nor selects models, registers or endpoints.
"""
import time

import native_legacy_session as shared
import native_room_equalizer
from native_scalar_session import local_sysex

PROTOCOLS = frozenset(('ModernFxDirectTagged', 'ModernFxQueuedParity', 'MultifaceDanteQueuedParity'))


def modern_profile(description, name):
    model, cap = description.get('native_model'), description.get('capabilities')
    if (not isinstance(model, dict) or type(model.get('schema')) is not int or model['schema'] != 1
            or model.get('codec') != 'modern_fx' or model.get('route_protocol') not in PROTOCOLS
            or model.get('reference_sha256') != shared.REFERENCE or not shared.uint(model.get('renderer_flags'), 32)
            or model.get('observation_schema', {}).get('encoding') != 'normalized'
            or not isinstance(cap, dict) or cap.get('observations') is not True or cap.get('set') is not False
            or cap.get('normalized_observations') is not True or cap.get('route_protocol') != model['route_protocol']
            or description.get('native_frontend_admitted') is not False
            or cap.get('max_commands') != 128 or cap.get('max_restore_bytes') != 1024 * 1024
            or model.get('max_restore_bytes') != cap['max_restore_bytes']
            or type(model.get('max_restore_commands')) is not int or not 1 <= model['max_restore_commands'] <= 4096
            or cap.get('max_restore_commands') != model['max_restore_commands']):
        raise RuntimeError('Invalid normalized native ModernFX model contract')
    initial = model.get('native_reconciliation', {})
    if any(initial.get(key) != value for key, value in
           (('initial_counter', 180), ('request_before_batch', 10), ('reconcile_before_batch', 179))):
        raise RuntimeError('Unsupported native ModernFX reconciliation contract')
    pcm = description.get('pcm_geometry')
    pcm_ports = model.get('pcm_ports')
    if (not isinstance(pcm, dict) or not isinstance(pcm_ports, dict)
            or any(type(pcm.get(key)) is not int or not 1 <= pcm[key] <= 256
                   or not isinstance(pcm_ports.get(bank), list) or len(pcm_ports[bank]) != pcm[key]
                   for key, bank in (('capture_channels', 'capture'), ('playback_channels', 'playback')))):
        raise RuntimeError('Invalid native ModernFX PCM geometry, distinct from mixer ports')
    lines = ['#oscmix-native-profile-v1', 'name\t' + name.replace('\t', ' ').replace('\n', ' ')]
    slots = [model.get(key + '_slots') for key in ('input', 'playback', 'output')]
    if any(type(count) is not int or not 1 <= count <= 256 for count in slots):
        raise RuntimeError('Invalid native ModernFX mixer geometry')
    lines.append('geometry\t' + '\t'.join(map(str, slots)))
    for bank, singular, count in zip(('inputs', 'playbacks', 'outputs'), ('input', 'playback', 'output'), slots):
        ports = model.get('ports', {}).get(bank)
        active = model.get('active_' + bank)
        if (not isinstance(ports, list) or any(not isinstance(port, dict) for port in ports)
                or not isinstance(active, list) or not active
                or any(type(ch) is not int or not 0 <= ch < count for ch in active) or len(set(active)) != len(active)
                or [port.get('native_channel') for port in ports] != [ch + 1 for ch in active]):
            raise RuntimeError('Invalid native ModernFX mixer ports')
        for port in ports:
            label = port.get('display_name')
            if (not isinstance(label, str) or not label.strip() or len(label.encode('utf-8')) >= 32
                    or any(ord(char) < 32 or ord(char) == 127 for char in label)):
                raise RuntimeError('Invalid native ModernFX mixer port label')
            lines.append(f"{singular}\t{port['native_channel'] - 1}\t{label}")
    inputs, playbacks, outputs = (len(model['active_' + bank]) for bank in ('inputs', 'playbacks', 'outputs'))
    room=native_room_equalizer.Parameters(description)
    expected = inputs * outputs + playbacks * outputs + 2 * inputs + outputs + (inputs + outputs) // 2 + (len(room.descriptors)*len(room.outputs) if room.cap is not None else 0)
    if model['max_restore_commands'] != expected:
        raise RuntimeError('Native ModernFX restoration geometry is inconsistent')
    lines.extend(('native-dialect\tmodern-fx\tmodern_fx', f"native-renderer-flags\t{model['renderer_flags']}"))
    shared.append_host_defaults(lines, description)
    lines.extend(shared.Parameters(description).profile(prefix='native'))
    lines.extend(room.profile())
    return lines


class ModernJournal:
    """Atomic ordered windows, including the native one-time collection retry."""
    def __init__(self, identity, packets):
        self.identity, self.packets = identity, packets
        self.cursor = self.latest = self.batches = self.retry = 0
        self.counter = 180
        self.prefix = None
        self.boundary = False
        self.counts_complete = False
        self.progress = time.monotonic()
        self.error = None

    @staticmethod
    def event(item):
        kind = item.get('kind')
        source = output = event = value = 0
        if kind == 'input_route_parameter':
            source, output, value = item.get('source'), item.get('output'), item.get('value')
            parameter = item.get('parameter')
            if parameter not in ('gain_db_tenths', 'pan_hundredths'):
                raise RuntimeError('Unknown normalized ModernFX route parameter')
            event = 1 if parameter == 'gain_db_tenths' else 2
        elif kind in ('channel_stereo', 'input_ms_proc', 'input_mute'):
            source, bank, enabled = item.get('channel'), item.get('bank'), item.get('enabled')
            if type(enabled) is not bool or bank not in ('input', 'output') or kind != 'channel_stereo' and bank != 'input':
                raise RuntimeError('Invalid normalized ModernFX boolean')
            value = int(enabled)
            event = (3 if bank == 'input' else 4) if kind == 'channel_stereo' else 5 if kind == 'input_ms_proc' else 6
        elif kind == 'output_master_parameter':
            output, value = item.get('output'), item.get('value')
            parameter = item.get('parameter')
            if parameter not in ('gain_db_tenths', 'pan_hundredths', 'mute'):
                raise RuntimeError('Unknown normalized ModernFX master parameter')
            event = {'gain_db_tenths': 7, 'pan_hundredths': 8, 'mute': 9}[parameter]
        elif kind == 'channel_parameter':
            source, output, value = item.get('channel'), item.get('native_parameter'), item.get('value')
            if item.get('bank') not in ('input', 'output'):
                raise RuntimeError('Invalid normalized ModernFX parameter bank')
            event = 10 if item['bank'] == 'input' else 11
        elif kind == 'global_fx_parameter':
            output, value, event = item.get('native_parameter'), item.get('value'), 12
            # These are already logical native-scaled values, including the
            # producer's firmware-dependent Reverb algorithm conversion.
        elif kind not in ('native_channel_setting', 'native_global_setting', 'native_room_equalizer_setting', 'firmware_status'):
            raise RuntimeError('Unknown normalized ModernFX observation')
        if (not shared.uint(source, 8) or not shared.uint(output, 8)
                or type(value) is not int or not -(1 << 31) <= value < 1 << 31):
            raise RuntimeError('Invalid normalized ModernFX event coordinates/value')
        return event << 16 | output << 8 | source, value & 0xffffffff

    def accept(self, value):
        if (not isinstance(value, dict) or type(value.get('schema')) is not int or value['schema'] != 1
                or value.get('identity') != self.identity or value.get('source') != 'native_dsp_usb'
                or value.get('reference_sha256') != shared.REFERENCE or value.get('normalized') is not True
                or not shared.uint(value.get('after_sequence')) or value['after_sequence'] != self.cursor
                or not shared.uint(value.get('next_sequence')) or not shared.uint(value.get('latest_sequence'))
                or value['latest_sequence'] < self.latest or not self.cursor <= value['next_sequence'] <= value['latest_sequence']
                or not shared.uint(value.get('batches')) or value['batches'] < self.batches
                or type(value.get('native_retry')) is not int or not self.retry <= value['native_retry'] <= 1
                or type(value.get('initial_counter')) is not int or not 0 <= value['initial_counter'] <= 180
                or value['native_retry'] == self.retry and value['initial_counter'] > self.counter
                or type(value.get('native_counts_complete')) is not bool
                or not shared.uint(value.get('parameter_words')) or not shared.uint(value.get('logical_words'))):
            raise RuntimeError('Invalid or stale normalized ModernFX journal')
        prefix = value.get('reconstruct_through_sequence')
        if (prefix is not None and (not shared.uint(prefix) or prefix > value['latest_sequence']
                or value['initial_counter'] != 0 or self.prefix is None and prefix < self.cursor)
                or self.prefix is not None and prefix != self.prefix
                or value['initial_counter'] == 0 and prefix is None
                or self.boundary and value['native_counts_complete'] != self.counts_complete):
            raise RuntimeError('Native ModernFX reconstruction boundary changed or was missed')
        observations = value.get('observations')
        if not isinstance(observations, list) or len(observations) > 256:
            raise RuntimeError('Invalid native ModernFX observation window length')
        sequence, events = self.cursor, []
        for item in observations:
            sequence += 1
            if (not isinstance(item, dict) or not shared.uint(item.get('sequence')) or item['sequence'] != sequence
                    or not shared.uint(item.get('age_ms'), 32)):
                raise RuntimeError('Noncontiguous or invalid native ModernFX observation')
            events.append((sequence, *self.event(item), item['age_ms']))
        if sequence != value['next_sequence']:
            raise RuntimeError('Native ModernFX observation cursor mismatch')
        pending, words = [], []
        boundary, end = self.boundary, self.cursor
        def flush():
            if words:
                pending.append((local_sysex(88, words), end));words.clear()
        def mark():
            nonlocal boundary
            flush();pending.append((local_sysex(89, (prefix & 0xffffffff, prefix >> 32, int(value['native_counts_complete']))), None));boundary = True
        for sequence_number, coordinate, units, age in events:
            if prefix is not None and not boundary and sequence_number > prefix:mark()
            end = sequence_number
            words.extend((end & 0xffffffff, end >> 32, coordinate, units, age))
            if len(words) == 32 * 5:flush()
        flush()
        if prefix is not None and not boundary and sequence == prefix:mark()
        for packet, through in pending:self.packets.put(packet, through)
        if sequence > self.cursor or value['batches'] > self.batches:self.progress = time.monotonic()
        self.cursor, self.latest, self.prefix, self.boundary = sequence, value['latest_sequence'], prefix, boundary
        self.batches, self.retry, self.counter = value['batches'], value['native_retry'], value['initial_counter']
        self.counts_complete = value['native_counts_complete']


class TypedModernPipe(shared.TypedLegacyPipe):
    REQUEST_BYTE_LIMIT = 1024 * 1024
    USB_PACKETS_PER_COMMAND = 2  # Distinct DSP/Matrix packets, including native sync.
    ALLOW_HOST_ONLY = True

    def __init__(self, description, *args, **kwargs):
        modern_profile(description, 'Native ModernFX')  # Validate all authority before any OUT.
        super().__init__(description, *args, **kwargs)
        self.restore_limit = description['native_model']['max_restore_commands']
        self.startup_fx_limit = len(self.parameters.global_fx) + sum(
            len(self.inputs if bank == 'input' else self.outputs)
            for descriptor in self.parameters.channel.values() if descriptor.get('startup_restore', True)
            for bank in descriptor['banks'])
        self.queued_matrix = description['native_model']['route_protocol'] != 'ModernFxDirectTagged'

    def maintenance_valid(self, answer):
        count = answer.get('maintenance_usb_completed')
        # The owner may complete one native SYNC before each Matrix data
        # packet. These completions never count as semantic commands/data.
        return shared.uint(count) and count <= (answer['usb_completed'] if self.queued_matrix else 0)


def pcm_matches(description, admitted):
    geometry = description.get('pcm_geometry')
    if not isinstance(geometry, dict):return False
    return all(type(geometry.get(key)) is int and geometry[key] == admitted.get(key)
               for key in ('capture_channels', 'playback_channels'))


def run(args, transition=None):
    return shared.run(args, transition, profile_builder=modern_profile,
                      journal_type=ModernJournal, pipe_type=TypedModernPipe, admission_check=pcm_matches)
