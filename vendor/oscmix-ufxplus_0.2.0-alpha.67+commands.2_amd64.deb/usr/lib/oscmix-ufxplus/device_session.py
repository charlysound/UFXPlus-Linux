"""Prepare owner-scoped OSCmix files. Never opens USB or modifies legacy files."""
import argparse
import configparser
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile

UID = re.compile(r'rme:[0-9a-f]{4}:[0-9a-f]{4}:serial:[0-9a-f]+\Z')


def write_json(path, value):
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as file:
        temporary = Path(file.name)
        json.dump(value, file, indent=2)
        file.write('\n')
        file.flush()
        os.fsync(file.fileno())
    os.replace(temporary, path)


def prepare(uid, config=None, state=None):
    if uid is not None and not UID.fullmatch(uid):
        raise ValueError('A stable serial-based RME UID is required for persistent mixer control')
    config = Path(config or os.environ.get('XDG_CONFIG_HOME', str(Path.home()/'.config'))).resolve()
    state = Path(state or os.environ.get('XDG_STATE_HOME', str(Path.home()/'.local/state'))).resolve()
    key = hashlib.sha256((uid or 'device-view-without-control').encode()).hexdigest()
    parent = config/'oscmix/devices'/key
    config_root = parent/'config'
    state_root = state/'oscmix/devices'/key/'state'
    parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(parent, 0o700)
    lock_fd = os.open(parent/'.lock', os.O_WRONLY|os.O_CREAT, 0o600)
    with os.fdopen(lock_fd, 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        marker = parent/'identity.json'
        if marker.exists():
            identity = json.loads(marker.read_text())
            if identity.get('schema') != 1 or identity.get('uid') != uid:
                raise ValueError('Profile owner mismatch; existing files retained')
            config_root.mkdir(parents=True, exist_ok=True, mode=0o700)
            state_root.mkdir(parents=True, exist_ok=True, mode=0o700)
            return config_root, state_root
        pending = parent/'pending.json'
        if pending.exists():
            if json.loads(pending.read_text()).get('uid') != uid:
                raise ValueError('Incomplete profile belongs to another owner')
        elif any(path.exists() and any(path.iterdir()) for path in (config_root, state_root)):
            raise ValueError('Unidentified profile data retained; no automatic overwrite')
        else:
            write_json(pending, dict(schema=1, uid=uid))
        config_root.mkdir(parents=True, exist_ok=True, mode=0o700)
        state_root.mkdir(parents=True, exist_ok=True, mode=0o700)
        legacy = configparser.ConfigParser(interpolation=None, strict=False)
        legacy_path = state/'oscmix/ufxplus-native-dsp.ini'
        try:
            legacy.read(legacy_path, encoding='utf-8')
            serial = bytes.fromhex(uid.split(':')[-1]).decode('utf-8') if uid else None
            # This exact old native transport is the only global file format
            # being migrated. Other identities start empty, never with UFX data.
            imported = bool(uid and uid.startswith('rme:2a39:3fc1:serial:') and serial and
                            legacy.get('device', 'identity', fallback=None) == serial)
        except (ValueError, UnicodeError, configparser.Error):
            imported = False
        if imported:
            for source, target in [(config/'oscmix', config_root/'oscmix'), (state/'oscmix', state_root/'oscmix')]:
                if source.exists():
                    def ignore(directory, names):
                        return ['devices'] if Path(directory) == source and 'devices' in names else []
                    shutil.copytree(source, target, symlinks=True, dirs_exist_ok=True, ignore=ignore)
        write_json(marker, dict(schema=1, uid=uid, imported_legacy=imported,
                                config=str(config_root), state=str(state_root)))
        pending.unlink()
        return config_root, state_root


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--uid')
    group.add_argument('--view-only', action='store_true')
    args = parser.parse_args(argv)
    for path in prepare(args.uid):
        if '\n' in str(path) or '\r' in str(path):
            raise ValueError('Unsupported profile path')
        print(path)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        raise SystemExit(f'RME session files unavailable: {error}')
