"""OSCmixer presentation adapter for the common Linux settings authority.

No configuration writes or independent readiness inference: the installed
helper validates process identities and actual ALSA/PipeWire acknowledgements.
"""
import json
import os
from pathlib import Path
import subprocess
import sys


class SettingsStatusError(RuntimeError):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


def helper_path():
    return os.environ.get('OSCMIX_LINUX_SETTINGS_HELPER', '/usr/bin/rme-linux-settings')


def available():
    path = Path(helper_path())
    return path.is_file() and os.access(path, os.X_OK)


def status(uid):
    result = subprocess.run([helper_path(), 'status', '--uid', uid], capture_output=True,
                            text=True, timeout=4)
    if len(result.stdout) > 262144:
        raise RuntimeError('Linux settings response too large')
    value = json.loads(result.stdout)
    if not isinstance(value, dict):
        raise RuntimeError('Invalid Linux settings response')
    if result.returncode or value.get('ok') is False:
        raise SettingsStatusError(str(value.get('error', 'Linux audio unavailable')), value.get('code'))
    if type(value.get('schema')) is not int or value['schema'] != 1 or value.get('uid') != uid:
        raise RuntimeError('Linux status belongs to another device or schema')
    if not isinstance(value.get('state'), str):
        raise RuntimeError('Invalid Linux device state')
    for service in ('alsa', 'pipewire', 'midi'):
        if not isinstance(value.get(service), dict) or type(value[service].get('ready')) is not bool:
            raise RuntimeError('Invalid Linux service readiness')
    if value['state'] in ('running', 'recovering'):
        marker = value.get('marker')
        if not isinstance(marker, dict) or not isinstance(marker.get('attachment'), dict):
            raise RuntimeError('Linux process identity is unavailable')
        for key in ('manager_pid', 'manager_process_start', 'owner_pid', 'owner_process_start', 'worker_pid', 'worker_process_start'):
            number = marker.get(key)
            if isinstance(number, bool) or not str(number).isdigit() or int(number) <= 0:
                raise RuntimeError('Linux process identity is incomplete')
    return value


def summary(value):
    parts = ['Linux audio']
    recovering = value['state'] == 'recovering'
    if value['state'] not in ('running', 'recovering'):
        if value['state'] == 'hardware_changing':
            return 'Linux audio: changing device settings'
        if value['state'] == 'clock_idle':
            return 'Linux audio: external clock selected · select Internal to resume audio'
        change = value.get('rate_change') or {}
        if value['state'] == 'rate_changing' and type(change.get('requested_rate_hz')) is int:
            return f"Linux audio: changing sample rate to {change['requested_rate_hz']} Hz"
        return 'Linux audio: ' + str(value.get('error') or value['state'])
    applied, requested = value.get('applied') or {}, value.get('settings') or {}
    if not isinstance(applied, dict) or not isinstance(requested, dict):
        raise RuntimeError('Invalid Linux settings state')
    for key, title in (('alsa', 'ALSA'), ('pipewire', 'PipeWire'), ('midi', 'MIDI')):
        inactive = key == 'pipewire' and applied.get('backend') == 'alsa'
        parts.append(title + (' off' if inactive else ' recovering' if key == 'pipewire' and recovering
                             else ' ready' if value[key]['ready'] else ' unavailable'))
    rate, capture, playback = (value.get(key) for key in ('rate', 'capture_channels', 'playback_channels'))
    if type(rate) is int and rate > 0:
        parts.append(f'{rate / 1000:g} kHz')
    if type(capture) is int and type(playback) is int:
        parts.append(f'{capture} in / {playback} out')
    frames = applied.get('buffer_frames')
    if type(frames) is int:
        request = f'PipeWire buffer request {frames} frames' if frames else 'automatic PipeWire buffer request'
        if applied.get('backend') == 'alsa' or applied.get('buffer_active') is False:
            request += ' (saved for PipeWire)'
        parts.append(request)
    quantum = applied.get('observed_quantum_frames')
    if (applied.get('backend') != 'alsa' and applied.get('buffer_active') is not False
            and type(quantum) is int and quantum > 0):
        parts.append(f'observed PipeWire quantum {quantum} frames')
    if requested.get('revision') != applied.get('revision'):
        parts.append('settings pending')
    categories=category_summary(value)
    if categories:parts.insert(4,categories)
    return ' · '.join(parts)


def category_summary(value):
    """Same loaded-worker inventory as the settings panel; no second store."""
    abi=value.get('pipewire_nodes_abi')
    if abi is None or (type(abi) is int and abi == 1):return None
    if type(abi) is not int or abi != 2 or not isinstance(value.get('categories'),list):
        raise RuntimeError('Invalid PipeWire category inventory')
    selected=present=chosen=visible=unavailable=0
    seen=set()
    for category in value['categories']:
        if not isinstance(category,dict) or not isinstance(category.get('category'),str) or category['category'] in seen:
            raise RuntimeError('Invalid PipeWire category identity')
        seen.add(category['category'])
        if any(type(category.get(key)) is not bool for key in ('enabled','present')):
            raise RuntimeError('Invalid PipeWire category state')
        selected+=category['enabled'];present+=category['present']
        for direction in ('capture','playback'):
            ports=category.get(direction)
            if not isinstance(ports,list) or len(ports)>256:raise RuntimeError('Invalid PipeWire channel inventory')
            ids=set()
            for port in ports:
                if (not isinstance(port,dict) or type(port.get('native_channel')) is not int
                        or not 1<=port['native_channel']<=256 or port['native_channel'] in ids
                        or any(type(port.get(key)) is not bool for key in ('available','selected','present'))):
                    raise RuntimeError('Invalid PipeWire channel state')
                ids.add(port['native_channel']);chosen+=port['selected'];visible+=port['present']
                unavailable+=port['selected'] and not port['available']
    text=f'PipeWire categories {selected} selected / {present} present · channels {chosen} selected / {visible} present'
    return text+(f' · {unavailable} saved unavailable' if unavailable else '')


def channel_maps(value, uid, incarnation):
    """Presentation slots are canonical native indices, never compact PCM."""
    maps = value.get('channel_map')
    if value['state'] not in ('running', 'recovering') or not value['alsa']['ready'] or maps is None:
        return '-', '-'
    result = []
    for bank, count_key in (('capture', 'capture_channels'), ('playback', 'playback_channels')):
        slots = maps.get(bank) if isinstance(maps, dict) else None
        if (not isinstance(slots, list) or not slots or len(slots) != value.get(count_key)
                or any(type(i) is not int or not 0 <= i < 256 for i in slots)
                or len(set(slots)) != len(slots)):
            raise RuntimeError('Invalid native channel map')
        result.append(','.join(map(str, slots)))
    from device_inventory import enumerate_cached, records
    from native_runtime import current_attachment
    devices = enumerate_cached()
    if not any(row[0] == uid and row[5] == incarnation for row in records(devices)):
        raise RuntimeError('Selected device connection changed')
    device = next(d for d in devices if d['uid'] == uid)
    attachment = value['marker']['attachment']
    if any(attachment.get(key) != expected for key, expected in current_attachment(device).items()):
        raise RuntimeError('Native channel map belongs to another connection')
    return tuple(result)


def main(uid, incarnation):
    maps = ('-', '-')
    try:
        value = status(uid)
        text = summary(value)
        maps = channel_maps(value, uid, incarnation)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        text = 'Linux audio unavailable: ' + str(error)
    text = ''.join(char if ord(char) >= 32 and ord(char) != 127 else ' ' for char in text)[:380]
    print('\t'.join((uid, incarnation, text, *maps)))


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit(2)
    main(*sys.argv[1:])
