#!/usr/bin/env python3
"""Native RME per-attachment lifecycle; USB stays in the existing owners."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import secrets
import stat
import subprocess
import sys
import threading

from launch import ROOT, occupied, publish_status, select, verify
from rate_change import RateChanges
from owner_change import OwnerChanges
from hardware_change import HardwareChanges
from stopped_resume import StoppedResumes

SYSFS = Path('/sys/bus/usb/devices')


def process_start(pid):
    try:
        return (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()[19]
    except (OSError, ValueError, IndexError):
        return None


def attachment(device, root=SYSFS):
    """Same kernel incarnation fields and descriptor identity as rme::attachment.

    Re-read cached enumeration fields to reject a replacement during inventory.
    No claim, USB request, PID policy or capability inference occurs here.
    """
    name = device['usb_path']
    if not name or Path(name).name != name or name in ('.', '..'):
        raise ValueError('invalid attachment path')
    path = root / name
    before = path.stat()
    raw = (path / 'descriptors').read_bytes()
    for key, field, base in (('busnum', 'bus', 10), ('devnum', 'address', 10),
                             ('idVendor', 'vendor_id', 16), ('idProduct', 'product_id', 16),
                             ('bcdDevice', 'revision', 16)):
        if int((path / key).read_text().strip(), base) != device[field]:
            raise ValueError('attachment changed during inventory')
    if (path / 'bConfigurationValue').read_text().strip() != '1':
        raise ValueError('native configuration1 required')
    if len(raw) < 18 or raw[:2] != bytes((18, 1)) or any(
        int.from_bytes(raw[offset:offset + 2], 'little') != device[field]
        for offset, field in ((8, 'vendor_id'), (10, 'product_id'), (12, 'revision'))
    ):
        raise ValueError('descriptor identity differs from inventory')
    after = path.stat()
    fields = lambda m: (m.st_dev, m.st_ino, m.st_ctime_ns)
    if fields(before) != fields(after):
        raise ValueError('attachment changed during observation')
    seconds, nanos = divmod(after.st_ctime_ns, 1000000000)
    return {'connection_marker': f'{after.st_dev}:{after.st_ino}:{seconds}:{nanos}',
            'descriptor_sha256': hashlib.sha256(raw).hexdigest(),
            'sysfs_inode': after.st_ino, 'sysfs_ctime_ns': after.st_ctime_ns,
            'usb_path': name, 'bus': device['bus'], 'address': device['address']}


def private_directory(path):
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    metadata = path.lstat()
    if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != os.getuid() or metadata.st_mode & 0o077:
        raise ValueError('automatic owner runtime must be a private user directory')
    return path


def inventory(root=ROOT):
    result = json.loads(subprocess.check_output([str(root / 'ufxplusctl'), 'list-devices'],
                                               text=True, timeout=5))
    if not isinstance(result, list) or any(not isinstance(d, dict) for d in result):
        raise ValueError('invalid native inventory')
    return result


def legacy_main_pid():
    try:
        value = subprocess.check_output(['systemctl', '--user', 'show', '--property=MainPID',
                                         '--value', 'ufxplus-driver.service'],
                                        text=True, timeout=2, stderr=subprocess.DEVNULL).strip()
        return int(value) if value.isdecimal() and int(value) > 0 else None
    except (OSError, ValueError, subprocess.SubprocessError):return None


def legacy_supervisor(runtime=None, proc=Path('/proc'), lookup_main_pid=legacy_main_pid, expected_identity=None):
    """Reuse runtime_state.py identity, or validated service MainPID before JSON.

    Preserve its one-device discover() scope even before it claims IF0. This is
    distribution coexistence, not a second device catalogue or USB permission.
    """
    if runtime is None:
        value = os.environ.get('XDG_RUNTIME_DIR')
        runtime = Path(value) if value else None
    def validate(pid, expected_start=None, state='starting'):
        if type(pid) is not int or pid <= 0:return None
        try:
            process = proc / str(pid)
            if process.stat().st_uid != os.getuid():return None
            def ticks():return (process / 'stat').read_text().rsplit(')', 1)[1].split()[19]
            start = ticks()
            if expected_start is not None and expected_start != start:return None
            command = (process / 'cmdline').read_bytes().split(b'\0')
            if command and command[-1] == b'':command.pop()
            if command != [b'/usr/bin/python3', b'/usr/share/ufxplus-driver/service_start.py']:return None
            if start != ticks():return None
            return {'pid':pid, 'process_start':start, 'state':state}
        except (OSError, ValueError, IndexError):return None
    if expected_identity is not None:
        return validate(expected_identity.get('pid'), expected_identity.get('process_start'), expected_identity.get('state', 'starting'))
    try:
        value = json.loads((runtime / 'ufxplus-session.json').read_text()) if runtime else None
        if (isinstance(value, dict) and value.get('schema') == 1 and
                isinstance(value.get('state'), str) and value['state'] and value['state'] != 'stopped' and
                isinstance(value.get('process_start'), str) and value['process_start']):
            result = validate(value.get('pid'), value.get('process_start'), value['state'])
            if result:return result
    except (OSError, ValueError, KeyError, TypeError):pass
    # Type=simple service startup precedes its first status write. MainPID is
    # only a candidate: exact process identity and user ownership are required.
    return validate(lookup_main_pid())


class Supervisor:
    """A failed incarnation is latched. Only detach/replacement permits restart.

    No replacement owner starts until the preceding launcher has exited: that
    launcher's existing stop/finish code drains audio, MIDI and host endpoints.
    """
    def __init__(self, directory, root=ROOT, sysfs=SYSFS, enumerate_devices=inventory,
                 spawn=subprocess.Popen, observe=attachment, is_occupied=occupied, status_file=None, legacy_probe=legacy_supervisor,
                 legacy_current=lambda identity: legacy_supervisor(expected_identity=identity), rate_options=None, owner_options=None, hardware_options=None,
                 resume_stopped_from=None, resume_options=None):
        self.directory = directory
        self.status_file = status_file or directory / 'devices.json'
        self.root = root
        self.sysfs = sysfs
        self.enumerate = enumerate_devices
        self.spawn = spawn
        self.observe = observe
        self.is_occupied = is_occupied
        self.legacy_probe = legacy_probe
        self.legacy_current = legacy_current
        self.entries = {}
        self.generation = 0
        self.token = secrets.token_hex(8)
        # This is a capability of this loaded implementation, not of files a
        # later installation may replace. Keep it fixed across USB reconnects.
        self._hardware_request_abis = (1, 2)
        self._hardware_operations = ('clock_source', 'digital')
        self.inventory_error = None
        self.device_errors = {}
        self.closing = False
        self.rate_changes=RateChanges(self,**(rate_options or {}))
        self.owner_changes=OwnerChanges(self,**(owner_options or {}))
        self.hardware_changes=HardwareChanges(self,**(hardware_options or {}))
        self.stopped_resumes=StoppedResumes(self,resume_stopped_from,**(resume_options or {}))

    def launch(self,entry,rate=None,preserve_current_rate=False):
        if type(preserve_current_rate) is not bool or (preserve_current_rate and rate is None):
            raise ValueError('Current-rate preservation requires an explicit format-change rate')
        command=[sys.executable,str(self.root/'launch.py'),'--uid',entry['uid'],'--no-levels','--status-file',entry['owner_status_file'],
                 '--expected-attachment',json.dumps(entry['attachment'],separators=(',',':'))]
        if rate is not None:command+=['--format-change-rate',str(rate)]
        if preserve_current_rate:command+=['--preserve-current-rate','true']
        entry['_child']=self.spawn(command,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        entry['pid']=entry['_child'].pid;entry['process_start']=process_start(entry['pid'])

    def stop(self, entry, reason):
        child = entry.get('_child')
        if child is not None and child.poll() is None and not entry.get('_stop_sent'):
            try:
                child.send_signal(signal.SIGTERM)
            except ProcessLookupError:
                pass
            entry['_stop_sent'] = True
            entry['status'] = 'stopping'
            entry['reason'] = reason

    def reap(self, entry):
        child = entry.get('_child')
        if child is None or child.poll() is None:
            return
        child.wait()
        entry['returncode'] = child.returncode
        entry['_child'] = None
        entry['status'] = 'stopped' if entry.get('_stop_sent') and child.returncode == 0 else 'error'
        if ((entry.get('rate_change',{}).get('phase')=='error' and entry.get('rate_change',{}).get('uncertain')) or
                entry.get('_guarded_startup_failed') or entry.get('stopped_resume',{}).get('phase')=='error'):entry['status']='error'
        entry['reason'] = entry.get('reason', 'owner exited; no retry for this attachment')

    def tick(self):
        for entry in self.entries.values():
            self.reap(entry)
        observed = {}
        self.inventory_error = None
        self.device_errors = {}
        if not self.closing:
            try:
                devices = self.enumerate(self.root)
                if not isinstance(devices,list) or any(not isinstance(device,dict) for device in devices):raise ValueError('invalid native inventory')
                groups={}
                for device in devices:
                    uid = device.get('uid')
                    if device.get('model') is None:continue
                    if not isinstance(uid,str) or not uid:raise ValueError('invalid native device UID')
                    groups.setdefault(uid,[]).append(device)
                for uid,group in groups.items():
                    try:
                        # Refuse both ambiguous attachments of this UID, while
                        # preserving independent owners whose identity is known.
                        device=select(group,uid)
                        observed[uid]=(device,self.observe(device,self.sysfs))
                    except (OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError) as error:self.device_errors[uid]=str(error)
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
                self.inventory_error = str(error)
                observed = {}
        preferences={}
        for uid,(device,_) in observed.items():
            try:preferences[uid]=self.owner_changes.preference(device)
            except (OSError,ValueError,KeyError,TypeError) as error:preferences[uid]={'phase':'error','error':str(error)}
        legacy_targets = [uid for uid, (device, _) in observed.items()
                          if device.get('vendor_id') == 0x2a39 and device.get('product_id') == 0x3fc1]
        legacy = None
        if len(legacy_targets) == 1:
            target = legacy_targets[0]
            previous = self.entries.get(target, {})
            try:busy = self.is_occupied(observed[target][0], self.sysfs)
            except (OSError, ValueError):busy = False
            cached = previous.get('external_supervisor')
            # A cheap /proc identity check preserves the busy owner without
            # polling systemctl. A dead/recycled supervisor requires a refresh.
            legacy = self.legacy_current(cached) if busy and cached else None
            if legacy is None:
                legacy = self.legacy_probe()
        reserved_uid = legacy_targets[0] if legacy and len(legacy_targets) == 1 else None
        if reserved_uid and (preferences.get(reserved_uid) or {}).get('phase')=='committed' and (preferences.get(reserved_uid) or {}).get('owner')=='native' and legacy.get('state')=='delegated':
            reserved_uid=None
        for uid, entry in self.entries.items():
            current = observed.get(uid)
            if self.closing or current is None or current[1] != entry['attachment']:
                self.stop(entry, 'shutdown' if self.closing else 'attachment absent, changed or inventory unavailable')
                if entry.get('_owner_change'):
                    self.owner_changes.blocked(entry,'Attachment or manager changed during handoff; no automatic replay')
                if uid in self.device_errors:entry['reason']='Device discovery failed: '+self.device_errors[uid]
                if self.inventory_error is None and uid not in self.device_errors and current is None and not self.closing:
                    entry['_invalidated'] = True
        for uid, (device, identity) in observed.items():
            entry = self.entries.get(uid)
            if entry is not None and entry.get('_child') is not None:
                continue
            if entry is not None and entry['attachment'] == identity and not entry.get('_invalidated'):
                if entry.get('_legacy_reserved'):
                    if (preferences.get(uid) or {}).get('phase') in ('pending','error') and not entry.get('_owner_change'):
                        entry['status']='migration_blocked';entry['reason']='Interrupted owner handoff; explicit recovery required'
                        if legacy:entry['external_supervisor']=legacy
                        continue
                    busy = self.is_occupied(device, self.sysfs)
                    entry['status'] = 'external_owner' if busy else 'external_pending'
                    entry['reason'] = ('legacy UFX+ supervisor owns this attachment' if busy else
                                       'reserved for legacy UFX+ supervisor; audio not ready')
                    entry['external_supervisor'] = legacy if uid == reserved_uid else None
                continue  # includes owner errors: never loop on one attachment
            self.generation += 1
            status_path = self.directory / (hashlib.sha256(uid.encode()).hexdigest() + f'-{self.token}-{self.generation}.json')
            entry = {'uid': uid, 'attachment': identity, 'generation': self.generation,
                     'status': 'starting', 'owner_status_file': str(status_path),
                     'levels_owner': 'oscmix', 'model': device['model'], '_child': None}
            self.entries[uid] = entry
            try:
                busy = self.is_occupied(device, self.sysfs)
                if (preferences.get(uid) or {}).get('phase') in ('pending','error'):
                    entry['_legacy_reserved']=True
                    if legacy and uid in legacy_targets:entry['external_supervisor']=legacy
                    entry['status']='migration_blocked';entry['reason']=(preferences[uid].get('error') or 'Interrupted owner handoff; explicit recovery required')
                    continue
                if self.stopped_resumes.contains(uid):
                    if uid == reserved_uid:raise ValueError('Legacy authority still reserves this attachment')
                    self.stopped_resumes.start(entry,device)
                    continue
                if uid == reserved_uid:
                    entry['_legacy_reserved'] = True
                    entry['external_supervisor'] = legacy
                    entry['status'] = 'external_owner' if busy else 'external_pending'
                    entry['reason'] = ('legacy UFX+ supervisor owns this attachment' if busy else
                                       'reserved for legacy UFX+ supervisor; audio not ready')
                    continue
                if busy:
                    entry['status'] = 'external_owner'
                    entry['reason'] = 'existing audio owner preserved'
                    continue
                if self.hardware_changes.startup(entry):
                    rate=entry.pop('_startup_format_change_rate',None)
                    self.launch(entry,rate,preserve_current_rate=True) if rate is not None else self.launch(entry)
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
                entry['status'] = 'error'
                entry['reason'] = str(error)
        self.hardware_changes.tick(observed)
        self.rate_changes.tick(observed)
        self.owner_changes.tick(observed)
        self.stopped_resumes.tick()
        self.publish()

    def publish(self):
        records = []
        for entry in self.entries.values():
            record = {k: v for k, v in entry.items() if not k.startswith('_')}
            try:
                owner = json.loads(Path(entry['owner_status_file']).read_text())
                if owner.get('schema') == 1 and owner.get('uid') == entry['uid'] and owner.get('attachment') == entry['attachment']:
                    record['owner'] = owner
                    record['services'] = owner.get('services', {})
                    record['recovery']=owner.get('recovery')
                    workers=owner.get('workers') or {};audio=workers.get('audio') or {}
                    live=(owner.get('pid')==entry.get('pid') and owner.get('process_start')==entry.get('process_start') and
                          self.rate_changes.check_process(entry.get('pid'),entry.get('process_start'),os.getpid()) and
                          self.rate_changes.check_process(audio.get('pid'),audio.get('process_start'),entry.get('pid')))
                    if record['status'] in ('starting','running','recovering') and live and owner.get('status') == 'audio_ready':
                        try:
                            if self.hardware_changes.confirm_startup(entry,owner):
                                record['status'] = 'running';entry['status'] = 'running'
                                if entry.get('hardware_settings') is not None:record['hardware_settings']=entry['hardware_settings']
                        except (OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError) as error:
                            self.stop(entry,'Guarded audio opening did not preserve settings')
                            entry.update(status='error',reason=str(error),_guarded_startup_failed=True)
                            record.update(status='error',reason=str(error))
                    elif record['status'] in ('running','recovering') and not live:
                        record['status']='error';record['reason']='Audio process identity is no longer current; no automatic USB retry'
                    elif live and record['status'] in ('starting','running','recovering') and (owner.get('recovery') or {}).get('state') in ('waiting','error'):
                        record['status']='recovering';entry['status']='recovering'
            except (OSError, ValueError, TypeError, AttributeError):
                pass
            records.append(record)
        publish_status(self.status_file, {'schema': 1, 'manager_pid': os.getpid(), 'manager_process_start': process_start(os.getpid()), 'manager_nonce': self.token,
                       'manager_capabilities':dict(schema=1,hardware_request_abis=list(self._hardware_request_abis),operations=list(self._hardware_operations)),
                       'inventory_error': self.inventory_error, 'device_errors':self.device_errors,'closing': self.closing,
                       'devices': sorted(records, key=lambda r: r['uid'])})

    def close(self):
        self.closing = True
        self.tick()

    def drained(self):
        return all(e.get('_child') is None for e in self.entries.values())


def main():
    parser = argparse.ArgumentParser(description='Automatic native RME audio/MIDI owners; OSCmix owns levels/control.')
    default = Path(os.environ.get('XDG_RUNTIME_DIR', f'/tmp/rme-{os.getuid()}')) / 'rme-native'
    parser.add_argument('--runtime-root', '--runtime', dest='runtime', type=Path, default=default)
    parser.add_argument('--status-file', type=Path)
    parser.add_argument('--resume-stopped-from',type=Path,help='Consume one private stopped-owner authorization before the first tick')
    args = parser.parse_args()
    verify(ROOT)
    directory = private_directory(args.runtime)
    if args.status_file is not None and args.status_file.parent.resolve() != directory.resolve():
        raise ValueError('status-file must be inside the private runtime directory')
    lock_path = directory / 'manager.lock'
    with open(lock_path, 'a', opener=lambda p, f: os.open(p, f | os.O_NOFOLLOW, 0o600)) as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('automatic native RME manager already running')
        wake = threading.Event()
        previous = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)}
        for sig in previous:
            signal.signal(sig, lambda *_: wake.set())
        manager = Supervisor(directory, status_file=args.status_file,resume_stopped_from=args.resume_stopped_from)
        try:
            while not wake.is_set():
                manager.tick()
                wake.wait(0.5)
        finally:
            manager.closing = True
            for entry in manager.entries.values():
                manager.stop(entry, 'shutdown')
            # Drain even when publishing status failed (disk full, removal).
            # Do not kill a USB owner or create its replacement while it drains.
            while not manager.drained():
                for entry in manager.entries.values():
                    manager.reap(entry)
                if not manager.drained():threading.Event().wait(0.1)
            try:manager.publish()
            finally:
                for sig, handler in previous.items():signal.signal(sig, handler)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
