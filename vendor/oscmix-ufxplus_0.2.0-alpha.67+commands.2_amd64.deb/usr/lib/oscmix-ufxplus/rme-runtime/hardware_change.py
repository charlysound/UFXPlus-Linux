"""One-shot semantic hardware settings; codecs and USB ownership stay native."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
from launch import process_identity
from rate_change import private_json


def hardware(root,uid,attachment,operation=None,request=None):
    tool=root/'ufxplus-rate-guarded'
    if not tool.exists():
        # Source-tree unit fixtures have no binaries. Production verifies this
        # executable in the bundle manifest before constructing the manager.
        if (root/'manifest.json').exists():raise ValueError('Guarded settings codec is missing')
        return None
    binding=[uid,attachment['connection_marker'],attachment['descriptor_sha256']]
    if operation is None:args=['status-guarded',*binding]
    elif operation=='clock_source':args=['source-guarded',str(request['source']),*binding]
    elif operation=='digital':args=['digital-guarded',str(request['expected_flags']),*binding,*[f'{k}={v}' for k,v in sorted(request['changes'].items())]]
    else:raise ValueError('Unsupported hardware operation')
    result=subprocess.run([str(tool),*args],capture_output=True,text=True,timeout=8)
    if len(result.stdout)>1048576:raise ValueError('Hardware readback exceeds the metadata limit')
    if result.returncode:raise ValueError(result.stderr.strip() or 'Native hardware settings failed; no retry')
    value=json.loads(result.stdout)
    if operation is None:
        if value.get('supported') is False:return None
        if (value.get('schema')!=1 or value.get('uid')!=uid or value.get('connection_marker')!=binding[1] or
                value.get('descriptor_sha256')!=binding[2] or value.get('parameter_writes')!=0 or
                value.get('codec')!='ufxplus_runtime_settings' or not isinstance(value.get('clock_sources'),list) or
                not isinstance(value.get('status'),dict)):
            raise ValueError('Hardware settings readback belongs to another interface')
    elif not isinstance(value.get('after'),dict):raise ValueError('Native settings readback is missing')
    return value


def hardware_v2(root,uid,attachment,operation=None,request=None):
    """Explicit ABI2 endpoints; an ABI1 caller never reaches these writers."""
    tool=root/'ufxplus-rate-guarded'
    if not tool.exists():
        if (root/'manifest.json').exists():raise ValueError('Guarded settings codec is missing')
        return None
    binding=[uid,attachment['connection_marker'],attachment['descriptor_sha256']]
    if operation is None:args=['hardware-status-v2-guarded',*binding]
    elif operation=='clock_source':args=['hardware-source-v2-guarded',str(request['source']),request['expected_settings'],*binding]
    elif operation=='digital':args=['hardware-digital-v2-guarded',request['expected_settings'],*binding,*[f'{k}={v}' for k,v in sorted(request['changes'].items())]]
    else:raise ValueError('Unsupported hardware operation')
    result=subprocess.run([str(tool),*args],capture_output=True,text=True,timeout=8)
    if len(result.stdout)>1048576:raise ValueError('Hardware readback exceeds the metadata limit')
    if result.returncode:raise ValueError(result.stderr.strip() or 'Native hardware settings failed; no retry')
    value=json.loads(result.stdout)
    if (not isinstance(value,dict) or type(value.get('schema')) is not int or value['schema']!=2 or
            type(value.get('request_abi')) is not int or value['request_abi']!=2 or
            value.get('codec')!='rme_runtime_settings' or value.get('uid')!=uid or
            value.get('connection_marker')!=binding[1] or value.get('descriptor_sha256')!=binding[2]):
        raise ValueError('ABI2 hardware readback belongs to another interface or codec')
    if operation is None:
        if type(value.get('parameter_writes')) is not int or value['parameter_writes']!=0:raise ValueError('Hardware status performed a parameter write or omitted its count')
        if value.get('supported') is False:return None
        if value.get('supported') is not True or not isinstance(value.get('status'),dict):raise ValueError('Native settings status is missing')
    elif (not isinstance(value.get('before'),dict) or not isinstance(value.get('after'),dict) or
          type(value.get('parameter_writes')) is not int or value['parameter_writes']<0):raise ValueError('Native settings readback or completion count is missing')
    token=value.get('expected_settings')
    if not isinstance(token,str) or not 1<=len(token)<=8192:raise ValueError('Native settings guard is missing')
    return value


def internal_v2(observed):
    clock=observed['status'].get('clock') or {}
    if (clock.get('current_kind') not in ('internal','external') or clock.get('selected_kind') not in ('internal','external','unknown') or
            type(clock.get('current_internal_confirmed')) is not bool):
        raise ValueError('Native clock preference or current source is unknown; audio remains stopped')
    # A selected external source falling back to Internal does not prove the
    # Internal preference required to resume. An unknown preference is also
    # unconfirmed, but an explicit guarded source choice can repair it while
    # stopped. Never substitute the current source for that preference.
    return clock['selected_kind']=='internal' and clock['current_kind']=='internal' and clock['current_internal_confirmed'] is True


def audio_internal_v2(observed):
    """Audio follows the confirmed current clock; Digital keeps internal_v2."""
    clock=observed['status'].get('clock') or {}
    if (clock.get('current_kind') not in ('internal','external','unknown') or
            type(clock.get('current_internal_confirmed')) is not bool):
        raise ValueError('Native current clock confirmation is unavailable')
    return clock['current_kind']=='internal' and clock['current_internal_confirmed'] is True


def rate_v2(observed):
    rate=(observed['status'].get('clock') or {}).get('reference_nominal_rate_hz')
    if type(rate) is not int or rate<=0:raise ValueError('Native nominal rate is unavailable; no audio resume')
    return rate


class HardwareChanges:
    def __init__(self,manager,call=hardware,call_v2=hardware_v2):
        self.manager=manager;self.lifecycle=manager.rate_changes;self.call=call;self.call_v2=call_v2;self.consumed=set()

    def read(self,entry,abi):
        return (self.call_v2 if abi==2 else self.call)(self.manager.root,entry['uid'],entry['attachment'])

    def previous_rate(self,entry):
        remembered=entry.get('_hardware_audio_rate')
        if remembered is None:return None
        if remembered['uid']!=entry['uid'] or remembered['attachment']!=entry['attachment']:
            raise ValueError('The previous audio rate belongs to another attachment')
        return remembered['rate']

    def resume_rate(self,entry,observed):
        previous=self.previous_rate(entry)
        # A startup clock_idle has no running-rate history. Only its confirmed
        # native Internal reference may then supply a rate, never a default.
        return previous if previous is not None else rate_v2(observed)

    def confirm_reopen(self,entry,transaction):
        self.confirm_preserved(entry,transaction['settings_before_reopen'],entry['hardware_change']['observed_rate_hz'])

    def confirm_preserved(self,entry,expected,rate):
        fresh=self.read(entry,2)
        if fresh is not None:entry['hardware_settings']=fresh
        if fresh is None or not audio_internal_v2(fresh) or rate_v2(fresh)!=rate:
            raise ValueError('Native Internal clock is not confirmed after audio resume')
        before,after=expected['status'],fresh['status']
        if (any(before['clock'].get(k)!=after['clock'].get(k) for k in ('selected_source_id','selected_kind')) or
                before.get('input_transport')!=after.get('input_transport') or
                not isinstance(before.get('digital',{}).get('values'),dict) or
                before['digital']['values']!=after.get('digital',{}).get('values') or
                before['digital'].get('firmware_revision')!=after['digital'].get('firmware_revision') or
                any(expected.get(k)!=fresh.get(k) for k in ('native_profile','native_codec'))):
            raise ValueError('Native settings changed during audio resume; no applied acknowledgement')
        # The existing native format-change path actually executes and confirms
        # Rate. Its nominal DDS/rate bits can therefore change this opaque token
        # (notably idle SS -> previous DS/QS). Publish the newly observed guard.

    def confirm_startup(self,entry,owner=None):
        guarded=entry.get('_guarded_startup')
        if guarded is not None:
            if owner is not None and self.lifecycle.confirmed(entry,owner,guarded['rate']) is None:return False
            self.confirm_preserved(entry,guarded['expected'],guarded['rate'])
            entry.pop('_guarded_startup')
        return True

    def base(self,entry):
        return dict(manager_pid=os.getpid(),manager_process_start=process_identity(os.getpid())['process_start'],
                    manager_nonce=self.manager.token,generation=entry['generation'],attachment=entry['attachment'])

    def idle(self,entry,request_id,readback):
        entry['status']='clock_idle';entry['hardware_idle_request_id']=request_id
        entry['hardware_settings']=readback;entry['reason']='External clock is active; audio remains stopped. Select Internal to resume.'
        if readback.get('request_abi')==2:
            clock=readback['status']['clock']
            entry['reason']=('Native clock preference is unknown; audio remains stopped. Select a clock source explicitly to continue.'
                             if clock.get('selected_kind')=='unknown' else
                             'Internal clock is displayed, but native confirmation for audio resume is unavailable; audio remains stopped.'
                             if clock.get('selected_kind')=='internal' and clock.get('current_kind')=='internal' else
                             'External clock is selected or active; audio remains stopped. Select Internal to resume.')

    def startup(self,entry):
        observed=self.read(entry,2)
        if observed is not None:
            entry['hardware_settings']=observed
            if not audio_internal_v2(observed):
                self.idle(entry,'startup',observed);return False
            # A current clock does not prove that RME's engine was initialized.
            # First open must keep the normal native InitializationPrefix. Only
            # StoppedResumes explicitly authorizes a known stopped noPrefix open.
            rate_v2(observed)
            return True
        observed=self.call(self.manager.root,entry['uid'],entry['attachment'])
        if observed is not None:
            entry['hardware_settings']=observed
            if observed['status'].get('source')!=7:
                self.idle(entry,'startup',observed);return False
        return True

    def validate(self,entry,request):
        fields={'schema','uid','request_id','expected','operation'}
        abi=request.get('schema');operation=request.get('operation')
        fields|=({'source'} if operation=='clock_source' else {'expected_flags','changes'}) if abi==1 else ({'source','expected_settings'} if operation=='clock_source' else {'expected_settings','changes'})
        if (set(request)!=fields or type(abi) is not int or abi not in (1,2) or request.get('uid')!=entry['uid'] or
                not isinstance(request.get('request_id'),str) or len(request['request_id'])!=32 or any(c not in '0123456789abcdef' for c in request['request_id']) or
                operation not in ('clock_source','digital')):raise ValueError('Invalid hardware settings request')
        if operation=='clock_source':
            if type(request['source']) is not int or not 0<=request['source']<(7 if abi==1 else 65536):raise ValueError('Invalid clock source')
        elif ((abi==1 and (type(request['expected_flags']) is not int or not 0<=request['expected_flags']<=0xffffffff)) or
                not isinstance(request['changes'],dict) or not request['changes'] or len(request['changes'])>16 or
                any(not isinstance(k,str) or not k.replace('_','').isalnum() or type(v) is not int or not 0<=v<=65535 for k,v in request['changes'].items())):
            raise ValueError('Invalid semantic Digital I/O fields')
        if abi==2 and (not isinstance(request['expected_settings'],str) or not 1<=len(request['expected_settings'])<=8192):raise ValueError('Invalid native settings guard')

    def accept(self,entry,request):
        self.validate(entry,request)
        expected=request['expected'];base=self.base(entry)
        if isinstance(expected,dict) and all(k in expected for k in base) and any(expected[k]!=v for k,v in base.items()):return
        if any(entry.get(k) for k in ('_rate_change','_owner_change','_hardware_change')):raise ValueError('Another card transaction is in progress')
        idle=entry.get('status')=='clock_idle'
        if idle:
            marker=dict(base,hardware_idle_request_id=entry['hardware_idle_request_id'])
            if request['operation']!='clock_source' or expected!=marker or entry.get('_child') is not None:raise ValueError('Refresh the current idle clock authority')
            workers=[];card=None
        else:
            if entry.get('status')!='running' or entry.get('_legacy_reserved') or entry.get('_child') is None:raise ValueError('Selected audio owner is not ready')
            owner=self.lifecycle.owner(entry)
            if owner.get('status')!='audio_ready' or expected!=self.lifecycle.marker(entry,owner):raise ValueError('Hardware request belongs to another audio session')
            self.lifecycle.check_clients(owner);workers=list(owner.get('workers',{}).values());card=owner['kernel_card']
        abi=request['schema'];observed=self.read(entry,abi)
        if observed is None:raise ValueError('This interface has no admitted semantic hardware settings codec')
        if abi==2:
            internal=internal_v2(observed)
            if observed.get('expected_settings')!=request['expected_settings']:raise ValueError('Hardware settings changed; refresh before applying')
            if (observed.get('native_capabilities') or {}).get(request['operation']+'_write') is not True:raise ValueError('Native hardware operation is unavailable')
            if request['operation']=='digital' and not internal:raise ValueError('Digital I/O requires the selected and current Internal clock')
            if request['operation']=='clock_source' and request['source'] not in [r.get('id') for r in observed.get('clock_sources',[]) if isinstance(r,dict)]:raise ValueError('Clock source is unavailable for this native profile')
        elif observed['status'].get('input_transport')!='Bulk':raise ValueError('The current hardware settings codec requires Bulk transport')
        if abi==1 and request['operation']=='digital' and (observed['status'].get('source')!=7 or observed['status'].get('selected_source')!='Internal' or
                observed['status'].get('digital',{}).get('flags')!=request['expected_flags']):raise ValueError('Hardware settings changed; refresh before applying Digital I/O')
        if abi==2 and not idle:
            rate=card.get('rate')
            if type(rate) is not int or rate<=0 or owner.get('audio',{}).get('rate')!=rate:
                raise ValueError('The previous running audio rate is not confirmed')
            entry['_hardware_audio_rate']=dict(uid=entry['uid'],attachment=copy.deepcopy(entry['attachment']),rate=rate)
        lock=self.manager.owner_changes.hold_legacy_settings() if abi==1 else None
        entry['hardware_change']=dict(schema=1,uid=entry['uid'],request_id=request['request_id'],operation=request['operation'],from_generation=entry['generation'],phase='waiting_control' if idle else 'stopping')
        if abi==2:entry['hardware_change'].update(request_abi=2,previous_running_rate=self.previous_rate(entry))
        entry['_hardware_change']=dict(request=request,workers=workers,kernel_card=card,deadline=self.lifecycle.now()+35,lock=lock,was_idle=idle,dispatched=False)
        self.manager.stop(entry,'explicit per-device hardware settings');entry['status']='hardware_changing'

    def release(self,entry):
        transaction=entry.pop('_hardware_change',None)
        if transaction is not None and transaction['lock'] is not None:os.close(transaction['lock'])

    def fail(self,entry,error,uncertain):
        entry['hardware_change'].update(phase='error',error=str(error),uncertain=uncertain)
        transaction=entry.get('_hardware_change')
        if uncertain:self.manager.stop(entry,'hardware settings uncertain; no automatic retry')
        entry['status']='error' if uncertain else entry.get('_hardware_previous_status','running');entry['reason']=str(error)
        if transaction and transaction.get('drained') and not transaction['dispatched'] and not self.manager.closing:
            try:
                abi=transaction['request']['schema'];observed=self.read(entry,abi)
                if observed is None or not (audio_internal_v2(observed) if abi==2 else observed['status'].get('source')==7):raise ValueError('Previous Internal clock is no longer confirmed')
                self.lifecycle.check_drained_card(transaction['kernel_card'],allow_removed=True)
                self.manager.generation+=1;entry['generation']=self.manager.generation
                entry['owner_status_file']=str(self.manager.directory/(hashlib.sha256(entry['uid'].encode()).hexdigest()+f'-{self.manager.token}-{entry["generation"]}.json'))
                entry.pop('_stop_sent',None)
                self.manager.launch(entry,self.resume_rate(entry,observed)) if abi==2 else self.manager.launch(entry)
                entry['hardware_change'].update(uncertain=False,rollback='frontend_reopening',to_generation=entry['generation'])
                entry['status']='starting'
            except (OSError,ValueError,KeyError,subprocess.SubprocessError) as rollback:
                entry['hardware_change']['rollback_error']=str(rollback)
        self.release(entry)

    def tick(self,observed):
        for uid,entry in self.manager.entries.items():
            current=observed.get(uid)
            if current is None or current[1]!=entry['attachment'] or self.manager.closing:
                if entry.get('_hardware_change'):self.fail(entry,'Attachment or manager changed during hardware settings; no replay',True)
                continue
            path=self.manager.directory/'hardware-requests'/(hashlib.sha256(uid.encode()).hexdigest()+'.json')
            try:request=private_json(path)
            except FileNotFoundError:request=None
            except (OSError,ValueError) as error:
                request=None
                if not entry.get('_hardware_change'):entry['hardware_change']=dict(schema=1,uid=uid,request_id=None,phase='error',error=str(error),uncertain=False)
            if request is not None:
                identifier=request.get('request_id');key=(uid,identifier if isinstance(identifier,str) else 'invalid')
                if key not in self.consumed:
                    self.consumed.add(key);entry['_hardware_previous_status']=entry['status']
                    try:self.accept(entry,request)
                    except (OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError) as error:
                        if not entry.get('_hardware_change'):
                            entry['hardware_change']=dict(schema=1,uid=uid,request_id=identifier,phase='error',error=str(error),uncertain=False)
                            if type(request.get('schema')) is int and request['schema']==2:entry['hardware_change']['request_abi']=2
            transaction=entry.get('_hardware_change')
            if transaction is None:continue
            entry['status']='hardware_changing'
            try:
                if self.lifecycle.now()>transaction['deadline']:raise ValueError('Hardware settings deadline exceeded; no automatic retry')
                phase=entry['hardware_change']['phase']
                if phase=='stopping':
                    if entry.get('_child') is not None:continue
                    if entry.get('returncode')!=0:raise ValueError('Previous audio owner did not drain successfully')
                    if any(self.lifecycle.check_process(w.get('pid'),w.get('process_start')) for w in transaction['workers']):continue
                    previous=self.lifecycle.owner(entry)
                    if previous.get('cleanup_confirmed') is not True or previous.get('hardware_state_uncertain') is not False:raise ValueError('Native audio cleanup is not confirmed')
                    transaction['drained']=True
                    entry['hardware_change']['phase']='waiting_control'
                if entry['hardware_change']['phase']=='waiting_control':
                    if self.manager.is_occupied(current[0],self.manager.sysfs) or not self.lifecycle.probe_control(self.manager.root,uid,entry['attachment']):continue
                    if transaction['kernel_card'] is not None:self.lifecycle.check_drained_card(transaction['kernel_card'],allow_removed=True)
                    entry['hardware_change']['phase']='applying';transaction['dispatched']=True
                    abi=transaction['request']['schema'];call=self.call_v2 if abi==2 else self.call
                    report=call(self.manager.root,uid,entry['attachment'],transaction['request']['operation'],transaction['request'])
                    fresh=self.read(entry,abi)
                    if abi==2:
                        if fresh is None or fresh.get('expected_settings')!=report.get('expected_settings'):raise ValueError('Hardware settings changed after native readback')
                        clock_keys=('selected_source_id','current_source_id','current_kind','reference_nominal_rate_hz')
                        if any(fresh['status']['clock'].get(k)!=report['after'].get('clock',{}).get(k) for k in clock_keys):raise ValueError('Hardware clock changed after native settings readback')
                        if transaction['request']['operation']=='clock_source' and fresh['status']['clock'].get('selected_source_id')!=transaction['request']['source']:
                            raise ValueError('Native clock preference does not confirm the requested source')
                        internal=audio_internal_v2(fresh)
                        rate=self.resume_rate(entry,fresh) if internal else None
                    else:
                        if fresh is None or any(fresh['status'].get(k)!=report['after'].get(k) for k in ('source','selected_source','rate_hz','divisor')):raise ValueError('Hardware clock changed after native settings readback')
                        internal=fresh['status'].get('source')==7;rate=fresh['status']['rate_hz']
                    if transaction['request']['operation']=='digital' and any(fresh['status'].get('digital',{}).get('values',{}).get(k)!=v for k,v in transaction['request']['changes'].items()):
                        raise ValueError('Digital I/O changed after native settings readback')
                    entry['hardware_settings']=fresh
                    self.manager.generation+=1;entry['generation']=self.manager.generation
                    entry['hardware_change'].update(to_generation=entry['generation'],observed_rate_hz=rate)
                    if not internal:
                        self.idle(entry,transaction['request']['request_id'],fresh)
                        entry['hardware_change'].update(phase='applied',audio_resumed=False,capture_channels=None,playback_channels=None)
                        self.release(entry);continue
                    if abi==2:transaction['settings_before_reopen']=copy.deepcopy(fresh)
                    entry['owner_status_file']=str(self.manager.directory/(hashlib.sha256(uid.encode()).hexdigest()+f'-{self.manager.token}-{entry["generation"]}.json'))
                    entry.pop('_stop_sent',None);entry.pop('hardware_idle_request_id',None)
                    self.manager.launch(entry,rate) if abi==2 else self.manager.launch(entry)
                    entry['hardware_change']['phase']='starting';continue
                if entry['hardware_change']['phase']=='starting':
                    if entry.get('_child') is None:raise ValueError('New audio owner exited after hardware settings')
                    try:owner=self.lifecycle.owner(entry)
                    except FileNotFoundError:continue
                    if owner.get('status')!='audio_ready':continue
                    if self.lifecycle.confirmed(entry,owner,entry['hardware_change']['observed_rate_hz']) is None:continue
                    if transaction['request']['schema']==2:self.confirm_reopen(entry,transaction)
                    kernel=owner['kernel_card'];entry['hardware_change'].update(phase='applied',audio_resumed=True,capture_channels=kernel['capture_channels'],playback_channels=kernel['playback_channels'])
                    entry['status']='running';entry.pop('reason',None);self.release(entry)
            except (OSError,ValueError,KeyError,TypeError,AttributeError,subprocess.SubprocessError) as error:self.fail(entry,error,True)
