# RME Audio Preview

Open **RME Audio Preview** from the applications menu. Choose an **available**
interface in the terminal. Its audio ports appear in your audio application or
patchbay. Connections are explicit; the system default device is preserved.
The active UFX+ session is refused and stays with its current driver.

This preview provides the shared USB audio engine and physical input/output
ports. It uses the interface's current sample rate by default. An explicit --rate 48000 changes the nominal rate on the chosen idle interface before audio starts, within its existing rate family where an alternate change is required; see RATE.md. The original Babyface has
been tested at44100Hz with10inputs/12outputs, direct ALSA and PipeWire together.
The common catalogue covers33personalities/47USBidentities from the identified
reference; other hardware has software/native evidence and still needs physical
qualification. This does not mean that every RME product uses this USB driver.
Starting an idle interface applies the reference driver's initialization
defaults. This preview does not restore a mixer scene.

Audio runs **until you stop it**; Ctrl+C stops cleanly. There is no five-minute
limit or periodic restart. An explicit `--seconds 60` selects a timed test
(1..300seconds); normal launches have no timer. This is an audio preview alongside
your installed UFX+ driver. Mixer controls, high-rate hostFX and the card
selector **inside OSCmix** remain unfinished. No analog output or latency claim
is made from the silent playback tests.

The launcher also opens the selected interface’s MIDI ports when available.
It preserves any existing MIDI owner. MIDI runs until the audio session stops;
ports are not connected automatically. The Babyface exposes two logical USB
MIDI ports per direction; this is not a claim of two physical DIN connectors.
A separate `rme-midi --uid UID` starts MIDI without audio, until Ctrl+C.
Actual DIN cable loopback has not been qualified.

For direct ALSA, start `python3 /path/to/preview/launch.py --mode direct`.
The terminal prints the current ALSA device name and configuration/plugin paths.
Set ALSA_CONFIG_PATH and ALSA_PLUGIN_DIR to those paths for an application that
uses the direct device. Channels and rate must match the current session.
For an explicit non-interactive continuous choice, use `--uid UID`.
Add `--seconds 60` only for a timed test.
`--list` lists attached devices without activating audio.

Installation is versioned under ~/Applications/RME-Audio-Preview. A separate
menu entry and generated access rule are installed; existing audio services,
OSCmixer settings and default devices are preserved. The rule uses identities
exported by the single driver catalogue, including the reference's legacyVIDs.
It grants access through the audio group/session; it does not activate a card.
Access is activated only for the explicitly selected idle attachment.

Session reports are private under ~/.local/state/rme-audio-preview. Normal
shutdown removes temporary session files. After an abnormal process termination,
leftovers are preserved for review instead of silently deleted. To remove this
preview, remove its version folder and rme-audio-preview.desktop menu entry;
the separate70-rme-audio-preview.rules file can be removed and udev reloaded.
Removing it does not revoke an existing device permission until reattachment.
No background service or automatic audio restart is installed.


Continuous per-UID raw levels are now started with the preview audio/MIDI session. See rme-meter-stream.md; the separate1..5second diagnostic requires its control interface to be idle. Normal audio and levels run until explicit stop or error, without a5minute ceiling. Raw banks are not yet GUI channel meters.

To request a different running audio regime, use --session-rate 88200. The native owner prepares and confirms that stream before exposing its ports; MIDI and raw levels remain bound to the same UID. This option is separate from the idle --rate option and cannot be combined with it. Audio remains continuous until stopped. After stopping, alternate0 may report the base nominal rate; see FORMAT.md for the distinction and qualification evidence.
