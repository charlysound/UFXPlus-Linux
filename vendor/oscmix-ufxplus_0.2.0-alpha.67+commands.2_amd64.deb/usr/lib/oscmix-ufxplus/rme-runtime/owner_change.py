"""Explicit legacy→common Linux handoff. Existing owners retain every USB call."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
try:
    import owner_policy as policy
except ModuleNotFoundError:  # source tree; the verified bundle has this module
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
    import owner_policy as policy
from rate_change import live_process,private_json


def helper(operation,uid,payload=None):
    result=subprocess.run(['/usr/bin/rme-linux-settings','handoff-'+operation,'--uid',uid],
        input=json.dumps(payload) if payload is not None else None,capture_output=True,text=True,timeout=12)
    if len(result.stdout)>1048576:raise ValueError('Handoff metadata is too large')
    value=json.loads(result.stdout)
    if result.returncode or value.get('ok') is not True:raise ValueError(value.get('error') or 'Linux handoff preflight failed')
    return value


def prepare_legacy(root,uid,attachment,rate):
    """The native owner left Float32 active; restore only the PCM24 format bit."""
    result=subprocess.run([str(root/'ufxplus-rate-guarded'),'prepare-pcm-guarded',str(rate),uid,
        attachment['connection_marker'],attachment['descriptor_sha256']],capture_output=True,text=True,timeout=5)
    if result.returncode:raise ValueError(result.stderr.strip() or 'Guarded legacy PCM preparation failed; no retry')
    if len(result.stdout)>1048576:raise ValueError('Legacy PCM preparation report exceeds the limit')
    value=json.loads(result.stdout);before=value.get('before') or {};after=value.get('after') or {}
    flags=lambda raw:int.from_bytes(bytes(raw[12:16]),'little')
    a,b=before.get('raw'),after.get('raw')
    if (not isinstance(a,list) or not isinstance(b,list) or len(a)!=16 or len(b)!=16 or
            any(type(n) is not int or not 0<=n<=255 for raw in (a,b) for n in raw) or
            flags(b)!=flags(a)&~0x0800 or any(after.get(k)!=before.get(k) for k in ('divisor','source','rate_hz')) or
            after.get('source')!=7 or after.get('rate_hz')!=rate):
        raise ValueError('Legacy PCM preparation did not confirm the unchanged Internal rate and PCM24 format')
    return value


def legacy_state():
    return private_json(Path(os.environ['XDG_RUNTIME_DIR'])/'ufxplus-session.json')


def interfaces_free(device,sysfs):
    name=device['usb_path']
    for index in (0,2):
        path=sysfs/f'{name}:1.{index}'
        if (path/'driver').is_symlink() or (path/'bAlternateSetting').read_text().strip()!='0':return False
    return True


class OwnerChanges:
    def __init__(self,manager,call=helper,read_legacy=legacy_state,check_process=live_process,
                 free=interfaces_free,now=time.monotonic,settings_lock=None,prepare=prepare_legacy):
        self.manager=manager;self.call=call;self.read_legacy=read_legacy;self.check_process=check_process
        self.free=free;self.now=now;self.settings_lock=settings_lock;self.prepare=prepare;self.consumed=set()

    def preference(self,device):
        if not isinstance(device.get('uid'),str) or not device['uid'].startswith('rme:'):return None
        value=policy.read(device['uid'])
        if value is not None and not policy.matches(value,device):raise ValueError('Saved owner identity differs from this attachment')
        return value

    def hold_legacy_settings(self):
        path=self.settings_lock or Path(os.environ['XDG_RUNTIME_DIR'])/'ufxplus-settings.lock'
        fd=os.open(path,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:
            info=os.fstat(fd)
            if info.st_uid!=os.getuid() or info.st_mode&0o777!=0o600:raise ValueError('Invalid legacy settings lock')
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            return fd
        except BaseException:os.close(fd);raise

    def save_policy(self,transaction,owner,phase,**extra):
        value=dict(transaction['policy'],owner=owner,phase=phase,**extra)
        policy.save_json(policy.directory(value['uid'])/'owner.json',value)
        transaction['policy']=value

    def restore_preferences(self,transaction):
        for name,value in transaction['backups'].items():
            path=policy.directory(transaction['policy']['uid'])/name
            if value is None:path.unlink(missing_ok=True)
            else:policy.save_json(path,value)

    def release(self,entry):
        transaction=entry.pop('_owner_change',None)
        if transaction and transaction.get('lock') is not None:os.close(transaction['lock'])

    def retired(self,entry,expected):
        if not isinstance(expected,dict):return False
        actual=dict(manager_pid=os.getpid(),manager_process_start=self.manager_process_start(),manager_nonce=self.manager.token,
                    generation=entry['generation'],attachment=entry['attachment'])
        return all(k in expected for k in actual) and any(expected[k]!=v for k,v in actual.items())

    @staticmethod
    def manager_process_start():
        from launch import process_identity
        return process_identity(os.getpid())['process_start']

    def accept(self,entry,device,request):
        if (set(request)!={'schema','uid','request_id','owner','expected'} or type(request.get('schema')) is not int or request['schema']!=1 or
                request.get('uid')!=entry['uid'] or request.get('owner') not in ('native','legacy') or
                not isinstance(request.get('request_id'),str) or len(request['request_id'])!=32 or any(c not in '0123456789abcdef' for c in request['request_id'])):
            raise ValueError('Invalid owner handoff request')
        if self.retired(entry,request['expected']):return
        if entry.get('_owner_change') or entry.get('_rate_change'):raise ValueError('A card transaction is already in progress')
        if (entry.get('_child') is not None or not entry.get('external_supervisor') or
                not self.manager.legacy_current(entry['external_supervisor'])):
            raise ValueError('The historical supervisor is unavailable or changed')
        fd=self.hold_legacy_settings();transaction=None
        try:
            previous=self.preference(device)
            if request['owner']=='legacy':
                if previous is None or previous['phase'] not in ('pending','error') or not self.free(device,self.manager.sysfs):
                    raise ValueError('Interrupted owner handoff cannot be recovered while USB is occupied')
                state=self.read_legacy()
                expected=dict(manager_pid=os.getpid(),manager_process_start=self.manager_process_start(),manager_nonce=self.manager.token,
                              generation=entry['generation'],attachment=entry['attachment'],owner_pid=state.get('pid'),owner_process_start=state.get('process_start'),
                              session=state.get('session'),invocation=state.get('invocation'))
                if request['expected']!=expected or state.get('worker_pid') is not None:raise ValueError('Recovery authority or legacy state changed')
                self.call('drained',entry['uid'])
                saved=previous['rollback']
                transaction=dict(policy=previous,backups=saved['backups'],snapshot=saved['snapshot'],lock=fd,deadline=self.now()+40)
                # This is a new explicit recovery authority. Retain physical
                # endpoints, but never treat the retired manager as current.
                transaction['snapshot']=json.loads(json.dumps(transaction['snapshot']))
                transaction['snapshot']['current']['marker']=dict(expected)
                # The retired worker is not an authority for this explicit recovery.
                transaction['snapshot']['current']['marker'].pop('worker_pid',None)
                transaction['snapshot']['current']['marker'].pop('worker_process_start',None)
                entry['_owner_change']=transaction
                entry['owner_change']=dict(schema=1,uid=entry['uid'],request_id=request['request_id'],phase='rolling_back',from_generation=entry['generation'],recovery=True)
                resume=self.legacy_resume(entry)
                self.restore_preferences(transaction);self.save_policy(transaction,'legacy','committed',request_id=request['request_id'],legacy_resume=resume)
                return
            if entry.get('status')!='external_owner' or not entry.get('_legacy_reserved'):
                raise ValueError('The historical owner is not ready for migration')
            result=self.call('preflight',entry['uid']);current=result['current']
            if current['marker']!=request['expected'] or current['native'] or current['state']!='running':raise ValueError('Historical session changed before handoff')
            marker=current['marker']
            actual=dict(manager_pid=os.getpid(),manager_process_start=self.manager_process_start(),manager_nonce=self.manager.token,
                        generation=entry['generation'],attachment=entry['attachment'])
            if any(marker.get(k)!=v for k,v in actual.items()):raise ValueError('Handoff request belongs to another manager attachment')
            for pid,start,parent in ((marker['owner_pid'],marker['owner_process_start'],None),(marker['worker_pid'],marker['worker_process_start'],marker['owner_pid'])):
                if not self.check_process(pid,start,parent):raise ValueError('Historical process changed before handoff')
            catalogue=json.loads((self.manager.root/'catalogue.json').read_text())
            nodes,spans=policy.import_nodes(catalogue,device,result['legacy_nodes'])
            settings=result['settings']
            if settings.get('uid')!=entry['uid'] or settings.get('backend') not in ('alsa','pipewire+alsa') or settings.get('buffer_frames')!=current['applied']['buffer_frames']:
                raise ValueError('Imported settings differ from the live historical owner')
            backups={}
            for name in ('linux.json','nodes.json'):
                try:backups[name]=policy.read_json(policy.directory(entry['uid'])/name)
                except FileNotFoundError:backups[name]=None
            midi=current.get('midi') or {}
            if midi.get('state') not in ('ready','inactive','failed'):raise ValueError('Legacy MIDI ownership is not confirmed')
            if midi.get('state')=='ready' and not self.check_process(midi.get('pid'),midi.get('process_start')):raise ValueError('Legacy MIDI process changed')
            value=dict(schema=1,uid=entry['uid'],owner='native',phase='pending',request_id=request['request_id'],
                       device={k:device.get(k) for k in ('vendor_id','product_id','serial','usb_path')},expected=marker,
                       midi={k:midi[k] for k in ('pid','process_start')} if midi.get('state')=='ready' else None,
                       rollback=dict(snapshot=result,backups=backups))
            if len(json.dumps(value))>1048576:raise ValueError('Handoff snapshot exceeds the bounded transaction size')
            transaction=dict(policy=value,snapshot=result,backups=backups,spans=spans,nodes=nodes,settings=settings,
                             lock=fd,deadline=self.now()+40,previous=previous)
            # Reservation is durable BEFORE the old owner is asked to drain.
            policy.save_json(policy.directory(entry['uid'])/'owner.json',value)
            entry['_owner_change']=transaction
            entry['owner_change']=dict(schema=1,uid=entry['uid'],request_id=request['request_id'],phase='waiting_legacy',
                previous_running_rate_hz=current['rate'],from_generation=entry['generation'])
            policy.save_json(policy.directory(entry['uid'])/'nodes.json',nodes)
            policy.save_json(policy.directory(entry['uid'])/'linux.json',settings)
        except BaseException:
            if transaction is None or entry.get('_owner_change') is not transaction:os.close(fd)
            raise

    def legacy_resume(self,entry):
        transaction=entry['_owner_change'];old=transaction['snapshot']['current'];marker=old['marker']
        if self.check_process(marker.get('worker_pid'),marker.get('worker_process_start'),marker['owner_pid']):
            return None  # A refused preflight left the original PCM24 worker alive.
        if not self.check_process(marker['owner_pid'],marker['owner_process_start']):
            raise ValueError('Legacy keeper changed before numeric-format preparation')
        self.prepare(self.manager.root,entry['uid'],entry['attachment'],old['rate'])
        return dict(schema=1,request_id=entry['owner_change']['request_id'],supervisor_pid=marker['owner_pid'],
            supervisor_process_start=marker['owner_process_start'],attachment=entry['attachment'],rate_hz=old['rate'],
            pcm_format='signed-pcm24-in-32le',preparation_confirmed=True)

    def blocked(self,entry,error):
        transaction=entry.get('_owner_change')
        if transaction is not None:
            self.manager.stop(entry,'Owner handoff failed; no automatic USB retry')
            owner='legacy' if transaction['policy'].get('owner')=='legacy' else 'native'
            try:self.save_policy(transaction,owner,'error',error=str(error))
            except (OSError,ValueError):pass
            marker=transaction['snapshot']['current']['marker']
            entry['_legacy_reserved']=True
            entry['external_supervisor']=dict(pid=marker['owner_pid'],process_start=marker['owner_process_start'],state='delegated')
        entry['status']='migration_blocked';entry['reason']=str(error)
        entry.setdefault('owner_change',dict(schema=1,uid=entry['uid'],request_id=None)).update(phase='error',error=str(error),uncertain=True,rollback='not_permitted')
        self.release(entry)

    def rollback(self,entry,error):
        transaction=entry['_owner_change'];change=entry['owner_change']
        change.update(phase='rolling_back',error=str(error),uncertain=False,rollback='pending')
        transaction['deadline']=self.now()+40
        resume=self.legacy_resume(entry)
        self.restore_preferences(transaction);self.save_policy(transaction,'legacy','committed',legacy_resume=resume)
        entry['_legacy_reserved']=True
        marker=transaction['snapshot']['current']['marker']
        entry['external_supervisor']=dict(pid=marker['owner_pid'],process_start=marker['owner_process_start'],state='delegated')

    def advance(self,entry,device):
        manager=self.manager;transaction=entry['_owner_change'];change=entry['owner_change'];uid=entry['uid']
        if manager.closing:raise ValueError('Manager stopped during handoff; explicit recovery required')
        if self.now()>transaction['deadline']:raise ValueError('Owner handoff deadline exceeded')
        if change['phase']=='waiting_legacy':
            state=self.read_legacy();marker=transaction['snapshot']['current']['marker']
            if state.get('pid')!=marker['owner_pid'] or state.get('process_start')!=marker['owner_process_start']:
                raise ValueError('Historical supervisor changed during handoff')
            delegation=state.get('delegation') or {}
            if delegation.get('request_id')!=change['request_id']:return
            if delegation.get('state')=='error':
                if self.check_process(marker['worker_pid'],marker['worker_process_start'],marker['owner_pid']):
                    self.rollback(entry,delegation.get('error') or 'Historical owner refused handoff');return
                raise ValueError(delegation.get('error') or 'Historical drain was not confirmed')
            if delegation.get('state')!='drained' or delegation.get('clean') is not True or state.get('worker_pid') is not None:return
            if self.check_process(marker['worker_pid'],marker['worker_process_start']):return
            midi=transaction['policy'].get('midi')
            if midi and self.check_process(midi['pid'],midi['process_start']):return
            if not self.free(device,manager.sysfs):return
            self.call('drained',uid)
            # New owner uses existing activation at the observed current rate;
            # no --session-rate or saved hardware setting is replayed here.
            manager.generation+=1;entry['generation']=manager.generation
            entry['owner_status_file']=str(manager.directory/(hashlib.sha256(uid.encode()).hexdigest()+f'-{manager.token}-{manager.generation}.json'))
            entry.pop('_stop_sent',None);entry.pop('external_supervisor',None);entry.pop('_legacy_reserved',None)
            manager.launch(entry);change.update(phase='starting',to_generation=entry['generation']);return
        if change['phase'] in ('starting','stopping_new'):
            if entry.get('_child') is None:
                try:finished=private_json(Path(entry['owner_status_file']))
                except (OSError,ValueError):finished={}
                if (finished.get('uid')==uid and finished.get('attachment')==entry['attachment'] and
                        finished.get('cleanup_confirmed') is True and finished.get('hardware_state_uncertain') is False and
                        finished.get('observed_stop_rate_hz')==transaction['snapshot']['current']['rate'] and self.free(device,manager.sysfs)):
                    self.rollback(entry,transaction.get('failure') or 'New owner failed to become ready');return
                raise ValueError('New owner stopped without confirmed hardware cleanup; no automatic legacy restart')
            if change['phase']=='stopping_new':return
            try:owner=manager.rate_changes.owner(entry)
            except FileNotFoundError:return
            if owner.get('status')!='audio_ready':return
            manager.rate_changes.marker(entry,owner)
            audio=owner.get('audio') or {};kernel=owner.get('kernel_card') or {};midi=owner.get('midi') or {}
            old=transaction['snapshot']['current']
            if audio.get('rate')!=old['rate'] or any(kernel.get(k)!=old[k] for k in ('capture_channels','playback_channels')):
                raise ValueError('Migration changed the running rate or physical channel geometry')
            worker=(owner.get('workers') or {}).get('midi') or {}
            if midi.get('status')!='ready' or not self.check_process(worker.get('pid'),worker.get('process_start'),entry['pid']):return
            if (old.get('midi') or {}).get('ready') and max((midi.get('ready') or {}).get(k,0) for k in ('capture_ports','playback_ports'))!=old['midi']['ports']:
                raise ValueError('New MIDI port geometry differs from the historical owner')
            # Publish actual readiness for the common strict status reader;
            # owner_change still inhibits unrelated mutations until commit.
            entry['status']='running';change['phase']='restoring_links';manager.publish()
            self.call('finish',uid,dict(expected=manager.rate_changes.marker(entry,owner),previous=old,links=transaction['snapshot']['links'],
                                      settings=transaction['settings'],nodes=transaction['nodes']))
            # Attachment/process authority is checked again after route work.
            if manager.observe(device,manager.sysfs)!=entry['attachment']:raise ValueError('Attachment changed during route restoration')
            manager.rate_changes.marker(entry,manager.rate_changes.owner(entry))
            self.save_policy(transaction,'native','committed')
            change.update(phase='applied',owner='native',observed_rate_hz=audio['rate'],rollback=None)
            entry['status']='running';entry.pop('reason',None);self.release(entry);return
        if change['phase']=='rolling_back':
            state=self.read_legacy();old=transaction['snapshot']['current'];marker=old['marker']
            if state.get('pid')!=marker['owner_pid'] or state.get('process_start')!=marker['owner_process_start']:
                raise ValueError('Historical supervisor changed before rollback confirmation')
            resume=transaction['policy'].get('legacy_resume')
            if resume is not None and state.get('legacy_resume_request_id')!=change['request_id']:return
            if state.get('state') in ('blocked','failed','delegation-error') and (resume is not None or
                    not self.check_process(marker.get('worker_pid'),marker.get('worker_process_start'),marker['owner_pid'])):
                raise ValueError('Historical rollback failed: '+str(state.get('detail') or (state.get('delegation') or {}).get('error') or state['state']))
            if state.get('state')!='running':return
            if state.get('rate_hz')!=old['rate'] or not self.check_process(state.get('worker_pid'),state.get('worker_process_start'),state['pid']):
                raise ValueError('Historical rollback did not confirm its previous rate/process')
            entry['_legacy_reserved']=True;entry['external_supervisor']=dict(pid=state['pid'],process_start=state['process_start'],state='running')
            entry['status']='external_owner';manager.publish()
            # Legacy node names survive rollback. External endpoint serials
            # remain guarded by the same existing route-restoration adapter.
            try:self.call('rollback',uid,dict(previous=old,links=transaction['snapshot']['links']))
            except (OSError,ValueError,subprocess.SubprocessError) as error:
                change.update(phase='error',error=str(error),rollback='audio_restored_routes_unconfirmed',uncertain=True)
                self.release(entry);return
            if change.get('recovery'):change.update(phase='applied',owner='legacy',rollback='applied')
            else:change.update(phase='error',rollback='applied',uncertain=False)
            self.release(entry)

    def tick(self,observed):
        for uid,entry in self.manager.entries.items():
            request={}
            current=observed.get(uid)
            if current is None or current[1]!=entry['attachment']:
                if entry.get('_owner_change'):self.blocked(entry,'Attachment changed during handoff; no replay on another connection')
                continue
            path=self.manager.directory/'owner-requests'/(hashlib.sha256(uid.encode()).hexdigest()+'.json')
            try:
                request=private_json(path);key=(uid,request.get('request_id'))
                if not isinstance(key[1],str):raise ValueError('Invalid owner request identity')
                if key not in self.consumed:
                    self.consumed.add(key)
                    self.accept(entry,current[0],request)
            except FileNotFoundError:pass
            except (OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError) as error:
                if entry.get('_owner_change'):self.blocked(entry,error)
                else:entry['owner_change']=dict(schema=1,uid=uid,request_id=locals().get('request',{}).get('request_id'),phase='error',error=str(error),uncertain=False)
            if entry.get('_owner_change'):
                entry['status']='owner_changing'
                try:self.advance(entry,current[0])
                except (OSError,ValueError,KeyError,TypeError,subprocess.SubprocessError) as error:
                    if entry.get('_child') is not None and entry['_owner_change'].get('failure') is None:
                        entry['_owner_change']['failure']=str(error);entry['_owner_change']['deadline']=self.now()+30
                        entry['owner_change'].update(phase='stopping_new',error=str(error));self.manager.stop(entry,'Owner handoff failed; draining before rollback')
                    else:self.blocked(entry,error)
