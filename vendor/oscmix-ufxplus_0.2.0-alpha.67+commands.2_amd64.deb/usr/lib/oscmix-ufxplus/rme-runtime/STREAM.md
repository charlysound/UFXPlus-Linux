# Continuous common raw levels

Run rme-live-levels UID until SIGINT/SIGTERM. The audio preview starts this common owner alongside audio and MIDI, with the same selected UID. There is no time limit or periodic reopen. The existing rme-device-meters UID --seconds1..5 remains a separate bounded diagnostic for an idle control interface; it refuses an interface already owned by this stream.

The Q reader and native profile policies are reused. One control interface handle remains claimed throughout. Each complete synchronized bank is published, then requests a native cache refresh on the next accepted batch. No parameter/audio OUT, reset, detach, configuration or alternate-setting operation is added. Twenty millisecond polling is an explicit Linux adaptation, not a native timer claim.

The bounded NDJSON schema1 emits ready, snapshot and stopped events. A ready identity binds UID, connection incarnation, descriptor SHA256, control interface, IN endpoint, page geometry and a fresh nonzero 128-bit process nonce. Snapshots carry that exact identity, monotone sequence/elapsed milliseconds and all raw pages as hex. The final stopped event reports the last published sequence, requested_stop and any error. Every line is at most65536bytes. An incomplete batch is discarded. Disconnection, ownership errors and output failures terminate and release the owner without fallback/reconnect.

The preview validates identity, dimensions, sequences and termination before accepting data. It retains one latest bank, a frame count, bounded errors and stderr; it does not accumulate a recording in memory. Terminal Ctrl+C/TERM/HUP stops all three owners and saves a private final session report. A level failure is reported separately while audio may continue. Pipe readers must consume promptly; backpressure may delay shutdown while stdout is blocked. The bundled preview consumes continuously.

These are raw native caches, not a decoded GUI meter or a mixer-command acknowledgement. No per-channel attribution, GUI card selector or write transaction is claimed. The Rust tracker contract rejects former card/session frames after a change of selection; the future OSCmix consumer must bind its own selected identity.

## Decoded original Babyface strips

Snapshots for the already admitted original Babyface profile additionally expose
`decoded_levels`: input10, playback12 and output12 objects with `peak_db`,
`rms_db` (before the GUI RMS+3 preference) and `overload` (native low nibble).
The existing `babyface_meters::decode` and its native scaling methods are reused;
no USB request or raw format is added. Host FX slots remain distinct and are not
misidentified as physical strips. Zero values use the GUI floor -150dB, avoiding
non-finite JSON values. Existing raw schema1 fields and consumers are unchanged.
Reference TotalMix2.03 0x10011ccc0: assembly
`ev_536bcf84c81633a2e9256ceee5f6b24c55e6d0400caab8e4992c1af3624559c9`,
constants `ev_79c793a3eede21420a22f2c207437f75f4d08eed1a3012033c4c3dd9dc50a2d0`.
These existing RME-03 proofs establish offsets, banks and scaling; physical
qualification belongs to the installed consumer, not this software extension.
