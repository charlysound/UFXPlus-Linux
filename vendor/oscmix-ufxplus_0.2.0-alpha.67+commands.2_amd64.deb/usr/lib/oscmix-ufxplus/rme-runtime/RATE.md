# Shared nominal sample rate

rme-device-rate UID nominal-rate-hz sets one of the nine reference rates on an idle interface. The audio preview accepts --rate 48000 before starting audio/MIDI/levels on the selected UID. Normal launches without --rate use the current rate. Stop audio and the control owner before changing it. The command never selects another device; an active UFX+ or another owner is refused.

The reference3.39 Program::Rate is reused across33profiles. Its DDS/mask policies and VerifyOnly branches were checked by19437native activation oracle cases. A VerifyOnly interface cannot be set to a different nominal rate by this command. Source selection, external lock, measured clock and synchronized aggregation are separate; a nominal readback does not prove them.

The exact UID/incarnation/descriptor and firmware are checked under exclusive IF0 and control-interface ownership before each native step. No initialization defaults, alternate setting, audio submission, raw register API, reset or detach is added. The command applies only immutable native rate steps, then reads back the nominal rate. Transfer success alone is insufficient.

If a dispatched change fails or is interrupted, the command tries to restore the previous nominal rate while it still owns the same attachment. A replaced/disconnected device is never reopened or retargeted. Restoration failure remains explicit. Both interfaces are released on every path. Individual USB commands have bounded timeouts; these are not an audio-session duration limit.

The preview stores private rate-change reports and includes successful changes in its audio session report. A failed change prevents audio startup. Hardware qualification and exact source/package identity are recorded separately; absent models retain software/native evidence only.

For rate-family alternate interfaces, the native driver changes the audio alternate before setting the rate. This idle command deliberately cannot switch that family. A44100-to48000 change stays within one family; a44100-to88200 change is refused before OUT. The separate audio format owner must compose that higher-rate transition, allocate its new geometry and verify readback after the alternate. The first BF88200 trial on8479dca exposed this missing composition and correctly restored the old nominal rate; its evidence is retained. No per-BF register workaround was added.
