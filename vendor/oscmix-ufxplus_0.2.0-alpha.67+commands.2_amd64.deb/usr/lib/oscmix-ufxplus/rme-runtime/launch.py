#!/usr/bin/env python3
"""Explicit per-UID preview launcher; never selects a fallback or owns USB."""
import argparse, datetime, hashlib, json, os, shutil, signal, subprocess, sys, tempfile, threading
from collections import deque
from pathlib import Path

ROOT=Path(__file__).resolve().parent

class BoundedLog:
    """Keep a diagnostic tail while continuing to drain the child pipe."""
    def __init__(self,limit=131072):
        self.limit=limit;self.parts=deque();self.size=0;self.dropped=0;self.lock=threading.Lock()
    def append(self,text):
        text=str(text)
        with self.lock:
            self.parts.append(text);self.size+=len(text)
            while self.size>self.limit:
                first=self.parts.popleft();remove=min(len(first),self.size-self.limit)
                self.size-=remove;self.dropped+=remove
                if remove<len(first):self.parts.appendleft(first[remove:])
    def __iter__(self):
        with self.lock:return iter(list(self.parts))

def clean(text):return ''.join(c if c.isprintable() else ' ' for c in str(text))
def select(devices,uid):
    matches=[d for d in devices if d.get('model') is not None and d.get('uid')==uid]
    if len(matches)!=1:raise ValueError('Device absent, unsupported or identity ambiguous; no fallback selected.')
    return matches[0]
def occupied(device,sysfs=Path('/sys/bus/usb/devices')):
    name=device['usb_path']
    if not name or Path(name).name!=name:raise ValueError('invalid attachment path')
    interface=sysfs/f'{name}:1.0'
    return (interface/'driver').exists() or (interface/'bAlternateSetting').read_text().strip()!='0'
def verify(root):
    manifest=json.loads((root/'manifest.json').read_text())
    if manifest.get('schema')!=1:raise ValueError('unsupported preview manifest')
    for name,digest in manifest['files'].items():
        path=root/name
        if Path(name).name!=name or path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError('Preview file differs from its manifest: '+name)
    return manifest

def save_report(path,payload):
    with open(path,'x',opener=lambda p,f:os.open(p,f,0o600)) as file:
        json.dump(payload,file,indent=2)

def cleanup_state(report,expected):
    """A clean process exit alone is not proof that USB cleanup completed."""
    if not isinstance(report,dict):return dict(cleanup_confirmed=False,hardware_state_uncertain=True)
    after=report.get('after_stop') or {};identity=after.get('attachment') or {}
    same=isinstance(expected,dict) and all(identity.get(k)==expected.get(k) for k in ('connection_marker','descriptor_sha256'))
    context=(after.get('snapshot') or {}).get('runtime_context') or {}
    uncertain=bool(report.get('error')) and report.get('attempted_parameter_writes',1)!=0
    return dict(cleanup_confirmed=same and report.get('cleanup_errors')==[] and not uncertain,
                hardware_state_uncertain=uncertain or not same,observed_stop_rate_hz=context.get('reference_nominal_rate_hz'))

def duration_arg(seconds):
    if seconds is None:return 'until-stopped'
    if not 1<=seconds<=300:raise ValueError('Test duration must be1..300seconds.')
    return str(seconds)

def rate_arg(rate,rates):
    if rate is not None and (type(rate) is not int or rate not in rates):raise ValueError('Choose a nominal rate listed by this interface driver.')
    return rate

def change_rate(device,rate):
    if rate is None:return None
    rates=json.loads((ROOT/'catalogue.json').read_text())['rates'];rate_arg(rate,rates)
    if occupied(device):raise ValueError('Stop the selected interface audio before changing its nominal rate.')
    with StopRelay() as relay:
        child=subprocess.Popen([str(ROOT/'rme-device-rate'),device['uid'],str(rate)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True);relay.attach(child)
        stdout,stderr=child.communicate()
    report=json.loads(stdout) if stdout else None
    state=Path(os.environ.get('XDG_STATE_HOME',str(Path.home()/'.local/state')))/'rme-audio-preview/rate-changes'
    state.mkdir(mode=0o700,parents=True,exist_ok=True)
    path=state/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%f')+'.json')
    save_report(path,{'uid':device['uid'],'requested_nominal_rate_hz':rate,'report':report,'stderr':stderr,'returncode':child.returncode,'interrupted':relay.requested})
    if relay.requested or child.returncode or report is None or report.get('error') or report.get('cleanup_errors') or report.get('requested_nominal_rate_hz')!=rate or report.get('observed_nominal_rate_hz')!=rate:raise ValueError('Nominal-rate preparation stopped or failed. Audio was not started. Report: '+str(path))
    print(f'Nominal rate ready: {rate} Hz.',flush=True)
    return report

class StopRelay:
    """Forward terminal close/interrupt to the separately owned audio, MIDI and levels processes."""
    def __enter__(self):
        self.children=[];self.requested=False;self.sent={}
        self.previous={sig:signal.getsignal(sig) for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP)}
        for sig in self.previous:signal.signal(sig,self.stop)
        return self
    def stop(self,_signal,_frame):
        if self.requested:return
        self.requested=True
        for child in self.children[:]:self.send_stop(child)
    def send_stop(self,child):
        token=object()
        if self.sent.setdefault(child,token) is not token:return
        if child.poll() is None:
            try:child.send_signal(signal.SIGTERM)
            except ProcessLookupError:pass
    def attach(self,child):
        self.children.append(child)
        if self.requested:self.send_stop(child)
    def __exit__(self,*_args):
        for sig,previous in self.previous.items():signal.signal(sig,previous)

class MidiSession:
    """One exact-UID MIDI owner, started only after audio is ready."""
    def __init__(self,uid,relay,on_change=None):
        self.on_change=on_change
        self.uid=uid;self.relay=relay;self.child=None;self.stdout=BoundedLog(32768);self.stderr=BoundedLog(32768);self.ready=None;self.status='starting';self.threads=[]
        try:
            self.child=subprocess.Popen([str(ROOT/'rme-midi'),'--uid',uid],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
            relay.attach(self.child)
            for stream,lines in ((self.child.stdout,self.stdout),(self.child.stderr,self.stderr)):
                thread=threading.Thread(target=self.monitor,args=(stream,lines),daemon=True);thread.start();self.threads.append(thread)
            thread=threading.Thread(target=self.watch_exit,daemon=True);thread.start();self.threads.append(thread)
        except OSError as error:self.status='error';self.stderr.append(str(error))
    def watch_exit(self):
        self.child.wait()
        # Join the readers first: a clean ABSENT/OWNED response may precede EOF.
        for thread in self.threads[:2]:thread.join(timeout=2)
        if self.status not in ('absent','existing_owner'):
            self.status='stopped' if self.relay.requested and not self.child.returncode else 'error'
            self.ready=None
            if self.status=='error':self.stderr.append('MIDI owner exited; audio remains active. No automatic USB retry.\n')
        if self.on_change:self.on_change()
    def observe(self,line):
        fields=line.split()
        if fields[:2]==['RME_MIDI_READY',self.uid] and len(fields)==6:
            try:client,inputs,outputs,interface=map(int,fields[2:])
            except ValueError:return
            if client<0 or not 0<=inputs<=16 or not 0<=outputs<=16 or not inputs+outputs or not 1<=interface<=255:return
            self.ready={'client':client,'capture_ports':inputs,'playback_ports':outputs,'interface':interface};self.status='ready'
            print(f'MIDI ready: {inputs} input ports / {outputs} output ports. Connect them in your MIDI application.',flush=True)
        elif fields==['RME_MIDI_ABSENT',self.uid]:self.status='absent'
        elif fields==['RME_MIDI_OWNED',self.uid]:
            self.status='existing_owner';print('MIDI is already owned; its existing session is preserved.',flush=True)
        if getattr(self,'on_change',None):self.on_change()
    def monitor(self,stream,lines):
        while True:
            line=stream.readline(4096)
            if not line:break
            lines.append(line)
            if lines is self.stdout:self.observe(line)
    def finish(self):
        if self.child is not None:
            if self.child.poll() is None:self.relay.send_stop(self.child)
            try:self.child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.child.kill();self.child.wait();self.status='error';self.stderr.append('MIDI shutdown timeout; process terminated.')
            for thread in self.threads:thread.join(timeout=2)
            if self.child.returncode and self.status!='existing_owner':self.status='error'
            if self.status=='starting':self.status='error'
        if self.status=='error':print('MIDI session ended with an error; details are in the session report.',file=sys.stderr,flush=True)
        return {'uid':self.uid,'status':self.status,'ready':self.ready,'returncode':self.child.returncode if self.child else None,'stdout':''.join(self.stdout),'stderr':''.join(self.stderr),'dropped_chars':sum(getattr(log,'dropped',0) for log in (self.stdout,self.stderr))}

class LevelSession:
    """Bounded latest-state receiver; never applies a foreign stream to this UID."""
    def __init__(self,uid,relay):
        self.uid=uid;self.relay=relay;self.child=None;self.identity=None;self.latest=None;self.sequence=0;self.elapsed_ms=0;self.frames=0;self.stopped=None;self.status='starting';self.errors=[];self.stderr=[];self.threads=[]
        try:
            self.child=subprocess.Popen([str(ROOT/'rme-live-levels'),uid],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
            relay.attach(self.child)
            for target in (self.monitor,self.monitor_errors):
                thread=threading.Thread(target=target,daemon=True);thread.start();self.threads.append(thread)
        except OSError as error:self.fail(str(error))
    def fail(self,error):
        self.status='error'
        if len(self.errors)<4:self.errors.append(str(error)[:1024])
        if self.child is not None and self.child.poll() is None:
            try:self.relay.send_stop(self.child)
            except ProcessLookupError:pass
    @staticmethod
    def hex_string(value,length):return isinstance(value,str) and len(value)==length and all(c in '0123456789abcdefABCDEF' for c in value)
    def observe(self,frame):
        if type(frame.get('schema')) is not int or frame.get('schema')!=1 or self.stopped is not None:raise ValueError('invalid or closed levels stream')
        event=frame.get('event')
        if event=='ready':
            identity=frame.get('identity',{})
            if not isinstance(identity,dict):raise ValueError('invalid levels identity')
            pages=identity.get('page_count');size=identity.get('page_bytes');interface=identity.get('interface');endpoint=identity.get('endpoint');nonce=identity.get('nonce');marker=identity.get('connection_marker')
            if self.identity is not None or identity.get('uid')!=self.uid or not self.hex_string(nonce,32) or int(nonce,16)==0 or not self.hex_string(identity.get('descriptor_sha256'),64) or not isinstance(marker,str) or not 0<len(marker)<=256 or any(type(v) is not int for v in (pages,size,interface,endpoint)) or not 1<=pages<=15 or not 4<=size<=1024 or size%4 or not 1<=interface<=255 or not 0<=endpoint<=255 or endpoint&0x80==0 or endpoint&0x70 or endpoint&15==0:raise ValueError('foreign or invalid level identity')
            self.identity=identity;self.status='ready';print('Levels ready for the selected interface.',flush=True)
        elif event=='snapshot':
            seq=frame.get('sequence');elapsed=frame.get('elapsed_ms');payload=frame.get('pages_hex')
            if self.identity is None or frame.get('identity')!=self.identity or type(seq) is not int or not self.sequence<seq<2**64 or type(elapsed) is not int or not self.elapsed_ms<=elapsed<2**64 or not isinstance(payload,list) or len(payload)!=self.identity['page_count'] or any(not self.hex_string(p,self.identity['page_bytes']*2) for p in payload):raise ValueError('stale, foreign or incomplete levels snapshot')
            self.sequence=seq;self.elapsed_ms=elapsed;self.latest=frame;self.frames+=1
        elif event=='stopped':
            if frame.get('uid')!=self.uid or not self.hex_string(frame.get('nonce'),32) or (self.identity is not None and frame['nonce']!=self.identity['nonce']) or type(frame.get('sequence')) is not int or frame['sequence']<self.sequence or frame['sequence']>=2**64 or type(frame.get('requested_stop')) is not bool or (frame.get('error') is not None and not isinstance(frame['error'],str)) or (self.identity is None and frame.get('error') is None) or (not frame.get('requested_stop') and frame.get('error') is None):raise ValueError('invalid level termination')
            self.stopped=frame
            if frame.get('error') is not None:self.fail(frame['error'])
            elif self.status!='error':self.status='stopped'
        else:raise ValueError('unknown level stream event')
    def monitor(self):
        try:
            while True:
                line=self.child.stdout.readline(65537)
                if not line:break
                if len(line.encode())>65536:raise ValueError('level stream frame too long')
                frame=json.loads(line)
                if not isinstance(frame,dict):raise ValueError('invalid level stream frame')
                self.observe(frame)
            if self.stopped is None:self.fail('level stream closed without termination')
        except (ValueError,OSError,RecursionError) as error:self.fail(error)
    def monitor_errors(self):
        while True:
            line=self.child.stderr.readline(1024)
            if not line:break
            if sum(map(len,self.stderr))<16384:self.stderr.append(line)
    def finish(self):
        if self.child is not None:
            if self.child.poll() is None:self.relay.send_stop(self.child)
            try:self.child.wait(timeout=5)
            except subprocess.TimeoutExpired:self.child.kill();self.child.wait();self.fail('level shutdown timeout')
            for thread in self.threads:thread.join(timeout=2)
            if self.child.returncode or self.stopped is None:self.fail('level owner exited without a clean stream termination')
        if self.status=='error':print('Levels unavailable or stopped with an error; details are in the session report.',file=sys.stderr,flush=True)
        return {'uid':self.uid,'status':self.status,'identity':self.identity,'frames':self.frames,'last':self.latest,'stopped':self.stopped,'errors':self.errors,'stderr':''.join(self.stderr),'returncode':self.child.returncode if self.child else None}

def publish_status(path,payload):
    """Atomic private host status; this file never grants USB authority."""
    if path is None:return
    path=Path(path)
    fd,temporary=tempfile.mkstemp(prefix='.'+path.name+'.',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as file:json.dump(payload,file)
        os.replace(temporary,path)
    finally:
        try:os.unlink(temporary)
        except FileNotFoundError:pass

def process_identity(pid):
    """A live PID alone is not an ownership token."""
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        if fields[0] in ('Z','X'):return None
        return {'pid':pid,'process_start':fields[19]}
    except (OSError,ValueError,IndexError):return None

class AudioAvailability:
    """ALSA socket readiness and remote PipeWire publication are independent."""
    def __init__(self,uid,mode,status_file,attachment):
        self.uid=uid;self.mode=mode;self.status_file=status_file;self.attachment=attachment
        self.audio=None;self.pipewire=None;self.kernel_card=None;self.pcm_clients=None
        self.linux_settings=None;self.linux_settings_error=None;self.workers={};self.midi=None
        self.recovery=None
        self._publish_lock=threading.Lock()
        self.identity=process_identity(os.getpid()) or {'pid':os.getpid(),'process_start':None}
    def set_worker(self,name,child,required=True):
        identity=process_identity(child.pid)
        if identity is None:
            if required:raise ValueError('Audio worker exited before ownership publication.')
            # Native MIDI may report absent/external ownership and exit while
            # its reader is publishing that outcome. This cannot stop audio.
            self.publish();return
        self.workers[name]=(child,identity);self.publish()
    def observe_settings(self,metadata):
        if (not isinstance(metadata,dict) or type(metadata.get('schema')) is not int or metadata.get('schema')!=1 or metadata.get('uid')!=self.uid or
                metadata.get('applied') is not True or metadata.get('state')!='applied' or
                type(metadata.get('revision')) is not int or not 0<=metadata['revision']<2**64 or
                metadata.get('backend') not in ('alsa','pipewire+alsa') or
                type(metadata.get('buffer_frames')) is not int or metadata['buffer_frames']<0 or
                type(metadata.get('connection_generation')) is not int or metadata['connection_generation']<=0 or
                type(metadata.get('format_generation')) is not int or metadata['format_generation']<=0):
            raise ValueError('Invalid Linux settings acknowledgement.')
        if self.audio is None or metadata['connection_generation']!=self.audio.get('connection_generation') or metadata['format_generation']!=self.audio.get('format_generation'):
            raise ValueError('Linux settings belong to another audio session.')
        if self.linux_settings is not None and metadata['revision']<self.linux_settings['revision']:raise ValueError('Stale Linux settings acknowledgement.')
        if (metadata['backend']=='alsa')!=(self.pipewire is None):raise ValueError('Linux settings do not match actual PipeWire publication.')
        self.linux_settings=metadata;self.linux_settings_error=None;self.publish()
    def observe_settings_error(self,metadata):
        if not isinstance(metadata,dict) or metadata.get('uid')!=self.uid or metadata.get('state')!='error' or not isinstance(metadata.get('error'),str):
            raise ValueError('Invalid Linux settings error.')
        if metadata.get('frontend_failed') is True:self.pipewire=None
        self.linux_settings_error=metadata;self.publish()
    def observe_recovery(self,metadata):
        if (not isinstance(metadata,dict) or metadata.get('schema')!=1 or metadata.get('uid')!=self.uid or
                metadata.get('state') not in ('waiting','recovered','error') or metadata.get('usb_restarted') is not False or
                type(metadata.get('attempt')) is not int or not 0<=metadata['attempt']<=3 or not isinstance(metadata.get('reason'),str) or len(metadata['reason'])>512 or
                self.audio is None or any(metadata.get(k)!=self.audio.get(k) for k in ('connection_generation','format_generation'))):
            raise ValueError('Foreign or invalid Linux frontend recovery event.')
        self.recovery=metadata
        if metadata['state']!='recovered':self.pipewire=None
        self.publish()
    def remove_pipewire(self,uid):
        if uid!=self.uid:raise ValueError('Foreign PipeWire removal.')
        self.pipewire=None;self.publish()
    def observe_pcm_clients(self,metadata):
        if (not isinstance(metadata,dict) or metadata.get('uid')!=self.uid or type(metadata.get('connection_generation')) is not int or
                metadata['connection_generation']<=0 or type(metadata.get('clients')) is not int or not 0<=metadata['clients']<=64):
            raise ValueError('Invalid PCM client observation.')
        if self.audio is not None and metadata['connection_generation']!=self.audio.get('connection_generation'):raise ValueError('PCM clients belong to another audio session.')
        self.pcm_clients=metadata;self.publish()
    def observe_alsa(self,metadata):
        if metadata.get('uid')!=self.uid:raise ValueError('Foreign ALSA readiness.')
        if self.kernel_card is not None and (metadata.get('rate')!=self.kernel_card['rate'] or metadata.get('connection_generation')!=self.kernel_card['generation']):raise ValueError('Kernel/ALSA session differs.')
        if self.pipewire is not None and metadata.get('rate')!=self.pipewire['rate']:raise ValueError('PipeWire/ALSA rate differs.')
        if self.pcm_clients is not None and self.pcm_clients['connection_generation']!=metadata.get('connection_generation'):raise ValueError('PCM client generation differs.')
        self.audio=metadata;self.publish()
    def observe_pipewire(self,uid,metadata):
        if uid!=self.uid or not isinstance(metadata,dict):raise ValueError('Foreign PipeWire readiness.')
        device=metadata.get('device_id');nodes=metadata.get('nodes');rate=metadata.get('rate')
        if type(device) is not int or not 0<=device<2**32-1 or type(rate) is not int or rate<=0 or not isinstance(nodes,list) or not nodes:
            raise ValueError('Invalid PipeWire publication.')
        if self.audio is not None and rate!=self.audio.get('rate'):raise ValueError('PipeWire/ALSA rate differs.')
        ids=set();names=set()
        for node in nodes:
            if (not isinstance(node,dict) or not isinstance(node.get('name'),str) or not node['name'] or node['name'] in names or type(node.get('enabled',True)) is not bool):
                raise ValueError('Incomplete PipeWire nodes.')
            if node.get('enabled',True):
                if type(node.get('id')) is not int or not 0<=node['id']<2**32-1 or node['id'] in ids:raise ValueError('Invalid active PipeWire node.')
                ids.add(node['id'])
            elif node.get('id') is not None:raise ValueError('Disabled PipeWire node still has an active identity.')
            names.add(node['name'])
        self.pipewire=metadata;self.publish()
    def observe_pipewire_timing(self,value):
        if (not isinstance(value,dict) or value.get('schema')!=1 or value.get('uid')!=self.uid or
                self.audio is None or self.pipewire is None or
                value.get('connection_generation')!=self.audio.get('connection_generation') or
                value.get('format_generation')!=self.audio.get('format_generation') or
                value.get('device_id')!=self.pipewire.get('device_id')):
            return  # A retired frontend cannot replace the current diagnostics.
        self.pipewire['timing']=value;self.publish()
    def observe_kernel(self,metadata):
        if (not isinstance(metadata,dict) or metadata.get('schema')!=1 or metadata.get('uid')!=self.uid or
                any(type(metadata.get(k)) is not int or metadata[k]<=0 for k in ('generation','rate','capture_channels','playback_channels')) or
                type(metadata.get('card_index')) is not int or metadata['card_index']<0 or not isinstance(metadata.get('card_id'),str) or not metadata['card_id']):
            raise ValueError('Invalid native ALSA kernel card readiness.')
        if self.audio is not None and (metadata['rate']!=self.audio.get('rate') or metadata['generation']!=self.audio.get('connection_generation')):
            raise ValueError('Kernel/ALSA session differs.')
        self.kernel_card=metadata;self.publish()
    def complete(self):
        alsa_only=self.mode=='direct' or (self.linux_settings is not None and self.linux_settings['backend']=='alsa')
        return self.audio is not None and self.kernel_card is not None and (alsa_only or self.pipewire is not None) and (self.recovery is None or self.recovery['state']=='recovered')
    def publish(self):
        # MIDI readiness may arrive on its own reader thread. Serialize the
        # snapshot and atomic replacement so an older snapshot cannot erase ACK.
        with self._publish_lock:self._publish()
    def _publish(self):
        publish_status(self.status_file,{'schema':1,'uid':self.uid,
            'status':'audio_ready' if self.complete() else 'audio_preparing',
            **self.identity,'workers':{name:identity for name,(child,identity) in list(self.workers.items()) if child.poll() is None and process_identity(child.pid)==identity},
            'audio':self.audio,'attachment':self.attachment,'pipewire':self.pipewire,'kernel_card':self.kernel_card,
            'linux_settings':self.linux_settings,'linux_settings_error':self.linux_settings_error,'pcm_clients':self.pcm_clients,
            'recovery':self.recovery,
            'midi':{'status':self.midi.status,'ready':self.midi.ready} if self.midi is not None else None,
            'services':{'alsa':'ready' if self.audio else 'starting',
                        'alsa_kernel':'ready' if self.kernel_card else 'starting',
                        'midi':self.midi.status if self.midi is not None else 'starting',
                        'pipewire':'not_requested' if self.mode=='direct' or (self.linux_settings is not None and self.linux_settings['backend']=='alsa') else ('ready' if self.pipewire else ('recovering' if self.recovery and self.recovery['state']=='waiting' else 'error' if self.linux_settings_error and self.linux_settings_error.get('frontend_failed') else 'starting'))}})


def run(device,seconds,mode,rate_change=None,session_rate=None,with_levels=True,status_file=None,expected_attachment=None,format_change_rate=None,preserve_current_rate=False):
    duration=duration_arg(seconds)
    if type(preserve_current_rate) is not bool or (preserve_current_rate and (format_change_rate is None or expected_attachment is None or mode!='hybrid')):
        raise ValueError('Current-rate preservation requires bound hybrid format-change mode.')
    if expected_attachment is not None:
        from auto import attachment
        if attachment(device)!=expected_attachment:raise ValueError('Attachment changed before audio launch.')
    if occupied(device):raise ValueError('This interface is already active. Its current driver session is preserved.')
    bus=int(device['bus']);address=int(device['address']);node=Path(f'/dev/bus/usb/{bus:03}/{address:03}')
    if not os.access(node,os.R_OK|os.W_OK):raise ValueError('USB access unavailable. Install the preview access rule, then reconnect this idle interface.')
    runtime=Path(os.environ.get('XDG_RUNTIME_DIR','/tmp'))
    directory=Path(tempfile.mkdtemp(prefix='rme-audio-',dir=runtime))
    if len(os.fsencode(directory))+32+11>=108:
        directory.rmdir();raise ValueError('Runtime path too long for the PCM socket.')
    command=[str(ROOT/('rme-live-audio' if mode=='hybrid' else 'rme-direct-pcm')),device['uid'],duration]
    command+=['--alsa-directory',str(directory)] if mode=='hybrid' else [str(directory)]
    if session_rate is not None:command+=['--session-rate',str(session_rate)]
    if format_change_rate is not None:
        if expected_attachment is None or session_rate is not None:raise ValueError('Format change requires an exact manager attachment and exclusive rate mode.')
        command+=['--format-change-rate',str(format_change_rate),'--expected-connection-marker',expected_attachment['connection_marker'],
                  '--expected-descriptor-sha256',expected_attachment['descriptor_sha256']]
        if preserve_current_rate:command+=['--preserve-current-rate','true']
    stderr=BoundedLog();ready=[];midi=[];midi_report=None;levels=[];level_report=None
    availability=AudioAvailability(device['uid'],mode,status_file,expected_attachment)
    with StopRelay() as relay:
        child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
        relay.attach(child)
        availability.set_worker('audio',child)
        def monitor():
            for line in iter(lambda:child.stderr.readline(65536),''):
                stderr.append(line)
                if line.startswith('RME_ALSA_READY '):
                    _,name,config=line.rstrip().split(' ',2)
                    try:
                        metadata=json.loads(Path(config).with_name('session.json').read_text())
                        if metadata.get('uid')!=device['uid']:raise ValueError('Foreign audio owner readiness.')
                        if expected_attachment is not None and attachment(device)!=expected_attachment:raise ValueError('Attachment changed before audio readiness.')
                    except (ValueError,OSError) as error:
                        stderr.append(str(error));relay.stop(None,None);return
                    ready.append(metadata)
                    if not midi:
                        midi.append(MidiSession(device['uid'],relay,on_change=availability.publish))
                        availability.midi=midi[0]
                        if midi[0].child is not None and midi[0].child.poll() is None:availability.set_worker('midi',midi[0].child,required=False)
                    if with_levels and not levels:levels.append(LevelSession(device['uid'],relay))
                    availability.observe_alsa(metadata)
                    print(f"Audio ready: {clean(device['product'])} — {len(metadata['capture_names'])} inputs / {len(metadata['playback_names'])} outputs at {metadata['rate']} Hz.",flush=True)
                    if mode=='hybrid':print('Choose the RME device ports in your audio application or patchbay.',flush=True)
                    print(f'ALSA configuration: {config}\nALSA device: {name}\nALSA plugin directory: {ROOT}',flush=True)
                    print('Audio runs until stopped. Ctrl+C stops cleanly.' if seconds is None else f'Timed test: {seconds} seconds. Ctrl+C stops cleanly.',flush=True)
                elif line.startswith('RME_PCM_CLIENTS '):
                    try:availability.observe_pcm_clients(json.loads(line.split(' ',1)[1]))
                    except (ValueError,OSError,TypeError) as error:
                        stderr.append(str(error));relay.stop(None,None);return
                elif line.startswith('RME_KERNEL_PCM_READY '):
                    try:
                        if expected_attachment is not None and attachment(device)!=expected_attachment:raise ValueError('Attachment changed before kernel card readiness.')
                        availability.observe_kernel(json.loads(line.split(' ',1)[1]))
                    except (ValueError,OSError,TypeError) as error:
                        stderr.append(str(error));relay.stop(None,None);return
                elif line.startswith('RME_PIPEWIRE_TIMING '):
                    try:availability.observe_pipewire_timing(json.loads(line.split(' ',1)[1]))
                    except (ValueError,TypeError,OSError):pass
                elif line.startswith('RME_PIPEWIRE_READY '):
                    try:
                        _,uid,payload=line.rstrip().split(' ',2)
                        if expected_attachment is not None and attachment(device)!=expected_attachment:raise ValueError('Attachment changed before PipeWire readiness.')
                        availability.observe_pipewire(uid,json.loads(payload))
                        print('Native PipeWire device and audio nodes ready.',flush=True)
                    except (ValueError,OSError,TypeError) as error:
                        stderr.append(str(error));relay.stop(None,None);return
                elif line.startswith(('RME_LINUX_SETTINGS ', 'RME_LINUX_SETTINGS_ERROR ', 'RME_PIPEWIRE_REMOVED ', 'RME_LINUX_RECOVERY ')):
                    try:
                        if expected_attachment is not None and attachment(device)!=expected_attachment:raise ValueError('Attachment changed before Linux settings acknowledgement.')
                        marker,payload=line.rstrip().split(' ',1)
                        if marker=='RME_PIPEWIRE_REMOVED':availability.remove_pipewire(payload)
                        elif marker=='RME_LINUX_RECOVERY':availability.observe_recovery(json.loads(payload))
                        elif marker=='RME_LINUX_SETTINGS':availability.observe_settings(json.loads(payload))
                        else:availability.observe_settings_error(json.loads(payload))
                    except (ValueError,OSError,TypeError) as error:
                        stderr.append(str(error));relay.stop(None,None);return
                else:print(clean(line.rstrip()),file=sys.stderr,flush=True)
        monitor_thread=threading.Thread(target=monitor,daemon=True);monitor_thread.start()
        try:
            try:stdout=child.stdout.read();child.wait()
            except KeyboardInterrupt:
                child.send_signal(signal.SIGTERM);stdout=child.stdout.read();child.wait()
        finally:
            if child.poll() is None:child.send_signal(signal.SIGTERM);child.wait()
            relay.stop(None,None)
            monitor_thread.join(timeout=3)
            if midi:midi_report=midi[0].finish()
            if levels:level_report=levels[0].finish()
            # Only remove the empty directories made for this launch; never erase
            # configuration files left after an abnormal owner shutdown.
            for path in directory.iterdir():
                if path.is_dir() and not path.is_symlink():
                    try:path.rmdir()
                    except OSError:pass
            try:directory.rmdir()
            except OSError:pass
        report=json.loads(stdout) if stdout else None
        state=Path(os.environ.get('XDG_STATE_HOME',str(Path.home()/'.local/state')))/'rme-audio-preview'
        state.mkdir(mode=0o700,parents=True,exist_ok=True)
        report_path=state/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%f')+'.json')
        save_report(report_path,{'uid':device['uid'],'preview':verify(ROOT)['version'],'report':report,'stderr':''.join(stderr),'stderr_dropped_chars':stderr.dropped,'ready':ready,'midi':midi_report,'levels':level_report,'rate_change':rate_change,'requested_session_rate':session_rate,'requested_format_change_rate':format_change_rate,'preserve_current_rate':preserve_current_rate,'pipewire':availability.pipewire,'kernel_card':availability.kernel_card,'linux_settings':availability.linux_settings,'linux_settings_error':availability.linux_settings_error})
        publish_status(status_file,{'schema':1,'uid':device['uid'],'status':'stopped','report':str(report_path),'attachment':expected_attachment,
                                    **cleanup_state(report,expected_attachment)})
        print('Session stopped. Report: '+str(report_path))
        if child.returncode or not ready or not availability.complete() or report is None or report.get('error') or report.get('cleanup_errors'):raise RuntimeError('Audio session ended with an error; see the saved report.')

def main():
    parser=argparse.ArgumentParser(description='RME Audio Preview — continuous audio, shared MIDI and levels; mixer/OSCmixer selection unfinished.')
    rates=parser.add_mutually_exclusive_group();rates.add_argument('--rate',type=int,default=None,help='Set idle nominal Hz before audio');rates.add_argument('--session-rate',type=int,default=None,help='Request the running audio rate with native format reconfiguration');rates.add_argument('--format-change-rate',type=int,default=None,help=argparse.SUPPRESS);parser.add_argument('--list',action='store_true');parser.add_argument('--uid');parser.add_argument('--seconds',type=int,default=None);parser.add_argument('--mode',choices=('hybrid','direct'),default='hybrid');parser.add_argument('--no-levels',action='store_true',help='Audio/MIDI only; preserve a separate OSCmix levels/control owner');parser.add_argument('--status-file',type=Path,help=argparse.SUPPRESS);parser.add_argument('--expected-attachment',help=argparse.SUPPRESS);parser.add_argument('--preserve-current-rate',choices=('true',),default=None,help=argparse.SUPPRESS);args=parser.parse_args()
    if args.preserve_current_rate is not None:
        count=sum(arg=='--preserve-current-rate' or arg.startswith('--preserve-current-rate=') for arg in sys.argv[1:])
        if count!=1 or args.format_change_rate is None or not args.expected_attachment or args.mode!='hybrid':
            parser.error('Current-rate preservation requires one bound hybrid format-change request.')
    verify(ROOT)
    devices=json.loads(subprocess.check_output([str(ROOT/'ufxplusctl'),'list-devices'],text=True))
    if args.list:print(json.dumps(devices,indent=2));return
    duration_arg(args.seconds)
    if args.uid:device=select(devices,args.uid)
    else:
        supported=[d for d in devices if d.get('model') is not None]
        if not supported:raise ValueError('No supported RME interface connected.')
        print('RME Audio Preview — choose an idle interface. Existing active sessions are preserved.')
        for i,d in enumerate(supported,1):print(f"{i}. {clean(d['product'])} — {'already active' if occupied(d) else 'available'}")
        index=int(input('Device number (Ctrl+C to cancel): '))-1
        if not 0<=index<len(supported):raise ValueError('Invalid selection.')
        device=select(devices,supported[index]['uid'])
    rate_arg(args.session_rate,json.loads((ROOT/"catalogue.json").read_text())["rates"])
    rate_change=change_rate(device,args.rate)
    expected=json.loads(args.expected_attachment) if args.expected_attachment else None
    try:run(device,args.seconds,args.mode,rate_change,args.session_rate,not args.no_levels,args.status_file,expected,args.format_change_rate,args.preserve_current_rate=='true')
    except (ValueError,RuntimeError,OSError,subprocess.SubprocessError) as error:
        final={}
        try:
            previous=json.loads(args.status_file.read_text()) if args.status_file else {}
            if previous.get('uid')==device['uid'] and previous.get('attachment')==expected and previous.get('status')=='stopped':final=previous
        except (OSError,ValueError,AttributeError):pass
        publish_status(args.status_file,dict(final,schema=1,uid=device['uid'],status='error',error=str(error),attachment=expected))
        raise
if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError,subprocess.SubprocessError) as error:print(str(error),file=sys.stderr);sys.exit(1)
    except KeyboardInterrupt:sys.exit(130)
