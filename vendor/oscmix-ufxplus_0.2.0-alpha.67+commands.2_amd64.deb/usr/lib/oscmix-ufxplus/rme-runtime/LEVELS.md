# Shared native level return path

The3.39 reference driver is first: RMEFirefaceUSB x86_64 SHA256
19c8b7d292a8d1588e4a777d351d0489523bf2da3fab655269ea63fe6e07c2cb.
Its twenty valid control-family tables supply interface, endpoint descriptor
indices, transfer count and transfer size. openUSBInterfaces0x2de4 binds the
last pipe column bac0 to the level-IN owner. The endpoint address is resolved
from actual descriptors; it is not a copied UFX+ constant. Profiles without
a mixer-write pipe must not be treated as supporting UFX+ bulk writes.

REA levelControlStart0x3faa, TriggerLevel0x4ab8 and
levelMeterCompletionAction0x4368 define buffer dimensions, synchronization
markers/discard reads and page-specific held-peak windows. The accumulator
compares complete unsigned words and independently preserves the maximum low
four-bit overload counter. Other cached bytes remain from the initial copy
until the consumer requests a fresh bank, as in the reference. The raw previous
batch determines synchronization independently of accumulated peak values.
Alias3f8c is canonicalized to3fa0 by native initHardware0x323e.

Controlled replay executes original0x4368/0x4ab8 instructions for3762cases and
all33profiles. The private shadow image binds the unresolved memcpy relocation
to libc; supplied IOBuffer objects return memory, allocations return memory,
and pipe reads only record arguments. No USB, IOKit, target process launch or
original file modification occurs. The functional CSV contains hashes and
read sizes only. Fixture SHA256
16b4063d33bf905b5db9327314330ca407e60d4ce9a5a1e16474ea3026152733.
Evidence: ev_2348f51c3ed5f1d3cc6a1130f2c9a610e33097b99eb7ec6ad336e06f6ccf6aa7,
ev_c9c842524c0675c4933d8aa753ab711c12dc0fa3993e4e60306678ef8640019d,
assembly ev_88c50e907ed65074696a9acf9494a42355a9ff644d0d11707175eb7c1aa22129.
This is controlled branch execution, not original source or hardware evidence.

Plan resolution binds the full UID/attachment incarnation, descriptor digest,
VID/PID/revision, current configuration and idle control interface. Bulk packet
sizes and companions must agree with the observed bus speed. The private IN
transport preserves existing owners, claims only that control interface and
releases it on every result. It has no reset/detach, alternate/configuration
change, parameter OUT, arbitrary endpoint or reconnect API. Short/incomplete
batches fail; invalid synchronization batches are discarded. Complete batches
are applied atomically, and foreign attachments leave current caches intact.

Build `cargo build --release -p ufxplus-readonly-probe --bin rme-device-meters`.
Run `rme-device-meters UID --seconds 1` for a passive1..5second diagnostic.
This diagnostic duration does not limit normal audio, which runs until stopped.
Linux20ms diagnostic pacing and strict short-transfer rejection are explicit
host policies, not claims of identical native scheduling or failure handling.
The JSON reports the attachment, native dimensions, held wire cache as hex,
counts and zero parameter/audio-OUT operations. Raw cache words are not yet
all model-specific GUI meters, channel attribution, status or acknowledgments.
No arbitrary raw write interface is exposed. The previous exact Babyface/UFX+
readers and services remain available; this shared path replaces neither.

Hardware qualification is recorded separately. Reading levels may drain/reset
hardware peak counters, but does not change gains, routing or the audio stream.
The full multi-model mixer command and OSCmix selector work remains open.


Continuous per-UID raw levels are now started with the preview audio/MIDI session. See rme-meter-stream.md; the separate1..5second diagnostic requires its control interface to be idle. Normal audio and levels run until explicit stop or error, without a5minute ceiling. Raw banks are not yet GUI channel meters.
