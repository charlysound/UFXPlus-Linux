#!/usr/bin/env python3
"""Install this standalone preview without changing existing driver services."""
import argparse,json,os,shutil,subprocess
from pathlib import Path
from launch import verify

def desktop_command(path):
    return '/usr/bin/python3 "'+str(path).replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$').replace('%','%%')+'"'
def install(source,base,applications):
    manifest=verify(source);destination=base/manifest['version']
    base.mkdir(parents=True,exist_ok=True)
    if destination.exists():
        if verify(destination)!=manifest:raise ValueError('Existing version differs; it is preserved.')
    else:
        shutil.copytree(source,destination)
        verify(destination)
    applications.mkdir(parents=True,exist_ok=True)
    desktop=applications/'rme-audio-preview.desktop'
    marker='X-RME-Audio-Preview=true'
    if desktop.exists() and marker not in desktop.read_text():raise ValueError('Existing unrelated desktop entry is preserved.')
    desktop.write_text('[Desktop Entry]\nType=Application\nName=RME Audio Preview\nComment=Audio preview — explicit device, runs until stopped\nExec='+desktop_command(destination/'launch.py')+'\nIcon=audio-card\nTerminal=true\nCategories=AudioVideo;Audio;\n'+marker+'\n')
    os.chmod(desktop,0o644)
    return destination,desktop

def access_rule(source,usb_path):
    if not usb_path or Path(usb_path).name!=usb_path:raise ValueError('Explicit idle USB attachment required.')
    interface=Path('/sys/bus/usb/devices')/f'{usb_path}:1.0'
    if (interface/'driver').exists() or (interface/'bAlternateSetting').read_text().strip()!='0':raise ValueError('Active interface preserved; access activation requires an idle device.')
    rule=Path('/etc/udev/rules.d/70-rme-audio-preview.rules');data=(source/rule.name).read_bytes()
    if rule.exists() and rule.read_bytes()!=data:raise ValueError('Existing access rule differs; no overwrite.')
    subprocess.run(['sudo','-n','install','-m','0644',str(source/rule.name),str(rule)],check=True)
    subprocess.run(['sudo','-n','udevadm','control','--reload-rules'],check=True)
    subprocess.run(['sudo','-n','udevadm','trigger','--action=change','--subsystem-match=usb','--sysname-match='+usb_path],check=True)
    subprocess.run(['sudo','-n','udevadm','settle','--timeout=5'],check=True)
    return str(rule)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,default=Path.home()/'Applications/RME-Audio-Preview');parser.add_argument('--activate-access-for');args=parser.parse_args()
    source=Path(__file__).resolve().parent
    destination,desktop=install(source,args.base,Path.home()/'.local/share/applications')
    rule=access_rule(destination,args.activate_access_for) if args.activate_access_for else None
    print(json.dumps({'installed':str(destination),'desktop':str(desktop),'access_rule':rule,'manifest':verify(destination)},indent=2))
