#!/usr/bin/env python3
"""Explicit, one-shot reopening of a proven stopped owner. Never retries USB."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import secrets
import stat
import subprocess

from launch import process_identity
from rate_change import live_process

MAX_BYTES = 4 * 1024 * 1024
BINDING = ('connection_marker', 'descriptor_sha256')


def _integer(value, minimum=0):
    return type(value) is int and value >= minimum


def _read(path, private=False):
    path = Path(path)
    if not path.is_absolute():
        raise ValueError('Resume evidence paths must be absolute')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as source:
        before = os.fstat(source.fileno())
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid() or
                before.st_mode & (0o077 if private else 0o022) or before.st_size > MAX_BYTES):
            raise ValueError('Resume evidence must be owned, bounded and protected from other writers')
        raw = source.read(MAX_BYTES + 1)
        after = os.fstat(source.fileno())
        if (len(raw) > MAX_BYTES or (before.st_size, before.st_mtime_ns, before.st_ctime_ns) !=
                (after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
            raise ValueError('Resume evidence changed during reading')
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError('Resume evidence must be a JSON object')
    return value, hashlib.sha256(raw).hexdigest()


def _private_parent(path):
    parent = Path(path).parent
    metadata = parent.lstat()
    if not stat.S_ISDIR(metadata.st_mode) or metadata.st_uid != os.getuid() or metadata.st_mode & 0o077:
        raise ValueError('Resume authorization needs a private user directory')


def _exclusive(path, value):
    _private_parent(path)
    data = json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
    with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600), 'wb') as output:
        output.write(data)
        output.flush()
        os.fsync(output.fileno())
    directory = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def _same_binding(attachment, expected, uid):
    return (isinstance(attachment, dict) and all(attachment.get(k) == expected.get(k) for k in BINDING) and
            attachment.get('device', {}).get('uid') == uid)


def _previous_manager(snapshot):
    value = {k: snapshot.get(k) for k in ('manager_pid', 'manager_process_start', 'manager_nonce')}
    if (type(snapshot.get('schema')) is not int or snapshot['schema'] != 1 or
            not _integer(value['manager_pid'], 1) or not isinstance(value['manager_process_start'], str) or
            not value['manager_process_start'].isdecimal() or not isinstance(value['manager_nonce'], str) or
            not value['manager_nonce'] or not isinstance(snapshot.get('devices'), list)):
        raise ValueError('Previous manager identity is unavailable')
    return value


def stop_evidence(record, wrapper):
    """Classify *control* completion separately from historical PCM delivery."""
    uid = record['uid']
    expected = record['attachment']
    owner = record.get('owner') or {}
    report = wrapper.get('report') or {}
    duplex = report.get('duplex') or {}
    if (record.get('status') not in ('error', 'stopped') or not _integer(record.get('generation'), 1) or
            not _integer(record.get('pid'), 1) or not isinstance(record.get('process_start'), str) or
            not record['process_start'].isdecimal() or type(record.get('returncode')) is not int or
            owner.get('uid') != uid or owner.get('attachment') != expected or
            owner.get('status') not in ('error', 'stopped') or wrapper.get('uid') != uid or
            not isinstance(expected, dict) or any(not isinstance(expected.get(k), str) or not expected[k] for k in BINDING)):
        raise ValueError('Previous owner is not a bound terminal audio session')
    if report.get('cleanup_errors') != [] or duplex.get('cleanup_errors') != []:
        raise ValueError('Both native cleanup levels must be proven clean')
    before, after = report.get('before') or {}, report.get('after_stop') or {}
    if not all(_same_binding(a, expected, uid) for a in (before.get('attachment'), after.get('attachment'), duplex.get('attachment'))):
        raise ValueError('Native stop is missing or belongs to another attachment')
    old, stopped = before.get('snapshot') or {}, after.get('snapshot') or {}
    old_context, context = old.get('runtime_context') or {}, stopped.get('runtime_context') or {}
    rate = context.get('reference_nominal_rate_hz')
    card = wrapper.get('kernel_card') or {}
    if (not _integer(rate, 1) or old_context.get('reference_nominal_rate_hz') != rate or
            card.get('uid') != uid or card.get('rate') != rate or (duplex.get('format') or {}).get('rate') != rate or
            not isinstance(context.get('protocol'), str) or context['protocol'] != old_context.get('protocol') or
            any(old.get(k) != stopped.get(k) for k in ('vendor_id', 'product_id', 'canonical_product_id', 'firmware_revision')) or
            not _integer(stopped.get('firmware_revision'), 1) or
            not _integer(duplex.get('input_endpoint'), 1) or not _integer(duplex.get('output_endpoint'), 1)):
        raise ValueError('Stopped firmware/context/actual audio rate is not confirmed')
    # Normal error cleanup drains callbacks but does not credit late PCM
    # completions. No delivery outcome is fabricated for that historical delta.
    submitted, completed, cancelled = (duplex.get(k) for k in
        ('submitted_output_batches', 'completed_output_batches', 'cancelled_output_batches'))
    if not all(_integer(n) for n in (submitted, completed, cancelled)) or completed + cancelled > submitted:
        raise ValueError('Invalid stopped PCM accounting')
    if duplex.get('parameter_writes') != 0 or type(duplex.get('parameter_writes')) is not int or (type(duplex.get('successful_parameter_writes')) is not int or duplex['successful_parameter_writes'] != 0):
        raise ValueError('Separate duplex parameter writes are not attributed by this stop proof')
    attempted, successful = report.get('attempted_parameter_writes'), report.get('successful_parameter_writes')
    steps = report.get('steps')
    if not _integer(attempted) or not _integer(successful) or attempted != successful or not isinstance(steps, list):
        raise ValueError('A vendor control completion is uncertain')
    writes = 0
    for step in steps:
        setup = step.get('setup') if isinstance(step, dict) else None
        if (not isinstance(setup, list) or len(setup) != 8 or any(not _integer(v) or v > 255 for v in setup) or
                setup[0] not in (0x40,0xc0) or type(step.get('status')) is not int or step['status'] != 0 or type(step.get('reply_bytes')) is not int):
            raise ValueError('A recorded vendor operation failed or is malformed')
        length = setup[6] | setup[7] << 8
        if step['reply_bytes'] != length:
            raise ValueError('A recorded vendor operation is incomplete')
        if setup[0] & 0x80 == 0:
            writes += 1
    if writes != attempted:
        raise ValueError('Unattributed vendor parameter write; no reopening')
    midi = wrapper.get('midi')
    if midi is not None and (midi.get('uid') != uid or midi.get('status') != 'stopped' or type(midi.get('returncode')) is not int or midi['returncode'] != 0):
        raise ValueError('The previous MIDI owner did not stop cleanly')
    return dict(observed_rate_hz=rate, firmware_revision=stopped['firmware_revision'], protocol=context['protocol'],
                vendor_writes_completed=successful, transport_drained=True, control_state_known=True,
                pcm_submitted=submitted, pcm_completed=completed, pcm_cancelled_attested=cancelled,
                pcm_delivery_unattested=submitted - completed - cancelled)


def prepare(snapshot_path, output, uids):
    snapshot, snapshot_sha = _read(snapshot_path)
    manager = _previous_manager(snapshot)
    if not uids or len(uids) != len(set(uids)):
        raise ValueError('Select each exact stopped UID once')
    devices = []
    for uid in uids:
        records = [r for r in snapshot['devices'] if r.get('uid') == uid]
        if len(records) != 1:
            raise ValueError('Stopped UID is absent or ambiguous')
        record = records[0]
        report_path = (record.get('owner') or {}).get('report')
        wrapper, report_sha = _read(report_path)
        evidence = stop_evidence(record, wrapper)
        devices.append(dict(uid=uid, generation=record['generation'], attachment=record['attachment'],
                            report_path=report_path, report_sha256=report_sha, evidence=evidence))
    value = dict(schema=1, request_id=secrets.token_hex(16), previous_manager=manager,
                 snapshot_path=str(Path(snapshot_path)), snapshot_sha256=snapshot_sha, devices=devices)
    _exclusive(output, value)
    return value


class StoppedResumes:
    def __init__(self, manager, path, check_process=live_process):
        self.manager = manager
        self.targets = {}
        self.check_process = check_process
        if path is None:
            return
        path = Path(path)
        _private_parent(path)
        value, digest = _read(path, private=True)
        if (set(value) != {'schema','request_id','previous_manager','snapshot_path','snapshot_sha256','devices'} or
                type(value['schema']) is not int or value['schema'] != 1 or not isinstance(value['request_id'], str) or
                len(value['request_id']) != 32 or any(c not in '0123456789abcdef' for c in value['request_id']) or
                not isinstance(value['devices'], list) or not 1 <= len(value['devices']) <= 256):
            raise ValueError('Invalid stopped-owner authorization')
        snapshot, sha = _read(value['snapshot_path'])
        previous = _previous_manager(snapshot)
        if sha != value['snapshot_sha256'] or previous != value['previous_manager']:
            raise ValueError('Previous manager snapshot changed')
        if check_process(previous['manager_pid'], previous['manager_process_start']):
            raise ValueError('The previous manager is still alive; no owner is replaced')
        for target in value['devices']:
            uid = target['uid']
            if uid in self.targets:
                raise ValueError('Duplicate stopped-owner authorization')
            rows = [r for r in snapshot['devices'] if r.get('uid') == uid]
            if len(rows) != 1:
                raise ValueError('Previous UID is ambiguous')
            record = rows[0]
            if (set(target) != {'uid','generation','attachment','report_path','report_sha256','evidence'} or
                    target['attachment'] != record.get('attachment') or target['generation'] != record.get('generation') or
                    target['report_path'] != (record.get('owner') or {}).get('report')):
                raise ValueError('Stopped-owner binding changed')
            wrapper, report_sha = _read(target['report_path'])
            if report_sha != target['report_sha256'] or stop_evidence(record, wrapper) != target['evidence']:
                raise ValueError('Stopped-owner report changed')
            processes = [dict(pid=record['pid'], process_start=record['process_start'])]
            processes += list((record.get('owner') or {}).get('workers', {}).values())
            if any(check_process(p.get('pid'), p.get('process_start')) for p in processes):
                raise ValueError('A previous audio/MIDI process is still alive')
            self.targets[uid] = dict(target=target, record=record, wrapper=wrapper)
        # O_EXCL survives a subsequent manager crash. Authorization is consumed
        # before the first inventory tick, IN helper or child process launch.
        _exclusive(Path(str(path) + '.consumed'), dict(schema=1, request_id=value['request_id'], manifest_sha256=digest,
                   manager_pid=os.getpid(), manager_process_start=process_identity(os.getpid())['process_start'], manager_nonce=manager.token))
        self.request_id, self.previous = value['request_id'], previous

    def contains(self, uid):
        return uid in self.targets

    def start(self, entry, device):
        """A single attempt; every failure leaves the normal per-UID latch set."""
        if not self.contains(entry['uid']) or 'stopped_resume' in entry:
            return
        # Consume this in-memory authorization before validation, any fresh
        # read or spawn. A later entry is an ordinary new incarnation.
        item = self.targets.pop(entry['uid'])
        target, previous = item['target'], item['record']
        state = dict(schema=1, request_id=self.request_id, previous_manager=self.previous,
                     previous_generation=target['generation'], phase='error', **target['evidence'])
        entry['stopped_resume'] = state
        try:
            if entry['attachment'] != target['attachment']:
                raise ValueError('Stopped-owner authorization belongs to another attachment')
            original = item['wrapper']['report']['after_stop']['attachment']['device']
            if any(device.get(k) != original.get(k) for k in ('uid','vendor_id','product_id','revision','usb_path','bus','address')):
                raise ValueError('The enumerated device differs from the stopped context')
            if self.check_process(previous['pid'], previous['process_start']):
                raise ValueError('Previous launcher is no longer retired')
            if self.manager.is_occupied(device, self.manager.sysfs) or not self.manager.rate_changes.probe_control(self.manager.root, entry['uid'], entry['attachment']):
                raise ValueError('Selected audio/control interfaces are occupied; no owner is stopped')
            self.manager.rate_changes.check_drained_card(item['wrapper']['kernel_card'], allow_removed=True)
            if not self.manager.hardware_changes.startup(entry):
                raise ValueError('Current native clock does not admit conservative audio opening')
            fresh = entry.get('hardware_settings')
            if fresh is not None and fresh.get('request_abi') == 2:
                entry['_guarded_startup'] = dict(expected=copy.deepcopy(fresh), rate=state['observed_rate_hz'])
            self.manager.launch(entry, state['observed_rate_hz'], preserve_current_rate=True)
            entry['_stopped_resume_deadline']=self.manager.rate_changes.now()+35
            state['phase'] = 'starting'
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
            entry['status'] = 'error'
            entry['reason'] = str(error)
            state['error'] = str(error)

    def tick(self):
        for entry in self.manager.entries.values():
            state = entry.get('stopped_resume') or {}
            if state.get('phase') != 'starting':
                continue
            try:
                if self.manager.rate_changes.now()>entry['_stopped_resume_deadline']:
                    raise ValueError('Conservative audio opening deadline exceeded; no retry')
                if self.manager.closing or entry.get('_child') is None or entry.get('_stop_sent'):
                    raise ValueError('Conservative audio opening ended; no retry or cold fallback')
                try:
                    owner = self.manager.rate_changes.owner(entry)
                except FileNotFoundError:
                    continue
                if owner.get('status') != 'audio_ready':
                    continue
                if self.manager.rate_changes.confirmed(entry, owner, state['observed_rate_hz']) is None:
                    continue
                self.manager.hardware_changes.confirm_startup(entry)
                state['phase'] = 'applied'
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
                self.manager.stop(entry, 'Conservative audio opening failed; no retry')
                entry['status'] = 'error'; entry['reason'] = str(error)
                state.update(phase='error', error=str(error))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    command = sub.add_parser('prepare')
    command.add_argument('--snapshot', type=Path, required=True)
    command.add_argument('--output', type=Path, required=True)
    command.add_argument('--uid', action='append', required=True)
    args = parser.parse_args()
    result = prepare(args.snapshot, args.output, args.uid)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
