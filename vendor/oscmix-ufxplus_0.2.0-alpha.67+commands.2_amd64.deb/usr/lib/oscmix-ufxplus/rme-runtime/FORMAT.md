# Requested format and real confirmation

RequestedFormat prepares the requested profile geometry and descriptor alternate from a coherent, unchanged pre-change observation. The nine native rates and native VerifyOnly rules remain authoritative. This value is separate from InputPlan: its desired InputPlan is private and has no getter. Public getters expose layout metadata only; before() exposes the actual old observed plan.

The origin session/format epoch must be valid and match the selected UID. The target keeps that session generation and advances format generation once with overflow checking. No USB authority, settings write, ownership or submission is granted.

Native performFormatChange0xab18 calls getAudioPipes0x3908 before hwSetSampleRate when the rate-family alternate changes. rate_alternate_before_rate describes that condition. The future owner must allocate the requested queue geometry, select the validated alternate in that order, execute immutable rate steps and then obtain a real post-change context. A requested sample rate must never be substituted into a hardware observation.

confirm requires the target epoch, exact attachment/incarnation/descriptors and firmware identity. It reconstructs an ordinary InputPlan using the real decoded clock/context and then compares rate, complete format, roles, transfer kind and alternate with the requested metadata. An old clock, relabelled nominal field, stale epoch or reconnected card is rejected.

Existing observed InputPlan behavior is unchanged. Software tests use legal synthetic full descriptors across the reference catalogue; they are not hardware high-rate qualification. Candidate, installed and physically qualified versions are recorded separately in the shared delivery reports.

ReferenceRMEFirefaceUSB3.39 x86_64 SHA19c8b7d292a8d1588e4a777d351d0489523bf2da3fab655269ea63fe6e07c2cb. REAperformFormatChange ev_077de74ed10bf8f6fc773b3362b7ab4d9ee88528187f9776d25927f749e67b1d and getAudioPipes ev_ab84504569c4bbdd9b3855f6599e8b8b5b9a7abfd109d7a18dfadfb1fa62b6ad. Native pseudocode is not original source or proof of physical execution.

Some declared geometries (the Network clock family's64000/128000) have no coherent value in the reference clock decoder. Preparation is not a support or dispatch claim: these geometries cannot become an observed plan through an invented nominal field. Tests record them separately from successful confirmations; future owners must preserve that distinction.

The requested-rate runtime uses one IF0/control owner during initialization and configuration, replaces only drained input slots, and selects the rate-family alternate before Rate when required. It confirms the real post-change context before any duplex or host ports. Control IF is released before the preview starts its separate raw-level owner. No backend per model or additional numeric codec is introduced.

rme-requested-duplex UID Hz seconds is an explicit silent1..5second diagnostic. The preview's --session-rate 88200 (with a space) selects the running stream rate; --rate 48000 remains the separate idle nominal command. The options cannot be combined. Normal requested-rate audio still runs until stopped, with no five-minute cutoff.

On shutdown the audio alternate returns to0. The device's idle nominal may consequently return to its base-rate regime; after_idle reports the observed result, not the requested running rate. Diagnostics and failures while control is still owned restore the previous nominal. A host session never takes the control interface back from another owner for restoration; the report marks that deferred state. Explicit qualification restores its starting nominal after all owners stop. Physical high-rate results and package installation are recorded separately.

## Explicit frequency transaction on an existing session

Preview0.10 adds linux_rate_abi1. A private manager request at rate-requests/SHA256(uid).json contains exactly schema1, uid, request_id (32 lowercase hexadecimal characters), requested_rate_hz and expected. expected is the complete current Linux session marker, including audio_format_generation. No frequency is saved in linux.json, and a reconnect never replays a requested rate.

The manager validates the exact attachment, nonce, launcher and audio worker PID/start identities before stopping anything. It requires a generation-matched PCM client observation of zero plus closed statuses for every substream of the identified kernel ALSA card. The PCM producer counts accepted connections before their handshake; it publishes RME_PCM_CLIENTS with uid, connection_generation and clients, initially0 before readiness. Existing Linux preferences and the other interfaces are preserved.

Only the selected launcher is drained. status rate_changing asks the separate OSCmix control owner to release its interface. The manager waits for the old launcher to exit successfully, for its workers to disappear and for both audio and the cached native control topology to be free on the exact attachment. It checks the old ALSA card again if it still exists. Resource waiting has a30second deadline, without treating elapsed time as proof of readiness.

Exactly one replacement launch uses --format-change-rate with the expected connection marker and descriptor SHA. This path skips InitializationPrefix completely: the existing --session-rate startup path retains that initialization behavior. Format-change reuses RequestedFormat, queue preparation, native alternate/rate programs, real readback and confirmation. Clock decoder admission is checked before any OUT; Network64000/128000 is not advertised or attempted. Existing guarded cleanup and restoration remain unchanged. The previously running rate is reported separately from the fresh idle clock, which may differ after alternate0.

The rate_change record identifies the request and old/new manager generations, with phase stopping, waiting_control, starting, applied or error. applied requires a live new audio owner, the requested observed rate, matching active capture/playback geometry and ALSA card, and confirmed frontend preferences. PipeWire mode also requires an actual bound Device and every selected node; ALSA-only requires no PipeWire publication. Errors latch for that attachment and never trigger automatic frequency retries.

Audio metadata rate_capabilities is derived from the core profile, real clock context and cached descriptors: source rme_profile; policy native_format_change or verify_only; rates; and formats containing rate, capture_channels, playback_channels and native regime1/2/3. VerifyOnly exposes the observed rate alone. Physical port counts filter inactive/alias/FX slots through HostLayout. This is admission metadata, not proof of physical qualification for every model.

REA reinspection of the same3.39 binary/performFormatChange Evidence ID above found no direct InitializationPrefix calls; three virtual calls remain unattributed. This bounded port reuses the established pipe/rate/confirmation composition and does not claim those unresolved calls have been reproduced.
