# Automatic native RME owners

`auto.py` starts without a card and watches the shared `ufxplusctl list-devices`
producer. It starts the existing `launch.py` audio/MIDI owner once per exact UID
and kernel attachment. There is no PID table, new USB transport, CC fallback or
session duration limit. Profile admission, descriptor checks, activation, rates,
PCM/MIDI, transfer cancellation/drain and release remain in the existing owners.
An already active audio interface is left with its existing owner.

This is the Linux orchestration of the reference's separate device instances;
polling sysfs every 500ms and the JSON host contract are Linux adaptations, not
claims of original IOKit source identity. Reference: RMEFirefaceUSB3.39 x86_64,
SHA256 `19c8b7d292a8d1588e4a777d351d0489523bf2da3fab655269ea63fe6e07c2cb`.
Existing REA evidence `ev_c47f27d8c0c1512bf0ee786ccdc6cae0f0a011d93386b4619b7dbb8d9f960a2c`
(engine stop), `ev_35027dd436383c63150b802dea8ff881b735ef8dbfd3bf3de347f394ca4d90b4`
(audio stop) and `ev_942d06f17e3c17fc9f333e196ecd19749e4fc52939d728766d9cd7e6e36d6507`
(interface close) support keeping ordered stop/drain/release per instance. They
are static evidence, not a complete native notification/retry policy proof.

## Host availability contract

Run from a manifest-verified bundle:

```
python3 /path/to/bundle/auto.py --runtime-root /private/runtime/rme-native
```

The private directory must belong to the current user, mode0700, and cannot be a
symlink. An advisory lock allows one manager in that directory. `--status-file`
may name a file inside the same directory; default is `devices.json`. All status
files are atomically replaced with mode0600. Owner status filenames contain a
random manager nonce to prevent reuse of readiness from an earlier manager. A controller launching/reading a
manager must additionally ensure it has not launched another manager against a
different directory; USB ownership remains authoritative for other processes.

`devices.json` schema1 contains `manager_pid`, `manager_nonce`, `closing`, `inventory_error` and
`devices`. Each device record has `uid`, `model`, `attachment`, `generation`,
`status`, `owner_status_file`, `levels_owner:"oscmix"`, optional `pid`, `reason`
and `returncode`. `attachment` has `usb_path`, `bus`, `address`,
`descriptor_sha256`, `connection_marker`, `sysfs_inode`, `sysfs_ctime_ns`.
`connection_marker` is the same `dev:ino:ctimeSeconds:ctimeNanos` as the Rust
attachment reader. `attachment(device, sysfs)` is public for consumers needing
this exact comparison. Unknown/ambiguous identities never choose a fallback.

`starting` means launcher alive, not audio available. `running` is exposed only
when the launcher reports `audio_ready` for the exact UID and expected attachment
(after observing `RME_ALSA_READY` and verifying the matching session metadata).
`owner.audio` contains the producer's PCM `session.json`, including exact active
ports/rate, ALSA config/socket and format generation. `external_owner` means IF0
was already active and preserved; it does not claim that any other service is
ready. The GUI must also compare the current attachment before associating
levels/control, and must never treat the status file as USB authority.

The manager deliberately uses `launch.py --no-levels`: OSCmix's existing
`rme-live-levels --mixer-socket` remains the only levels/control owner. After
`running` or preserved `external_owner`, OSCmix may attach its existing owner;
it must still pass that owner's profile and identity admission. The manager
neither creates a second levels owner nor promises scalar control on all models.

## Removal, replacement and shutdown

Kernel inode/ctime and descriptor hashing detect a replacement even if both
polls see the same UID and USB address. An absent, changed or uncertain inventory
invalidates the old owner, sends SIGTERM once and waits for launcher completion
before replacement. The launcher uses its existing StopRelay, audio cleanup and
MIDI finish. The manager never kills a potentially draining USB owner, changes
another owner's alternate, or detaches a kernel driver. SIGTERM/SIGINT/SIGHUP
stop all managed launchers and wait for completion; there is no runtime timer.

An owner error is latched for that attachment. Inventory errors fail closed,
without repeatedly retrying the same attachment after inventory recovery. A
confirmed detach/replug or new kernel incarnation permits one new launch. An
external owner's disappearance without an actual replug does not trigger an
automatic takeover. These explicit Linux error policies are not a claim of
byte-for-byte native retry equivalence. Polling can miss an unplug/replug if
all kernel incarnation fields are indistinguishable; there is no invented
fallback device in that case.

Discovery errors attributable to one UID are exposed in the additive
`device_errors` map. A duplicated UID or unreadable attachment is refused for
that UID alone; independent, coherently observed cards retain their owners.
An observation error is not treated as a proven physical absence, so recovery
of that same observation never triggers an automatic USB reopen. A malformed
whole inventory still fails closed globally through `inventory_error`.

This delivery supplies native automatic lifecycle orchestration. It does not
complete control/FX/state coverage, decode raw meters, qualify every hardware
model, or install a system/user service. The existing Preview manual entry point
is retained. The parent application's distribution integration chooses the user
service lifetime independently from the OSCmix window lifetime.

## Installed legacy UFX+ owner coexistence

The legacy `ufxplus-driver.service` also owns arrival/reconnect of its one native
VID2a39/PID3fc1 interface. Its read-only `runtime_state.py` status contract is
reused (schema1, supervisor PID/start ticks), with `/proc` command line restricted
to `/usr/bin/python3 /usr/share/ufxplus-driver/service_start.py`. A stale,
recycled or unrelated PID never reserves a device. A live non-stopped legacy
supervisor reserves its exact single-interface discovery scope even when IF0
has not been claimed yet. Other catalogue families are unaffected.

The availability record reports `external_pending` while IF0 is idle and
`external_owner` once occupied, updating each tick without a new launcher. The
former is explicitly **not audio ready**; consumers must wait. There is no
same-attachment takeover when the legacy supervisor stops. On next physical
replug the current reservation is reevaluated. Before the first JSON publication,
`systemctl --user show --property=MainPID --value ufxplus-driver.service` supplies
only a candidate PID: current-user ownership, exact command line and unchanged
process start ticks are verified before reservation. A foreign/recycled PID is
never authority. This fallback is queried for new presence, pending legacy state
or idle IF0; an occupied legacy owner does not cause a systemctl query each tick.
No JSON value or MainPID is interpreted as audio readiness.

## Explicit host-service availability

Hybrid availability now requires three separate confirmations tied to the same
UID, attachment and rate: the direct PCM endpoint, an actual native ALSA kernel
card (`RME_KERNEL_PCM_READY`), and bound PipeWire Device/nodes
(`RME_PIPEWIRE_READY` after core sync). `owner.kernel_card` identifies the ALSA
card index/id and capture/playback dimensions; `owner.pipewire` identifies the
Device and configurable nodes. Inactive PipeWire nodes remain listed as
`enabled:false,id:null`; disabling all nodes still leaves the device and ALSA
card present. `services.alsa_kernel` and `services.pipewire` expose their actual
status. A userspace ALSA socket alone no longer marks the hybrid session ready.
The normal direct mode also requires its native kernel card.

Native node selection uses
`$XDG_CONFIG_HOME/rme-native/devices/SHA256(uid)/nodes.json`:
`{"schema":1,"uid":"...","enabled":{"stable NodePlan.name":false}}`.
Absent entries are enabled. UID, node prefix and boolean types are validated;
a hot invalid file is ignored with an error while current streams remain.
Valid changes connect/disconnect only the existing PipeWire streams, retaining
native USB, ALSA, mixer owners and connection/format generation. UFX+ legacy
configuration and its existing service remain separate and preserved.
# Explicit Linux owner migration

The existing UFX+ audio/MIDI owner can hand its device to the common manager.
This is Linux ownership adaptation: the native audio codec, activation,
HostContract, rate readback, ALSA bridge and MIDI endpoints are reused. The
existing UFX+ mixer/level helper on IF1 remains its control owner. No common
scalar-mixer admission is inferred for its different protocol.

`rme-linux-settings owner --uid UID --expected-marker JSON --target native`
requests one handoff using the current marker returned by `status`. The old
supervisor must already publish `owner_handoff_abi:1`; installing a Python file
does not update a running interpreter. The common ALSA character device must
also be present and accessible. Missing prerequisites refuse before drain.

The manager reads a private one-shot `owner-requests/<sha256uid>.json` beside
`devices.json`: schema1, uid, request_id (32 lower-case hex), owner (`native` or
`legacy`) and expected (the complete current Linux marker). Old manager,
generation or attachment requests are ignored after restart/replug. The
published row adds `owner_change` with request_id, phase, from_generation,
to_generation, previous_running_rate_hz, observed_rate_hz, error, uncertain and
rollback when applicable. Linux settings ABI1 and linux.json are unchanged.

`~/.config/rme-native/devices/<sha256uid>/owner.json` records schema1, uid,
owner, phase (`pending`, `committed`, `error`), request_id and producer-issued
device identity (vendor_id, product_id, serial, usb_path). The pending record
also contains the previous owner authority, MIDI identity and a bounded rollback
snapshot. It is atomically persisted and synced before requesting drain. Both
supervisors respect pending/error, including after process or machine restart;
neither automatically replays an interrupted transaction.

The historical supervisor stays alive. It checks the preference in its existing
loop (within one second; SIGUSR1 is only an optional wakeup), rechecks clients,
identity and attachment, drains its audio worker and signals only the validated
MIDI companion via pidfd, exact process-start and a USB handle for this device.
It publishes a clean delegation only after successful audio retirement. The
manager separately waits for both previous processes to leave and IF0/IF2 to
be free, and rechecks ALSA/plugin clients before opening the existing common
launcher once. No `systemctl stop` of the audio unit, forced driver detach,
arbitrary settling delay, rate request or mixer write is part of the handoff.

All old preference files are retained. Five legacy node switches are translated
to the native producer catalogue's stream IDs, including groups inactive at the
current rate; no second model table is introduced. The live buffer request is
preserved. Backend `alsa` stays ALSA-only; both historical PipeWire modes map
to the common `pipewire+alsa` backend, which additionally exposes kernel ALSA.
The already running rate and physical channel counts must remain unchanged.
ALSA, settings revision/backend/buffer, PipeWire Device and nodes, MIDI identity
and ports must really be ready. Previously existing PipeWire links are mapped
through native physical channel coordinates; foreign endpoint IDs/serials and
the server incarnation stay exact. Only then is owner=native committed.

On failure, the new launcher is drained before considering rollback. Returning
to the old owner requires an exact attachment, explicit native cleanup
attestation, no uncertain parameter write and the previous observed rate. Its
prepared session token avoids replaying old preparation. Unconfirmed cleanup
latches an error instead. `--target legacy` is an explicit recovery for a
pending/error handoff once IF0/IF2 are free, tied to the new current marker.
Routes which cannot safely be restored are reported separately; they do not
cause a second USB retry. The legacy MIDI unit's compatibility ExecStart
adapter respects committed/pending owner preferences on future boots.

The common ALSA card has its UID identity. The old static UFXPlus kernel card
may remain loaded for rollback; this transaction does not unload modules or
silently retarget an application's saved ALSA device. Qualification/retirement
of that obsolete frontend is a separate explicit installation step. A portable
host install does not replace files owned by an existing distribution package;
its legacy compatibility overlay must be installed before migration is admitted.

