"""One-shot native rate transitions. Existing launchers retain all USB work."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time
from launch import process_identity

def private_json(path):
    metadata=path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid!=os.getuid() or metadata.st_mode&0o077 or metadata.st_size>1048576:
        raise ValueError('Rate transaction file must be private and bounded')
    value=json.loads(path.read_text())
    if not isinstance(value,dict):raise ValueError('Rate transaction JSON must be an object')
    return value

def live_process(pid,start,parent=None):
    identity=process_identity(pid)
    if identity is None or identity['process_start']!=start:return False
    try:
        process=Path('/proc')/str(pid)
        fields=(process/'stat').read_text().rsplit(')',1)[1].split()
        return process.stat().st_uid==os.getuid() and (parent is None or int(fields[1])==parent) and process_identity(pid)==identity
    except (OSError,ValueError,IndexError):return False

def alsa_closed(card,asound=Path('/proc/asound'),allow_removed=False):
    index=card.get('card_index');identifier=card.get('card_id')
    if type(index) is not int or index<0 or not isinstance(identifier,str):raise ValueError('ALSA card identity unavailable')
    path=asound/('card'+str(index))
    try:observed=(path/'id').read_text().strip()
    except FileNotFoundError:
        if allow_removed and not path.exists():return
        raise
    if observed!=identifier:raise ValueError('ALSA card changed before rate transaction')
    statuses=list(path.glob('pcm*/sub*/status'))
    if not statuses or any(p.read_text().strip()!='closed' for p in statuses):
        raise ValueError('Close the selected interface ALSA applications before changing frequency')
    if (path/'id').read_text().strip()!=identifier:raise ValueError('ALSA card changed during client inspection')

def clients_closed(owner,asound=Path('/proc/asound')):
    audio=owner.get('audio') or {};card=owner.get('kernel_card') or {};clients=owner.get('pcm_clients')
    if (not isinstance(clients,dict) or clients.get('uid')!=owner.get('uid') or
            clients.get('connection_generation')!=audio.get('connection_generation') or
            type(clients.get('clients')) is not int or clients['clients']<0):
        raise ValueError('PCM client observation is unavailable; no rate change performed')
    if clients['clients']:
        raise ValueError('Close the selected interface PCM applications before changing frequency')
    alsa_closed(card,asound)

def control_free(root,uid,expected):
    result=subprocess.run([str(root/'rme-control-layout'),uid],capture_output=True,text=True,timeout=3,check=True)
    value=json.loads(result.stdout);topology=value.get('topology') or {};attachment=topology.get('attachment') or {}
    if (attachment.get('device',{}).get('uid')!=uid or
            any(attachment.get(k)!=expected.get(k) for k in ('connection_marker','descriptor_sha256')) or
            value.get('usb_calls')!=0 or value.get('parameter_writes')!=0):
        raise ValueError('Control topology belongs to another attachment')
    return value.get('current_owner') is None

class RateChanges:
    def __init__(self,manager,check_process=live_process,check_clients=clients_closed,probe_control=control_free,now=time.monotonic,check_drained_card=alsa_closed):
        self.manager=manager;self.check_process=check_process;self.check_clients=check_clients;self.probe_control=probe_control;self.now=now
        self.check_drained_card=check_drained_card
        self.consumed=set()
    def owner(self,entry):
        value=private_json(Path(entry['owner_status_file']))
        if value.get('uid')!=entry['uid'] or value.get('attachment')!=entry['attachment']:raise ValueError('Stale audio owner snapshot')
        return value
    def marker(self,entry,owner):
        audio=owner.get('audio') or {};worker=(owner.get('workers') or {}).get('audio') or {}
        if (owner.get('pid')!=entry.get('pid') or owner.get('process_start')!=entry.get('process_start') or
            not self.check_process(entry.get('pid'),entry.get('process_start'),os.getpid()) or
            not self.check_process(worker.get('pid'),worker.get('process_start'),entry.get('pid'))):
            raise ValueError('Audio process identity changed')
        return dict(manager_pid=os.getpid(),manager_process_start=process_identity(os.getpid())['process_start'],manager_nonce=self.manager.token,
                    generation=entry['generation'],attachment=entry['attachment'],owner_pid=entry['pid'],owner_process_start=entry['process_start'],
                    worker_pid=worker['pid'],worker_process_start=worker['process_start'],audio_generation=audio.get('connection_generation'),audio_format_generation=audio.get('format_generation'))
    def fail(self,entry,error,uncertain=False):
        entry['rate_change'].update(phase='error',error=str(error),uncertain=uncertain)
        if entry.get('_rate_change') is not None:
            self.manager.stop(entry,'rate transition failed; no automatic retry')
            entry.pop('_rate_change',None)
        entry['status']='error' if uncertain else entry.get('_rate_previous_status','running')
        entry['reason']=str(error)
    def validate_request(self,entry,request):
        if (set(request)!={'schema','uid','request_id','requested_rate_hz','expected'} or type(request.get('schema')) is not int or request['schema']!=1 or
            request.get('uid')!=entry['uid'] or not isinstance(request.get('request_id'),str) or len(request['request_id'])!=32 or
            any(c not in '0123456789abcdef' for c in request['request_id']) or type(request.get('requested_rate_hz')) is not int or request['requested_rate_hz']<=0):
            raise ValueError('Invalid native rate request')
    def retired(self,entry,request):
        """A persisted one-shot for a retired authority is not a new request."""
        self.validate_request(entry,request)
        expected=request['expected']
        integers=('manager_pid','generation','owner_pid','worker_pid','audio_generation','audio_format_generation')
        strings=('manager_process_start','manager_nonce','owner_process_start','worker_process_start')
        if (not isinstance(expected,dict) or set(expected)!=set(integers+strings+('attachment',)) or
                any(type(expected[k]) is not int or expected[k]<=0 for k in integers) or
                any(not isinstance(expected[k],str) or not expected[k] for k in strings) or
                not isinstance(expected['attachment'],dict)):
            return False  # malformed current requests retain their error ACK
        authority=dict(manager_pid=os.getpid(),manager_process_start=process_identity(os.getpid())['process_start'],
                       manager_nonce=self.manager.token,generation=entry['generation'],attachment=entry['attachment'])
        return json.dumps({k:expected[k] for k in authority},sort_keys=True)!=json.dumps(authority,sort_keys=True)
    def accept(self,entry,request):
        self.validate_request(entry,request)
        if entry.get('_rate_change') is not None or entry.get('_hardware_change') or entry.get('_owner_change'):raise ValueError('A card transaction is already in progress')
        if entry.get('status')!='running' or entry.get('_legacy_reserved') or entry.get('_child') is None:
            raise ValueError('Selected native audio session is not ready for frequency change')
        owner=self.owner(entry)
        if owner.get('status')!='audio_ready':raise ValueError('Audio frontends are transitioning; no frequency change performed')
        if json.dumps(request['expected'],sort_keys=True)!=json.dumps(self.marker(entry,owner),sort_keys=True):raise ValueError('Frequency request belongs to a previous session')
        audio=owner.get('audio') or {};caps=audio.get('rate_capabilities') or {}
        if request['requested_rate_hz'] not in caps.get('rates',[]) or caps.get('source')!='rme_profile':
            raise ValueError('Requested rate is not admitted by the native active profile')
        self.check_clients(owner)
        workers=[dict(v) for v in owner.get('workers',{}).values()]
        entry['_rate_previous_status']=entry['status']
        entry['rate_change']=dict(schema=1,uid=entry['uid'],request_id=request['request_id'],requested_rate_hz=request['requested_rate_hz'],
                                  previous_running_rate_hz=audio['rate'],from_generation=entry['generation'],phase='stopping')
        entry['_rate_change']=dict(deadline=self.now()+30,workers=workers,request=request,kernel_card=owner['kernel_card'])
        self.manager.stop(entry,'explicit per-device format change')
        entry['status']='rate_changing'
    def confirmed(self,entry,owner,rate):
        uid=entry["uid"]
        self.marker(entry,owner)
        audio=owner.get('audio') or {};kernel=owner.get('kernel_card') or {};settings=owner.get('linux_settings') or {};pw=owner.get('pipewire')
        if audio.get('rate')!=rate or kernel.get('rate')!=rate or kernel.get('generation')!=audio.get('connection_generation'):
            raise ValueError('Native format or ALSA card did not confirm the requested rate')
        if settings.get('backend')=='pipewire+alsa' and (not isinstance(pw,dict) or pw.get('rate')!=rate):return None
        if settings.get('backend') not in ('alsa','pipewire+alsa') or settings.get('applied') is not True:return None
        if (settings.get('uid')!=uid or settings.get('connection_generation')!=audio.get('connection_generation') or
                settings.get('format_generation')!=audio.get('format_generation')):
            raise ValueError('Frontend settings belong to another format')
        if settings['backend']=='alsa' and pw is not None:raise ValueError('ALSA-only session unexpectedly publishes PipeWire')
        if settings['backend']=='pipewire+alsa':
            plans=audio.get('nodes') or [];nodes=pw.get('nodes')
            if (type(pw.get('device_id')) is not int or not 0<=pw['device_id']<2**32-1 or not plans or not isinstance(nodes,list) or
                    {p.get('name') for p in plans}!={n.get('name') for n in nodes} or len(nodes)!=len(plans) or
                    any(type(n.get('enabled')) is not bool or (n['enabled'] and (type(n.get('id')) is not int or not 0<=n['id']<2**32-1)) or
                        (not n['enabled'] and n.get('id') is not None) for n in nodes)):
                raise ValueError('PipeWire nodes did not confirm the new format')
        if kernel.get('capture_channels')!=len(audio.get('capture_names',[])) or kernel.get('playback_channels')!=len(audio.get('playback_names',[])):
            raise ValueError('Native active channels and ALSA card differ')
        return owner
    def tick(self,observed):
        manager=self.manager
        for uid,entry in manager.entries.items():
            current=observed.get(uid)
            if current is None or current[1]!=entry['attachment'] or manager.closing:
                if entry.get('_rate_change'):self.fail(entry,'Attachment disappeared during frequency transition',True)
                continue
            path=manager.directory/'rate-requests'/(hashlib.sha256(uid.encode()).hexdigest()+'.json')
            try:request=private_json(path)
            except FileNotFoundError:request=None
            except (OSError,ValueError) as error:
                request=None
                entry.setdefault('rate_change',dict(schema=1,uid=uid,request_id=None))
                if not entry.get('_rate_change'):entry['rate_change'].update(phase='error',error=str(error))
            if request is not None:
                identifier=request.get('request_id')
                key=(uid,identifier if isinstance(identifier,str) else 'invalid')
                if key not in self.consumed:
                    self.consumed.add(key)
                    try:
                        if not self.retired(entry,request):self.accept(entry,request)
                    except (OSError,ValueError,KeyError,TypeError,AttributeError) as error:
                        if not entry.get('_rate_change'):
                            entry['rate_change']=dict(schema=1,uid=uid,request_id=request.get('request_id'),phase='error',error=str(error),uncertain=False)
            transaction=entry.get('_rate_change')
            if transaction is None:continue
            entry['status']='rate_changing'
            try:
                if self.now()>transaction['deadline']:raise ValueError('Frequency transition deadline exceeded; no automatic retry')
                phase=entry['rate_change']['phase']
                if phase=='stopping':
                    if entry.get('_child') is not None:continue
                    if entry.get('returncode')!=0:raise ValueError('Previous audio owner did not drain successfully')
                    if any(self.check_process(w.get('pid'),w.get('process_start')) for w in transaction['workers']):continue
                    entry['rate_change']['phase']='waiting_control'
                if entry['rate_change']['phase']=='waiting_control':
                    if manager.is_occupied(current[0],manager.sysfs) or not self.probe_control(manager.root,uid,entry['attachment']):continue
                    self.check_drained_card(transaction['kernel_card'],allow_removed=True)
                    manager.generation+=1;entry['generation']=manager.generation
                    entry['owner_status_file']=str(manager.directory/(hashlib.sha256(uid.encode()).hexdigest()+f'-{manager.token}-{manager.generation}.json'))
                    entry.pop('_stop_sent',None)
                    manager.launch(entry,transaction['request']['requested_rate_hz'])
                    entry['rate_change'].update(phase='starting',to_generation=entry['generation'])
                    continue
                if entry['rate_change']['phase']=='starting':
                    if entry.get('_child') is None:raise ValueError('New audio owner exited during format change')
                    try:owner=self.owner(entry)
                    except FileNotFoundError:continue
                    if owner.get('status')!='audio_ready':continue
                    rate=transaction['request']['requested_rate_hz']
                    if self.confirmed(entry,owner,rate) is None:continue
                    audio=owner['audio'];kernel=owner['kernel_card']
                    entry['rate_change'].update(phase='applied',observed_rate_hz=rate,capture_channels=kernel['capture_channels'],playback_channels=kernel['playback_channels'],
                                               audio_connection_generation=audio['connection_generation'],audio_format_generation=audio['format_generation'])
                    entry.pop('_rate_change');entry['status']='running';entry.pop('reason',None)
            except (OSError,ValueError,KeyError,TypeError,AttributeError,subprocess.SubprocessError) as error:self.fail(entry,error,True)
