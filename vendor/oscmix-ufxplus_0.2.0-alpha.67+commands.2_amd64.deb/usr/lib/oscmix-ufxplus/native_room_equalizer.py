"""Shared semantic RoomEQ descriptors and complete raw intentions.

No registers, model table, bit interpretation, USB writer or default readback.
Typed43 is a local staging marker, never an RME command.
"""
REFERENCE='75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'
IDS=tuple(range(53,85))
NAMES={5:'room_equalizer_volume_calibration',53:'room_equalizer_master',54:'room_equalizer_delay',82:'room_equalizer_band1_type',83:'room_equalizer_band8_type',84:'room_equalizer_band9_type'}
for band in range(1,10):
    for part,suffix in enumerate(('frequency','q','gain')):NAMES[55+3*(band-1)+part]=f'room_equalizer_band{band}_{suffix}'


class Parameters:
    def __init__(self,description):
        model=description.get('native_model',{});room=model.get('room_equalizer');entries=[d for d in model.get('channel_parameters',[]) if isinstance(d,dict) and str(d.get('parameter','')).startswith('room_equalizer_')]
        self.cap=None;self.descriptors={}
        if room is None or isinstance(room,dict) and room.get('available') is False:
            if entries:raise RuntimeError('RoomEQ descriptors without native admission authority')
            return
        if (model.get('codec') not in ('ufx_fx','modern_fx') or not isinstance(room,dict)
                or room.get('available') is not True or type(room.get('admitted')) is not bool
                or room.get('reference_sha256')!=REFERENCE or room.get('native_parameters')!=list(IDS)
                or type(room.get('parameter_count')) is not int or room['parameter_count']!=32
                or any(room.get(k) is not True for k in ('full_restore_required','raw_master_preserved','boolean_master_requires_known_value'))):
            raise RuntimeError('Invalid native RoomEQ authority')
        calibration=room.get('volume_calibration',False)
        if type(calibration) is not bool:raise RuntimeError('Invalid native calibration authority')
        expected=set(IDS)|({5} if calibration else set())
        outputs=room.get('outputs')
        if (not isinstance(outputs,list) or not outputs or any(type(ch) is not int or not 0<=ch<=255 for ch in outputs)
                or outputs!=sorted(set(outputs)) or outputs!=model.get('active_outputs')
                or type(room.get('max_raw_restore_commands')) is not int or room['max_raw_restore_commands']!=(32+calibration)*len(outputs)):
            raise RuntimeError('Invalid native RoomEQ outputs or full-model bound')
        defaults=description.get('host_mixer_defaults',{})
        if (defaults.get('provenance')!='host_template' or defaults.get('reference_sha256')!=REFERENCE
                or defaults.get('operation_mode')!='full' or defaults.get('hardware_confirmed') is not False):
            raise RuntimeError('Missing native Full RoomEQ intention provenance')
        for d in entries:
            p=d.get('native_parameter')
            if (type(p) is not int or p not in expected or p in self.descriptors or d.get('parameter')!=NAMES[p]
                    or d.get('command_kind')!='room_equalizer_parameter' or d.get('banks')!=['output']
                    or d.get('channels')!=outputs or d.get('startup_restore') is not True
                    or type(d.get('stereo_shared')) is not bool or d['stereo_shared']!=(p==53)
                    or any(type(d.get(k)) is not int or not -2**31<=d[k]<2**31 for k in ('min','max','step','scale','initial'))
                    or d['step']<=0 or d['scale']<=0 or not d['min']<=d['initial']<=d['max']
                    or (d['initial']-d['min'])%d['step']):
                raise RuntimeError('Invalid native RoomEQ descriptor')
            self.descriptors[p]=dict(d)
        if set(self.descriptors)!=expected:raise RuntimeError('Incomplete native RoomEQ descriptors')
        if calibration and any(self.descriptors[5].get(k)!=v for k,v in (('min',-2400),('max',300),('step',10),('scale',100),('initial',0))):raise RuntimeError('Invalid native calibration descriptor')
        master=self.descriptors[53]
        if (any(master.get(k)!=v or type(master.get(k)) is not int for k,v in (('min',0),('max',1),('step',1),('scale',1)))
                or master.get('raw_restore_range')!={'min':0,'max':65535}
                or any(type(master['raw_restore_range'].get(k)) is not int for k in ('min','max'))
                or master.get('interactive_requires_known_boolean') is not True):
            raise RuntimeError('Invalid native RoomEQ opaque-master guard')
        self.cap=dict(room);self.outputs=frozenset(outputs)

    def valid(self,channel,parameter,value,raw=False):
        if self.cap is None or channel not in self.outputs or type(value) is not int:return False
        d=self.descriptors.get(parameter)
        if d is None:return False
        return 0<=value<=65535 if raw and parameter==53 else d['min']<=value<=d['max'] and (value-d['min'])%d['step']==0

    def profile(self):
        return [] if self.cap is None else ['room-equalizer\t1\t65535\t'+','.join(map(str,sorted(self.outputs)))]

    def validate_full(self,records,all_outputs=False):
        """Tuples (output,native parameter,value), prevalidated as one model."""
        if self.cap is None:raise RuntimeError('Native RoomEQ unavailable')
        grouped={}
        for ch,p,value in records:
            if not self.valid(ch,p,value,True) or p in grouped.setdefault(ch,{}):raise RuntimeError('Invalid or duplicate raw RoomEQ field')
            grouped[ch][p]=value
        if (not grouped or len(records)>self.cap['max_raw_restore_commands']
                or any(set(fields)!=set(self.descriptors) for fields in grouped.values())
                or all_outputs and set(grouped)!=self.outputs):
            raise RuntimeError('Raw RoomEQ restoration requires complete32-field outputs')

    def confirm(self,description,identity):
        current=Parameters(description)
        state=description.get('state',{})
        if (description.get('identity')!=identity or not isinstance(state,dict)
                or state.get('identity')!=identity or state.get('retired') is not False
                or state.get('state_complete') is not True or state.get('hardware_confirmed') is not False
                or current.cap is None or current.cap['admitted'] is not True
                or any(current.cap.get(k)!=v for k,v in self.cap.items() if k!='admitted')
                or current.descriptors!=self.descriptors):
            raise RuntimeError('Native RoomEQ restoration was not completed')

    def command(self,channel,parameter,value,raw=False):
        if not self.valid(channel,parameter,value,raw):raise RuntimeError('Invalid native RoomEQ value or output')
        return dict(kind='room_equalizer_parameter',output=channel,parameter=NAMES[parameter],value=value,raw_restore=bool(raw))


def is_command(command):return command.get('kind')=='room_equalizer_parameter'


def tuples(commands):
    by_name={name:p for p,name in NAMES.items()}
    return [(c['output'],by_name[c['parameter']],c['value']) for c in commands if is_command(c)]
