"""Projection of the native producer's EQ model and complete typed records.

The native owner alone owns DSP slots, initialization, encoding and USB.
This module does not select models, synthesize hardware defaults or reset DSP.
"""
import math
import copy

REFERENCE = '75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'
CONTROLS = frozenset(range(25,40))
BOOLS = frozenset((25,28,29,36))
FREQUENCIES = frozenset((31,34,38))
GAINS = frozenset((30,33,37))
QS = frozenset((32,35,39))


def capability(description):
    value = description.get('capabilities', {}).get('equalizer')
    if value is None:
        return None
    if isinstance(value,dict) and value.get('available') is False and value.get('admitted') is False:
        return None
    if (not isinstance(value,dict) or value.get('available') is not True
            or type(value.get('admitted')) is not bool
            or type(value.get('initialization_required')) is not bool
            or value.get('hardware_readback') is not False
            or type(value.get('sample_rate_hz')) is not int
            or not 32000 <= value['sample_rate_hz'] <= 192000
            or type(value.get('slot_capacity')) is not int
            or not 1 <= value['slot_capacity'] <= 22):
        raise RuntimeError('Invalid native equalizer capability')
    if 'restore_transport' in value and value['restore_transport'] != 'restore_matrix':
        raise RuntimeError('Invalid native equalizer restore transport')
    if 'initial_clear_entries' in value and (type(value['initial_clear_entries']) is not int or value['initial_clear_entries'] != 22):
        raise RuntimeError('Invalid native equalizer unused-key sweep')
    if 'allocated_slots' in value and (type(value['allocated_slots']) is not int or not 0 <= value['allocated_slots'] <= value['slot_capacity']):
        raise RuntimeError('Invalid native equalizer allocation count')
    result = dict(value)
    for bank,key in (('input','inputs'),('output','outputs')):
        channels = value.get(key)
        active = {port['native_channel']-1 for port in description['inputs' if bank=='input' else 'outputs_and_playbacks']}
        if (not isinstance(channels,list) or not channels
                or any(type(channel) is not int or not 0 <= channel <= 255 or channel not in active for channel in channels)
                or len(set(channels)) != len(channels)):
            raise RuntimeError('Invalid native equalizer coordinates')
        result[key] = frozenset(channels)
    ranges = value.get('ui_ranges')
    if not isinstance(ranges,dict):
        raise RuntimeError('Missing native equalizer ranges')
    for key in ('frequency_hz','lowcut_frequency_hz','gain_db','q'):
        bounds = ranges.get(key)
        if (not isinstance(bounds,dict)
                or any(type(bounds.get(field)) not in (int,float) or not math.isfinite(bounds[field])
                       for field in ('min','max','step'))
                or bounds['min'] > bounds['max'] or bounds['step'] <= 0):
            raise RuntimeError('Invalid native equalizer range')
    return result


def _range(value, key, cap):
    bounds = cap['ui_ranges'][key]
    if (type(value) not in (int,float) or not math.isfinite(value)
            or not bounds['min']-1e-7 <= value <= bounds['max']+1e-7
            or abs((value-bounds['min'])/bounds['step']-round((value-bounds['min'])/bounds['step'])) > 1e-5):
        raise RuntimeError('Equalizer parameter outside native descriptor')
    return value


def settings(fields, cap):
    if set(fields) != CONTROLS or any(type(value) is not int for value in fields.values()):
        raise RuntimeError('Incomplete native equalizer model')
    if any(fields[control] not in (0,1) for control in BOOLS) or not 0 <= fields[27] <= 3:
        raise RuntimeError('Invalid native equalizer switch')
    result = dict(enabled=bool(fields[28]),lowcut_enabled=bool(fields[25]),lowcut_slope=fields[27],
                  lowcut_frequency_hz=_range(fields[26],'lowcut_frequency_hz',cap),bands=[])
    for frequency,gain,q,shape in ((31,30,32,29),(34,33,35,None),(38,37,39,36)):
        result['bands'].append(dict(frequency_hz=_range(fields[frequency],'frequency_hz',cap),
            q=_range(fields[q]/10,'q',cap),gain_db=_range(fields[gain]/10,'gain_db',cap),
            shelf=bool(fields[shape]) if shape else False))
    return result


def fields(settings_value, cap):
    try:
        value = settings_value
        if (not isinstance(value,dict) or type(value['enabled']) is not bool
                or type(value['lowcut_enabled']) is not bool or type(value['lowcut_slope']) is not int
                or not isinstance(value['bands'],list) or len(value['bands']) != 3):
            raise RuntimeError('Invalid native equalizer model')
        result={25:int(value['lowcut_enabled']),26:round(value['lowcut_frequency_hz']),
                27:value['lowcut_slope'],28:int(value['enabled'])}
        if result[26] != value['lowcut_frequency_hz']:
            raise RuntimeError('Fractional native equalizer frequency')
        for band,frequency,gain,q,shape in zip(value['bands'],(31,34,38),(30,33,37),(32,35,39),(29,None,36)):
            if type(band['shelf']) is not bool or (shape is None and band['shelf']):
                raise RuntimeError('Invalid native equalizer band type')
            for target,key,scale in ((frequency,'frequency_hz',1),(gain,'gain_db',10),(q,'q',10)):
                if type(band[key]) not in (int,float) or not math.isfinite(band[key]):
                    raise RuntimeError('Invalid native equalizer parameter')
                result[target]=round(band[key]*scale)
                if abs(result[target]-band[key]*scale)>1e-5:
                    raise RuntimeError('Unsupported native equalizer precision')
            if shape:result[shape]=int(band['shelf'])
        settings(result,cap)
        return result
    except (KeyError,TypeError,ValueError,OverflowError) as error:
        raise RuntimeError('Invalid native equalizer model') from error


def profile_lines(description):
    cap=capability(description)
    if cap is None:return []
    initial=description.get('host_mixer_defaults',{})
    if (initial.get('provenance')!='host_template' or initial.get('reference_sha256')!=REFERENCE
            or initial.get('hardware_confirmed') is not False):
        raise RuntimeError('Missing native host equalizer template')
    defaults=fields(initial.get('equalizer'),cap)
    lines=[f'eq-slot-capacity\t{cap["slot_capacity"]}']
    lines.extend(f'eq-{bank}\t{channel}' for bank,key in (('input','inputs'),('output','outputs')) for channel in sorted(cap[key]))
    lines.extend(f'eq-default\t{control}\t{defaults[control]}' for control in sorted(CONTROLS))
    lines.extend(f"eq-range\t{key}\t{bounds['min']:g}\t{bounds['max']:g}\t{bounds['step']:g}"
                 for key,bounds in sorted(cap['ui_ranges'].items()) if key in ('frequency_hz','lowcut_frequency_hz','gain_db','q'))
    return lines


class Records:
    def __init__(self, description):
        self.cap=capability(description)
        self.pending={}
        self.initial={}
        self.initializing=self.cap is not None
        self.accepted={}

    def feed(self, kind, coordinate, units):
        if self.cap is None:raise RuntimeError('Native equalizer unavailable')
        channel=coordinate&255
        if kind in (11,12):
            bank='input' if kind==11 else 'output'
            control=(coordinate>>8)&255
            if control not in CONTROLS:raise RuntimeError('Invalid native equalizer field')
        else:
            bank_index=(coordinate>>8)&255
            if kind!=13 or bank_index not in (0,1) or units not in (0,1):
                raise RuntimeError('Invalid native equalizer commit')
            bank='input' if bank_index==0 else 'output'
        if channel not in self.cap['inputs' if bank=='input' else 'outputs']:
            raise RuntimeError('Unsupported native equalizer coordinate')
        key=(bank,channel)
        if kind in (11,12):
            staged=self.pending.setdefault(key,{})
            if control in staged:raise RuntimeError('Duplicate native equalizer field')
            staged[control]=units
            return None
        complete=self.pending.pop(key,{})
        command=dict(kind='equalizer',bank=bank,channel=channel,stereo=bool(units),settings=settings(complete,self.cap))
        if command['stereo'] and (channel^1) not in self.cap['inputs' if bank=='input' else 'outputs']:
            raise RuntimeError('Incomplete native equalizer stereo pair')
        if self.initializing:
            if key in self.initial:raise RuntimeError('Duplicate initial native equalizer')
            self.initial[key]=command
            return None
        if not self.cap['admitted']:raise RuntimeError('Native equalizer initialization incomplete')
        return command

    def initial_commands(self):
        expected={(bank,channel) for bank,key in (('input','inputs'),('output','outputs')) for channel in self.cap[key]}
        if self.pending or set(self.initial)!=expected:
            raise RuntimeError('Incomplete initial native equalizer coverage')
        active=sum(command['settings']['enabled'] or command['settings']['lowcut_enabled'] for command in self.initial.values())
        if active > self.cap['slot_capacity']:
            raise RuntimeError('Native equalizer slot capacity exceeded')
        for (bank,channel),command in self.initial.items():
            if command['stereo']:
                other=self.initial[bank,channel^1]
                if not other['stereo'] or other['settings']!=command['settings']:
                    raise RuntimeError('Incoherent initial native equalizer stereo pair')
        return [self.initial[key] for key in sorted(expected)]

    def initialized(self):
        self.accepted={(c["bank"],c["channel"]):copy.deepcopy(c) for c in self.initial_commands()}
        self.initial.clear()
        self.initializing=False
        self.cap['admitted']=True

    def validate_commands(self,commands):
        eq=[c for c in commands if c.get('kind')=='equalizer']
        if not eq:return
        if self.cap is None or self.initializing or not self.cap['admitted']:
            raise RuntimeError('Native equalizer initialization incomplete')
        proposed=dict(self.accepted)
        for c in eq:
            key=(c.get('bank'),c.get('channel'))
            if (key[0] not in ('input','output') or type(key[1]) is not int
                    or key[1] not in self.cap['inputs' if key[0]=='input' else 'outputs']
                    or type(c.get('stereo')) is not bool):raise RuntimeError('Invalid native equalizer coordinate')
            fields(c.get('settings'),self.cap)
            proposed[key]=c
            active=sum(v['settings']['enabled'] or v['settings']['lowcut_enabled'] for v in proposed.values())
            if active>self.cap['slot_capacity']:raise RuntimeError('Native equalizer slot capacity exceeded')

    def completed(self,commands):
        for command in commands:
            if command.get('kind')=='equalizer':self.accepted[command['bank'],command['channel']]=copy.deepcopy(command)

    def confirm(self,description,identity,commands):
        current=capability(description)
        stable=('inputs','outputs','sample_rate_hz','slot_capacity','ui_ranges')
        if (description.get('identity')!=identity or description.get('retired') is not False
                or current is None or current['admitted'] is not True
                or any(current[k]!=self.cap[k] for k in stable)
                or any(current.get(k)!=self.cap.get(k) for k in ('restore_transport','initial_clear_entries'))):
            raise RuntimeError('Native equalizer owner did not complete initialization')
        active=sum(c['settings']['enabled'] or c['settings']['lowcut_enabled'] for c in commands)
        if 'allocated_slots' in current and current['allocated_slots']!=active:
            raise RuntimeError('Native equalizer owner allocation does not match the restored intention')
        self.initialized()

    def feedback(self, command):
        base=0x1000 if command['bank']=='input' else 0x4000
        for control,value in sorted(fields(command['settings'],self.cap).items()):
            word=((base+control*256+command['channel'])<<16)|(value&65535)
            yield word|((1-word.bit_count()%2)<<31)
