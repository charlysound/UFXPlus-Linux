"""Control an existing OSCmix UI through the desktop session bus.

Return codes: 0 success, 1 no matching instance, 2 invalid/ambiguous request,
3 running instance refused the action. Never starts a driver or backend.
"""
import argparse
import hashlib
import re
import subprocess
import sys
import time

PREFIX = 'io.github.charlysound.Oscmix.Control.'
INTERFACE = 'io.github.charlysound.Oscmix.Window'
OBJECT = '/io/github/charlysound/Oscmix/Window'


def bus_name(mode, port=None):
    if mode == 'native-usb3':
        return PREFIX + 'native'
    return PREFIX + 'cc.p' + hashlib.sha256(port.encode()).hexdigest()[:24]


def call(destination, path, method):
    return subprocess.run(['/usr/bin/gdbus', 'call', '--session', '--timeout', '12',
                           '--dest', destination, '--object-path', path,
                           '--method', method], capture_output=True, text=True, timeout=14)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['show', 'minimize', 'quit', 'status', 'name', 'selection'])
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--native-usb3', action='store_true')
    modes.add_argument('--class-compliant', action='store_true')
    parser.add_argument('--cc-port')
    parser.add_argument('--wait', action='store_true')
    parser.add_argument('--uid')
    args = parser.parse_args(argv)
    if args.action=='selection':
        import json
        from pathlib import Path
        sys.path.insert(0,'/usr/lib/rme-native-host/settings')
        import selection_control
        print(json.dumps(selection_control.live(args.uid)));return 0
    if args.cc_port and (args.native_usb3 or not re.fullmatch(r'\d+:\d+', args.cc_port)):
        parser.error('Use --cc-port CLIENT:PORT with Class Compliant mode.')
    mode = 'native-usb3' if args.native_usb3 else 'class-compliant' if args.class_compliant or args.cc_port else None
    if args.action == 'name':
        if not mode or (mode == 'class-compliant' and not args.cc_port):
            parser.error('A transport and CC port, if applicable, are required.')
        print(bus_name(mode, args.cc_port))
        return 0
    deadline = time.monotonic() + (4 if args.wait else 0)
    while True:
        result = call('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus.ListNames')
        names = sorted(set(re.findall(r"'(" + re.escape(PREFIX) + r"[A-Za-z0-9_.]+)'", result.stdout)))
        if mode == 'native-usb3' or args.cc_port:
            names = [name for name in names if name == bus_name(mode, args.cc_port)]
        elif mode == 'class-compliant':
            names = [name for name in names if name.startswith(PREFIX + 'cc.')]
        if len(names) > 1:
            print('Multiple OSCmix sessions are open; select --native-usb3 or --cc-port CLIENT:PORT.', file=sys.stderr)
            return 2
        if names:
            if args.action == 'status':
                print('running')
                return 0
            result = call(names[0], OBJECT, INTERFACE + '.' + args.action.capitalize())
            if result.returncode == 0:
                return 0
            print(result.stderr.strip(), file=sys.stderr)
            return 3
        if time.monotonic() >= deadline:
            if args.action == 'status':
                print('stopped')
            return 1
        time.sleep(.1)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, subprocess.TimeoutExpired) as error:
        print(f'Window control unavailable: {error}', file=sys.stderr)
        raise SystemExit(3)
