"""Private FX bus contract, shared by scalar and sparse owner adapters.

Kinds40..42 and local SysEx90 are OSCmix IPC, never RME wire commands.
Native coordinates, domains, Full intentions and actual completions remain
owned by the Describe/Restore/Set contract bba8420.
"""
import copy

REFERENCE='75fff5c851e7156aebedf530e2c648d29edddcda26a66add5c985159fd711265'
BANKS=('input','playback','output')
FIELDS=('input_to_fx','playback_to_fx','fx_to_output')


def capability(description):
    cap=(description.get('capabilities') or {}).get('private_fx_matrix')
    if cap is None:return None
    if (not isinstance(cap,dict) or type(cap.get('schema')) is not int or cap['schema']!=1
            or cap.get('available') is not True or type(cap.get('initialized')) is not bool
            or type(cap.get('coordinate_base')) is not int or cap['coordinate_base']!=0
            or cap.get('sides')!=['left','right'] or type(cap.get('unit')) is not int or cap['unit']!=32768
            or type(cap.get('coefficient_min')) is not int or cap['coefficient_min']!=-131072
            or type(cap.get('coefficient_max')) is not int or cap['coefficient_max']!=131071
            or cap.get('restore_op') not in ('restore_fx_bus','restore_matrix') or cap.get('live_op')!='set_fx_bus'
            or cap.get('restoration_before_ready') is not True or cap.get('software_effects_admitted') is not False
            or cap.get('reference_sha256')!=REFERENCE):
        raise RuntimeError('Invalid native private FX capability')
    active,lengths=cap.get('active'),cap.get('required_lengths')
    geometry=description.get('mixer_geometry')
    if not isinstance(active,dict) or set(active)!=set(BANKS) or not isinstance(lengths,dict) or set(lengths)!=set(FIELDS) or not isinstance(geometry,dict):
        raise RuntimeError('Incomplete native private FX geometry')
    for bank,key,field in zip(BANKS,('input_slots','playback_slots','output_slots'),FIELDS):
        values=active[bank]
        if (type(geometry.get(key)) is not int or not 1<=geometry[key]<=256 or not isinstance(values,list) or not values
                or any(type(v) is not int or not 0<=v<geometry[key] for v in values)
                or len(set(values))!=len(values) or type(lengths[field]) is not int or lengths[field]!=2*len(values)):
            raise RuntimeError('Invalid native private FX active coordinates')
        # Port authority is physical native coordinates, never dense ordinal.
        ports=description.get('inputs' if bank=='input' else 'outputs_and_playbacks')
        if not isinstance(ports,list) or any(not isinstance(p,dict) or type(p.get('native_channel')) is not int for p in ports) or [p['native_channel']-1 for p in ports]!=values:
            raise RuntimeError('Private FX active ports disagree with the owner')
    send=cap.get('input_fx_send');ret=cap.get('output_fx_return')
    expected_send=dict(parameter='input_fx_send',native_parameter=11,banks=['input','playback'],scale=10,min=-3000,max=0,step=5,ui_min=-650,initial=-3000,hardware_readback=False)
    expected_return=dict(parameter='output_fx_return',native_parameter=3,banks=['output'],scale=10,min=-650,max=0,step=5,initial=-650,renderer='native_1000752a0',hardware_readback=False)
    if send!=expected_send or ret!=expected_return or any(type(actual.get(k)) is not int for actual,expected in ((send,expected_send),(ret,expected_return)) for k,v in expected.items() if type(v) is int):raise RuntimeError('Changed native private FX parameter domains')
    defaults=(description.get('host_mixer_defaults') or {}).get('private_fx')
    if (not isinstance(defaults,dict) or defaults.get('hardware_confirmed') is not False
            or defaults.get('provenance')!='native_full_descriptor_initials_1000f2b30_10023d0e0'
            or any(type(defaults.get(k)) is not int or defaults[k]!=v for k,v in
                   (('input_fx_send_db_tenths',-3000),('playback_fx_send_db_tenths',-3000),('output_fx_return_db_tenths',-650)))):
        raise RuntimeError('Unattributed native private FX Full intentions')
    matrix=defaults.get('matrix')
    if not isinstance(matrix,dict) or type(matrix.get('schema')) is not int or matrix['schema']!=1:
        raise RuntimeError('Missing native private FX Full matrix')
    for field in FIELDS:
        if not isinstance(matrix.get(field),list) or len(matrix[field])!=lengths[field] or any(type(v) is not int or v!=0 for v in matrix[field]):
            raise RuntimeError('Invalid native private FX Full matrix')
    return copy.deepcopy(cap)


def profile_lines(description):
    cap=capability(description)
    if cap is None:return []
    return ['private-fx\t1\t-3000\t-3000\t-650']+[
        f'private-fx-port\t{bank}\t{ch}' for bank in BANKS for ch in cap['active'][bank]]


class Records:
    def __init__(self,description):
        self.cap=capability(description);self.initial={};self.commands=[];self.initialized=False
        self.control_room=copy.deepcopy((description.get('capabilities') or {}).get('control_room'))
        if self.cap and self.cap['initialized']:raise RuntimeError('Private FX owner is already initialized')

    @property
    def count(self):return sum(self.cap['required_lengths'].values()) if self.cap else 0

    def accept(self,kind,coordinate,units):
        if self.cap is None:raise RuntimeError('Unadmitted private FX command')
        low,high=coordinate&255,(coordinate>>8)&255
        bank=BANKS[kind-40];channel,side=(high,low) if kind==42 else (low,high)
        if side not in (0,1) or channel not in self.cap['active'][bank] or type(units) is not int or not -131072<=units<=131071:
            raise RuntimeError('Invalid native private FX coefficient')
        key=(bank,channel,side)
        item=dict(kind='input_send' if kind==40 else 'playback_send' if kind==41 else 'output_return',side=('left','right')[side],units=units)
        item['output' if kind==42 else 'source']=channel
        if self.initialized:self.commands.append(item)
        else:self.initial[key]=units

    def matrix(self):
        if self.cap is None:return None
        if self.initialized or len(self.initial)!=self.count:raise RuntimeError('Incomplete or duplicate private FX opening')
        return dict(schema=1,**{field:[self.initial[(bank,ch,side)] for ch in self.cap['active'][bank] for side in (0,1)] for bank,field in zip(BANKS,FIELDS)})

    def confirm(self,description,identity):
        current=capability(description)
        if (current is None or description.get('identity')!=identity or description.get('retired') is not False
                or current['initialized'] is not True or dict(current,initialized=False)!=self.cap):
            raise RuntimeError('Native private FX restore was not confirmed by this owner')
        cr=(description.get('capabilities') or {}).get('control_room') or {}
        expected=dict(self.control_room or {},fx_return='admitted',external_input=True,talkback=True,listenback=True,talk_receive=True)
        if cr!=expected or any(cr.get(k) is not True for k in ('external_input','talkback','listenback','talk_receive')):
            raise RuntimeError('Native private FX Control Room admission incomplete')
        self.initialized=True;self.initial.clear()

    def completed(self,answer,identity,sequence,count,restoring=False):
        sparse=self.cap['restore_op']=='restore_matrix'
        if (not isinstance(answer,dict) or answer.get('error') or answer.get('identity',identity)!=identity
                or type(answer.get('sequence')) is not int or answer['sequence']!=sequence
                or answer.get('accepted_by_host') is not True or answer.get('hardware_confirmed') is not False
                or answer.get('session_retired') is not False or answer.get('state_complete') is not True
                or type(answer.get('commands_completed')) is not int or answer['commands_completed']!=count
                or any(type(answer.get(k)) is not int or answer[k]<0 for k in ('usb_completed','host_noops','maintenance_usb_completed'))
                or answer['host_noops']>count or answer['maintenance_usb_completed']!=(6 if restoring else 0)
                or (not sparse and answer['usb_completed']+answer['host_noops']!=count)
                or (sparse and answer['usb_completed']>2*count)):
            raise RuntimeError('Native private FX completion incomplete; no retry')
